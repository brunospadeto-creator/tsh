# Números complementares do artigo (análise adicional, só leitura dos caches)

`complementos.py`. Nenhum parâmetro do método é recalculado: as contagens vêm dos caches do `operacional.py`, as frações do `robustez/R1.pkl` e o recorte do Market da unidade e da calibração registradas do `robustez.py`.

## 1. Instantes por conjunto (`tab:bases`)

| conjunto | casos com instantes com causa | instantes normais | instantes com causa |
|---|---|---|---|
| RCAEval inédito | 474 | 2984 | 3204 |
| RCAEval com rastros | 239 | 1826 | 2130 |
| OpenRCA Market | 77 | 121 | 678 |
| TeaStore inédito | 17 | 85 | 85 |
| TeaStore definitiva | 24 | 120 | 120 |

## 2. Sorteios de baseline do R1 abaixo do critério (S5)

| conjunto | F1@1 < 0,6 | F1@2 < 0,7 | alarme > 20% |
|---|---|---|---|
| RCAEval inédito (HMR) | 45 de 500 (9.0%) | 61 de 500 (12.2%) | 0 de 500 (0.0%) |
| TeaStore inédito (HTS) | 1 de 500 (0.2%) | 3 de 500 (0.6%) | 101 de 500 (20.2%) |

## 3. OpenRCA Market sem os casos com falha anterior recente (S6)

Casos de falha: 77; com falha anterior a menos de 20 min: 23.

| recorte | casos | F1@1 HMR | AC@1 HMR | AC@1 BARO |
|---|---|---|---|---|
| todos | 77 | 0.428 | 0.649 | 0.221 |
| sem os contaminados | 54 | 0.406 | 0.593 | 0.167 |
