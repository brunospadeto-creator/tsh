# Cache da robustez

`robustez.py` (parte 1) lê estes arquivos em vez de recalcular os escores por instante.

- `u-<base>-120-600.pkl`: escores por instante na grade do artigo (janela de 120 s, referência de 600 s), para
  A = RCAEval inédito, C = RCAEval com rastros, M = OpenRCA Market e T = TeaStore. Bastam para todas as análises
  da robustez, menos a variação das constantes (R5).
- `R1.pkl` e `resultados.pkl`: resultados da reamostragem da baseline e das demais análises, como foram gravados;
  `gerar_figuras.py` lê o `resultados.pkl` para a figura da reamostragem.

Os caches das outras oito combinações de janela (60, 120 e 180 s) e referência (300, 600 e 900 s), usados só na R5,
ficaram fora do depósito para reduzir o tamanho (cerca de 0,9 GB). `robustez.py` os recalcula a partir dos dados
públicos e da parte 3 quando não os encontra. O resultado da R5 está em `resultado-robustez.md` (parte 1).
