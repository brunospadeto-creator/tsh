# TeaStore: registros derivados

Saídas dos scripts de `experimento-falhas/teastore/stage3-online/replay/` (parte 1), um `jsonl.gz` por cenário e
instante, com o relatório de cada protocolo.

| pasta | script | o que é |
|---|---|---|
| `protocolo-coleta-definitiva/` | `definitiva.py`, `definitiva_unificado.py` (`unificado/`), `definitiva_sem_k8s.py` | métodos de rastros nos 24 cenários da coleta definitiva |
| `protocolo-metricas-rz/def/` | `metricas_rz_teastore.py` | Híbrido de Métricas e Rastros na coleta definitiva |
| `protocolo-metricas-rz/b-ineditos/` | `metricas_rz_ineditos.py` | os 17 cenários inéditos (B′): método proposto e métodos de rastros |
| `protocolo-metricas-rz/k8s/` | `metricas_rz_k8s.py` | extensão com eventos do Kubernetes (Híbrido de Três Sinais) nos 41 cenários |
| `protocolo-metricas-rz/robustez/` | `robustez_cache_teastore.py` | cache por instante usado pela robustez (emenda 3) |

A telemetria bruta de que esses registros saem está na parte 3.
