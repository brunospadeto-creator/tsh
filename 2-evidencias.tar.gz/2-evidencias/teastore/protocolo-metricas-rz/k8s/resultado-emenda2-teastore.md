# Emenda 2 no TeaStore — método novo com eventos K8s, BARO/N-Sigma oficiais, AC@k e sensibilidade

`PROTOCOLO-COMPLETO.md` emenda 2 (E2.4). H-k1 e H-k2 confirmatórios; o resto descritivo.

## B′ (17 cenários, 170 instantes comuns)

Checagem: decisão e ranking do `g-m∨t|mf` recalculados × gravados — 0 diferenças. Instantes com sintoma K8s: 20. τ do g-m (FP 0,05) = 1.854.

| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|
| g-m∨t∨k|mfk | 0.710 [0.489–0.904] | 0.765 | 15.3% | 0% | 76% | 82% |
| g-m∨t|mfk | 0.710 [0.489–0.904] | 0.765 | 15.3% | 0% | 76% | 82% |
| g-m∨t∨k|mf | 0.601 [0.374–0.800] | 0.656 | 15.3% | 0% | 65% | 73% |
| g-m∨t|mf | 0.601 [0.374–0.800] | 0.656 | 15.3% | 0% | 65% | 73% |
| g-m∨t|BARO-janela | 0.273 [0.120–0.452] | 0.536 | 15.3% | 0% | 29% | 62% |
| g-m∨t|mf @FP0,01 | 0.601 [0.374–0.800] | 0.656 | 15.3% | 0% | 65% | 73% |
| g-m∨t|mf @FP0,10 | 0.598 [0.372–0.795] | 0.652 | 16.5% | 0% | 65% | 73% |
| g-m∨t∨k|mfk @FP0,01 | 0.710 [0.489–0.904] | 0.765 | 15.3% | 0% | 76% | 82% |
| g-m∨t∨k|mfk @FP0,10 | 0.707 [0.486–0.899] | 0.761 | 16.5% | 0% | 76% | 82% |
| d9-k+a | 0.959 [0.889–1.000] | 0.959 | 1.2% | 0% | 96% | 96% |
| d9-k | 0.921 [0.815–0.994] | 0.921 | 1.2% | 7% | 96% | 96% |
| v-cons-b | 0.885 [0.768–0.982] | 0.958 | 1.2% | 7% | 93% | 100% |
| d9+a | 0.842 [0.667–0.994] | 0.842 | 1.2% | 0% | 85% | 85% |
| d9 | 0.800 [0.610–0.940] | 0.800 | 1.2% | 7% | 85% | 85% |

Por caso (AC@k, serviço; 1º instante estável para os nossos, todo o pós-injeção para BARO/N-Sigma):

| método | casos | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|
| BARO (oficial) | 17 | 0.882 | 1.000 | 0.965 |
| N-Sigma (oficial) | 17 | 0.882 | 1.000 | 0.976 |
| g-m∨t|mf — 1º instante | 17 | 0.647 | 0.765 | 0.765 |
| g-m∨t∨k|mfk — 1º instante | 17 | 0.765 | 0.824 | 0.824 |

**H-k2 (B′, leitura fixada):** F1@1 0.710 (≥ 0,6: sim), F1@2 0.765 (≥ 0,7: sim), alarme 15.3% (≤ 20%: sim) → **CONFIRMA**.

## definitiva (24 cenários, 240 instantes comuns)

Checagem: decisão e ranking do `g-m∨t|mf` recalculados × gravados — 0 diferenças. Instantes com sintoma K8s: 30. τ do g-m (FP 0,05) = 2.692.

| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|
| g-m∨t∨k|mfk | 0.605 [0.407–0.794] | 0.782 | 6.7% | 0% | 62% | 83% |
| g-m∨t|mfk | 0.605 [0.407–0.794] | 0.782 | 6.7% | 0% | 62% | 83% |
| g-m∨t∨k|mf | 0.524 [0.325–0.714] | 0.702 | 6.7% | 0% | 54% | 75% |
| g-m∨t|mf | 0.524 [0.325–0.714] | 0.702 | 6.7% | 0% | 54% | 75% |
| g-m∨t|BARO-janela | 0.210 [0.104–0.317] | 0.395 | 6.7% | 0% | 22% | 54% |
| g-m∨t|mf @FP0,01 | 0.524 [0.325–0.714] | 0.702 | 6.7% | 0% | 54% | 75% |
| g-m∨t|mf @FP0,10 | 0.516 [0.321–0.698] | 0.690 | 10.0% | 0% | 54% | 75% |
| g-m∨t∨k|mfk @FP0,01 | 0.605 [0.407–0.794] | 0.782 | 6.7% | 0% | 62% | 83% |
| g-m∨t∨k|mfk @FP0,10 | 0.595 [0.402–0.775] | 0.770 | 10.0% | 0% | 62% | 83% |
| d9-k+a | 0.979 [0.942–1.000] | 0.979 | 0.8% | 0% | 98% | 98% |
| d9-k | 0.887 [0.777–0.970] | 0.887 | 0.8% | 17% | 98% | 98% |
| v-cons-b | 0.887 [0.780–0.962] | 0.905 | 0.8% | 17% | 98% | 100% |
| d9+a | 0.896 [0.772–0.996] | 0.896 | 0.8% | 0% | 90% | 90% |
| d9 | 0.739 [0.563–0.880] | 0.739 | 0.8% | 25% | 90% | 90% |

Por caso (AC@k, serviço; 1º instante estável para os nossos, todo o pós-injeção para BARO/N-Sigma):

| método | casos | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|
| BARO (oficial) | 24 | 0.833 | 0.958 | 0.933 |
| N-Sigma (oficial) | 24 | 0.875 | 1.000 | 0.958 |
| g-m∨t|mf — 1º instante | 24 | 0.542 | 0.750 | 0.742 |
| g-m∨t∨k|mfk — 1º instante | 24 | 0.625 | 0.833 | 0.792 |

## H-k1 — eventos K8s melhoram a descoberta (41 cenários, pareado)

ΔF1@1 (`g-m∨t∨k|mfk` − `g-m∨t|mf`) = +0.093 [IC 95% +0.023 a +0.187] → **CONFIRMA**.

- g-m∨t∨k|mfk × g-m∨t|mf: ΔF1@1 +0.093 [+0.023; +0.187]; McNemar só g-m∨t∨k|mfk 4, só g-m∨t|mf 0, p = 0.125
- g-m∨t∨k|mfk × d9-k+a: ΔF1@1 -0.321 [-0.468; -0.182]; McNemar só g-m∨t∨k|mfk 1, só d9-k+a 13, p = 0.002
- g-m∨t∨k|mfk × d9-k: ΔF1@1 -0.252 [-0.405; -0.103]; McNemar só g-m∨t∨k|mfk 4, só d9-k 11, p = 0.118
- d9-k × d9: ΔF1@1 +0.136 [+0.042; +0.249]; McNemar só d9-k 6, só d9 0, p = 0.031
- d9-k+a × d9+a: ΔF1@1 +0.097 [+0.024; +0.194]; McNemar só d9-k+a 4, só d9+a 0, p = 0.125
