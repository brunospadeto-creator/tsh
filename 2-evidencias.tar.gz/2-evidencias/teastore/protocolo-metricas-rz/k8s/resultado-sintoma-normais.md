# Alarme do canal de sintoma no TeaStore (análise adicional)

Saída de `replay/sintoma_normais.py --jobs 16`, rodado no depósito `deposito-g-m-t-k-20261021-d9ef611c` em 2026-10-23. A coluna do BARO fica vazia porque o BARO oficial é desligado nesta contagem.

Total: 41 cenários; 0 de 205 instantes normais com sintoma (Clopper–Pearson 95%: 0 a 1,78%); 50 de 205 instantes com causa com sintoma, em 10 cenários (limite de memória g3/g4 e falta de memória h2).

| conjunto | cenário | instantes | com sintoma K8s (normais / estáveis) | BARO devolveu |
|---|---|---|---|---|
| B′ | 20261013T051436Z/h3-auth-jvm-heap | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T061915Z/g1-auth-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T061915Z/g2-persistence-down | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T061915Z/g3-image-memory-limit | 10 | 0 / 5 | 0 serviços |
| B′ | 20261013T061915Z/g4-db-memory-limit | 10 | 0 / 5 | 0 serviços |
| B′ | 20261013T061915Z/g5-recommender-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T061915Z/g6-persistence-jvm-heap | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T143247Z/g1-auth-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T143247Z/g2-persistence-down | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T143247Z/g3-image-memory-limit | 10 | 0 / 5 | 0 serviços |
| B′ | 20261013T143247Z/g4-db-memory-limit | 10 | 0 / 5 | 0 serviços |
| B′ | 20261013T143247Z/g5-recommender-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| B′ | 20261013T143247Z/g6-persistence-jvm-heap | 10 | 0 / 0 | 0 serviços |
| B′ | 20261016T075241Z/h1-image-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| B′ | 20261016T075241Z/h3-auth-jvm-heap | 10 | 0 / 0 | 0 serviços |
| B′ | 20261016T075241Z/h4-db-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| B′ | 20261016T075241Z/h5-image-registry-misconfig | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T002739Z/h1-image-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T002739Z/h2-recommender-oom | 10 | 0 / 5 | 0 serviços |
| definitiva | 20261016T002739Z/h3-auth-jvm-heap | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T002739Z/h4-db-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T002739Z/h5-image-registry-misconfig | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T002739Z/h6-recommender-down | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T151716Z/h1-image-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T151716Z/h2-recommender-oom | 10 | 0 / 5 | 0 serviços |
| definitiva | 20261016T151716Z/h3-auth-jvm-heap | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T151716Z/h4-db-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T151716Z/h5-image-registry-misconfig | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T151716Z/h6-recommender-down | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T223053Z/g1-auth-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T223053Z/g2-persistence-down | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T223053Z/g3-image-memory-limit | 10 | 0 / 5 | 0 serviços |
| definitiva | 20261016T223053Z/g4-db-memory-limit | 10 | 0 / 5 | 0 serviços |
| definitiva | 20261016T223053Z/g5-recommender-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261016T223053Z/g6-persistence-jvm-heap | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261017T050131Z/g1-auth-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261017T050131Z/g2-persistence-down | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261017T050131Z/g3-image-memory-limit | 10 | 0 / 5 | 0 serviços |
| definitiva | 20261017T050131Z/g4-db-memory-limit | 10 | 0 / 5 | 0 serviços |
| definitiva | 20261017T050131Z/g5-recommender-cpu-throttle | 10 | 0 / 0 | 0 serviços |
| definitiva | 20261017T050131Z/g6-persistence-jvm-heap | 10 | 0 / 0 | 0 serviços |
