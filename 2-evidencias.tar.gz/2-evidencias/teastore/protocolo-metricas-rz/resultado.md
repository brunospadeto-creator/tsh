# `g-m∨t|mf` sem mudança — TeaStore definitiva (teste de 10 min, exploratório)

`replay/metricas_rz_teastore.py`. Mesmo código do RCAEval; só o adaptador de métricas é daqui. Baseline das métricas = trecho de cada sessão antes do período normal medido (desvio declarado: a coleção 32c273a6 não tem série de métricas). Instantes e portão de traces do `baseline_dinamica.py`.

Janelas de baseline das métricas: 197; τ do g-m = 2.692; famílias com N: 6 de 7.

## Definitiva (24 cenários, 240 instantes)

| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|
| d9-k | 0.887 [0.777–0.970] | 0.887 | 0.8% | 17% | 98% | 98% |
| v-cons-b | 0.887 [0.780–0.962] | 0.905 | 0.8% | 17% | 98% | 100% |
| d9-k+a | 0.979 [0.942–1.000] | 0.979 | 0.8% | 0% | 98% | 98% |
| d9 | 0.739 [0.563–0.880] | 0.739 | 0.8% | 25% | 90% | 90% |
| d9-k-b+c@0.01 | 0.944 [0.900–0.976] | 0.952 | 6.7% | 0% | 98% | 98% |
| d9-b+c@0.01 | 0.863 [0.742–0.956] | 0.871 | 6.7% | 0% | 90% | 90% |
| m-rzf | 0.361 [0.222–0.500] | 0.483 | 100.0% | 0% | 54% | 72% |
| g-m|mf | 0.565 [0.356–0.756] | 0.757 | 0.0% | 8% | 54% | 72% |
| g-m∨t|mf | 0.524 [0.325–0.714] | 0.702 | 6.7% | 0% | 54% | 72% |
| g-m∧t|mf | 0.565 [0.356–0.756] | 0.757 | 0.0% | 8% | 54% | 72% |

- McNemar g-m∨t|mf × d9-k (top-1 com portão): só g-m∨t|mf 2, só d9-k 9, p = 0.065
- McNemar g-m∨t|mf × d9-k+a (top-1 com portão): só g-m∨t|mf 0, só d9-k+a 11, p = 0.001
- McNemar g-m∨t|mf × d9-b+c@0.01 (top-1 com portão): só g-m∨t|mf 0, só d9-b+c@0.01 9, p = 0.004
