# Parte B′ — TeaStore, 17 cenários gravados nunca vistos pelo `g-m∨t|mf` (confirmatório)

`PROTOCOLO-COMPLETO.md` emenda 1; `replay/metricas_rz_ineditos.py`. 13 do dev com pacotes de métricas (baseline 547ba505) + 4 da tentativa abortada do C2 (32c273a6). Executores em modo confirmatório (D0.4 na hora); só os instantes comuns a todos os modos.

Instantes: 170 (85 normais). Janelas de baseline das métricas: 144; τ do g-m = 1.854; famílias com N: 6 de 7.

| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|
| g-m∨t|mf | 0.601 [0.374–0.800] | 0.656 | 15.3% | 0% | 65% | 71% |
| g-m|mf | 0.647 [0.412–0.824] | 0.706 | 0.0% | 0% | 65% | 71% |
| d9-b+c@0.01|mf | 0.601 [0.374–0.800] | 0.656 | 15.3% | 0% | 65% | 71% |
| m-rzf | 0.431 [0.275–0.549] | 0.471 | 100.0% | 0% | 65% | 71% |
| d9-k | 0.921 [0.815–0.994] | 0.921 | 1.2% | 7% | 96% | 96% |
| d9-k+a | 0.959 [0.889–1.000] | 0.959 | 1.2% | 0% | 96% | 96% |
| v-cons-b | 0.885 [0.768–0.982] | 0.958 | 1.2% | 7% | 93% | 100% |
| d2c-r | 0.752 [0.550–0.921] | 0.752 | 0.0% | 6% | 73% | 73% |
| d9 | 0.800 [0.610–0.940] | 0.800 | 1.2% | 7% | 85% | 85% |
| d9-k-b+c@0.01 | 0.896 [0.822–0.960] | 0.896 | 15.3% | 0% | 96% | 96% |
| d9-b+c@0.01 | 0.787 [0.628–0.919] | 0.787 | 15.3% | 0% | 85% | 85% |

**Leitura fixada (§6):** F1@1 0.601 (≥ 0,6: sim), F1@2 0.656 (≥ 0,7: não), alarme 15.3% (≤ 20%: sim) → **NÃO CONFIRMA**.

- McNemar g-m∨t|mf × d9-k (top-1 com portão): só g-m∨t|mf 2, só d9-k 6, p = 0.289
- McNemar g-m∨t|mf × d9-k+a (top-1 com portão): só g-m∨t|mf 1, só d9-k+a 6, p = 0.125
- McNemar g-m∨t|mf × v-cons-b (top-1 com portão): só g-m∨t|mf 1, só v-cons-b 4, p = 0.375
- McNemar g-m∨t|mf × d2c-r (top-1 com portão): só g-m∨t|mf 1, só d2c-r 2, p = 1.000
- McNemar g-m∨t|mf × d9 (top-1 com portão): só g-m∨t|mf 2, só d9 4, p = 0.688

## Por grupo (descritivo)

### h (5 cenários)

| modo | F1@1 | F1@2 | alarme | sabendo top-1 |
|---|---|---|---|---|
| g-m∨t|mf | 0.784 | 0.980 | 4.0% | 80% |
| g-m|mf | 0.800 | 1.000 | 0.0% | 80% |
| d9-b+c@0.01|mf | 0.784 | 0.980 | 4.0% | 80% |
| m-rzf | 0.533 | 0.667 | 100.0% | 80% |
| d9-k | 0.880 | 0.880 | 0.0% | 88% |
| d9-k+a | 0.880 | 0.880 | 0.0% | 88% |
| v-cons-b | 1.000 | 1.000 | 0.0% | 100% |
| d2c-r | 0.800 | 0.800 | 0.0% | 80% |
| d9 | 0.880 | 0.880 | 0.0% | 88% |
| d9-k-b+c@0.01 | 0.863 | 0.863 | 4.0% | 88% |
| d9-b+c@0.01 | 0.863 | 0.863 | 4.0% | 88% |

### g (12 cenários)

| modo | F1@1 | F1@2 | alarme | sabendo top-1 |
|---|---|---|---|---|
| g-m∨t|mf | 0.530 | 0.530 | 20.0% | 58% |
| g-m|mf | 0.583 | 0.583 | 0.0% | 58% |
| d9-b+c@0.01|mf | 0.530 | 0.530 | 20.0% | 58% |
| m-rzf | 0.389 | 0.389 | 100.0% | 58% |
| d9-k | 0.939 | 0.939 | 1.7% | 100% |
| d9-k+a | 0.992 | 0.992 | 1.7% | 100% |
| v-cons-b | 0.835 | 0.939 | 1.7% | 90% |
| d2c-r | 0.730 | 0.730 | 0.0% | 70% |
| d9 | 0.765 | 0.765 | 1.7% | 83% |
| d9-k-b+c@0.01 | 0.909 | 0.909 | 20.0% | 100% |
| d9-b+c@0.01 | 0.758 | 0.758 | 20.0% | 83% |

