# Coleta definitiva — ablação do canal K8s (§42.87, secundário)

24 cenários, mesmos instantes e medida do `definitiva.py`; única troca: nenhum evento K8s na entrada (`_k8s_limpo` → []). Nada ajustado.

| modo | F1@1 [IC 95%] | F1@2 | F1@3 | F1@1 h | F1@1 g | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 |
|---|---|---|---|---|---|---|---|---|---|---|
| d9-k com K8s | 0.887 [0.777–0.970] | 0.887 | 0.887 | 0.865 | 0.909 | 0.8% | 17% | 98% [95%–100%] | 98% | 98% |
| **d9-k sem K8s** | 0.739 [0.563–0.880] | 0.739 | 0.739 | 0.752 | 0.727 | 0.8% | 25% | 90% [78%–100%] | 90% | 90% |
| v-cons-b com K8s | 0.887 [0.780–0.962] | 0.905 | 0.905 | 0.883 | 0.891 | 0.8% | 17% | 98% [96%–100%] | 100% | 100% |
| **v-cons-b sem K8s** | 0.749 [0.574–0.885] | 0.758 | 0.758 | 0.772 | 0.727 | 0.8% | 25% | 91% [78%–100%] | 92% | 92% |
| v-cons-b-1 com K8s | 0.878 [0.770–0.957] | 0.896 | 0.896 | 0.865 | 0.891 | 0.8% | 17% | 98% [93%–100%] | 99% | 99% |
| **v-cons-b-1 sem K8s** | 0.739 [0.563–0.880] | 0.749 | 0.749 | 0.752 | 0.727 | 0.8% | 25% | 90% [78%–100%] | 91% | 91% |
| d9 (não usa K8s) | 0.739 [0.563–0.880] | 0.739 | 0.739 | 0.752 | 0.727 | 0.8% | 25% | 90% [78%–100%] | 90% | 90% |

## d9-k sem K8s × d9, instante a instante

- instantes comparados: 240
- decisão (decidiu × absteve) diferente: 0
- 1º serviço diferente quando os dois decidem: 0
- ranking forçado diferente: top-1 0, top-3 0
- d9 desta rodada = d9 da rodada com K8s (ranking e forçado): 240/240

## McNemar exato pareado (acerto majoritário por cenário)

- d9-k com × sem K8s (top-1 com portão): só o 1º 4, só o 2º 0, p = 0.125
- d9-k sem K8s × d9 (top-1 com portão): só o 1º 0, só o 2º 0, p = 1.000
- v-cons-b com × sem K8s (top-3 sabendo): só o 1º 2, só o 2º 0, p = 0.500
- v-cons-b × d9-k, ambos sem K8s (top-3 sabendo): só o 1º 0, só o 2º 0, p = 1.000

## Por cenário (top-1 com portão; top-3 sabendo do v-cons-b)

| cenário | esperado | d9-k com | d9-k sem | d9 | v-cons-b o3 com | v-cons-b o3 sem |
|---|---|---|---|---|---|---|
| 20261016T002739Z/h1-image-cpu-throttle | image | 3/5 | 3/5 | 3/5 | 5/5 | 5/5 |
| 20261016T002739Z/h2-recommender-oom | recommender | 5/5 | 0/5 | 0/5 | 5/5 | 5/5 |
| 20261016T002739Z/h3-auth-jvm-heap | auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h4-db-cpu-throttle | db | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h5-image-registry-misconfig | image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h6-recommender-down | recommender | 0/5 | 0/5 | 0/5 | 5/5 | 5/5 |
| 20261016T151716Z/h1-image-cpu-throttle | image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h2-recommender-oom | recommender | 5/5 | 0/5 | 0/5 | 5/5 | 5/5 |
| 20261016T151716Z/h3-auth-jvm-heap | auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h4-db-cpu-throttle | db | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h5-image-registry-misconfig | image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h6-recommender-down | recommender | 0/5 | 0/5 | 0/5 | 5/5 | 5/5 |
| 20261016T223053Z/g1-auth-cpu-throttle | auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g2-persistence-down | persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g3-image-memory-limit | image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g4-db-memory-limit | db | 5/5 | 0/5 | 0/5 | 5/5 | 0/5 |
| 20261016T223053Z/g5-recommender-cpu-throttle | recommender | 0/5 | 0/5 | 0/5 | 5/5 | 5/5 |
| 20261016T223053Z/g6-persistence-jvm-heap | persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g1-auth-cpu-throttle | auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g2-persistence-down | persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g3-image-memory-limit | image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g4-db-memory-limit | db | 5/5 | 0/5 | 0/5 | 5/5 | 0/5 |
| 20261017T050131Z/g5-recommender-cpu-throttle | recommender | 0/5 | 0/5 | 0/5 | 5/5 | 5/5 |
| 20261017T050131Z/g6-persistence-jvm-heap | persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
