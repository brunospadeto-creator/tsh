# Coleta definitiva — resultado (PROTOCOLO-COLETA-DEFINITIVA.md)

24 cenários (12 h, 12 g), lotes C1=20261016T002739Z, C2=20261016T151716Z, C3=20261016T223053Z, C4=20261017T050131Z. Nada ajustado.

## Grupo: todos

| modo | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 [IC 95%] |
|---|---|---|---|---|---|---|---|---|
| d9-k | 0.887 [0.777–0.970] | 0.887 | 0.887 | 0.8% | 17% | 98% [95%–100%] | 98% | 98% [95%–100%] |
| v-cons-b (n = 5, avaliado) | 0.887 [0.780–0.962] | 0.905 | 0.905 | 0.8% | 17% | 98% [96%–100%] | 100% | 100% [100%–100%] |
| v-cons-b disparo único (produto) | 0.878 [0.770–0.957] | 0.896 | 0.896 | 0.8% | 17% | 98% [93%–100%] | 99% | 99% [98%–100%] |
| d9 (referência) | 0.739 [0.563–0.880] | 0.739 | 0.739 | 0.8% | 25% | 90% [78%–100%] | 90% | 90% [78%–100%] |

## Grupo: h

| modo | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 [IC 95%] |
|---|---|---|---|---|---|---|---|---|
| d9-k | 0.865 [0.695–0.976] | 0.865 | 0.865 | 1.7% | 17% | 97% [90%–100%] | 97% | 97% [90%–100%] |
| v-cons-b (n = 5, avaliado) | 0.883 [0.716–0.983] | 0.901 | 0.901 | 1.7% | 17% | 98% [95%–100%] | 100% | 100% [100%–100%] |
| v-cons-b disparo único (produto) | 0.865 [0.695–0.976] | 0.883 | 0.883 | 1.7% | 17% | 97% [90%–100%] | 98% | 98% [95%–100%] |
| d9 (referência) | 0.752 [0.522–0.922] | 0.752 | 0.752 | 1.7% | 33% | 97% [90%–100%] | 97% | 97% [90%–100%] |

## Grupo: g

| modo | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 [IC 95%] |
|---|---|---|---|---|---|---|---|---|
| d9-k | 0.909 [0.737–1.000] | 0.909 | 0.909 | 0.0% | 17% | 100% [100%–100%] | 100% | 100% [100%–100%] |
| v-cons-b (n = 5, avaliado) | 0.891 [0.716–1.000] | 0.909 | 0.909 | 0.0% | 17% | 98% [95%–100%] | 100% | 100% [100%–100%] |
| v-cons-b disparo único (produto) | 0.891 [0.716–1.000] | 0.909 | 0.909 | 0.0% | 17% | 98% [95%–100%] | 100% | 100% [100%–100%] |
| d9 (referência) | 0.727 [0.455–0.957] | 0.727 | 0.727 | 0.0% | 17% | 83% [58%–100%] | 83% | 83% [58%–100%] |

## McNemar exato pareado (acerto majoritário por cenário)

- d9-k × d9, top-1 com portão: só d9-k 4, só d9 (referência) 0, p = 0.125
- v-cons-b × d9-k, top-3 sabendo: só v-cons-b (n = 5, avaliado) 0, só d9-k 0, p = 1.000

## Por cenário (top-1 com portão / top-1 e top-3 sabendo)

| cenário | esperado | d9-k tp1 | d9 tp1 | v-cons-b o1 | v-cons-b o3 | d9-k o3 |
|---|---|---|---|---|---|---|
| 20261016T002739Z/h1-image-cpu-throttle | teastore-image | 3/5 | 3/5 | 4/5 | 5/5 | 3/5 |
| 20261016T002739Z/h2-recommender-oom | teastore-recommender | 5/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h3-auth-jvm-heap | teastore-auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h4-db-cpu-throttle | teastore-db | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h5-image-registry-misconfig | teastore-image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T002739Z/h6-recommender-down | teastore-recommender | 0/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h1-image-cpu-throttle | teastore-image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h2-recommender-oom | teastore-recommender | 5/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h3-auth-jvm-heap | teastore-auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h4-db-cpu-throttle | teastore-db | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h5-image-registry-misconfig | teastore-image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T151716Z/h6-recommender-down | teastore-recommender | 0/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g1-auth-cpu-throttle | teastore-auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g2-persistence-down | teastore-persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g3-image-memory-limit | teastore-image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g4-db-memory-limit | teastore-db | 5/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g5-recommender-cpu-throttle | teastore-recommender | 0/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261016T223053Z/g6-persistence-jvm-heap | teastore-persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g1-auth-cpu-throttle | teastore-auth | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g2-persistence-down | teastore-persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g3-image-memory-limit | teastore-image | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g4-db-memory-limit | teastore-db | 5/5 | 0/5 | 4/5 | 5/5 | 5/5 |
| 20261017T050131Z/g5-recommender-cpu-throttle | teastore-recommender | 0/5 | 0/5 | 5/5 | 5/5 | 5/5 |
| 20261017T050131Z/g6-persistence-jvm-heap | teastore-persistence | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |

## Leitura (§6, fixada antes)

- d9-k: F1@1 0.887 × d9 0.739; alarme 0.8% → **confirma**.
- v-cons-b: top-3 sabendo 100% (≥ 80%); top-1 sabendo 98% × d9 90% → **confirma**. (Secundário: top-3 × d9-k 98%.)
