# Correspondência entre os nomes do artigo e os códigos do experimento

O artigo usa só os nomes por extenso. Os códigos continuam valendo nos documentos do experimento
(`bases-externas/`, `PROTOCOLO-COMPLETO.md`, relatórios de resultado e scripts).

## Métodos

| nome no artigo | nome em inglês (proposta) | código | o que é |
|---|---|---|---|
| **Híbrido de Três Sinais** (método proposto) | Three-Signal Hybrid | `g-m∨t∨k\|mfk` | Portão de Métricas **ou** Portão de Rastros **ou** Portão de Sintoma; ranking pelo Escore de Desvio por Família, com o serviço com sintoma promovido ao 1º lugar |
| **Híbrido de Métricas e Rastros** | Metrics-and-Traces Hybrid | `g-m∨t\|mf` | o mesmo, sem os eventos do orquestrador |
| Contraste da Sessão | Session Contrast | `d9` | portão por razão de mediana e erro contra a janela anterior da sessão; ranking pelo resíduo no grafo |
| Contraste da Sessão com Orquestrador | Session Contrast with Orchestrator | `d9-k` | Contraste da Sessão + eventos de sintoma do Kubernetes (abre o portão e promove o serviço) |
| Contraste com Reserva | Session Contrast with Fallback | `d9+a` | Contraste da Sessão; quando ele se abstém, Nulo Rolante Adaptativo |
| Contraste com Orquestrador e Reserva | Session Contrast with Orchestrator and Fallback | `d9-k+a` | Contraste da Sessão com Orquestrador; quando ele se abstém, Nulo Rolante Adaptativo |
| Teste Exato contra Baseline | Exact Test against Baseline | `d2c` | testes de Fisher + Benjamini–Hochberg com a nula de outro dia |
| Nulo Rolante | Rolling Null | `d2c-r` | o mesmo, com a nula na janela anterior da sessão (q = 1e-50) |
| Nulo Rolante Adaptativo | Adaptive Rolling Null | `d2c-a` | Nulo Rolante com q = 1e-3 × menor p_min das janelas anteriores da sessão |
| Contraste Calibrado | Calibrated Session Contrast | `d9-b` | Contraste da Sessão com λ calculado pela baseline |
| Nulo Rolante Calibrado | Calibrated Rolling Null | `d2c-b` | Nulo Rolante com q = quantil do p_min na baseline |
| Consenso de Detectores | Detector Consensus | `v-cons-b` | consenso por Borda ponderada de três detectores (não entra no artigo) |
| BARO, N-Sigma | BARO, N-Sigma | `baro`, `nsigma` | nomes publicados, mantidos |

## Siglas usadas no artigo (Tabela `tab:siglas`, a partir da Seção 5.2)

HTS = Híbrido de Três Sinais; HMR = Híbrido de Métricas e Rastros; CS = Contraste da Sessão; CSO = Contraste da Sessão
com Orquestrador; CR = Contraste com Reserva; COR = Contraste com Orquestrador e Reserva; NR = Nulo Rolante. O resumo, a
introdução, a Seção 4, a conclusão e o Apêndice A usam os nomes por extenso.

## Peças do método

| nome no artigo | nome em inglês (proposta) | código | o que é |
|---|---|---|---|
| Portão de Métricas | Metrics Gate | `g-m` | abre se o maior escore de serviço ≥ τ (τ pela baseline, FP 0,05) |
| Portão de Rastros | Traces Gate | `t` = `d9-b+c@0.01` | Contraste Calibrado; se abstém, Nulo Rolante Calibrado (FP 0,01) |
| Portão de Sintoma | Symptom Gate | `k` | evento BackOff/OOMKilled/Unhealthy/Evicted (`d9k.servico_k8s`) |
| Escore de Desvio por Família | Family-wise Deviation Score | `m-rzf` (`mf`) | desvio robusto, escala log, normalizado pela baseline por família, com reserva por família |
| Escore de Desvio por Família com Promoção | Family-wise Deviation Score with Promotion | `mfk` | o mesmo, com o serviço com sintoma em 1º (`d9k._promover`) |
| Escore BARO na Janela | Windowed BARO Score | `BARO-janela` | escalonamento robusto do BARO no lugar do Escore de Desvio por Família, mesmo portão |
| Escore N-Sigma na Janela | Windowed N-Sigma Score | `N-Sigma-janela` | escalonamento padronizado do N-Sigma (média e desvio) no lugar do Escore de Desvio por Família, mesmo portão (`operacional.py`) |
| Portão de Métricas sozinho | Metrics Gate alone | `g-m\|mf` | ablação: só o Portão de Métricas |
| meta de falso positivo, $\mathrm{FP}_{\mathrm{alvo}}$ | false-positive target | `FP_ALVO` | única constante de política |

## Iterações do ciclo de melhoria (RCAEval)

| nome no artigo | nome em inglês (proposta) | código |
|---|---|---|
| Desvio Bruto | Raw Deviation | `m-rz` (iteração 1) |
| Desvio Normalizado pela Baseline | Baseline-normalized Deviation | `m-rzb` (iteração 2) |
| Desvio com Resíduo no Grafo | Graph-residual Deviation | `m-rzg` (iteração 3) |
| Desvio em Escala Log | Log-scale Deviation | `m-rzl` (ablação da iteração 3) |
| Fusão por Borda | Borda Fusion | `f-borda` / `…\|fb` (iteração 4) |
| Fusão por Concordância | Agreement Fusion | `f-conc` / `…\|fc` (iteração 4) |
| Escore de Desvio por Família + Portão de Métricas | Family-wise Deviation Score | `m-rzf` + `g-m` (iteração 5) |
| Máximo de CPU | CPU Maximum | `cpu-max` (comparador do confirmatório RCAEval) |

## Conjuntos e partes do protocolo

| nome no artigo | nome em inglês (proposta) | código |
|---|---|---|
| Confirmatório RCAEval (480 casos inéditos, só métricas) |  | parte A |
| Confirmatório TeaStore (17 cenários inéditos) |  | parte B′ |
| TeaStore inédito |  | B′ |
| TeaStore, coleta definitiva |  | definitiva (coleção 32c273a6) |
| Descritivo |  | parte C |
| Hipótese do ganho do orquestrador |  | H-k1 |
| Hipótese da meta com orquestrador |  | H-k2 |
| grupo de desenvolvimento / grupo de validação (TeaStore) |  | famílias `h` / `g` |

## Conclusões testadas na robustez

| nome no artigo | nome em inglês (proposta) | código |
|---|---|---|
| Meta no RCAEval inédito |  | K-A |
| Meta no TeaStore inédito com orquestrador |  | K-B |
| Ganho do orquestrador |  | K-k1 |
| Superioridade no RCAEval com rastros |  | K-RC |
| Superioridade no Market |  | K-M |

## Testes de robustez

| nome no artigo | nome em inglês (proposta) | código |
|---|---|---|
| Sorteio de baseline |  | R1 |
| Bootstrap de casos |  | R2 |
| Permutação pareada |  | R3 |
| Placebo do orquestrador |  | R4 |
| Grade de constantes |  | R5 |
| Retirada de grupo |  | R6 |
| Divisões dev/holdout |  | R7 |
| Comparação com o acaso |  | R8 |
