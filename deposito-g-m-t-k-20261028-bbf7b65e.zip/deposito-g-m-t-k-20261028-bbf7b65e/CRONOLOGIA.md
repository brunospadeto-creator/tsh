# Cronologia do registro

Gerada por `montar.sh` a partir do repositório do autor (privado). As datas dos commits são declaradas pelo
autor; os hashes permitem conferir que os arquivos deste pacote são os registrados.

## Commits do protocolo, das emendas e das análises

| commit | data (UTC-4) | assunto |
|---|---|---|
| `6ca30930fb331cd2e02effcb37fdbadaee9b424c` | 2026-10-18T21:05:05-04:00 | prereg(metricas-rz): protocolo completo do g-m∨t|mf -- A: RCAEval inédito só métricas (RE1-OB/SS/TT, RE2-SS, RE3-SS; 480 casos), B: TeaStore lote novo (24 cenários, sementes 20261041-44, driver run-metricas-rz-lotes.sh), C: descritivos (RCAEval com traces, Market, definitiva); Eadro fora |
| `8af3e35bf9555f272ddc3ad1633ceabab01061ff` | 2026-10-18T21:17:17-04:00 | prereg(metricas-rz): emenda 1 -- sem coleta nova; B' = 17 cenários gravados nunca vistos pelo g-m∨t|mf (13 dev com pacotes + 4 da tentativa abortada do C2), bateria completa de comparadores e ablação; antes de executar B |
| `8d83f022155d7595bae3ecf395addfb2efba6675` | 2026-10-18T21:30:26-04:00 | exp(metricas-rz): protocolo completo -- A (RCAEval inédito, 480 casos) CONFIRMA 0.614/0.704/6.6%; B' (TeaStore, 17 inéditos) NÃO CONFIRMA 0.601/0.656/15.3% (d9-k+a 0.959); C descritivos com ablação |
| `c6022f76ea6e68642f9503384fc9a3c059d74c73` | 2026-10-18T21:32:36-04:00 | prereg(metricas-rz): emenda 2 -- BARO/N-Sigma oficiais (RCAEval 1.8.0), AC@1/AC@3/Avg@5, BARO-janela, sensibilidade FP, e método novo g-m∨t∨k|mfk (eventos K8s) com H-k1 (K8s melhora: ΔF1@1 IC>0 em 41 cenários) e H-k2 (meta em B'); antes de rodar |
| `599430e07e48aa6bf1b2e8ea0414f9a928e865df` | 2026-10-18T21:44:12-04:00 | prereg(metricas-rz): emenda 3 -- robustez estatística (R1 baseline 500x, R2 bootstrap 10k, R3 permutação 10k x12 com Holm, R4 placebo K8s 10k, R5 grade de constantes, R6 deixa-um-grupo-fora, R7 1000 divisões, R8 acaso 10k); teto 9 h; antes de rodar |
| `914591b0a33614c2e7175d1490e429eea134d42f` | 2026-10-19T12:39:16-04:00 | fix(bases-externas): tira a cópia multi-source-data do RCAEval, recalcula C e robustez; auditoria do BARO, escada do escore, N-Sigma e revisão do código |
| `bd02bb0cf7ded77330018ec2dc36f02d1044ed6f` | 2026-10-20T07:19:51-04:00 | docs(artigo): CIRCA e RCD oficiais nos mesmos casos (analise adicional, fora do protocolo) |
| `5c89e6c2aef672971d25c9661e4aeea0ada39b79` | 2026-10-20T09:48:23-04:00 | docs(artigo): MicroRank e TraceRCA oficiais nos mesmos casos com rastros; afirmacao restrita |

## Histórico do PROTOCOLO-COMPLETO.md

- `599430e0` 2026-10-18T21:44:12-04:00 prereg(metricas-rz): emenda 3 -- robustez estatística (R1 baseline 500x, R2 bootstrap 10k, R3 permutação 10k x12 com Holm, R4 placebo K8s 10k, R5 grade de constantes, R6 deixa-um-grupo-fora, R7 1000 divisões, R8 acaso 10k); teto 9 h; antes de rodar
- `c6022f76` 2026-10-18T21:32:36-04:00 prereg(metricas-rz): emenda 2 -- BARO/N-Sigma oficiais (RCAEval 1.8.0), AC@1/AC@3/Avg@5, BARO-janela, sensibilidade FP, e método novo g-m∨t∨k|mfk (eventos K8s) com H-k1 (K8s melhora: ΔF1@1 IC>0 em 41 cenários) e H-k2 (meta em B'); antes de rodar
- `8d83f022` 2026-10-18T21:30:26-04:00 exp(metricas-rz): protocolo completo -- A (RCAEval inédito, 480 casos) CONFIRMA 0.614/0.704/6.6%; B' (TeaStore, 17 inéditos) NÃO CONFIRMA 0.601/0.656/15.3% (d9-k+a 0.959); C descritivos com ablação
- `8af3e35b` 2026-10-18T21:17:17-04:00 prereg(metricas-rz): emenda 1 -- sem coleta nova; B' = 17 cenários gravados nunca vistos pelo g-m∨t|mf (13 dev com pacotes + 4 da tentativa abortada do C2), bateria completa de comparadores e ablação; antes de executar B
- `6ca30930` 2026-10-18T21:05:05-04:00 prereg(metricas-rz): protocolo completo do g-m∨t|mf -- A: RCAEval inédito só métricas (RE1-OB/SS/TT, RE2-SS, RE3-SS; 480 casos), B: TeaStore lote novo (24 cenários, sementes 20261041-44, driver run-metricas-rz-lotes.sh), C: descritivos (RCAEval com traces

## Código congelado: sha256 no registro e neste pacote

| arquivo | no registro (6ca30930) | neste pacote | commits depois do registro |
|---|---|---|---|
| `bases-externas/metricas-rz/ciclo.py` | `40d86a363ed2` | `143cbba51958` | 914591b0  |
| `bases-externas/metricas-rz/outras.py` | `35de2d920c9a` | `35de2d920c9a` | nenhum |
| `bases-externas/baseline-dinamica/calib.py` | `8703dc7a6b43` | `8703dc7a6b43` | nenhum |
| `bases-externas/baseline-dinamica/rcaeval.py` | `0d05ed8ff492` | `6c6d408058d1` | 914591b0  |
| `experimento-falhas/teastore/stage3-online/replay/metricas_rz_teastore.py` | `4a1293f3a0ea` | `4a1293f3a0ea` | nenhum |
| `experimento-falhas/teastore/stage3-online/replay/baseline_dinamica.py` | `d9edbf430618` | `d9edbf430618` | nenhum |

As duas mudanças depois do registro (commit 914591b0, 19/10/2026) só retiram da leitura o caso duplicado do
RCAEval (`multi-source-data`); não alteram regra de decisão nem de ordenação.

## Limpeza dos comentários

Nos demais arquivos `.py` e `.sh`, o `montar.sh` retirou dos comentários e das docstrings as referências
às notas internas do autor, que não fazem parte do depósito. A árvore sintática (AST) de cada arquivo Python,
sem as docstrings, é a mesma do commit `bbf7b65e`; as strings que os scripts gravam
nos relatórios não foram alteradas.
