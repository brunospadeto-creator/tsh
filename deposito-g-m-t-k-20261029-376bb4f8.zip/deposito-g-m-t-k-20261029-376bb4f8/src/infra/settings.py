from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="VERITAS_", case_sensitive=False)

    db_url: str = "postgresql://veritas:password@postgres:5432/veritas"
    models_dir: str = "/data/models"
    loki_url: str = "http://loki:3100"
    prometheus_url: str = "http://prometheus:9090"
    embedding_model: str = "paraphrase-multilingual-MiniLM-L12-v2"
    auth_enabled: bool = True
    auth_mode: str = "api_key"
    admin_api_key: str = "change-me"
    jwt_secret: str = "change-me-jwt-secret"
    jwt_algorithm: str = "HS256"
    cookie_secure: bool = False

    port: int = 8000

    rate_limit_enabled: bool = False
    rate_limit_default: str = "60/minute"
    rate_limit_internal: str = "30/minute"
    rate_limit_login: str = "5/minute"

    lockout_enabled: bool = True
    lockout_max_failures: int = 5
    lockout_seconds: int = 900

    notifier_backend: str = "log"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_to: str = ""
    smtp_use_tls: bool = True
    webhook_url: str = ""

    k8s_api_url: str = ""
    k8s_token: str = ""
    k8s_verify_ssl: bool = True
    k8s_namespace: str = ""

    container_socket: str = "/var/run/docker.sock"
    compose_project: str = "veritas"

    gitlab_url: str = "https://gitlab.com"
    gitlab_token: str = ""
    gitlab_project_id: str = ""

    ml_runtime_url: str = "http://ml-runtime:8000"
    collection_rate_limit: str = "10/m"
    collection_concurrency: int = 2
    processing_concurrency: int = 1
    job_poll_interval_sec: float = 2.0
    job_lock_timeout_sec: int = 1800
    monitoring_job_lock_timeout_sec: int = 120
    job_max_attempts: int = 3

    gate_recalibration_interval_sec: int = 86400
    container_runtime: Literal["podman", "k8s"] = "podman"
    governance_enforced: bool = False  # false = modo shadow


def get_settings() -> Settings:
    return Settings()
