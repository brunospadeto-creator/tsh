import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class CollectionModel(Base):
    __tablename__ = "collections"

    collection_id = Column(String, primary_key=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String, nullable=False, default="planned")
    package_window_seconds = Column(Integer, nullable=False, default=60)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))

    system = relationship("SystemModel", back_populates="collections")
    failures = relationship("FailureModel", back_populates="collection", cascade="all, delete-orphan")
    baseline = relationship("CollectionBaselineModel", uselist=False, cascade="all, delete-orphan")


class SystemModel(Base):
    __tablename__ = "systems"

    system_id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    loki_label_selector = Column(String, nullable=False)
    prometheus_label_selector = Column(String, nullable=False)
    metric_queries = Column(Text, nullable=True)
    ref_class = Column(String, nullable=False, default="MODELO")
    polling_interval_sec = Column(Integer, nullable=False, default=300)
    pipeline_config = Column(Text, nullable=False)
    monitoring_active = Column(Boolean, nullable=False, default=False)
    active_run_id = Column(String, nullable=True)
    next_monitor_at = Column(DateTime, nullable=True)
    k8s_namespace = Column(String, nullable=True)
    gitlab_project_id = Column(String, nullable=True)
    gitlab_config_path = Column(String, nullable=True)
    gitlab_ref = Column(String, nullable=True)
    allowed_collection_window = Column(Text, nullable=True)
    max_parallel_collections = Column(Integer, nullable=False, default=3)
    engine_type   = Column(String, nullable=True)
    engine_config = Column(Text, nullable=True)
    llm_prompt    = Column(Text, nullable=True)
    # estado ativo do monitoramento por estágio
    stage1_engine = Column(String, nullable=True)
    stage2_engine = Column(String, nullable=True)
    stage1_run_id = Column(String, nullable=True)
    stage2_run_id = Column(String, nullable=True)
    active_version_cenario = Column(String, nullable=True)
    # Stage 3: investigação detalhada por incidente, habilitada por sistema
    stage3_enabled = Column(Boolean, nullable=False, default=False)
    stage3_config = Column(JSON, nullable=False, default=dict)
    created_at    = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))
    updated_at    = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))

    collections = relationship("CollectionModel", back_populates="system", cascade="all, delete-orphan",
                               order_by="CollectionModel.created_at")
    failures = relationship("FailureModel", back_populates="system", cascade="all, delete-orphan")
    evidence_packages = relationship("EvidencePackageModel", back_populates="system", cascade="all, delete-orphan")
    training_runs = relationship("TrainingRunModel", back_populates="system", cascade="all, delete-orphan")
    monitoring_logs = relationship("MonitoringLogModel", back_populates="system", cascade="all, delete-orphan")
    raw_collections = relationship("RawCollectionModel", back_populates="system", cascade="all, delete-orphan")


class FailureModel(Base):
    __tablename__ = "failures"

    failure_id = Column(String, primary_key=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    collection_id = Column(String, ForeignKey("collections.collection_id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    window_start = Column(DateTime, nullable=False)
    window_end = Column(DateTime, nullable=False)
    status = Column(String, nullable=False, default="pending_collection")
    evidence_count = Column(Integer, nullable=False, default=0)
    is_baseline = Column(Boolean, nullable=False, default=False)
    package_window_seconds = Column(Integer, nullable=False, default=60)
    validation_status = Column(String, nullable=False, default="pending")
    validation_errors = Column(Text, nullable=True)
    version_context_snapshot = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))

    system = relationship("SystemModel", back_populates="failures")
    collection = relationship("CollectionModel", back_populates="failures")


class EvidencePackageModel(Base):
    __tablename__ = "evidence_packages"

    evidence_id = Column(String, primary_key=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    failure_id = Column(String, ForeignKey("failures.failure_id"), nullable=True)
    collection_id = Column(String, ForeignKey("collections.collection_id"), nullable=True)
    package_json = Column(Text, nullable=False)
    window_start = Column(DateTime, nullable=True)
    window_end = Column(DateTime, nullable=True)
    # governança — nullable; backfill v28 usa "legacy-import"
    gov_agent = Column(String, nullable=True)
    gov_scope = Column(String, nullable=True)
    gov_sha256 = Column(String, nullable=True)
    gov_collected_at = Column(String, nullable=True)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))

    system = relationship("SystemModel", back_populates="evidence_packages")


class TrainingRunModel(Base):
    __tablename__ = "training_runs"

    run_id        = Column(String, primary_key=True)
    system_id     = Column(String, ForeignKey("systems.system_id"), nullable=False)
    collection_id = Column(String, ForeignKey("collections.collection_id"), nullable=True)
    status        = Column(String, nullable=False)
    n_classes     = Column(Integer, nullable=False)
    n_samples     = Column(Integer, nullable=False)
    stage1_cfg    = Column(Text, nullable=False)
    stage2_cfg    = Column(Text, nullable=False)
    confusion_matrix = Column(Text, nullable=True)
    metrics       = Column(Text, nullable=True)
    model_path    = Column(Text, nullable=True)
    progress      = Column(Integer, nullable=False, default=0)
    started_at    = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))
    completed_at  = Column(DateTime, nullable=True)
    error         = Column(Text, nullable=True)
    stage         = Column(Integer, nullable=True)  # 1, 2, ou NULL (pipeline legado completo)
    engine        = Column(String, nullable=True)   # motor usado neste run ("faiss","ml-rf","rules","llm")

    system = relationship("SystemModel", back_populates="training_runs")


class JobModel(Base):
    __tablename__ = "jobs"

    job_id = Column(String, primary_key=True)
    kind = Column(String, nullable=False, index=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False, index=True)
    payload_json = Column(Text, nullable=False, default="{}")
    status = Column(String, nullable=False, default="pending", index=True)
    priority = Column(Integer, nullable=False, default=0)
    attempts = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=3)
    available_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None), index=True)
    locked_at = Column(DateTime, nullable=True)
    locked_by = Column(String, nullable=True)
    last_error = Column(Text, nullable=True)
    result_json = Column(Text, nullable=True)
    dedupe_key = Column(String, nullable=True, unique=True)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))
    completed_at = Column(DateTime, nullable=True)


class MonitoringLogModel(Base):
    __tablename__ = "monitoring_logs"

    log_id = Column(String, primary_key=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    run_id = Column(String, nullable=True)
    collection_id = Column(String, nullable=True)
    evidence_id = Column(String, nullable=False)
    contract_id = Column(String, nullable=False)
    collected_at = Column(DateTime, nullable=False)
    window_start = Column(DateTime, nullable=True)
    window_end = Column(DateTime, nullable=True)
    package_window_seconds = Column(Integer, nullable=True)
    steps_json = Column(Text, nullable=True)
    # Stage 3: resumo compacto entidade × métrica do ciclo (o EvidencePackage não é persistido)
    metrics_by_entity_json = Column(Text, nullable=True)
    stage1_result = Column(String, nullable=False)
    primary_hypothesis = Column(Text, nullable=True)
    confidence = Column(Float, nullable=True)
    error = Column(Text, nullable=True)
    reviewed = Column(Boolean, nullable=False, default=False)
    contract_json = Column(Text, nullable=False)
    # contribuições por bloco — lista [{block, delta, share}] em JSON
    block_contributions = Column(Text, nullable=True)

    system = relationship("SystemModel", back_populates="monitoring_logs")


class IncidentModel(Base):
    __tablename__ = "incidents"

    incident_id = Column(String, primary_key=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    monitoring_log_id = Column(String, ForeignKey("monitoring_logs.log_id"), nullable=True)
    evidence_id = Column(String, nullable=True)
    failure_id = Column(String, nullable=True)
    profile_id = Column(String, nullable=True)
    engine_type = Column(String, nullable=True)
    stage1_result = Column(String, nullable=True)
    hypothesis = Column(Text, nullable=True)
    confidence = Column(Float, nullable=True)
    status = Column(String, nullable=False, default="open")
    opened_reason = Column(Text, nullable=True)
    consecutive_anomalies = Column(Integer, nullable=False, default=3)
    log_ids_json = Column(Text, nullable=True)
    evidence_ids_json = Column(Text, nullable=True)
    # Stage 3: perfil de monitoramento vigente quando o incidente abriu
    profile_snapshot_json = Column(Text, nullable=True)
    # Coleta de referência do MESMO cenário, gravada antes da injeção da falha. A
    # localização compara a janela da falha com essa referência, além da
    # baseline global, para não chamar de anomalia o que é deriva do ambiente.
    referencia_collection_id = Column(String, nullable=True)
    window_start = Column(DateTime, nullable=True)
    window_end = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    known_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))
    updated_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))


class RawCollectionModel(Base):
    __tablename__ = "raw_collections"

    id = Column(Integer, primary_key=True, autoincrement=True)
    failure_id = Column(String, ForeignKey("failures.failure_id"), nullable=False)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    source = Column(String, nullable=False)
    status = Column(String, nullable=False, default="pending")
    data = Column(Text, nullable=True)
    error = Column(Text, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    system = relationship("SystemModel", back_populates="raw_collections")


class PartialEvidencePackageModel(Base):
    __tablename__ = "partial_evidence_packages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    failure_id = Column(String, ForeignKey("failures.failure_id"), nullable=False)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    partial_package_json = Column(Text, nullable=False)
    source_run_id = Column(String, nullable=False, default="")
    window_start = Column(DateTime, nullable=True)
    window_end = Column(DateTime, nullable=True)
    chunk_index = Column(Integer, nullable=False, default=0)
    chunk_window_start = Column(DateTime, nullable=True)
    chunk_window_end = Column(DateTime, nullable=True)
    drain_status = Column(String, nullable=False, default="pending")
    progress = Column(Integer, nullable=False, default=0)
    error = Column(Text, nullable=True)
    evidence_id = Column(String, nullable=True)
    validation_status = Column(String, nullable=False, default="pending")
    validation_errors = Column(Text, nullable=True)
    # governança — nullable; backfill v28 usa "legacy-import"
    gov_agent = Column(String, nullable=True)
    gov_scope = Column(String, nullable=True)
    gov_sha256 = Column(String, nullable=True)
    gov_collected_at = Column(String, nullable=True)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))
    updated_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))


class ProfileModel(Base):
    __tablename__ = "monitoring_profiles"

    profile_id    = Column(String, primary_key=True)
    system_id     = Column(String, ForeignKey("systems.system_id"), nullable=False)
    name          = Column(String, nullable=False)
    # legado — mantido para compatibilidade reversa
    engine_type   = Column(String, nullable=False, default="ml-rf")
    engine_config = Column(Text, nullable=True)
    llm_prompt    = Column(Text, nullable=True)
    active_run_id = Column(String, nullable=True)
    active        = Column(Boolean, nullable=False, default=True)
    # novos campos de estágios independentes
    stage1_engine = Column(String, nullable=True)   # "faiss" | "ml-rf" | "rules" | "llm"
    stage2_engine = Column(String, nullable=True)
    stage1_run_id = Column(String, nullable=True)   # TrainingRun com stage=1
    stage2_run_id = Column(String, nullable=True)   # TrainingRun com stage=2
    stage1_config = Column(Text, nullable=True)     # JSON: config específica do motor stage1
    stage2_config = Column(Text, nullable=True)     # JSON: tau, class_map, prompt, etc.
    created_at    = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))
    updated_at    = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))


class LLMConfigModel(Base):
    __tablename__ = "llm_config"

    id = Column(String, primary_key=True, default="global")
    api_key = Column(Text, nullable=True)
    cohere_api_key = Column(Text, nullable=True)
    provider = Column(String, nullable=False, default="gemini")
    model = Column(String, nullable=False, default="gemini-1.5-flash")
    prompt_stage1 = Column(Text, nullable=True)
    prompt_stage2 = Column(Text, nullable=True)
    stage1_text_mode = Column(String, nullable=True)
    stage2_text_mode = Column(String, nullable=True)
    updated_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))


class VersionContextModel(Base):
    __tablename__ = "version_contexts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    cenario = Column(String, nullable=False)
    data = Column(Text, nullable=False)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.datetime.now(datetime.UTC).replace(tzinfo=None))

    __table_args__ = (
        __import__("sqlalchemy").UniqueConstraint("system_id", "cenario", name="uq_version_context_system_cenario"),
    )


class GateThresholdModel(Base):
    __tablename__ = "gate_thresholds"

    id = Column(String, primary_key=True)
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    run_id = Column(String, nullable=True)
    ref_class = Column(String, nullable=False, default="MODELO")
    alpha = Column(Float, nullable=False, default=0.05)
    min_samples = Column(Integer, nullable=False, default=30)
    payload = Column(Text, nullable=False)  # GateCalibration serializado (JSON)
    fitted_at = Column(DateTime, nullable=False)
    active = Column(Boolean, nullable=False, default=True)


def _utcnow_naive() -> datetime.datetime:
    return datetime.datetime.now(datetime.UTC).replace(tzinfo=None)


# Modos de decisao do Stage 3. Fica aqui, e nao em `application/stage3/abordagens/base.py`,
# porque e uma restricao de integridade da coluna `stage3_abordagens.modo` — e `store` nao pode
# importar de `application`. A camada de cima importa daqui, entao a lista tem um so dono.
# `d1c`/`d2c`/`d4c`: os mesmos d_k com atribuicao causal no ranking, lado a lado com as v1
# congeladas -- arquivos novos, para o hold-out pre-registrado das v1 continuar valendo.
# `d9-k` e `v-cons-b`: as soluções definitivas
MODOS_STAGE3: tuple[str, ...] = ("a0", "d1", "d2", "d3", "d4", "d1c", "d2c", "d4c", "d5", "d6", "d7", "d8", "d9",
                                 "d9-k", "v-cons-b")
MODOS_DECISORIOS_STAGE3: tuple[str, ...] = ("d1", "d2", "d3", "d4", "d1c", "d2c", "d4c", "d5", "d6", "d7", "d8", "d9",
                                            "d9-k", "v-cons-b")
# Modo nulo do caminho de teste. Vive **fora** de `MODOS_STAGE3` de proposito:
# ele sempre absteve, entao nunca pode ser `escolhido` num lote de verdade -- e como `ler_modos()`
# valida contra `MODOS_STAGE3`, essa impossibilidade e estrutural, nao uma convencao.
MODOS_TESTE_STAGE3: tuple[str, ...] = ("d0_nula",)
MODOS_CONHECIDOS_STAGE3: tuple[str, ...] = MODOS_STAGE3 + MODOS_TESTE_STAGE3
# Status terminal = decisao registrada. Imutavel: um re-run do job nao pode reescrever `ranking`,
# `completed_at` nem deixar um `audit_package` descrevendo um resultado que saiu da linha.
STATUS_TERMINAIS_STAGE3: frozenset[str] = frozenset({"completed", "abstained", "failed"})


class CollectionBaselineModel(Base):
    """Baseline pré-computado de uma coleção para o Stage 3."""

    __tablename__ = "collection_baselines"

    baseline_id = Column(String, primary_key=True)
    collection_id = Column(
        String, ForeignKey("collections.collection_id", ondelete="CASCADE"), nullable=False, unique=True
    )
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False)
    job_id = Column(String, ForeignKey("jobs.job_id"), nullable=True)
    status = Column(String(20), nullable=False, default="pending")
    error_message = Column(Text, nullable=True)
    n_samples = Column(Integer, nullable=True)
    computed_at = Column(DateTime, nullable=True)
    # {entidade: {métrica: [mean, std, min, max, p95]}}
    metric_stats = Column(JSON, nullable=True)
    # Estado da coleta de traces (job collect_trace_baseline): null | pending | running | completed | failed
    trace_status = Column(String(20), nullable=True)
    trace_error = Column(Text, nullable=True)
    # {endpoint: "<base64 do PNML do PetriNet>"} — escritos só por collect_trace_baseline
    process_models = Column(JSON, nullable=True)
    # {endpoint: {atividade: [mean, std, min, max, p95]}}
    span_stats = Column(JSON, nullable=True)
    # {endpoint: {"src->dst": [calls_por_trace, mean_ms, std_ms, p95_ms]}}
    service_graph = Column(JSON, nullable=True)
    # {endpoint: {"nodes": [...], "edges": [...]}} — grafo Cytoscape pré-computado (collect_trace_baseline)
    process_graphs = Column(JSON, nullable=True)
    # M8: {"servicos", "entrada", "presenca", "endpoints", "operacoes", "arestas", ...} (service_stats.py)
    service_stats = Column(JSON, nullable=True)
    # Spec 42.8: {modo: {"versao", "artefato", "calibracao"}} — um artefato por modo, só dos escolhidos
    abordagens = Column(JSON, nullable=True)
    # Spec 42.8: {modo: "pending" | "running" | "completed" | "failed"}
    abordagens_status = Column(JSON, nullable=True)
    created_at = Column(DateTime, nullable=False, default=_utcnow_naive)
    completed_at = Column(DateTime, nullable=True)


class Stage3DiagnosisModel(Base):
    """Resultado do Stage 3 por incidente, com o pacote de auditoria congelado."""

    __tablename__ = "stage3_diagnoses"

    diagnosis_id = Column(String, primary_key=True)
    incident_id = Column(
        String, ForeignKey("incidents.incident_id", ondelete="CASCADE"), nullable=False, unique=True
    )
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False, index=True)
    job_id = Column(String, ForeignKey("jobs.job_id"), nullable=True)

    status = Column(String(20), nullable=False, default="pending")
    abstain_reason = Column(String(50), nullable=True)
    localizacao_abstain_reason = Column(String(50), nullable=True)
    error_message = Column(Text, nullable=True)

    endpoint = Column(String(255), nullable=True)
    trace_id = Column(String(64), nullable=True)
    n_traces_recuperados = Column(Integer, nullable=True)
    entity_candidates = Column(JSON, nullable=True)
    top_candidate_pod = Column(String(255), nullable=True)
    top_candidate_service = Column(String(255), nullable=True)
    top_candidate_activity = Column(String(255), nullable=True)
    top_candidate_confidence = Column(String(10), nullable=True)
    top_candidate_score = Column(Float, nullable=True)   # fitness do trace

    anomaly_type = Column(String(50), nullable=True)
    dominant_metric = Column(String(100), nullable=True)
    dominant_delta = Column(Float, nullable=True)
    anomalous_metrics = Column(JSON, nullable=True)
    metric_deltas = Column(JSON, nullable=True)
    t_start = Column(DateTime, nullable=True)

    temporal_deviations = Column(JSON, nullable=True)
    problem_map = Column(JSON, nullable=True)
    restricted_evidence = Column(JSON, nullable=True)

    llm_fault = Column(Text, nullable=True)
    llm_error = Column(Text, nullable=True)
    llm_failure = Column(Text, nullable=True)
    llm_hypothesis = Column(Text, nullable=True)
    llm_confidence = Column(String(10), nullable=True)
    llm_confidence_reason = Column(Text, nullable=True)
    llm_supporting_evidence = Column(JSON, nullable=True)
    llm_alternatives = Column(JSON, nullable=True)
    llm_missing_evidence = Column(JSON, nullable=True)
    llm_abstain = Column(Boolean, nullable=False, default=False)
    llm_abstain_reason = Column(Text, nullable=True)
    llm_prompt = Column(Text, nullable=True)
    llm_raw_response = Column(Text, nullable=True)
    llm_provider = Column(String(50), nullable=True)
    llm_model = Column(String(100), nullable=True)

    baseline_n_samples = Column(Integer, nullable=True)
    theta_snapshot = Column(JSON, nullable=True)

    # Pacote de auditoria do incidente: imutável depois de gravado
    audit_package = Column(JSON, nullable=True)
    audit_sha256 = Column(String(64), nullable=True)
    audit_created_at = Column(DateTime, nullable=True)
    # Revisão humana (write-once; fora do hash do pacote)
    review_status = Column(String(20), nullable=False, default="pending_human_review")
    review_reason = Column(Text, nullable=True)
    review_actual_entity = Column(String(255), nullable=True)
    reviewed_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, nullable=False, default=_utcnow_naive)
    completed_at = Column(DateTime, nullable=True)


class Stage3AbordagemModel(Base):
    """Resultado de um **modo** de decisão por incidente.

    A a0 entra nesta tabela como `modo = "a0"`, e não como linha em `stage3_diagnoses`. É o que
    permite comparar os cinco lado a lado numa consulta só, com a mesma chave `UNIQUE`, em vez de duas
    tabelas com duas formas de consultar a mesma coisa.
    """

    __tablename__ = "stage3_abordagens"

    abordagem_id = Column(String, primary_key=True)
    incident_id = Column(
        String, ForeignKey("incidents.incident_id", ondelete="CASCADE"), nullable=False
    )
    system_id = Column(String, ForeignKey("systems.system_id"), nullable=False, index=True)
    job_id = Column(String, ForeignKey("jobs.job_id"), nullable=True)

    modo = Column(String(10), nullable=False)  # MODOS_STAGE3
    versao = Column(String(50), nullable=False)
    status = Column(String(20), nullable=False, default="pending")
    motivo_abstencao = Column(String(50), nullable=True)
    error_message = Column(Text, nullable=True)

    # Lista de ItemRanking — vazia quando o modo absteve, nunca "omitida" para parecer que rodou
    ranking = Column(JSON, nullable=True)
    evidencias = Column(JSON, nullable=True)
    # Efetivos em uso, incluindo o calibrado; fora dele é bug
    parametros = Column(JSON, nullable=True)
    # Insumos resumidos, janelas e segundos de execução
    execucao = Column(JSON, nullable=True)

    # Imutável depois de gravado, como em stage3_diagnoses; `failed` nunca tem pacote
    audit_package = Column(JSON, nullable=True)
    audit_sha256 = Column(String(64), nullable=True)
    audit_created_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, nullable=False, default=_utcnow_naive)
    completed_at = Column(DateTime, nullable=True)

    __table_args__ = (
        UniqueConstraint("incident_id", "modo", name="uq_stage3_abordagens_incident_modo"),
    )
