import datetime
import json
import logging
import uuid
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from src.diagnosis.calibration import GateCalibration

logger = logging.getLogger(__name__)

from sqlalchemy import and_, create_engine, func, or_, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, sessionmaker

from src.diagnosis.labels import canonical_label, is_baseline_label
from src.domain.incidents import INACTIVE_INCIDENT_STATUSES
from src.store.models import (
    MODOS_CONHECIDOS_STAGE3,
    STATUS_TERMINAIS_STAGE3,
    Base,
    CollectionBaselineModel,
    CollectionModel,
    EvidencePackageModel,
    FailureModel,
    GateThresholdModel,
    IncidentModel,
    JobModel,
    LLMConfigModel,
    MonitoringLogModel,
    PartialEvidencePackageModel,
    ProfileModel,
    RawCollectionModel,
    Stage3AbordagemModel,
    Stage3DiagnosisModel,
    SystemModel,
    TrainingRunModel,
    VersionContextModel,
)


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.UTC).replace(tzinfo=None)


def _parse_datetime(value: Any) -> datetime.datetime | Any:
    if isinstance(value, str):
        try:
            return datetime.datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
        except ValueError:
            return None
    return value


def _iso_utc(value: datetime.datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=datetime.UTC)
    else:
        value = value.astimezone(datetime.UTC)
    return value.isoformat().replace("+00:00", "Z")


_SECRET_KEY_PARTS = ("api_key", "secret", "token", "password")


def _strip_secrets(value: Any) -> Any:
    """Remove recursivamente chaves com cara de credencial (o snapshot vai ao pacote de auditoria)."""
    if isinstance(value, dict):
        return {
            k: _strip_secrets(v)
            for k, v in value.items()
            if not any(part in str(k).lower() for part in _SECRET_KEY_PARTS)
        }
    if isinstance(value, list):
        return [_strip_secrets(v) for v in value]
    return value


def _load_json_dict(raw: Any) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        data = json.loads(str(raw))
    except (json.JSONDecodeError, TypeError):
        return {}
    return data if isinstance(data, dict) else {}


def _profile_snapshot(
    profile: ProfileModel | None,
    *,
    llm_provider: str | None,
    llm_model: str | None,
    captured_at: datetime.datetime,
    source: str = "incident_open",
) -> dict[str, Any]:
    """Perfil de monitoramento vigente, congelado para o pacote de auditoria.

    Sem chaves de API. Os thresholds das regras não são persistidos pelo perfil (limitação
    registrada pelo pacote); `gates` traz a configuração dos estágios (ex.: tau).
    """
    return {
        "profile_id": profile.profile_id if profile else None,
        "stage1_engine": (profile.stage1_engine or profile.engine_type) if profile else None,
        "stage2_engine": profile.stage2_engine if profile else None,
        "run_ids": {
            "stage1": profile.stage1_run_id if profile else None,
            "stage2": profile.stage2_run_id if profile else None,
        },
        "gates": {
            "stage1": _strip_secrets(_load_json_dict(profile.stage1_config)) if profile else {},
            "stage2": _strip_secrets(_load_json_dict(profile.stage2_config)) if profile else {},
        },
        "llm_provider": llm_provider,
        "llm_model": llm_model,
        "captured_at": _iso_utc(captured_at),
        "source": source,
    }


class Repository:
    def __init__(self, db_url: str):
        self.engine = create_engine(db_url, pool_pre_ping=True)
        self._session_factory = sessionmaker(bind=self.engine)

    def _migrate(self) -> None:
        try:
            with self._session() as session:
                session.execute(
                    text("ALTER TABLE systems ADD COLUMN active_run_id VARCHAR")
                )
                session.commit()
        except Exception:
            pass
        for statement in (
            "ALTER TABLE training_runs ADD COLUMN collection_id VARCHAR",
            "ALTER TABLE monitoring_logs ADD COLUMN run_id VARCHAR",
            "ALTER TABLE monitoring_logs ADD COLUMN collection_id VARCHAR",
            "ALTER TABLE monitoring_logs ADD COLUMN window_start TIMESTAMP",
            "ALTER TABLE monitoring_logs ADD COLUMN window_end TIMESTAMP",
            "ALTER TABLE monitoring_logs ADD COLUMN package_window_seconds INTEGER",
            "ALTER TABLE monitoring_logs ADD COLUMN steps_json TEXT",
            "ALTER TABLE monitoring_logs ADD COLUMN error TEXT",
        ):
            try:
                with self._session() as session:
                    session.execute(text(statement))
                    session.commit()
            except Exception:
                pass
        try:
            with self._session() as session:
                session.execute(text(
                    """
                    UPDATE training_runs
                    SET collection_id = (
                        SELECT f.collection_id
                        FROM failures f
                        WHERE f.system_id = training_runs.system_id
                          AND f.status = 'completed'
                        GROUP BY f.collection_id
                        ORDER BY COUNT(*) DESC
                        LIMIT 1
                    )
                    WHERE collection_id IS NULL
                    """
                ))
                session.commit()
        except Exception:
            pass
        try:
            IncidentModel.__table__.create(self.engine, checkfirst=True)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            with self._session() as session:
                session.execute(text(
                    """
                    UPDATE systems
                    SET prometheus_label_selector = CASE
                            WHEN lower(name) LIKE '%jpetstore%' THEN 'name=~".*jpetstore.*"'
                            WHEN lower(name) LIKE '%teastore%' THEN 'name=~".*teastore.*"'
                            ELSE prometheus_label_selector
                        END,
                        loki_label_selector = CASE
                            WHEN lower(name) LIKE '%jpetstore%' THEN '{app="jpetstore"}'
                            WHEN lower(name) LIKE '%teastore%' THEN '{app="teastore"}'
                            ELSE loki_label_selector
                        END
                    WHERE (prometheus_label_selector IS NULL OR prometheus_label_selector = ''
                        OR loki_label_selector IS NULL OR loki_label_selector = '')
                      AND (lower(name) LIKE '%jpetstore%' OR lower(name) LIKE '%teastore%')
                    """
                ))
                session.commit()
        except Exception:
            pass

    def create_all(self) -> None:
        Base.metadata.create_all(self.engine)
        self._migrate()

    def _session(self) -> Session:
        return self._session_factory()

    # --- Systems ---

    def create_system(self, system: dict[str, Any]) -> SystemModel:
        with self._session() as session:
            model = SystemModel(**system)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_system(self, system_id: str) -> SystemModel | None:
        with self._session() as session:
            return session.query(SystemModel).filter_by(system_id=system_id).first()

    def list_systems(self) -> list[SystemModel]:
        with self._session() as session:
            return list(session.query(SystemModel).all())

    def get_dashboard_stats(self) -> dict[str, int]:
        """Single-query aggregate for dashboard counters. Avoids N+1 per system."""
        with self._session() as session:
            system_ids = [r[0] for r in session.query(SystemModel.system_id).all()]
            if not system_ids:
                return {"failure_count": 0, "collection_count": 0, "anomaly_count": 0}
            failure_count = (
                session.query(func.count(FailureModel.failure_id))
                .filter(FailureModel.system_id.in_(system_ids))
                .scalar() or 0
            )
            collection_count = (
                session.query(func.count(CollectionModel.collection_id))
                .filter(CollectionModel.system_id.in_(system_ids))
                .scalar() or 0
            )
            anomaly_count = (
                session.query(func.count(MonitoringLogModel.log_id))
                .filter(
                    MonitoringLogModel.system_id.in_(system_ids),
                    MonitoringLogModel.stage1_result == "anomalous",
                )
                .scalar() or 0
            )
            return {
                "failure_count": int(failure_count),
                "collection_count": int(collection_count),
                "anomaly_count": int(anomaly_count),
            }

    def get_completed_training_system_ids(self) -> set[str]:
        """Returns set of system_ids that have at least one completed training run."""
        with self._session() as session:
            rows = (
                session.query(TrainingRunModel.system_id)
                .filter(TrainingRunModel.status == "completed")
                .distinct()
                .all()
            )
            return {r[0] for r in rows}

    def update_system(self, system_id: str, updates: dict[str, Any]) -> SystemModel | None:
        with self._session() as session:
            model = session.query(SystemModel).filter_by(system_id=system_id).first()
            if model is None:
                return None
            for key, value in updates.items():
                setattr(model, key, value)
            model.updated_at = _utcnow()  # type: ignore[assignment]
            session.commit()
            session.refresh(model)
            return model

    def delete_system(self, system_id: str) -> bool:
        with self._session() as session:
            model = session.query(SystemModel).filter_by(system_id=system_id).first()
            if model is None:
                return False
            # Deletes explícitos dos dependentes: os relationships com
            # cascade não cobrem jobs/incidents/profiles/version_contexts/
            # gate_thresholds/partial_evidence_packages, e FKs sem ON DELETE
            # CASCADE quebram no Postgres (SQLite ignora por default).
            for stage3_dependent in (
                Stage3DiagnosisModel,
                Stage3AbordagemModel,
                CollectionBaselineModel,
            ):
                session.query(stage3_dependent).filter_by(system_id=system_id).delete(
                    synchronize_session=False
                )
            session.query(IncidentModel).filter_by(system_id=system_id).delete(
                synchronize_session=False
            )
            for dependent in (
                PartialEvidencePackageModel,
                RawCollectionModel,
                EvidencePackageModel,
                GateThresholdModel,
                ProfileModel,
                VersionContextModel,
                TrainingRunModel,
                MonitoringLogModel,
                JobModel,
                FailureModel,
                CollectionModel,
            ):
                session.query(dependent).filter_by(system_id=system_id).delete(
                    synchronize_session=False
                )
            session.delete(model)
            session.commit()
            return True

    def list_active_monitoring_systems(self) -> list[SystemModel]:
        with self._session() as session:
            return list(session.query(SystemModel).filter_by(monitoring_active=True).all())

    def get_system_by_name(self, name: str) -> SystemModel | None:
        with self._session() as session:
            return session.query(SystemModel).filter_by(name=name).first()

    # --- Collections ---

    def create_collection(self, collection: dict[str, Any]) -> CollectionModel:
        with self._session() as session:
            model = CollectionModel(**collection)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_collection(self, collection_id: str) -> CollectionModel | None:
        with self._session() as session:
            return session.query(CollectionModel).filter_by(collection_id=collection_id).first()

    def list_collections(self, system_id: str) -> list[CollectionModel]:
        with self._session() as session:
            return list(
                session.query(CollectionModel)
                .filter_by(system_id=system_id)
                .order_by(CollectionModel.created_at.desc())
                .all()
            )

    def update_collection(self, collection_id: str, updates: dict[str, Any]) -> CollectionModel | None:
        with self._session() as session:
            model = session.query(CollectionModel).filter_by(collection_id=collection_id).first()
            if model is None:
                return None
            for key, value in updates.items():
                setattr(model, key, value)
            session.commit()
            session.refresh(model)
            return model

    def delete_collection(self, collection_id: str) -> bool:
        with self._session() as session:
            model = session.query(CollectionModel).filter_by(collection_id=collection_id).first()
            if model is None:
                return False
            failure_ids = [
                r[0] for r in
                session.query(FailureModel.failure_id).filter_by(collection_id=collection_id).all()
            ]
            for fid in failure_ids:
                session.query(RawCollectionModel).filter_by(failure_id=fid).delete()
                session.query(EvidencePackageModel).filter_by(failure_id=fid).delete()
                session.query(PartialEvidencePackageModel).filter_by(failure_id=fid).delete()
            session.query(FailureModel).filter_by(collection_id=collection_id).delete()
            session.query(TrainingRunModel).filter_by(collection_id=collection_id).delete()
            session.delete(model)
            session.commit()
            return True

    def list_failures_by_collection(
        self, collection_id: str, status: str | None = None
    ) -> list[FailureModel]:
        with self._session() as session:
            query = session.query(FailureModel).filter_by(collection_id=collection_id)
            if status is not None:
                query = query.filter_by(status=status)
            return list(query.all())

    # --- Failures ---

    def create_failure(self, failure: dict[str, Any]) -> FailureModel:
        with self._session() as session:
            safe = dict(failure)
            if not safe.get("collection_id"):
                collection = (
                    session.query(CollectionModel)
                    .filter_by(system_id=safe["system_id"], name="Coleta padrão")
                    .first()
                )
                if collection is None:
                    collection = CollectionModel(
                        collection_id=str(uuid.uuid4()),
                        system_id=safe["system_id"],
                        name="Coleta padrão",
                        description="Criada automaticamente para compatibilidade",
                        status="completed",
                        package_window_seconds=int(safe.get("package_window_seconds") or 60),
                        created_at=_utcnow(),
                    )
                    session.add(collection)
                    session.flush()
                safe["collection_id"] = collection.collection_id
            model = FailureModel(**safe)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_failure(self, failure_id: str) -> FailureModel | None:
        with self._session() as session:
            return session.query(FailureModel).filter_by(failure_id=failure_id).first()

    def list_failures(
        self, system_id: str, status: str | None = None, is_baseline: bool | None = None,
        collection_id: str | None = None,
    ) -> list[FailureModel]:
        with self._session() as session:
            query = session.query(FailureModel).filter_by(system_id=system_id)
            if status is not None:
                query = query.filter_by(status=status)
            if is_baseline is not None:
                query = query.filter_by(is_baseline=is_baseline)
            if collection_id is not None:
                query = query.filter_by(collection_id=collection_id)
            return list(query.all())

    def update_failure(self, failure_id: str, updates: dict[str, Any]) -> FailureModel | None:
        with self._session() as session:
            model = session.query(FailureModel).filter_by(failure_id=failure_id).first()
            if model is None:
                return None
            for key, value in updates.items():
                setattr(model, key, value)
            session.commit()
            session.refresh(model)
            return model

    def update_failure_status(self, failure_id: str, status: str, evidence_count: int | None = None) -> None:
        with self._session() as session:
            model = session.query(FailureModel).filter_by(failure_id=failure_id).first()
            if model:
                model.status = status  # type: ignore[assignment]
                if evidence_count is not None:
                    model.evidence_count = evidence_count  # type: ignore[assignment]
                session.commit()

    def update_failure_validation(
        self,
        failure_id: str,
        validation_status: str,
        validation_errors: list[str] | None = None,
    ) -> None:
        with self._session() as session:
            model = session.query(FailureModel).filter_by(failure_id=failure_id).first()
            if model:
                model.validation_status = validation_status  # type: ignore[assignment]
                if validation_errors is not None:
                    model.validation_errors = json.dumps(validation_errors, ensure_ascii=False)
                session.commit()

    def delete_failure(self, failure_id: str) -> bool:
        with self._session() as session:
            model = session.query(FailureModel).filter_by(failure_id=failure_id).first()
            if model is None:
                return False
            session.query(RawCollectionModel).filter_by(failure_id=failure_id).delete()
            session.query(EvidencePackageModel).filter_by(failure_id=failure_id).delete()
            session.query(PartialEvidencePackageModel).filter_by(failure_id=failure_id).delete()
            session.delete(model)
            session.commit()
            return True

    # --- Evidence Packages ---

    def save_evidence_package(self, package: dict[str, Any]) -> EvidencePackageModel:
        with self._session() as session:
            model = EvidencePackageModel(**package)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def save_evidence_packages(self, packages: list[dict[str, Any]]) -> list[EvidencePackageModel]:
        with self._session() as session:
            models = [EvidencePackageModel(**p) for p in packages]
            for m in models:
                session.add(m)
            session.commit()
            for m in models:
                session.refresh(m)
            return models

    def get_evidence_package(self, evidence_id: str) -> EvidencePackageModel | None:
        with self._session() as session:
            return session.query(EvidencePackageModel).filter_by(evidence_id=evidence_id).first()

    def list_evidence_packages(self, system_id: str, failure_id: str | None = None) -> list[EvidencePackageModel]:
        with self._session() as session:
            query = session.query(EvidencePackageModel).filter_by(system_id=system_id)
            if failure_id is not None:
                query = query.filter_by(failure_id=failure_id)
            return list(query.all())

    # --- Training Runs ---

    def create_training_run(self, run: dict[str, Any]) -> TrainingRunModel:
        with self._session() as session:
            model = TrainingRunModel(**run)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_training_run(self, run_id: str) -> TrainingRunModel | None:
        with self._session() as session:
            return session.query(TrainingRunModel).filter_by(run_id=run_id).first()

    def get_latest_training_run(self, system_id: str) -> TrainingRunModel | None:
        with self._session() as session:
            return (
                session.query(TrainingRunModel)
                .filter_by(system_id=system_id)
                .order_by(TrainingRunModel.started_at.desc())
                .first()
            )

    def list_training_runs(self, system_id: str) -> list[TrainingRunModel]:
        with self._session() as session:
            return list(
                session.query(TrainingRunModel)
                .filter_by(system_id=system_id)
                .order_by(TrainingRunModel.started_at.desc())
                .all()
            )

    def list_all_training_runs(self) -> list[TrainingRunModel]:
        with self._session() as session:
            return list(
                session.query(TrainingRunModel)
                .order_by(TrainingRunModel.started_at.desc())
                .all()
            )

    def update_training_run(self, run_id: str, updates: dict[str, Any]) -> TrainingRunModel | None:
        safe_updates = dict(updates)
        if isinstance(safe_updates.get("metrics"), (dict, list)):
            safe_updates["metrics"] = json.dumps(
                safe_updates["metrics"],
                ensure_ascii=False,
                default=str,
            )
        with self._session() as session:
            model = session.query(TrainingRunModel).filter_by(run_id=run_id).first()
            if model is None:
                return None
            for key, value in safe_updates.items():
                setattr(model, key, value)
            session.commit()
            session.refresh(model)
            return model

    def has_running_training(self, system_id: str) -> bool:
        with self._session() as session:
            return (
                session.query(TrainingRunModel)
                .filter(
                    TrainingRunModel.system_id == system_id,
                    TrainingRunModel.status.in_(("queued", "running")),
                )
                .first()
                is not None
            )

    def create_training_run_with_job(
        self,
        run: dict[str, Any],
        payload: dict[str, Any],
        max_attempts: int = 3,
    ) -> tuple[TrainingRunModel, JobModel]:
        job_kind = payload.get("kind", "training")
        with self._session() as session:
            run_model = TrainingRunModel(**run)
            job_model = JobModel(
                job_id=str(uuid.uuid4()),
                kind=job_kind,
                system_id=run["system_id"],
                payload_json=json.dumps(payload, ensure_ascii=False),
                status="pending",
                max_attempts=max_attempts,
                available_at=_utcnow(),
                dedupe_key=f"training:{run['system_id']}:{run['run_id']}",
            )
            session.add(run_model)
            session.add(job_model)
            session.commit()
            session.refresh(run_model)
            session.refresh(job_model)
            return run_model, job_model

    def delete_training_run(self, run_id: str) -> bool:
        with self._session() as session:
            model = session.query(TrainingRunModel).filter_by(run_id=run_id).first()
            if model is None:
                return False
            session.delete(model)
            session.commit()
            return True

    # --- Persistent Jobs ---

    def enqueue_job(self, job: dict[str, Any]) -> JobModel:
        with self._session() as session:
            model = JobModel(**job)
            session.add(model)
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                dedupe_key = job.get("dedupe_key")
                if dedupe_key:
                    existing = session.query(JobModel).filter_by(dedupe_key=dedupe_key).first()
                    if existing is not None:
                        return existing
                raise
            session.refresh(model)
            return model

    def enqueue(
        self,
        kind: str,
        system_id: str,
        payload: dict[str, Any],
        *,
        priority: int = 0,
        max_attempts: int = 3,
        dedupe_key: str | None = None,
        available_at: datetime.datetime | None = None,
    ) -> JobModel:
        if dedupe_key:
            with self._session() as session:
                existing = session.query(JobModel).filter_by(dedupe_key=dedupe_key).first()
                if existing is not None:
                    if existing.status in ("pending", "running"):
                        return existing
                    existing.dedupe_key = None  # type: ignore[assignment]
                    session.commit()
        return self.enqueue_job({
            "job_id": str(uuid.uuid4()),
            "kind": kind,
            "system_id": system_id,
            "payload_json": json.dumps(payload, ensure_ascii=False),
            "status": "pending",
            "priority": priority,
            "attempts": 0,
            "max_attempts": max_attempts,
            "available_at": available_at or _utcnow(),
            "dedupe_key": dedupe_key,
            "created_at": _utcnow(),
        })

    def get_job(self, job_id: str) -> JobModel | None:
        with self._session() as session:
            return session.query(JobModel).filter_by(job_id=job_id).first()

    def claim_next_job(
        self,
        worker_id: str,
        lock_timeout_sec: int = 1800,
        monitoring_lock_timeout_sec: int | None = None,
        kinds: tuple[str, ...] | None = None,
    ) -> JobModel | None:
        now = _utcnow()
        stale_before = now - datetime.timedelta(seconds=lock_timeout_sec)
        monitoring_stale_before = now - datetime.timedelta(
            seconds=monitoring_lock_timeout_sec
            if monitoring_lock_timeout_sec is not None
            else lock_timeout_sec
        )
        stale_lock_filter = or_(
            and_(JobModel.kind == "monitoring", JobModel.locked_at < monitoring_stale_before),
            and_(JobModel.kind != "monitoring", JobModel.locked_at < stale_before),
        )
        with self._session() as session:
            exhausted = (
                session.query(JobModel)
                .filter(
                    JobModel.status == "running",
                    stale_lock_filter,
                    JobModel.attempts >= JobModel.max_attempts,
                )
                .with_for_update(skip_locked=True)
                .all()
            )
            for stale_job in exhausted:
                stale_job.status = "failed"  # type: ignore[assignment]
                stale_job.completed_at = now  # type: ignore[assignment]
                stale_job.last_error = "job lock expired after final attempt"  # type: ignore[assignment]
                stale_job.locked_at = None  # type: ignore[assignment]
                stale_job.locked_by = None  # type: ignore[assignment]
                if stale_job.kind == "training":
                    payload = json.loads(stale_job.payload_json or "{}")
                    run_id = payload.get("run_id")
                    if run_id:
                        run = session.query(TrainingRunModel).filter_by(run_id=run_id).first()
                        if run is not None:
                            run.status = "failed"  # type: ignore[assignment]
                            run.error = str(stale_job.last_error)  # type: ignore[assignment]
                            run.completed_at = now  # type: ignore[assignment]
            query = session.query(JobModel).filter(
                JobModel.attempts < JobModel.max_attempts,
                JobModel.available_at <= now,
                or_(
                    JobModel.status == "pending",
                    and_(JobModel.status == "running", stale_lock_filter),
                ),
            )
            if kinds:
                query = query.filter(JobModel.kind.in_(kinds))
            model = (
                query.order_by(JobModel.priority.desc(), JobModel.created_at.asc())
                .with_for_update(skip_locked=True)
                .first()
            )
            if model is None:
                session.commit()
                return None
            model.status = "running"  # type: ignore[assignment]
            model.locked_at = now  # type: ignore[assignment]
            model.locked_by = worker_id  # type: ignore[assignment]
            model.attempts = int(model.attempts) + 1  # type: ignore[assignment]
            session.commit()
            session.refresh(model)
            return model

    def complete_job(self, job_id: str, result: dict[str, Any] | None = None) -> JobModel | None:
        with self._session() as session:
            model = session.query(JobModel).filter_by(job_id=job_id).first()
            if model is None:
                return None
            model.status = "completed"  # type: ignore[assignment]
            model.result_json = json.dumps(result or {}, ensure_ascii=False, default=str)  # type: ignore[assignment]
            model.completed_at = _utcnow()  # type: ignore[assignment]
            model.last_error = None  # type: ignore[assignment]
            model.locked_at = None  # type: ignore[assignment]
            model.locked_by = None  # type: ignore[assignment]
            session.commit()
            session.refresh(model)
            return model

    def fail_job(self, job_id: str, error: str, retry_delay_sec: int = 30) -> JobModel | None:
        with self._session() as session:
            model = session.query(JobModel).filter_by(job_id=job_id).first()
            if model is None:
                return None
            model.last_error = error  # type: ignore[assignment]
            model.locked_at = None  # type: ignore[assignment]
            model.locked_by = None  # type: ignore[assignment]
            if int(model.attempts) >= int(model.max_attempts):
                model.status = "failed"  # type: ignore[assignment]
                model.completed_at = _utcnow()  # type: ignore[assignment]
            else:
                model.status = "pending"  # type: ignore[assignment]
                model.available_at = _utcnow() + datetime.timedelta(  # type: ignore[assignment]
                    seconds=retry_delay_sec
                )
            session.commit()
            session.refresh(model)
            return model

    def schedule_due_monitoring(self, limit: int = 100) -> int:
        now = _utcnow()
        scheduled = 0
        with self._session() as session:
            systems = (
                session.query(SystemModel)
                .filter(
                    SystemModel.monitoring_active.is_(True),
                    or_(SystemModel.next_monitor_at.is_(None), SystemModel.next_monitor_at <= now),
                )
                .order_by(SystemModel.next_monitor_at.asc())
                .with_for_update(skip_locked=True)
                .limit(limit)
                .all()
            )
            for system in systems:
                existing_job = (
                    session.query(JobModel)
                    .filter(
                        JobModel.kind == "monitoring",
                        JobModel.system_id == system.system_id,
                        JobModel.status.in_(("pending", "running")),
                    )
                    .first()
                )
                if existing_job is not None:
                    continue
                interval = self._monitoring_interval_for_system(session, system)
                bucket = int(now.timestamp()) // interval
                job = JobModel(
                    job_id=str(uuid.uuid4()),
                    kind="monitoring",
                    system_id=system.system_id,
                    payload_json=json.dumps({"system_id": system.system_id}),
                    status="pending",
                    max_attempts=3,
                    available_at=now,
                    dedupe_key=f"monitoring:{system.system_id}:{bucket}",
                    created_at=now,
                )
                session.add(job)
                system.next_monitor_at = now + datetime.timedelta(seconds=interval)  # type: ignore[assignment]
                scheduled += 1
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
            return scheduled

    def schedule_due_gate_recalibrations(
        self, limit: int = 100, *, interval_sec: int | None = None
    ) -> int:
        """Enfileira ``recalibrate_gate`` para sistemas com calibração vencida.

        Um sistema é elegível quando possui calibração ativa cuja linha mais
        antiga tem ``fitted_at`` anterior a ``now - interval_sec`` e está com
        monitoramento ativo. Dedupe por janela via ``dedupe_key``.
        """
        from src.store.models import GateThresholdModel

        if interval_sec is None:
            from src.infra.settings import get_settings

            interval_sec = int(get_settings().gate_recalibration_interval_sec)
        interval = max(60, int(interval_sec))
        now = _utcnow()
        horizon = now - datetime.timedelta(seconds=interval)
        scheduled = 0
        with self._session() as session:
            rows = (
                session.query(
                    GateThresholdModel.system_id,
                    func.min(GateThresholdModel.fitted_at),
                )
                .join(SystemModel, SystemModel.system_id == GateThresholdModel.system_id)
                .filter(
                    GateThresholdModel.active.is_(True),
                    SystemModel.monitoring_active.is_(True),
                )
                .group_by(GateThresholdModel.system_id)
                .having(func.min(GateThresholdModel.fitted_at) <= horizon)
                .limit(limit)
                .all()
            )
            bucket = int(now.timestamp()) // interval
            for system_id, _oldest in rows:
                job = JobModel(
                    job_id=str(uuid.uuid4()),
                    kind="recalibrate_gate",
                    system_id=str(system_id),
                    payload_json=json.dumps({"system_id": str(system_id)}),
                    status="pending",
                    max_attempts=3,
                    available_at=now,
                    dedupe_key=f"recalibrate_gate:{system_id}:{bucket}",
                    created_at=now,
                )
                session.add(job)
                scheduled += 1
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                return 0
        return scheduled

    def _monitoring_interval_for_system(self, session: Session, system: SystemModel) -> int:
        interval = int(system.polling_interval_sec or 300)
        collection_id = None
        if system.active_run_id:
            run = session.query(TrainingRunModel).filter_by(run_id=system.active_run_id).first()
            collection_id = run.collection_id if run is not None else None
        if not collection_id and system.engine_config:
            try:
                engine_config = json.loads(str(system.engine_config))
                collection_id = engine_config.get("collection_id")
            except (json.JSONDecodeError, TypeError):
                collection_id = None
        if not collection_id:
            profiles = session.query(ProfileModel).filter_by(system_id=system.system_id, active=True).first()
            if profiles and profiles.stage1_run_id:
                run = session.query(TrainingRunModel).filter_by(run_id=profiles.stage1_run_id).first()
                collection_id = run.collection_id if run is not None else None
        if collection_id:
            collection = session.query(CollectionModel).filter_by(collection_id=collection_id).first()
            if collection is not None:
                interval = int(collection.package_window_seconds or interval)
        return max(10, interval)

    def mark_monitoring_cycle_finished(self, system_id: str) -> None:
        now = _utcnow()
        with self._session() as session:
            system = session.query(SystemModel).filter_by(system_id=system_id).first()
            if system is None or not system.monitoring_active:
                return
            interval = self._monitoring_interval_for_system(session, system)
            system.next_monitor_at = now + datetime.timedelta(seconds=interval)  # type: ignore[assignment]
            session.commit()

    # --- Monitoring Logs ---

    def create_monitoring_log(self, log: dict[str, Any]) -> MonitoringLogModel:
        with self._session() as session:
            safe = dict(log)
            safe.setdefault("log_id", str(uuid.uuid4()))
            for key in ("collected_at", "window_start", "window_end"):
                if key in safe:
                    safe[key] = _parse_datetime(safe[key])
            if isinstance(safe.get("contract_json"), dict):
                safe["contract_json"] = json.dumps(safe["contract_json"], ensure_ascii=False, default=str)
            if "steps" in safe and "steps_json" not in safe:
                safe["steps_json"] = json.dumps(safe.pop("steps"), ensure_ascii=False, default=str)
            model = MonitoringLogModel(**safe)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def save_monitoring_log(self, log: dict[str, Any]) -> MonitoringLogModel:
        return self.create_monitoring_log(log)

    def list_monitoring_logs(
        self, system_id: str, limit: int = 50, offset: int = 0, anomaly_only: bool = False
    ) -> tuple[list[MonitoringLogModel], int]:
        with self._session() as session:
            query = session.query(MonitoringLogModel).filter_by(system_id=system_id)
            if anomaly_only:
                query = query.filter_by(stage1_result="anomalous")
            total = query.count()
            logs = query.order_by(MonitoringLogModel.collected_at.desc()).offset(offset).limit(limit).all()
            return list(logs), total

    def get_monitoring_log(self, log_id: str) -> MonitoringLogModel | None:
        with self._session() as session:
            return session.query(MonitoringLogModel).filter_by(log_id=log_id).first()

    # --- Gate de confiança calibrado ---

    def save_gate_calibration(
        self,
        system_id: str,
        run_id: str | None,
        calibration: "GateCalibration",
    ) -> GateThresholdModel:
        """Persiste uma calibração e desativa a anterior do mesmo par."""
        from src.store.models import GateThresholdModel

        with self._session() as session:
            query = session.query(GateThresholdModel).filter_by(
                system_id=system_id, active=True
            )
            if run_id is not None:
                query = query.filter_by(run_id=run_id)
            for row in query.all():
                row.active = False
            model = GateThresholdModel(
                id=str(uuid.uuid4()),
                system_id=system_id,
                run_id=run_id,
                ref_class=calibration.ref_class,
                alpha=calibration.alpha,
                min_samples=calibration.min_samples,
                payload=json.dumps(calibration.to_dict(), ensure_ascii=False),
                fitted_at=_parse_datetime(calibration.fitted_at)
                or datetime.datetime.now(datetime.UTC).replace(tzinfo=None),
                active=True,
            )
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def list_gate_calibrations(self, system_id: str) -> list[GateThresholdModel]:
        from src.store.models import GateThresholdModel

        with self._session() as session:
            rows = (
                session.query(GateThresholdModel)
                .filter_by(system_id=system_id)
                .order_by(GateThresholdModel.fitted_at.desc())
                .all()
            )
            result: list[GateThresholdModel] = []
            for row in rows:
                row.payload = json.loads(row.payload) if isinstance(row.payload, str) else row.payload
                result.append(row)
            return result

    def get_active_gate_calibration(
        self, system_id: str, run_id: str | None = None
    ) -> GateThresholdModel | None:
        from src.store.models import GateThresholdModel

        with self._session() as session:
            query = session.query(GateThresholdModel).filter_by(
                system_id=system_id, active=True
            )
            if run_id is not None:
                exact = query.filter_by(run_id=run_id).order_by(
                    GateThresholdModel.fitted_at.desc()
                ).first()
                if exact is not None:
                    exact.payload = (
                        json.loads(exact.payload)
                        if isinstance(exact.payload, str)
                        else exact.payload
                    )
                    return exact
            row = query.order_by(GateThresholdModel.fitted_at.desc()).first()
            if row is not None:
                row.payload = (
                    json.loads(row.payload)
                    if isinstance(row.payload, str)
                    else row.payload
                )
            return row

    # --- Incidents ---

    def create_incident(self, incident: dict[str, Any]) -> IncidentModel:
        with self._session() as session:
            safe = dict(incident)
            safe.setdefault("incident_id", str(uuid.uuid4()))
            for key in ("created_at", "updated_at", "resolved_at", "known_at"):
                if key in safe:
                    safe[key] = _parse_datetime(safe[key])
            if isinstance(safe.get("log_ids"), list) and "log_ids_json" not in safe:
                safe["log_ids_json"] = json.dumps(safe.pop("log_ids"), ensure_ascii=False, default=str)
            if isinstance(safe.get("evidence_ids"), list) and "evidence_ids_json" not in safe:
                safe["evidence_ids_json"] = json.dumps(
                    safe.pop("evidence_ids"), ensure_ascii=False, default=str
                )
            model = IncidentModel(**safe)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def list_incidents(
        self,
        system_id: str,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[IncidentModel], int]:
        with self._session() as session:
            query = session.query(IncidentModel).filter_by(system_id=system_id)
            if status:
                query = query.filter_by(status=status)
            total = query.count()
            rows = (
                query.order_by(IncidentModel.created_at.desc())
                .offset(offset)
                .limit(limit)
                .all()
            )
            return list(rows), total

    def get_incident(self, system_id: str, incident_id: str) -> IncidentModel | None:
        with self._session() as session:
            return (
                session.query(IncidentModel)
                .filter_by(system_id=system_id, incident_id=incident_id)
                .first()
            )

    def update_incident(
        self,
        system_id: str,
        incident_id: str,
        updates: dict[str, Any],
    ) -> IncidentModel | None:
        allowed = {
            "status", "notes", "resolved_at", "known_at", "updated_at",
            "hypothesis", "confidence", "referencia_collection_id",
        }
        with self._session() as session:
            model = (
                session.query(IncidentModel)
                .filter_by(system_id=system_id, incident_id=incident_id)
                .first()
            )
            if model is None:
                return None
            safe = {k: v for k, v in updates.items() if k in allowed}
            if "hypothesis" in safe:
                system = session.query(SystemModel).filter_by(system_id=system_id).first()
                ref_class = system.ref_class if system else None
                safe["hypothesis"] = canonical_label(safe.get("hypothesis"), ref_class=ref_class)
            now = _utcnow()
            safe["updated_at"] = safe.get("updated_at") or now
            status = safe.get("status")
            if status in {"resolved", "closed", "concluded"} and not safe.get("resolved_at"):
                safe["resolved_at"] = now
            if status == "known" and not safe.get("known_at"):
                safe["known_at"] = now
            for key in ("resolved_at", "known_at", "updated_at"):
                if key in safe:
                    safe[key] = _parse_datetime(safe[key])
            for key, value in safe.items():
                setattr(model, key, value)
            session.commit()
            session.refresh(model)
            return model

    def has_active_incident(self, system_id: str, hypothesis: str | None = None) -> bool:
        with self._session() as session:
            query = (
                session.query(IncidentModel)
                .filter(IncidentModel.system_id == system_id)
                .filter(~IncidentModel.status.in_(INACTIVE_INCIDENT_STATUSES))
            )
            if hypothesis is not None:
                query = query.filter(IncidentModel.hypothesis == hypothesis)
            return query.first() is not None

    def maybe_open_incident_for_recent_anomalies(
        self,
        system_id: str,
        *,
        threshold: int = 3,
    ) -> IncidentModel | None:
        with self._session() as session:
            logs = (
                session.query(MonitoringLogModel)
                .filter_by(system_id=system_id)
                .order_by(MonitoringLogModel.collected_at.desc())
                .limit(threshold)
                .all()
            )
            if len(logs) < threshold:
                return None
            if any(log.stage1_result != "anomalous" for log in logs):
                return None
            current = logs[0]
            system = session.query(SystemModel).filter_by(system_id=system_id).first()
            ref_class = system.ref_class if system else None
            current_hypothesis = canonical_label(current.primary_hypothesis, ref_class=ref_class)
            if is_baseline_label(current_hypothesis, ref_class=ref_class):
                return None
            duplicate = (
                session.query(IncidentModel)
                .filter(IncidentModel.system_id == system_id)
                .filter(~IncidentModel.status.in_(INACTIVE_INCIDENT_STATUSES))
                .filter(IncidentModel.hypothesis == current_hypothesis)
                .first()
            )
            if duplicate is not None:
                return None
            active_profile = (
                session.query(ProfileModel)
                .filter_by(system_id=system_id, active=True)
                .first()
            )
            active_profile_id = active_profile.profile_id if active_profile else None
            active_engine = (
                (active_profile.stage1_engine or active_profile.engine_type)
                if active_profile else "monitor"
            )
            now = _utcnow()
            # Spec 29.4/33: a janela do incidente é min(window_start)..max(window_end) dos logs
            # que o originaram, sem buffer — é exatamente o intervalo que o Stage 3 consulta no
            # Jaeger. Logs sem janela (legado) caem no instante da detecção ± a janela do pacote.
            starts: list[datetime.datetime] = [
                log.window_start for log in logs if log.window_start is not None  # type: ignore[misc]
            ]
            ends: list[datetime.datetime] = [
                log.window_end for log in logs if log.window_end is not None  # type: ignore[misc]
            ]
            incident_start: datetime.datetime
            incident_end: datetime.datetime
            if starts and ends:
                incident_start, incident_end = min(starts), max(ends)
            else:
                fallback_sec = int(current.package_window_seconds or 60)
                incident_start = now - datetime.timedelta(seconds=fallback_sec)
                incident_end = now
            llm_row = session.query(LLMConfigModel).filter_by(id="global").first()
            profile_snapshot = _profile_snapshot(
                active_profile,
                llm_provider=str(llm_row.provider) if llm_row else None,
                llm_model=str(llm_row.model) if llm_row else None,
                captured_at=now,
            )
            model = IncidentModel(
                incident_id=str(uuid.uuid4()),
                system_id=system_id,
                monitoring_log_id=current.log_id,
                evidence_id=current.evidence_id,
                profile_id=active_profile_id,
                engine_type=active_engine,
                stage1_result=current.stage1_result,
                hypothesis=current_hypothesis,
                confidence=current.confidence,
                status="open",
                opened_reason=f"{threshold} anomalias seguidas no monitoramento",
                consecutive_anomalies=threshold,
                log_ids_json=json.dumps([log.log_id for log in logs], ensure_ascii=False),
                # Spec 33: vincula os evidence packages que originaram o incidente
                evidence_ids_json=json.dumps(
                    [log.evidence_id for log in logs if log.evidence_id],
                    ensure_ascii=False,
                ),
                window_start=incident_start,
                window_end=incident_end,
                profile_snapshot_json=json.dumps(profile_snapshot, ensure_ascii=False),
                created_at=now,
                updated_at=now,
            )
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def capture_profile_snapshot(self, system_id: str, source: str = "stage3_start") -> dict[str, Any]:
        """Perfil ativo agora, sem chaves de API — para incidentes sem `profile_snapshot_json`."""
        with self._session() as session:
            profile = session.query(ProfileModel).filter_by(system_id=system_id, active=True).first()
            llm_row = session.query(LLMConfigModel).filter_by(id="global").first()
            return _profile_snapshot(
                profile,
                llm_provider=str(llm_row.provider) if llm_row else None,
                llm_model=str(llm_row.model) if llm_row else None,
                captured_at=_utcnow(),
                source=source,
            )

    # --- Stage 3: baseline da coleção ---

    def get_collection_baseline(self, collection_id: str) -> CollectionBaselineModel | None:
        with self._session() as session:
            return session.query(CollectionBaselineModel).filter_by(collection_id=collection_id).first()

    def create_or_replace_collection_baseline(
        self, collection_id: str, system_id: str, job_id: str | None = None
    ) -> CollectionBaselineModel:
        with self._session() as session:
            session.query(CollectionBaselineModel).filter_by(collection_id=collection_id).delete(
                synchronize_session=False
            )
            model = CollectionBaselineModel(
                baseline_id=str(uuid.uuid4()),
                collection_id=collection_id,
                system_id=system_id,
                job_id=job_id,
                status="pending",
                created_at=_utcnow(),
            )
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def _update_baseline(self, baseline_id: str, updates: dict[str, Any]) -> CollectionBaselineModel:
        with self._session() as session:
            model = session.query(CollectionBaselineModel).filter_by(baseline_id=baseline_id).first()
            if model is None:
                raise ValueError(f"baseline not found: {baseline_id}")
            for key, value in updates.items():
                setattr(model, key, value)
            session.commit()
            session.refresh(model)
            return model

    def mark_trace_baseline(
        self, baseline_id: str, status: str, error: str | None = None
    ) -> CollectionBaselineModel:
        return self._update_baseline(baseline_id, {"trace_status": status, "trace_error": error})

    def mark_baseline_pending_job(self, baseline_id: str, job_id: str) -> CollectionBaselineModel:
        return self._update_baseline(baseline_id, {"job_id": job_id})

    def mark_baseline_running(self, baseline_id: str, job_id: str | None = None) -> CollectionBaselineModel:
        updates: dict[str, Any] = {"status": "running", "error_message": None}
        if job_id:
            updates["job_id"] = job_id
        return self._update_baseline(baseline_id, updates)

    def mark_baseline_completed(
        self, baseline_id: str, metric_stats: dict[str, Any], n_samples: int
    ) -> CollectionBaselineModel:
        return self._update_baseline(baseline_id, {
            "status": "completed",
            "metric_stats": metric_stats,
            "n_samples": n_samples,
            "error_message": None,
            "computed_at": _utcnow(),
            "completed_at": _utcnow(),
        })

    def mark_baseline_failed(self, baseline_id: str, error: str) -> CollectionBaselineModel:
        return self._update_baseline(baseline_id, {
            "status": "failed",
            "error_message": error,
            "completed_at": _utcnow(),
        })

    def update_baseline_trace_artifacts(
        self,
        baseline_id: str,
        process_models: dict[str, str],
        span_stats: dict[str, Any],
        service_graph: dict[str, Any] | None = None,
        process_graphs: dict[str, Any] | None = None,
        service_stats: dict[str, Any] | None = None,
    ) -> CollectionBaselineModel:
        updates: dict[str, Any] = {
            "process_models": process_models, "span_stats": span_stats,
            "trace_status": "completed", "trace_error": None,
        }
        if service_graph is not None:
            updates["service_graph"] = service_graph
        if process_graphs is not None:
            updates["process_graphs"] = process_graphs
        if service_stats is not None:
            updates["service_stats"] = service_stats
        return self._update_baseline(baseline_id, updates)

    # --- Stage 3: leituras de monitoring logs / incidente ---

    def get_monitoring_logs(self, log_ids: list[str]) -> list[MonitoringLogModel]:
        """Logs pedidos em ordem cronológica (window_start, depois collected_at)."""
        if not log_ids:
            return []
        with self._session() as session:
            rows = session.query(MonitoringLogModel).filter(MonitoringLogModel.log_id.in_(log_ids)).all()
            return sorted(rows, key=lambda r: (r.window_start or r.collected_at, r.collected_at))

    def get_incident_window(self, incident_id: str) -> tuple[datetime.datetime, datetime.datetime] | None:
        with self._session() as session:
            row = session.query(IncidentModel).filter_by(incident_id=incident_id).first()
            if row is None or row.window_start is None or row.window_end is None:
                return None
            return row.window_start, row.window_end  # type: ignore[return-value]

    def list_monitoring_logs_before(
        self, system_id: str, run_id: str | None, before: datetime.datetime, limit: int
    ) -> list[MonitoringLogModel]:
        """Até `limit` logs com window_end anterior ou igual a `before`, mais recentes primeiro."""
        with self._session() as session:
            query = session.query(MonitoringLogModel).filter_by(system_id=system_id)
            if run_id:
                query = query.filter_by(run_id=run_id)
            query = query.filter(
                func.coalesce(MonitoringLogModel.window_end, MonitoringLogModel.collected_at) <= before
            )
            return list(
                query.order_by(
                    func.coalesce(MonitoringLogModel.window_end, MonitoringLogModel.collected_at).desc()
                )
                .limit(limit)
                .all()
            )

    def list_monitoring_logs_in_window(
        self, system_id: str, window_start: datetime.datetime, window_end: datetime.datetime
    ) -> list[MonitoringLogModel]:
        """Logs cujo `window_end` (ou `collected_at`, se ausente) cai em `[window_start, window_end]`,
        em ordem cronológica -- mesmo uso do Stage 3 real (`run.logs`), mas sem um incidente
        persistido por trás (monitoramento online, spec de melhoria 21/09/2026)."""
        with self._session() as session:
            ts = func.coalesce(MonitoringLogModel.window_end, MonitoringLogModel.collected_at)
            rows = (
                session.query(MonitoringLogModel)
                .filter_by(system_id=system_id)
                .filter(ts >= window_start, ts <= window_end)
                .order_by(ts.asc())
                .all()
            )
            return list(rows)

    # --- Stage 3: diagnóstico ---

    def create_stage3_diagnosis(
        self, incident_id: str, system_id: str, job_id: str | None = None
    ) -> Stage3DiagnosisModel:
        with self._session() as session:
            model = Stage3DiagnosisModel(
                diagnosis_id=str(uuid.uuid4()),
                incident_id=incident_id,
                system_id=system_id,
                job_id=job_id,
                status="pending",
                created_at=_utcnow(),
            )
            session.add(model)
            session.commit()  # IntegrityError se o incidente já tem diagnóstico
            session.refresh(model)
            return model

    def get_stage3_diagnosis(self, incident_id: str) -> Stage3DiagnosisModel | None:
        with self._session() as session:
            return session.query(Stage3DiagnosisModel).filter_by(incident_id=incident_id).first()

    def _apply_stage3_fields(
        self, model: Stage3DiagnosisModel, fields: dict[str, Any], *, strict: bool
    ) -> None:
        valid = {c.name for c in Stage3DiagnosisModel.__table__.columns}
        protected = {"diagnosis_id", "incident_id", "system_id", "audit_package", "audit_sha256",
                     "audit_created_at", "review_status", "review_reason", "review_actual_entity",
                     "reviewed_at"}
        for key, value in fields.items():
            if key not in valid or key in protected:
                if strict:
                    raise ValueError(f"campo nao atualizavel: {key}")
                continue
            setattr(model, key, value)

    def update_stage3_diagnosis(self, diagnosis_id: str, **fields: Any) -> Stage3DiagnosisModel:
        with self._session() as session:
            model = session.query(Stage3DiagnosisModel).filter_by(diagnosis_id=diagnosis_id).first()
            if model is None:
                raise ValueError(f"stage3 diagnosis not found: {diagnosis_id}")
            self._apply_stage3_fields(model, fields, strict=True)
            session.commit()
            session.refresh(model)
            return model

    def _finish_stage3(
        self,
        diagnosis_id: str,
        status: str,
        fields: dict[str, Any],
        audit_package: dict[str, Any] | None,
        audit_sha256: str | None,
    ) -> Stage3DiagnosisModel:
        """Resultado + pacote de auditoria na mesma transação."""
        with self._session() as session:
            model = session.query(Stage3DiagnosisModel).filter_by(diagnosis_id=diagnosis_id).first()
            if model is None:
                raise ValueError(f"stage3 diagnosis not found: {diagnosis_id}")
            self._apply_stage3_fields(model, fields, strict=False)
            model.status = status  # type: ignore[assignment]
            model.completed_at = _utcnow()  # type: ignore[assignment]
            if audit_package is not None:
                if model.audit_package is not None:
                    raise ValueError("audit package already exists for this diagnosis")
                model.audit_package = audit_package
                model.audit_sha256 = audit_sha256
                model.audit_created_at = _utcnow()
            session.commit()
            session.refresh(model)
            return model

    def mark_stage3_completed(
        self,
        diagnosis_id: str,
        result: dict[str, Any],
        *,
        audit_package: dict[str, Any] | None = None,
        audit_sha256: str | None = None,
    ) -> Stage3DiagnosisModel:
        return self._finish_stage3(diagnosis_id, "completed", result, audit_package, audit_sha256)

    def mark_stage3_abstained(
        self,
        diagnosis_id: str,
        abstain_reason: str,
        result: dict[str, Any] | None = None,
        *,
        audit_package: dict[str, Any] | None = None,
        audit_sha256: str | None = None,
    ) -> Stage3DiagnosisModel:
        fields = dict(result or {})
        fields["abstain_reason"] = abstain_reason
        return self._finish_stage3(diagnosis_id, "abstained", fields, audit_package, audit_sha256)

    def mark_stage3_failed(self, diagnosis_id: str, error: str) -> Stage3DiagnosisModel:
        with self._session() as session:
            model = session.query(Stage3DiagnosisModel).filter_by(diagnosis_id=diagnosis_id).first()
            if model is None:
                raise ValueError(f"stage3 diagnosis not found: {diagnosis_id}")
            model.status = "failed"  # type: ignore[assignment]
            model.error_message = error  # type: ignore[assignment]
            model.completed_at = _utcnow()  # type: ignore[assignment]
            session.commit()
            session.refresh(model)
            return model

    # --- Stage 3: pacote de auditoria e revisão ---

    def save_stage3_audit_package(
        self, diagnosis_id: str, package: dict[str, Any], sha256: str
    ) -> Stage3DiagnosisModel:
        with self._session() as session:
            model = session.query(Stage3DiagnosisModel).filter_by(diagnosis_id=diagnosis_id).first()
            if model is None:
                raise ValueError(f"stage3 diagnosis not found: {diagnosis_id}")
            if model.audit_package is not None:
                raise ValueError("audit package already exists for this diagnosis")
            model.audit_package = package
            model.audit_sha256 = sha256
            model.audit_created_at = _utcnow()
            session.commit()
            session.refresh(model)
            return model

    def get_stage3_audit_package(self, incident_id: str) -> dict[str, Any] | None:
        with self._session() as session:
            model = session.query(Stage3DiagnosisModel).filter_by(incident_id=incident_id).first()
            if model is None or model.audit_package is None:
                return None
            return {
                "package": model.audit_package,
                "sha256": model.audit_sha256,
                "created_at": _iso_utc(model.audit_created_at),  # type: ignore[arg-type]
                "review": {
                    "status": model.review_status,
                    "reason": model.review_reason,
                    "actual_entity": model.review_actual_entity,
                    "reviewed_at": _iso_utc(model.reviewed_at),  # type: ignore[arg-type]
                },
            }

    def submit_stage3_review(
        self, incident_id: str, status: str, reason: str = "", actual_entity: str | None = None
    ) -> Stage3DiagnosisModel:
        if status not in {"confirmed", "rejected"}:
            raise ValueError(f"invalid review status: {status!r}, must be confirmed or rejected")
        with self._session() as session:
            model = session.query(Stage3DiagnosisModel).filter_by(incident_id=incident_id).first()
            if model is None or model.audit_package is None:
                raise ValueError("no audit package to review for this incident")
            if model.review_status in {"confirmed", "rejected"}:
                raise ValueError(f"diagnosis already reviewed with status: {model.review_status!r}")
            model.review_status = status  # type: ignore[assignment]
            model.review_reason = reason  # type: ignore[assignment]
            model.review_actual_entity = actual_entity  # type: ignore[assignment]
            model.reviewed_at = _utcnow()  # type: ignore[assignment]
            session.commit()
            session.refresh(model)
            return model

    # --- Stage 3: modos de decisão ---

    def create_stage3_abordagem(
        self, incident_id: str, system_id: str, modo: str, versao: str, job_id: str | None = None
    ) -> Stage3AbordagemModel:
        if modo not in MODOS_CONHECIDOS_STAGE3:
            raise ValueError(
                f"invalid stage3 mode: {modo!r}, "
                f"must be one of {sorted(MODOS_CONHECIDOS_STAGE3)}"
            )
        if self.get_stage3_abordagem(incident_id, modo) is not None:
            raise ValueError(f"stage3 abordagem already exists: {incident_id}/{modo}")
        with self._session() as session:
            model = Stage3AbordagemModel(
                abordagem_id=str(uuid.uuid4()),
                incident_id=incident_id,
                system_id=system_id,
                job_id=job_id,
                modo=modo,
                versao=versao,
                status="pending",
                created_at=_utcnow(),
            )
            session.add(model)
            try:
                session.commit()
            except IntegrityError as exc:
                # A UniqueConstraint e a ultima linha; a checagem acima e so para dar nome ao erro
                session.rollback()
                raise ValueError(
                    f"stage3 abordagem already exists: {incident_id}/{modo}"
                ) from exc
            session.refresh(model)
            return model

    def get_stage3_abordagem(self, incident_id: str, modo: str) -> Stage3AbordagemModel | None:
        with self._session() as session:
            return (
                session.query(Stage3AbordagemModel)
                .filter_by(incident_id=incident_id, modo=modo)
                .first()
            )

    def list_stage3_abordagens(self, incident_id: str) -> list[Stage3AbordagemModel]:
        with self._session() as session:
            return (
                session.query(Stage3AbordagemModel)
                .filter_by(incident_id=incident_id)
                .order_by(Stage3AbordagemModel.modo)
                .all()
            )

    def _apply_stage3_abordagem_fields(
        self, model: Stage3AbordagemModel, fields: dict[str, Any], *, strict: bool
    ) -> None:
        """Whitelist derivada das colunas + blacklist do que e write-once.

        `audit_*` fica fora de propósito: pacote de auditoria e imutavel depois de gravado, entao
        ele so entra por `mark_stage3_abordagem_{completed,abstained}`.
        """
        valid = {c.name for c in Stage3AbordagemModel.__table__.columns}
        protected = {"abordagem_id", "incident_id", "modo", "audit_package", "audit_sha256",
                     "audit_created_at"}
        for key, value in fields.items():
            if key not in valid or key in protected:
                if strict:
                    raise ValueError(f"campo nao atualizavel: {key}")
                continue
            setattr(model, key, value)

    def update_stage3_abordagem(self, abordagem_id: str, **fields: Any) -> Stage3AbordagemModel:
        with self._session() as session:
            model = (
                session.query(Stage3AbordagemModel).filter_by(abordagem_id=abordagem_id).first()
            )
            if model is None:
                raise ValueError(f"stage3 abordagem not found: {abordagem_id}")
            if model.status in STATUS_TERMINAIS_STAGE3:
                raise ValueError(
                    f"stage3 abordagem {abordagem_id} ja esta em status terminal {model.status!r}"
                    f" e nao aceita atualizacao"
                )
            self._apply_stage3_abordagem_fields(model, fields, strict=True)
            session.commit()
            session.refresh(model)
            return model

    def _finish_stage3_abordagem(
        self,
        abordagem_id: str,
        status: str,
        fields: dict[str, Any],
        audit_package: dict[str, Any] | None,
        audit_sha256: str | None,
    ) -> Stage3AbordagemModel:
        """Resultado + pacote de auditoria na mesma transacao (como `_finish_stage3`).

        Status terminal e imutavel. Sem essa trava, um re-run do job sobrescreve `ranking` e
        `completed_at` de uma decisao ja registrada, e o `audit_package` que existia passa a
        descrever um resultado que ja nao esta na linha -- o pacote vira prova de outra coisa.
        """
        with self._session() as session:
            model = (
                session.query(Stage3AbordagemModel).filter_by(abordagem_id=abordagem_id).first()
            )
            if model is None:
                raise ValueError(f"stage3 abordagem not found: {abordagem_id}")
            if model.status in STATUS_TERMINAIS_STAGE3:
                raise ValueError(
                    f"stage3 abordagem {abordagem_id} ja esta em status terminal {model.status!r}"
                    f" e nao aceita novo resultado"
                )
            self._apply_stage3_abordagem_fields(model, fields, strict=False)
            model.status = status  # type: ignore[assignment]
            model.completed_at = _utcnow()  # type: ignore[assignment]
            if audit_package is not None:
                if model.audit_package is not None:
                    raise ValueError("audit package already exists for this approach")
                model.audit_package = audit_package
                model.audit_sha256 = audit_sha256
                model.audit_created_at = _utcnow()
            session.commit()
            session.refresh(model)
            return model

    def mark_stage3_abordagem_completed(
        self,
        abordagem_id: str,
        resultado: dict[str, Any],
        *,
        audit_package: dict[str, Any] | None = None,
        audit_sha256: str | None = None,
    ) -> Stage3AbordagemModel:
        return self._finish_stage3_abordagem(
            abordagem_id, "completed", resultado, audit_package, audit_sha256
        )

    def mark_stage3_abordagem_abstained(
        self,
        abordagem_id: str,
        motivo: str,
        resultado: dict[str, Any] | None = None,
        *,
        audit_package: dict[str, Any] | None = None,
        audit_sha256: str | None = None,
    ) -> Stage3AbordagemModel:
        fields = dict(resultado or {})
        fields["motivo_abstencao"] = motivo
        return self._finish_stage3_abordagem(
            abordagem_id, "abstained", fields, audit_package, audit_sha256
        )

    def mark_stage3_abordagem_failed(
        self, abordagem_id: str, error: str
    ) -> Stage3AbordagemModel:
        # `failed` nunca tem pacote de auditoria: o pacote e a prova de uma decisao, nao de um erro
        with self._session() as session:
            model = (
                session.query(Stage3AbordagemModel).filter_by(abordagem_id=abordagem_id).first()
            )
            if model is None:
                raise ValueError(f"stage3 abordagem not found: {abordagem_id}")
            if model.status in STATUS_TERMINAIS_STAGE3:
                raise ValueError(
                    f"stage3 abordagem {abordagem_id} ja esta em status terminal {model.status!r}"
                    f" e nao aceita falhar depois"
                )
            model.status = "failed"  # type: ignore[assignment]
            model.error_message = error  # type: ignore[assignment]
            model.completed_at = _utcnow()  # type: ignore[assignment]
            session.commit()
            session.refresh(model)
            return model

    def save_stage3_abordagem_audit_package(
        self, abordagem_id: str, package: dict[str, Any], sha256: str
    ) -> Stage3AbordagemModel:
        with self._session() as session:
            model = (
                session.query(Stage3AbordagemModel).filter_by(abordagem_id=abordagem_id).first()
            )
            if model is None:
                raise ValueError(f"stage3 abordagem not found: {abordagem_id}")
            if model.audit_package is not None:
                raise ValueError("audit package already exists for this approach")
            model.audit_package = package
            model.audit_sha256 = sha256
            model.audit_created_at = _utcnow()
            session.commit()
            session.refresh(model)
            return model

    def get_stage3_abordagem_audit_package(self, incident_id: str, modo: str) -> dict[str, Any] | None:
        model = self.get_stage3_abordagem(incident_id, modo)
        if model is None or model.audit_package is None:
            return None
        return {
            "package": model.audit_package,
            "sha256": model.audit_sha256,
            "created_at": _iso_utc(model.audit_created_at),  # type: ignore[arg-type]
        }

    def update_baseline_abordagens(
        self, baseline_id: str, abordagens: dict[str, Any] | None = None,
        abordagens_status: dict[str, Any] | None = None,
    ) -> CollectionBaselineModel:
        """Grava artefato e/ou status dos modos, sem tocar no resto da linha do baseline."""
        updates: dict[str, Any] = {}
        if abordagens is not None:
            updates["abordagens"] = abordagens
        if abordagens_status is not None:
            updates["abordagens_status"] = abordagens_status
        return self._update_baseline(baseline_id, updates)

    # --- Contracts ---

    def list_contracts(self) -> list[dict[str, Any]]:
        with self._session() as session:
            rows = (
                session.query(
                    MonitoringLogModel.contract_id,
                    MonitoringLogModel.contract_json,
                    MonitoringLogModel.system_id,
                    MonitoringLogModel.collected_at,
                )
                .distinct()
                .all()
            )
            seen: set[str] = set()
            contracts: list[dict[str, Any]] = []
            for row in rows:
                if row.contract_id and row.contract_id not in seen:
                    seen.add(row.contract_id)
                    contract_json_str = str(row.contract_json) if row.contract_json else "{}"
                    contracts.append({
                        "contract_id": row.contract_id,
                        "contract_json": json.loads(contract_json_str),
                        "system_id": row.system_id,
                        "collected_at": row.collected_at.isoformat() if row.collected_at else "",
                    })
            return contracts

    def get_contract(self, contract_id: str) -> dict[str, Any] | None:
        with self._session() as session:
            row = (
                session.query(MonitoringLogModel)
                .filter_by(contract_id=contract_id)
                .order_by(MonitoringLogModel.collected_at.desc())
                .first()
            )
            if row is None:
                return None
            contract_json_str = str(row.contract_json) if row.contract_json else "{}"
            return {
                "contract_id": row.contract_id,
                "contract_json": json.loads(contract_json_str),
                "system_id": row.system_id,
                "collected_at": row.collected_at.isoformat() if row.collected_at else "",
                "stage1_result": row.stage1_result,
                "primary_hypothesis": row.primary_hypothesis,
                "confidence": row.confidence,
            }

    def update_contract(self, contract_id: str, updates: dict[str, Any]) -> dict[str, Any] | None:
        with self._session() as session:
            rows = (
                session.query(MonitoringLogModel)
                .filter_by(contract_id=contract_id)
                .all()
            )
            if not rows:
                return None
            if "contract_json" in updates:
                contract_json_str = json.dumps(updates["contract_json"])
                for row in rows:
                    row.contract_json = contract_json_str  # type: ignore[assignment]
            session.commit()
            row = rows[0]
            updated_json_str = str(row.contract_json) if row.contract_json else "{}"
            return {
                "contract_id": row.contract_id,
                "contract_json": json.loads(updated_json_str),
                "system_id": row.system_id,
                "collected_at": row.collected_at.isoformat() if row.collected_at else "",
            }

    # --- Raw Collections ---

    def create_raw_collection(self, record: dict[str, Any]) -> RawCollectionModel:
        with self._session() as session:
            model = RawCollectionModel(**record)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_raw_collections(self, failure_id: str) -> list[RawCollectionModel]:
        with self._session() as session:
            return list(
                session.query(RawCollectionModel)
                .filter_by(failure_id=failure_id)
                .order_by(RawCollectionModel.source)
                .all()
            )

    def update_raw_collection(self, record_id: int, updates: dict[str, Any]) -> RawCollectionModel | None:
        with self._session() as session:
            model = session.query(RawCollectionModel).filter_by(id=record_id).first()
            if model is None:
                return None
            for key, value in updates.items():
                setattr(model, key, value)
            session.commit()
            session.refresh(model)
            return model

    def get_raw_collection_by_source(self, failure_id: str, source: str) -> RawCollectionModel | None:
        with self._session() as session:
            return (
                session.query(RawCollectionModel)
                .filter_by(failure_id=failure_id, source=source)
                .first()
            )

    def get_raw_collections_status(self, failure_id: str) -> dict[str, str]:
        with self._session() as session:
            rows = (
                session.query(RawCollectionModel.source, RawCollectionModel.status)
                .filter_by(failure_id=failure_id)
                .all()
            )
            return {row.source: row.status for row in rows}

    def delete_raw_collections(self, failure_id: str) -> bool:
        with self._session() as session:
            models = session.query(RawCollectionModel).filter_by(failure_id=failure_id).all()
            for m in models:
                session.delete(m)
            session.commit()
            return True

    def get_monitoring_status(self, system_id: str) -> dict[str, Any] | None:
        with self._session() as session:
            system = session.query(SystemModel).filter_by(system_id=system_id).first()
            if system is None:
                return None
            total_runs = (
                session.query(func.count(MonitoringLogModel.log_id))
                .filter_by(system_id=system_id)
                .scalar()
                or 0
            )
            anomalies = (
                session.query(func.count(MonitoringLogModel.log_id))
                .filter(
                    MonitoringLogModel.system_id == system_id,
                    MonitoringLogModel.stage1_result == "anomalous",
                )
                .scalar()
                or 0
            )
            last_run = (
                session.query(MonitoringLogModel)
                .filter_by(system_id=system_id)
                .order_by(MonitoringLogModel.collected_at.desc())
                .first()
            )
            return {
                "system_id": system_id,
                "monitoring_active": system.monitoring_active,
                "polling_interval_sec": system.polling_interval_sec,
                "last_run_at": _iso_utc(last_run.collected_at) if last_run else None,
                "last_result": last_run.stage1_result if last_run else None,
                "total_runs": total_runs,
            "anomalies_detected": anomalies,
        }

    # --- Partial Evidence Packages ---

    def save_partial_package(self, pkg: dict[str, Any]) -> PartialEvidencePackageModel:
        with self._session() as session:
            model = PartialEvidencePackageModel(**pkg)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def save_partial_packages(self, packages: list[dict[str, Any]]) -> list[PartialEvidencePackageModel]:
        with self._session() as session:
            models = [PartialEvidencePackageModel(**p) for p in packages]
            for m in models:
                session.add(m)
            session.commit()
            for m in models:
                session.refresh(m)
            return models

    def list_partial_packages(self, failure_id: str) -> list[PartialEvidencePackageModel]:
        with self._session() as session:
            return list(
                session.query(PartialEvidencePackageModel)
                .filter_by(failure_id=failure_id)
                .order_by(PartialEvidencePackageModel.chunk_index)
                .all()
            )

    def get_partial_package(self, pkg_id: int) -> PartialEvidencePackageModel | None:
        with self._session() as session:
            return session.query(PartialEvidencePackageModel).filter_by(id=pkg_id).first()

    def update_partial_package(self, pkg_id: int, updates: dict[str, Any]) -> PartialEvidencePackageModel | None:
        with self._session() as session:
            model = session.query(PartialEvidencePackageModel).filter_by(id=pkg_id).first()
            if model is None:
                return None
            for key, value in updates.items():
                setattr(model, key, value)
            model.updated_at = _utcnow()
            session.commit()
            session.refresh(model)
            return model

    def update_partial_package_validation(
        self,
        pkg_id: int,
        validation_status: str,
        validation_errors: list[str] | None = None,
    ) -> None:
        with self._session() as session:
            model = session.query(PartialEvidencePackageModel).filter_by(id=pkg_id).first()
            if model:
                model.validation_status = validation_status  # type: ignore[assignment]
                if validation_errors is not None:
                    model.validation_errors = json.dumps(validation_errors, ensure_ascii=False)
                model.updated_at = _utcnow()
                session.commit()

    def count_invalid_failures(self, system_id: str) -> int:
        with self._session() as session:
            return session.query(FailureModel).filter_by(
                system_id=system_id, validation_status="invalid"
            ).count()

    def get_partial_packages_status(self, failure_id: str) -> dict[str, int]:
        with self._session() as session:
            rows = (
                session.query(
                    PartialEvidencePackageModel.drain_status,
                    PartialEvidencePackageModel.id,
                )
                .filter_by(failure_id=failure_id)
                .all()
            )
            pending = sum(1 for r in rows if r.drain_status == "pending")
            processing = sum(1 for r in rows if r.drain_status == "processing")
            completed = sum(1 for r in rows if r.drain_status == "completed")
            failed = sum(1 for r in rows if r.drain_status == "failed")
            return {"pending": pending, "processing": processing, "completed": completed, "failed": failed}

    def delete_partial_packages(self, failure_id: str) -> None:
        with self._session() as session:
            session.query(PartialEvidencePackageModel).filter_by(failure_id=failure_id).delete()
            session.commit()

    # --- Monitoring Profiles ---

    def create_profile(self, profile: dict[str, Any]) -> ProfileModel:
        with self._session() as session:
            model = ProfileModel(**profile)
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_profile(self, system_id: str, profile_id: str) -> ProfileModel | None:
        with self._session() as session:
            return session.query(ProfileModel).filter_by(system_id=system_id, profile_id=profile_id).first()

    def list_profiles(self, system_id: str) -> list[ProfileModel]:
        with self._session() as session:
            return list(
                session.query(ProfileModel)
                .filter_by(system_id=system_id)
                .order_by(ProfileModel.created_at.asc())
                .all()
            )

    def update_profile(self, system_id: str, profile_id: str, updates: dict[str, Any]) -> ProfileModel | None:
        with self._session() as session:
            model = session.query(ProfileModel).filter_by(system_id=system_id, profile_id=profile_id).first()
            if model is None:
                return None
            for key, value in updates.items():
                setattr(model, key, value)
            model.updated_at = _utcnow()
            session.commit()
            session.refresh(model)
            return model

    def delete_profile(self, system_id: str, profile_id: str) -> bool:
        with self._session() as session:
            model = session.query(ProfileModel).filter_by(system_id=system_id, profile_id=profile_id).first()
            if model is None:
                return False
            session.delete(model)
            session.commit()
            return True

    # --- Version Contexts ---

    def save_version_context(self, record: dict[str, Any]) -> VersionContextModel:
        with self._session() as session:
            existing = session.query(VersionContextModel).filter_by(
                system_id=record["system_id"], cenario=record["cenario"]
            ).first()
            if existing:
                existing.data = json.dumps(record["data"]) if isinstance(record["data"], dict) else str(record["data"])
                session.commit()
                session.refresh(existing)
                return existing
            data_str = json.dumps(record["data"]) if isinstance(record["data"], dict) else str(record["data"])
            model = VersionContextModel(
                system_id=record["system_id"],
                cenario=record["cenario"],
                data=data_str,
            )
            session.add(model)
            session.commit()
            session.refresh(model)
            return model

    def get_version_context(self, system_id: str, cenario: str) -> VersionContextModel | None:
        with self._session() as session:
            return session.query(VersionContextModel).filter_by(
                system_id=system_id, cenario=cenario
            ).first()

    def list_version_contexts(self, system_id: str) -> list[VersionContextModel]:
        with self._session() as session:
            return list(
                session.query(VersionContextModel).filter_by(system_id=system_id).all()
            )

    def delete_version_context(self, system_id: str, cenario: str) -> bool:
        with self._session() as session:
            record = session.query(VersionContextModel).filter_by(
                system_id=system_id, cenario=cenario
            ).first()
            if record is None:
                return False
            session.delete(record)
            session.commit()
            return True

    def set_active_version_cenario(self, system_id: str, cenario: str | None) -> None:
        with self._session() as session:
            system = session.query(SystemModel).filter_by(system_id=system_id).first()
            if system:
                system.active_version_cenario = cenario
                session.commit()
            else:
                logger.warning("system %s not found for set_active_version_cenario", system_id)

    # --- LLM Config ---

    def get_llm_config(self) -> dict[str, Any]:
        with self._session() as session:
            row = session.query(LLMConfigModel).filter_by(id="global").first()
            if row is None:
                return {}
            return {
                "api_key": row.api_key or "",
                "cohere_api_key": row.cohere_api_key or "",
                "provider": row.provider or "gemini",
                "model": row.model or "gemini-1.5-flash",
                "prompt_stage1": row.prompt_stage1 or "",
                "prompt_stage2": row.prompt_stage2 or "",
                "stage1_text_mode": row.stage1_text_mode or "text_for_embedding_current",
                "stage2_text_mode": row.stage2_text_mode or "text_for_embedding_current",
            }

    def upsert_llm_config(self, data: dict[str, Any]) -> None:
        with self._session() as session:
            row = session.query(LLMConfigModel).filter_by(id="global").first()
            if row is None:
                row = LLMConfigModel(id="global")
                session.add(row)
            if "api_key" in data:
                row.api_key = data["api_key"]
            if "cohere_api_key" in data:
                row.cohere_api_key = data["cohere_api_key"]
            if "provider" in data:
                row.provider = data["provider"]
            if "model" in data:
                row.model = data["model"]
            if "prompt_stage1" in data:
                row.prompt_stage1 = data["prompt_stage1"]
            if "prompt_stage2" in data:
                row.prompt_stage2 = data["prompt_stage2"]
            if "stage1_text_mode" in data:
                row.stage1_text_mode = data["stage1_text_mode"]
            if "stage2_text_mode" in data:
                row.stage2_text_mode = data["stage2_text_mode"]
            row.updated_at = _utcnow()
            session.commit()
