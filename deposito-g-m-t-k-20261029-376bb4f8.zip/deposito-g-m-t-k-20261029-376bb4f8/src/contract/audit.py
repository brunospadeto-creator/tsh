from src.schemas.contract import EvidenceContract


def audit_completeness(contract: EvidenceContract) -> float:
    fields = [
        contract.incident.incident_id,
        contract.incident.evidence_id,
        contract.incident.system_id,
        contract.diagnosis.stage_1,
        contract.mobilized_evidence.log_templates,
        contract.mobilized_evidence.metric_features,
        contract.provenance.processing_stages,
        contract.provenance.model_params,
    ]
    filled = sum(1 for f in fields if f is not None and f != [] and f != {})
    return filled / len(fields)


def audit_traceability(contract: EvidenceContract) -> bool:
    if contract.incident.evidence_id and contract.incident.system_id:
        if contract.diagnosis.primary_hypothesis or contract.diagnosis.stage_1 == "normal":
            return True
    return False


def audit_reviewability(contract: EvidenceContract) -> bool:
    return contract.review.status == "pending_human_review"


def audit_reproducibility(
    contract_a: EvidenceContract,
    contract_b: EvidenceContract,
) -> bool:
    if contract_a.incident.system_id != contract_b.incident.system_id:
        return False
    if contract_a.provenance.model_params != contract_b.provenance.model_params:
        return False
    if contract_a.provenance.processing_stages != contract_b.provenance.processing_stages:
        return False
    return True
