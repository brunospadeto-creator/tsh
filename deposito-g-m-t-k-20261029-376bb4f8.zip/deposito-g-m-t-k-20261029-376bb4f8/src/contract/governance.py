"""Verificação de governança embutida no contrato (BL-3204, Extensão III.b).

Validade (Eq. 11 do artigo): pacote/contrato é schema-válido sse
``governance ≠ None`` **e** ``verify_governance(gov, package)``.
"""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any

_SKEW = timedelta(minutes=5)


def canonical_json(package_dict: dict[str, Any]) -> str:
    """Serialização canônica determinística: chaves ordenadas, float repr fixo."""
    return json.dumps(package_dict, sort_keys=True, separators=(", ", ": "), ensure_ascii=False)


def compute_package_sha256(package_dict: dict[str, Any]) -> str:
    """SHA-256 hex da serialização canônica do pacote."""
    return hashlib.sha256(canonical_json(package_dict).encode("utf-8")).hexdigest()


def _field(gov: object, name: str) -> Any:
    if isinstance(gov, dict):
        return gov.get(name)
    return getattr(gov, name, None)


def check_governance_metadata(
    gov: object,
    *,
    target_system_id: str | None = None,
    known_agents: set[str] | None = None,
    now: datetime | None = None,
) -> tuple[bool, str]:
    """Verifica as regras de metadados (2–4) sem o hash do pacote.

    Usada quando o pacote original não está disponível (ex.: badge na lista
    de contratos — o contrato não embute ``p``, só ``prov(p)``).
    ``gov=None`` é considerado neutro/válido (contratos legados).
    """
    if gov is None:
        return True, ""

    agent = _field(gov, "collecting_agent")
    scope = _field(gov, "authorization_scope")
    collected_at = _field(gov, "collected_at")

    if not agent or not str(agent).strip():
        return False, "agente coletor vazio (empty collecting agent)"
    if known_agents is not None and str(agent) not in known_agents:
        return False, f"agente desconhecido: {agent!r} (unknown collecting agent)"

    parts = str(scope or "").split(":")
    scope_ok = (
        len(parts) == 3
        and parts[0] == "system"
        and bool(parts[2])
        and (parts[1] == "*" or (target_system_id is not None and parts[1] == target_system_id))
    )
    if target_system_id is not None and not scope_ok:
        return False, (
            f"escopo {scope!r} não autoriza o sistema alvo {target_system_id!r} "
            "(authorization scope mismatch)"
        )

    try:
        collected = datetime.fromisoformat(str(collected_at).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return False, f"timestamp inválido: {collected_at!r} (unparseable timestamp)"
    if collected.tzinfo is None:
        collected = collected.replace(tzinfo=UTC)
    reference = now or datetime.now(UTC)
    if collected > reference + _SKEW:
        return False, (
            f"timestamp no futuro além do skew permitido: {collected_at!r} "
            "(future timestamp beyond allowed skew)"
        )

    return True, ""


def verify_governance(
    gov: object,
    package_dict: dict[str, Any],
    *,
    known_agents: set[str] | None = None,
    target_system_id: str | None = None,
    now: datetime | None = None,
) -> tuple[bool, str]:
    """Verifica ``prov(p)``; retorna ``(False, motivo)`` na primeira falha.

    Regras:
      1. ``source_package_sha256 == sha256(canonical_json(package))``
      2. agente não vazio e, quando ``known_agents`` fornecido, pertencente
         ao conjunto conhecido (workers ativos + API keys).
      3. escopo casa com o sistema alvo: ``system:<id>:<ação>`` ou ``system:*:<ação>``.
      4. ``collected_at`` ISO parseável e ≤ now + skew de 5 min.
    """
    if gov is None:
        return False, "governance ausente (missing governance)"

    sha = _field(gov, "source_package_sha256")
    expected_sha = compute_package_sha256(package_dict)
    if not isinstance(sha, str) or sha != expected_sha:
        return False, f"hash divergente: esperado {expected_sha[:12]}… (hash mismatch)"

    return check_governance_metadata(
        gov, target_system_id=target_system_id, known_agents=known_agents, now=now
    )


def make_governance(
    *,
    collecting_agent: str,
    authorization_scope: str,
    package_dict: dict[str, Any],
    collected_at: str | None = None,
) -> object:
    """Fábrica de governança consistente para um pacote construído internamente."""
    from src.schemas.contract import GovernanceInfo

    timestamp = collected_at or datetime.now(UTC).isoformat()
    return GovernanceInfo(
        collecting_agent=collecting_agent,
        authorization_scope=authorization_scope,
        source_package_sha256=compute_package_sha256(package_dict),
        collected_at=timestamp,
    )
