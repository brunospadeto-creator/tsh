from typing import Any

from src.diagnosis.engines.base import DiagnosisReport
from src.schemas.contract import (
    ContractProvenance,
    DiagnosisInfo,
    EvidenceContract,
    IncidentInfo,
    MobilizedEvidence,
    ReviewStatus,
)
from src.schemas.evidence_package import EvidencePackage


def build_evidence_contract(
    package: EvidencePackage,
    diagnosis: DiagnosisReport,
    engine_params: dict[str, Any] | None = None,
    stage_errors: list[str] | None = None,
    decision_explanation: dict[str, Any] | None = None,
) -> EvidenceContract:
    top_templates = package.log_details.top_templates
    template_texts = list(top_templates.keys())

    event_reasons = []
    for ev in package.k8s_infrastructure_events:
        reason = ev.get("reason", "")
        if reason and reason not in event_reasons:
            event_reasons.append(reason)

    return EvidenceContract(
        incident=IncidentInfo(
            incident_id=diagnosis.incident_id,
            evidence_id=package.evidence_id,
            system_id=package.system_id,
            failure_id=package.failure_id,
        ),
        diagnosis=DiagnosisInfo(
            stage_1=diagnosis.stage1_result,
            primary_hypothesis=diagnosis.primary_hypothesis,
            confidence=diagnosis.confidence,
            secondary_hypothesis=diagnosis.secondary_hypothesis,
        ),
        mobilized_evidence=MobilizedEvidence(
            log_templates=template_texts,
            metric_features=list(package.metrics.keys()) if package.metrics else [],
            events=event_reasons,
        ),
        provenance=ContractProvenance(
            processing_stages=["selection", "cleaning", "normalization", "representation"],
            model_params=engine_params or diagnosis.engine_params,
            stage_errors=stage_errors,
            decision_explanation=decision_explanation,
        ),
        review=ReviewStatus(),
    )
