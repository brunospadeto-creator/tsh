import json
from dataclasses import asdict, is_dataclass
from datetime import datetime
from html import escape
from typing import Any
from uuid import UUID

from src.schemas.contract import EvidenceContract


class ContractEncoder(json.JSONEncoder):
    def default(self, o: Any) -> Any:
        if isinstance(o, UUID):
            return str(o)
        if isinstance(o, datetime):
            return o.isoformat()
        if is_dataclass(o):
            return asdict(o)  # type: ignore[arg-type]
        return super().default(o)


def contract_to_json(contract: EvidenceContract) -> str:
    return json.dumps(contract, cls=ContractEncoder, ensure_ascii=False, indent=2)


def contract_to_html(contract: EvidenceContract) -> str:
    status_color = {
        "completa": "#28a745",
        "coleta_incompleta": "#ffc107",
        "pending_human_review": "#17a2b8",
        "confirmed": "#28a745",
        "rejected": "#dc3545",
    }.get(contract.status, "#6c757d")

    confidence_pct = (
        f"{contract.diagnosis.confidence * 100:.1f}%" if contract.diagnosis.confidence is not None else "N/A"
    )
    reviewed = (
        contract.review.status
        if contract.review.status == "pending_human_review"
        else f"{contract.review.status} ({contract.review.reason or 'no reason'})"
    )
    stage_errors = "; ".join(contract.provenance.stage_errors) if contract.provenance.stage_errors else "Nenhum"
    log_items = "".join(f"<li>{escape(template)}</li>" for template in contract.mobilized_evidence.log_templates)
    metric_items = "".join(f"<li>{escape(metric)}</li>" for metric in contract.mobilized_evidence.metric_features)
    model_param_items = "".join(
        f"<li>{escape(str(key))}: {escape(str(value))}</li>" for key, value in contract.provenance.model_params.items()
    )
    processing_stages = escape(", ".join(contract.provenance.processing_stages))
    primary_hypothesis = escape(contract.diagnosis.primary_hypothesis or "N/A")
    secondary_hypothesis = escape(contract.diagnosis.secondary_hypothesis or "—")

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="utf-8"><title>Contrato de Evidência</title></head>
<body style="font-family:sans-serif;max-width:800px;margin:40px auto">
<h1>Contrato de Evidência</h1>
<p><strong>Status:</strong> <span style="color:{status_color}">{escape(contract.status)}</span></p>
<hr>
<h2>Incidente</h2>
<table>
<tr><td>ID:</td><td>{escape(contract.incident.incident_id)}</td></tr>
<tr><td>Sistema:</td><td>{escape(contract.incident.system_id)}</td></tr>
<tr><td>Fault (causa injetada):</td><td>{escape(contract.incident.failure_id or "—")}</td></tr>
</table>
<h2>Diagnóstico</h2>
<table>
<tr><td>Estágio 1:</td><td>{escape(contract.diagnosis.stage_1)}</td></tr>
<tr><td>Hipótese primária:</td><td>{primary_hypothesis}</td></tr>
<tr><td>Confiança:</td><td>{escape(confidence_pct)}</td></tr>
<tr><td>Hipótese secundária:</td><td>{secondary_hypothesis}</td></tr>
</table>
<h2>Evidências Mobilizadas</h2>
<h3>Templates de Log</h3>
<ul>{log_items}</ul>
<h3>Métricas</h3>
<ul>{metric_items}</ul>
<h2>Proveniência</h2>
<p><strong>Estágios processados:</strong> {processing_stages}</p>
<p><strong>Parâmetros do modelo:</strong></p>
<ul>{model_param_items}</ul>
<p><strong>Erros nos estágios:</strong> {escape(stage_errors)}</p>
<h2>Revisão</h2>
<p>{escape(reviewed)}</p>
</body></html>"""
