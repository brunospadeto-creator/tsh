from __future__ import annotations

INACTIVE_INCIDENT_STATUSES = frozenset({"resolved", "known", "closed", "concluded"})


def is_active_incident_status(status: str | None) -> bool:
    return (status or "open") not in INACTIVE_INCIDENT_STATUSES
