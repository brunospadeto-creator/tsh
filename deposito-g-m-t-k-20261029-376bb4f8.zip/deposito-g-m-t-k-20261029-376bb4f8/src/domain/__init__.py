"""Domain rules shared across adapters and services."""
