import re
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any, cast
from uuid import uuid4

from src.diagnosis.feature_selection import _app_commit_changed, _config_status_changed
from src.schemas.evidence_package import (
    METRIC_NAMES,
    BaselineInfo,
    CategorizedFeatures,
    CollectionPolicy,
    EvidencePackage,
    LogDetails,
    MetadataEvidencia,
    Topology,
)
from src.schemas.intermediate import CollectConfig, NormalizedAggregated

TEXT_MODE_CURRENT = "text_for_embedding_current"
TEXT_MODE_CURRENT_NO_MEMORY_WSS = "text_for_embedding_current_no_memory_wss"
TEXT_MODE_CURRENT_WITH_MEMORY_WSS = "text_for_embedding_current_with_memory_wss"
TEXT_MODE_BASE = "text_for_embedding"
TEXT_MODE_TINY = "text_for_embedding_tiny"
TEXT_MODE_PURE = "text_for_embedding_pure"
TEXT_MODE_PLUS_TOP_TEMPLATES = "text_for_embedding_plus_top_templates"
TEXT_MODE_PLUS_METRICAS = "text_for_embedding_plus_metricas"
TEXT_MODE_PLUS_LOG_DETAILS = "text_for_embedding_plus_log_details"

# Acréscimos -- nunca alteram o texto
# dos 9 modos acima, só adicionam opções novas ao catálogo, selecionáveis
# lado a lado. Ver _version_summary_safe_text/entity_metrics_summary.
TEXT_MODE_CURRENT_SAFE_VERSION = "text_for_embedding_safe_version"
TEXT_MODE_PURE_SAFE = "text_for_embedding_pure_safe"
TEXT_MODE_PLUS_TOP_TEMPLATES_SAFE_VERSION = "text_for_embedding_plus_top_templates_safe_version"
TEXT_MODE_PLUS_ENTITY_SUMMARY = "text_for_embedding_plus_entity_summary"
TEXT_MODE_PLUS_ENTITY_DETAIL = "text_for_embedding_plus_entity_detail"

# cgroup working-set memory sobe monotonicamente com o uptime do container
# entre cenários (o jpetstore-web nunca é reiniciado durante a coleta) e por
# isso vaza informação temporal em vez de sinal real da falha (mesmo achado
# que já excluía essa métrica por padrão das 21 features tabulares do
# Explorador/Ablação/Treinamento: #10). Excluída por
# padrão de TODOS os modos de TFE agora (achado 29/07/2026: só o modo
# _no_memory_wss excluía -- os outros 7, incluindo o "Atual" usado por
# padrão pelo sistema, ainda vazavam essa métrica). Quem quiser incluí-la
# mesmo assim (comparação/diagnóstico) usa TEXT_MODE_CURRENT_WITH_MEMORY_WSS.
_MEMORY_WSS_METRIC = "memoria_working_set_mb"
_DEFAULT_EXCLUDED_METRICS: frozenset[str] = frozenset({_MEMORY_WSS_METRIC})

# `blocos`: composição em blocos ("logs + templates + ...") de cada modo,
# derivada de build_text_for_mode() abaixo. Mantida colada ao catálogo pra
# não driftar do que o texto realmente inclui -- usada, por exemplo, no
# tooltip do nome do modo na tabela de comparação da exploração FAISS.
TEXT_MODE_CATALOG: dict[str, dict[str, str]] = {
    TEXT_MODE_CURRENT: {
        "label": "Atual compatível",
        "description": "Reproduz exatamente o texto de embedding usado hoje pelo sistema novo.",
        "blocos": "logs + templates + pods + eventos K8s + métricas categorizadas + versão/config",
    },
    TEXT_MODE_CURRENT_NO_MEMORY_WSS: {
        "label": "Atual sem memory working set",
        "description": "Idêntico ao modo Atual agora que memoria_working_set_mb é excluída por padrão de todos os modos -- mantido só por compatibilidade com explorações/treinos antigos que já referenciam esse nome.",
        "blocos": "= Atual (mitigação de vazamento temporal agora é o padrão de todos os modos)",
    },
    TEXT_MODE_CURRENT_WITH_MEMORY_WSS: {
        "label": "Atual com memory working set",
        "description": "Igual ao modo Atual, mas MANTÉM memoria_working_set_mb nas métricas -- use com cautela: essa métrica vaza tempo de execução do container, não sinal real da falha (plano_correcao.md #10). Só pra comparação/diagnóstico.",
        "blocos": "= Atual, incluindo a métrica memória working-set (não recomendado por padrão)",
    },
    TEXT_MODE_BASE: {
        "label": "Base semântico",
        "description": "Modo base com padrões de log, pods, eventos, métricas categorizadas e configuração.",
        "blocos": "logs + templates + pods + eventos K8s + métricas categorizadas + versão/config",
    },
    TEXT_MODE_TINY: {
        "label": "Tiny",
        "description": "Contexto mínimo com volume de logs, desconhecidos, top patterns e métricas categorizadas.",
        "blocos": "logs + templates + métricas categorizadas (mínimo, sem pods/eventos/versão)",
    },
    TEXT_MODE_PURE: {
        "label": "Pure",
        "description": "Representação mais literal com templates, contagens, pods, eventos e métricas brutas.",
        "blocos": "logs brutos + templates brutos + pods brutos + eventos K8s literais + métricas brutas + versão",
    },
    TEXT_MODE_PLUS_TOP_TEMPLATES: {
        "label": "Base + top templates",
        "description": "Modo base acrescido dos top templates brutos e suas contagens.",
        "blocos": "Base + templates brutos",
    },
    TEXT_MODE_PLUS_METRICAS: {
        "label": "Base + métricas",
        "description": "Modo base acrescido das métricas numéricas brutas.",
        "blocos": "Base + métricas brutas",
    },
    TEXT_MODE_PLUS_LOG_DETAILS: {
        "label": "Base + log details",
        "description": "Modo base acrescido de detalhes ampliados de logs.",
        "blocos": "Base + detalhes ampliados de log",
    },
    TEXT_MODE_CURRENT_SAFE_VERSION: {
        "label": "Atual sem vazamento de versão",
        "description": (
            "Igual ao modo Atual, mas troca hash de commit bruto/tipo de mudança de config "
            "(chute por palavra-chave) pelas mesmas features binárias já validadas do vetor "
            "numérico (feature_selection.py::_app_commit_changed/_config_status_changed) -- "
            "achado real: o hash bruto separa quase sozinho as falhas de código do resto "
            "(F1=0.998 em teste histórico do lado numérico, mesmo padrão confirmado no texto "
            "na exploração FAISS Stage1 de 2026-09-10, sessão registrada em session.md)."
        ),
        "blocos": "= Atual, com Commit alterado?/Configuração alterada? binários em vez de hash/chute",
    },
    TEXT_MODE_PLUS_TOP_TEMPLATES_SAFE_VERSION: {
        "label": "Base + top templates, sem vazamento de versão",
        "description": (
            "Igual ao modo 'Base + top templates' (2º colocado na exploração FAISS Stage1 de "
            "2026-09-10, F1=0.962), mas sobre a base sem vazamento de versão em vez da base "
            "original -- pra medir quanto do F1 daquele modo vinha de sinal real (templates "
            "brutos) vs. do mesmo vazamento binário do modo 'Atual'."
        ),
        "blocos": "Top templates brutos + Atual sem vazamento de versão",
    },
    TEXT_MODE_PURE_SAFE: {
        "label": "Pure sem vazamento de versão",
        "description": (
            "Igual ao modo Pure, mas substitui o dump literal de versao/configuracao "
            "(que inclui o nome da falha e o diff da mudança por extenso) pelo mesmo resumo "
            "binário seguro usado no modo 'Atual sem vazamento de versão'. O resto do Pure "
            "(logs/templates/pods/eventos/métricas brutas) é mantido."
        ),
        "blocos": "= Pure, exceto versão/configuração (binária em vez de dump literal)",
    },
    TEXT_MODE_PLUS_ENTITY_SUMMARY: {
        "label": "Atual seguro + resumo por pod",
        "description": (
            "Modo 'Atual sem vazamento de versão' acrescido de um resumo dinâmico do pior pod "
            "por métrica canônica (metrics_by_entity), sem tabela fixa por serviço -- primeiro "
            "modo de TFE que dá a FAISS algum sinal por pod (plano-metricas-por-pod-faiss-ml.md "
            "Fase 1). Pacote sem metrics_by_entity (schema 1.0) degrada para 'sem dado'."
        ),
        "blocos": "= Atual sem vazamento de versão + resumo cross-pod (pior categoria por métrica)",
    },
    TEXT_MODE_PLUS_ENTITY_DETAIL: {
        "label": "Atual seguro + métricas por pod (blockwise)",
        "description": (
            "Modo 'Atual sem vazamento de versão' acrescido do perfil completo de CADA pod "
            "(não só o pior, como no resumo) -- mesma granularidade genuína por entidade que "
            "src/memory/blocks.py (motor blockwise) usa, aqui como texto em vez de um bloco "
            "numérico projetado. Nome do pod normalizado (sem sufixo de hash de ReplicaSet/"
            "índice de StatefulSet, mesma normalização de normalize_pod_name) para não repetir "
            "o vazamento de fingerprint de rollout confirmado em Pods crus (session.md §9.5). "
            "Pacote sem metrics_by_entity (schema 1.0) degrada para 'sem dado'."
        ),
        "blocos": "= Atual sem vazamento de versão + métricas categorizadas de cada pod individualmente",
    },
}


def available_text_modes() -> dict[str, dict[str, str]]:
    return TEXT_MODE_CATALOG.copy()


def canonical_text_mode(value: str | None, default: str = TEXT_MODE_CURRENT_SAFE_VERSION) -> str:
    """Resolve o modo de TFE efetivo. Padrão `safe_version` desde 20/09/2026 (achado:
    `current`/`pure` embutem commit/config crus no texto -- metadado do processo de
    injeção da falha, não sintoma real; `safe_version` é o mesmo texto de `current`
    com essa cauda binarizada, ver `_version_summary_safe_text`. Medido como F1
    idêntico a `current` isoladamente -- a troca é por
    princípio de segurança, não por ganho de métrica. `current`/`pure` continuam
    existindo no catálogo pra comparação, só deixam de ser o default de produção."""
    mode = (value or default or TEXT_MODE_CURRENT_SAFE_VERSION).strip()
    return mode if mode in TEXT_MODE_CATALOG else default


def get_logs_volume(count: int) -> str:
    if count <= 200:
        return "LOW"
    if count <= 800:
        return "MEDIUM"
    return "HIGH"


def normalize_pod_name(pod_name: str) -> str:
    if not pod_name or pod_name == "unknown":
        return "unknown"
    pattern = r"-[a-f0-9]{8,15}-[a-z0-9]{5}$"
    normalized = re.sub(pattern, "", str(pod_name))
    normalized = re.sub(r"-[0-9]+$", "", normalized)
    if normalized != str(pod_name):
        return f"{normalized} pod"
    return str(pod_name)


def categorize_metric(name: str, value: float) -> str:
    if value is None:
        return "UNKNOWN"
    val = float(value)
    name_lower = name.lower()
    if "cpu" in name_lower and "throttled" not in name_lower:
        if val < 0.2:
            return "LOW"
        if val < 0.6:
            return "NORMAL"
        if val < 0.85:
            return "HIGH"
        return "CRITICAL"
    if "throttled" in name_lower:
        if val < 1:
            return "LOW"
        if val < 5:
            return "NORMAL"
        if val < 10:
            return "HIGH"
        return "CRITICAL"
    if "memoria" in name_lower or "memory" in name_lower:
        if val < 100:
            return "LOW"
        if val < 500:
            return "NORMAL"
        if val < 1000:
            return "HIGH"
        return "CRITICAL"
    if "latencia" in name_lower or "latency" in name_lower or "time" in name_lower or "duration" in name_lower:
        if val < 50:
            return "NORMAL"
        if val < 200:
            return "ELEVATED"
        if val < 500:
            return "HIGH"
        return "CRITICAL"
    if "bytes" in name_lower:
        # Regressão encontrada revisando pacotes reais (2026-09-09): antes
        # caía no fallback genérico abaixo (thresholds 0-1.5, pensado pra
        # métrica já normalizada tipo razão/score), incompatível por várias
        # ordens de grandeza com taxas brutas de bytes/s (fs_writes_bytes,
        # fs_reads_bytes, network_*_bytes) -- na prática sempre CRITICAL,
        # inclusive em baseline sem falha nenhuma. Faixas aqui são um
        # primeiro corte por ordem de grandeza (KB/s a dezenas de MB/s), não
        # uma calibração rigorosa — ajustar com dados reais quando houver.
        if val < 100_000:
            return "LOW"
        if val < 1_000_000:
            return "NORMAL"
        if val < 10_000_000:
            return "HIGH"
        return "CRITICAL"
    if val < 0.25:
        return "LOW"
    if val < 0.75:
        return "NORMAL"
    if val < 1.5:
        return "HIGH"
    return "CRITICAL"


def extract_log_pattern(template: str) -> str:
    if not template or template == "UNKNOWN":
        return "UNKNOWN"
    raw = str(template)
    semantic_tokens = re.findall(
        r"\b([A-Z][A-Za-z0-9]*(?:Service|Client|Controller|Repository|Handler))\b",
        raw,
    )
    if semantic_tokens:
        return cast(str, semantic_tokens[-1])
    parts = raw.split(":")
    prefix = parts[0].strip() if parts else raw
    if "." in prefix:
        candidate = prefix.split(".")[-1].strip()
        if candidate:
            return re.sub(r"[^A-Za-z0-9_]", "", candidate)[:40] or "UNKNOWN"
    clean = re.sub(r"[^A-Za-z0-9_ ]", " ", prefix)
    compact = " ".join(clean.split())
    return compact[:40] if compact else "UNKNOWN"


# Motivo por trás de cada bucket: eventos de ciclo de vida do pod —
# derivados dos mesmos k8s events já
# coletados, sem query nova ao cluster.
_RESTART_REASONS = frozenset({"Created", "Started", "BackOff", "Recreated"})
_OOMKILL_REASONS = frozenset({"OOMKilling", "OOMKilled"})
_NOT_READY_REASONS = frozenset({"Unhealthy", "Failed", "Killing"})

_POD_HASH_SUFFIX = re.compile(r"-[a-f0-9]{8,15}-[a-z0-9]{5}$")
_ORDINAL_SUFFIX = re.compile(r"-[0-9]+$")


def _strip_pod_suffix(name: str) -> str:
    """Remove o sufixo de hash de ReplicaSet/Pod (Deployment) ou o índice
    ordinal (StatefulSet), deixando o nome base do serviço/container. Mesma
    normalização usada por `normalize_pod_name` (texto), mas sem o sufixo
    " pod" — aqui o resultado é usado como CHAVE de junção entre fontes de
    dados (métricas rotuladas por container vs. k8s events por pod), não
    como texto de exibição.
    """
    s = _POD_HASH_SUFFIX.sub("", str(name))
    s = _ORDINAL_SUFFIX.sub("", s)
    return s


def derive_entity_state(
    k8s_events: list[dict[str, Any]] | None,
    known_entities: Iterable[str],
) -> dict[str, dict[str, float]]:
    """Deriva contagens de estado por entidade (`restart_count`,
    `oomkill_count`, `not_ready_flags`) a partir dos k8s events da janela.

    Casa o pod referenciado no evento com uma entidade já conhecida (nome de
    serviço/container vindo de `metrics_by_entity`) comparando o nome base
    após remover sufixos de hash de pod/réplica — nunca inventa uma entidade
    nova só a partir de um evento (evitaria contagens presas a nomes de pod
    que as métricas nunca reportaram).
    """
    if not k8s_events or not known_entities:
        return {}
    bases = {_strip_pod_suffix(entity): entity for entity in known_entities}
    state: dict[str, dict[str, float]] = {}
    for ev in k8s_events:
        pod_ref = str(ev.get("involved_object") or ev.get("res") or ev.get("pod") or "")
        if not pod_ref:
            continue
        entity = bases.get(_strip_pod_suffix(pod_ref))
        if entity is None:
            continue
        reason = str(ev.get("reason", "")).strip()
        bucket = state.setdefault(
            entity, {"restart_count": 0.0, "oomkill_count": 0.0, "not_ready_flags": 0.0}
        )
        if reason in _RESTART_REASONS:
            bucket["restart_count"] += 1.0
        if reason in _OOMKILL_REASONS:
            bucket["oomkill_count"] += 1.0
        if reason in _NOT_READY_REASONS:
            bucket["not_ready_flags"] += 1.0
    return state


def format_k8s_events(events: list[dict[str, Any]] | None) -> str:
    if not events:
        return "Nenhum evento relevante"
    formatted = []
    seen = set()
    for ev in events:
        reason = str(ev.get("reason", "Unknown")).strip() or "Unknown"
        phrase = f"K8s event: {reason}"
        if phrase not in seen:
            seen.add(phrase)
            formatted.append(phrase)
    return " | ".join(formatted) if formatted else "Nenhum evento relevante"


def extract_config_change_type(diff_text: str | None) -> str:
    if not diff_text:
        return "NONE"
    diff_lower = str(diff_text).lower()
    if "-xmx" in diff_lower or "-xms" in diff_lower:
        return "JVM_HEAP_CHANGE"
    if "hikari" in diff_lower or "maximumpoolsize" in diff_lower:
        return "CONNECTION_POOL_CHANGE"
    if "jdbc" in diff_lower or "database" in diff_lower:
        return "DATABASE_CONFIG_CHANGE"
    if "timeout" in diff_lower:
        return "TIMEOUT_CHANGE"
    return "UNKNOWN_CHANGE"


def build_categorized_features(
    templates_dict: dict[str, int],
    metrics: dict[str, float] | None,
    unknown_count: int,
    pod_counts: dict[str, int] | None,
    k8s_events: list[dict[str, Any]] | None,
    versao: dict[str, Any] | None,
    top_k: int = 5,
) -> CategorizedFeatures:
    sorted_templates = sorted(templates_dict.items(), key=lambda x: -x[1])
    top = sorted_templates[:top_k]
    total_logs = sum(templates_dict.values())

    logs_volume = get_logs_volume(total_logs)

    template_patterns: list[str] = []
    seen = set()
    for t, c in top:
        simplified = extract_log_pattern(str(t))
        if simplified not in seen:
            seen.add(simplified)
            template_patterns.append(simplified)

    normalized_pods: list[str] = []
    for p in (pod_counts or {}).keys():
        np_name = normalize_pod_name(p)
        if np_name not in normalized_pods:
            normalized_pods.append(np_name)

    k8s_event_reasons: list[str] = []
    if k8s_events:
        seen_reasons = set()
        for ev in k8s_events:
            reason = str(ev.get("reason", "Unknown")).strip() or "Unknown"
            if reason not in seen_reasons:
                seen_reasons.add(reason)
                k8s_event_reasons.append(reason)

    categorized_metrics: dict[str, str] = {}
    if metrics:
        for k, v in metrics.items():
            categorized_metrics[k] = categorize_metric(k, v)

    app_commit = "N/A"
    config_change = "NONE"
    if versao:
        app_commit = (
            versao.get("aplicacao", {}).get("app_commit_version")
            or versao.get("app_commit")
            or "N/A"
        )
        diff_text = ""
        config_data = versao.get("configuracao", {})
        arquivos = config_data.get("arquivos_alterados") if isinstance(config_data, dict) else None
        if arquivos and isinstance(arquivos, list) and len(arquivos) > 0:
            first = arquivos[0]
            if isinstance(first, dict):
                diff_text = first.get("diff", "")
            elif isinstance(first, str):
                diff_text = first
        if not diff_text:
            diff_text = (
                config_data.get("diff")
                or versao.get("diff")
                or versao.get("config_diff")
                or ""
            )
        config_change = extract_config_change_type(diff_text)

    return CategorizedFeatures(
        logs_volume=logs_volume,
        template_patterns=template_patterns,
        categorized_metrics=categorized_metrics,
        normalized_pods=normalized_pods,
        k8s_event_reasons=k8s_event_reasons,
        app_commit=app_commit,
        config_change_type=config_change,
    )


def _build_current_embedding_text(
    pkg: EvidencePackage, exclude_metrics: frozenset[str] = _DEFAULT_EXCLUDED_METRICS,
) -> str:
    if pkg.categorized_features is not None:
        cf = pkg.categorized_features

        top_templates_text = ", ".join(cf.template_patterns) if cf.template_patterns else "UNKNOWN"

        pods_ativos_text = ", ".join(cf.normalized_pods) if cf.normalized_pods else "unknown"

        k8s_text = "Nenhum evento relevante"
        if cf.k8s_event_reasons:
            formatted = [f"K8s event: {r}" for r in cf.k8s_event_reasons]
            k8s_text = " | ".join(formatted)

        categorized_metrics = {
            k: v for k, v in cf.categorized_metrics.items() if k not in exclude_metrics
        }
        metricas_text = "Nenhuma metrica agregada"
        if categorized_metrics:
            metricas_text = ", ".join(
                f"{k}: {v}" for k, v in sorted(categorized_metrics.items())
            )

        return (
            f"Logs volume: {cf.logs_volume}. "
            f"Logs desconhecidos: {pkg.log_details.unknown_count}. "
            f"Top log patterns: {top_templates_text}. "
            f"Pods ativos: {pods_ativos_text}. "
            f"{k8s_text}. "
            f"Metricas categorizadas: {metricas_text}. "
            f"Commit da aplicação: {cf.app_commit}. "
            f"Configuration change type: {cf.config_change_type}."
        )

    templates_raw = ", ".join(pkg.log_details.top_templates.keys()) if pkg.log_details.top_templates else "UNKNOWN"
    unknown_count = pkg.log_details.unknown_count
    vol = get_logs_volume(sum(pkg.log_details.top_templates.values()) if pkg.log_details.top_templates else 0)

    pods_raw = "unknown"
    if pkg.topology and pkg.topology.active_pods:
        pods_raw = ", ".join(
            sorted({normalize_pod_name(p) for p in pkg.topology.active_pods.keys()})
        )

    k8s_text = format_k8s_events(pkg.k8s_infrastructure_events)

    metrics_text = "Nenhuma metrica agregada"
    if pkg.metrics:
        pairs = [
            f"{k}: {categorize_metric(k, v)}"
            for k, v in sorted(pkg.metrics.items())
            if k not in exclude_metrics
        ]
        metrics_text = ", ".join(pairs) if pairs else "Nenhuma metrica agregada"

    app_commit = "N/A"
    config_change = "NONE"
    if pkg.versao:
        app_commit = (
            pkg.versao.get("aplicacao", {}).get("app_commit_version")
            or pkg.versao.get("app_commit")
            or "N/A"
        )
        diff_text = pkg.versao.get("configuracao", {}).get("diff", "") or ""
        config_change = extract_config_change_type(diff_text)

    return (
        f"Logs volume: {vol}. "
        f"Logs desconhecidos: {unknown_count}. "
        f"Top log patterns: {templates_raw}. "
        f"Pods ativos: {pods_raw}. "
        f"{k8s_text}. "
        f"Metricas categorizadas: {metrics_text}. "
        f"Commit da aplicação: {app_commit}. "
        f"Configuration change type: {config_change}."
    )


def _categorized_features_for_text(pkg: EvidencePackage) -> CategorizedFeatures:
    if pkg.categorized_features is not None:
        return pkg.categorized_features
    return build_categorized_features(
        dict(pkg.log_details.top_templates or {}),
        pkg.metrics or {},
        pkg.log_details.unknown_count,
        (pkg.topology.active_pods if pkg.topology else {}) or {},
        pkg.k8s_infrastructure_events or [],
        pkg.versao or {},
    )


def _categorized_metrics_text(
    pkg: EvidencePackage, exclude_metrics: frozenset[str] = _DEFAULT_EXCLUDED_METRICS,
) -> str:
    cf = _categorized_features_for_text(pkg)
    filtered = {k: v for k, v in cf.categorized_metrics.items() if k not in exclude_metrics}
    if not filtered:
        return "Nenhuma metrica agregada"
    return ", ".join(f"{k}: {v}" for k, v in sorted(filtered.items()))


def _top_patterns_text(pkg: EvidencePackage) -> str:
    cf = _categorized_features_for_text(pkg)
    if cf.template_patterns:
        return ", ".join(cf.template_patterns)
    return "UNKNOWN"


def _raw_templates_text(pkg: EvidencePackage) -> str:
    templates = pkg.log_details.top_templates or {}
    if not templates:
        return "UNKNOWN"
    return ", ".join(f"{template}: {count}" for template, count in templates.items())


def _raw_metrics_text(
    pkg: EvidencePackage, exclude_metrics: frozenset[str] = _DEFAULT_EXCLUDED_METRICS,
) -> str:
    if not pkg.metrics:
        return "Nenhuma metrica bruta"
    filtered = {k: v for k, v in pkg.metrics.items() if k not in exclude_metrics}
    if not filtered:
        return "Nenhuma metrica bruta"
    return ", ".join(f"{k}: {v}" for k, v in sorted(filtered.items()))


def _raw_pods_text(pkg: EvidencePackage) -> str:
    if not pkg.topology or not pkg.topology.active_pods:
        return "unknown"
    return ", ".join(f"{pod}: {count}" for pod, count in sorted(pkg.topology.active_pods.items()))


def _literal_k8s_events_text(pkg: EvidencePackage) -> str:
    events = pkg.k8s_infrastructure_events or []
    if not events:
        return "Nenhum evento relevante"
    parts = []
    for ev in events[:10]:
        reason = ev.get("reason", "Unknown")
        message = ev.get("message") or ev.get("msg") or ""
        count = ev.get("count")
        count_text = f" count={count}" if count is not None else ""
        parts.append(f"{reason}{count_text}: {message}".strip())
    return " | ".join(parts)


def _log_details_text(pkg: EvidencePackage) -> str:
    samples = pkg.log_details.unknown_samples or []
    samples_text = " | ".join(str(s) for s in samples[:5]) if samples else "[]"
    return (
        f"Log details: total_count={pkg.log_details.total_count}; "
        f"unknown_count={pkg.log_details.unknown_count}; "
        f"unknown_samples={samples_text}; "
        f"top_templates={_raw_templates_text(pkg)}."
    )


def _base_text(
    pkg: EvidencePackage, exclude_metrics: frozenset[str] = _DEFAULT_EXCLUDED_METRICS,
) -> str:
    cf = _categorized_features_for_text(pkg)
    pods_text = ", ".join(cf.normalized_pods) if cf.normalized_pods else "unknown"
    k8s_text = (
        " | ".join(f"K8s event: {reason}" for reason in cf.k8s_event_reasons)
        if cf.k8s_event_reasons else "Nenhum evento relevante"
    )
    return (
        f"Logs volume: {cf.logs_volume}. "
        f"Logs desconhecidos: {pkg.log_details.unknown_count}. "
        f"Top log patterns: {_top_patterns_text(pkg)}. "
        f"Pods ativos: {pods_text}. "
        f"{k8s_text}. "
        f"Metricas categorizadas: {_categorized_metrics_text(pkg, exclude_metrics)}. "
        f"Commit da aplicação: {cf.app_commit}. "
        f"Configuration change type: {cf.config_change_type}."
    )


def _version_summary_safe_text(versao: dict[str, Any] | None) -> str:
    """Substitui as duas últimas linhas de _build_current_embedding_text/
    _base_text (hash de commit bruto + tipo de mudança por palavra-chave)
    pelas MESMAS funções binárias já validadas do vetor numérico
    (feature_selection.py::_app_commit_changed/_config_status_changed) --
    evita reintroduzir o vazamento confirmado na exploração FAISS Stage1 de
    2026-09-10
    sem duplicar lógica já testada. Nunca usada pelos modos originais --
    só pelos modos novos "_safe_version"/"pure_safe"/"plus_entity_summary"."""
    v = versao or {}
    commit_changed = "sim" if _app_commit_changed(v) else "não"
    config_changed = "sim" if _config_status_changed(v) else "não"
    return (
        f"Commit alterado em relação à referência: {commit_changed}. "
        f"Configuração alterada: {config_changed}."
    )


def _build_current_embedding_text_safe_version(
    pkg: EvidencePackage, exclude_metrics: frozenset[str] = _DEFAULT_EXCLUDED_METRICS,
) -> str:
    """Mesmo texto de _build_current_embedding_text (nunca alterada), só
    trocando a cauda de versão pela variante segura -- o resto do texto vem
    de _build_current_embedding_text real, não duplicado, então qualquer
    mudança futura nela (fora da cauda de versão) se propaga automaticamente."""
    full = _build_current_embedding_text(pkg, exclude_metrics)
    body = full.rsplit("Commit da aplicação:", 1)[0]
    return body + _version_summary_safe_text(pkg.versao)


def _base_text_safe_version(
    pkg: EvidencePackage, exclude_metrics: frozenset[str] = _DEFAULT_EXCLUDED_METRICS,
) -> str:
    """Mesmo texto de _base_text (nunca alterada), só trocando a cauda de
    versão pela variante segura -- ver _build_current_embedding_text_safe_version."""
    full = _base_text(pkg, exclude_metrics)
    body = full.rsplit("Commit da aplicação:", 1)[0]
    return body + _version_summary_safe_text(pkg.versao)


def _build_pure_text_safe(pkg: EvidencePackage) -> str:
    """Mesmos campos literais do modo Pure (reaproveita os mesmos helpers
    _raw_*/_literal_k8s_events_text), exceto a linha final: em vez do dump
    de pkg.versao inteiro (que inclui `motivo`/`arquivos_alterados`/
    `release_tag` citando o nome da falha por extenso -- confirmado na
    investigação de 2026-09-10), usa o mesmo resumo binário
    seguro dos outros modos novos."""
    return (
        f"Logs total_count: {pkg.log_details.total_count}. "
        f"Logs unknown_count: {pkg.log_details.unknown_count}. "
        f"Unknown samples: {', '.join(pkg.log_details.unknown_samples or []) or '[]'}. "
        f"Top templates brutos: {_raw_templates_text(pkg)}. "
        f"Pods crus: {_raw_pods_text(pkg)}. "
        f"K8s events literais: {_literal_k8s_events_text(pkg)}. "
        f"Metricas brutas: {_raw_metrics_text(pkg)}. "
        f"{_version_summary_safe_text(pkg.versao)}"
    )


def entity_metrics_summary(pkg: EvidencePackage) -> dict[str, tuple[str, str, float]]:
    """Por métrica canônica (METRIC_NAMES), acha a entidade com o MAIOR
    valor bruto em metrics_by_entity (proxy de pior categoria -- categorize_metric
    é monotônico em relação ao valor pra todas as métricas do catálogo) e
    categoriza esse valor com a MESMA categorize_metric usada no agregado
    global. Retorna {metric: (categoria, nome_da_entidade, valor)}.

    Métrica sem nenhuma entidade reportando dado (schema_version 1.0, ou
    metrics_by_entity vazio) simplesmente não entra no dict -- nunca inventa
    "sem dado" como um valor/categoria, mesmo padrão de degradação graciosa
    já usado em _normalize_by_entity/derive_entity_state (BL-3105).

    Só lê metrics_by_entity (dado observado em runtime) -- nunca pkg.versao/
    metadado de injeção, pra não repetir o vazamento da Fase 0.

    Nome da entidade retornado é NORMALIZADO (_strip_pod_suffix, mesmo
    tratamento de entity_metrics_detail) -- nome cru (com sufixo de hash de
    ReplicaSet/índice de StatefulSet) faria _entity_summary_text vazar
    fingerprint de rollout no texto pro FAISS, mesma categoria de vazamento
    já confirmada em _raw_pods_text, suspeitada antes e confirmada aqui."""
    mbe = pkg.metrics_by_entity or {}
    result: dict[str, tuple[str, str, float]] = {}
    for metric in METRIC_NAMES:
        best_entity: str | None = None
        best_value: float | None = None
        for entity, values in mbe.items():
            if metric not in values:
                continue
            v = values[metric]
            if best_value is None or v > best_value:
                best_value = v
                best_entity = entity
        if best_entity is not None and best_value is not None:
            result[metric] = (
                categorize_metric(metric, best_value),
                _strip_pod_suffix(best_entity),
                best_value,
            )
    return result


def _entity_summary_text(pkg: EvidencePackage) -> str:
    summary = entity_metrics_summary(pkg)
    if not summary:
        return "Pior pod por metrica: sem dado (pacote sem metricas por entidade)."
    parts = [f"{metric}={cat} ({entity})" for metric, (cat, entity, _val) in sorted(summary.items())]
    return "Pior pod por metrica: " + "; ".join(parts) + "."


# Nomes de contadores de estado por pod (mesclados em metrics_by_entity[entidade] por derive_entity_state +
# s4_represent) -- duplicado aqui em vez de importado de memory/blocks.py
# (ENTITY_STATE_NAMES) porque este módulo é copiado sozinho pro container do
# PyCaret (services/pycaret-eval/Dockerfile), que não tem src/memory/.
_ENTITY_STATE_NAMES_FOR_TEXT = ("restart_count", "oomkill_count", "not_ready_flags")


def entity_metrics_detail(pkg: EvidencePackage) -> dict[str, dict[str, str]]:
    """Perfil COMPLETO de cada pod (não só o pior, como entity_metrics_summary)
    -- mesma granularidade genuína por entidade que memory/blocks.py::
    blocks_for_package usa (um bloco por pod), aqui como categorias de texto
    em vez de um vetor numérico projetado.

    Agrupa por nome NORMALIZADO de entidade (_strip_pod_suffix, remove
    sufixo de hash de ReplicaSet/índice de StatefulSet) -- nunca o nome cru:
    cada rollout gera um hash novo por pod, e usar o nome cru faria cada
    "entidade" virar fingerprint de qual bloco/cenário específico em vez de
    sinal real do pod (mesma categoria de vazamento confirmada em
    _raw_pods_text -- nunca verificada aqui porque esta
    função ainda não existia). Métricas contínuas agregam por MAX entre
    instâncias cruas do mesmo serviço no mesmo pacote (rollout com pod
    antigo+novo coexistindo); contadores de estado agregam por SOMA.

    Retorna {entidade_normalizada: {metrica_ou_estado: categoria_ou_contagem}},
    ordenado por nome de entidade. Métrica/entidade sem nenhum dado
    simplesmente não entra -- nunca inventa "sem dado" como valor."""
    mbe = pkg.metrics_by_entity or {}
    grouped: dict[str, dict[str, float]] = {}
    for raw_entity, values in mbe.items():
        entity = _strip_pod_suffix(raw_entity)
        bucket = grouped.setdefault(entity, {})
        for key, value in (values or {}).items():
            try:
                v = float(value)
            except (TypeError, ValueError):
                continue
            if key in _ENTITY_STATE_NAMES_FOR_TEXT:
                bucket[key] = bucket.get(key, 0.0) + v
            else:
                bucket[key] = max(bucket.get(key, v), v)

    result: dict[str, dict[str, str]] = {}
    for entity in sorted(grouped):
        values = grouped[entity]
        cats: dict[str, str] = {}
        for metric in METRIC_NAMES:
            if metric in values:
                cats[metric] = categorize_metric(metric, values[metric])
        for state in _ENTITY_STATE_NAMES_FOR_TEXT:
            if state in values:
                cats[state] = str(int(values[state]))
        if cats:
            result[entity] = cats
    return result


def _entity_detail_text(pkg: EvidencePackage) -> str:
    detail = entity_metrics_detail(pkg)
    if not detail:
        return "Métricas por pod: sem dado (pacote sem métricas por entidade)."
    parts = [
        f"{entity}: " + ", ".join(f"{key}={val}" for key, val in cats.items())
        for entity, cats in detail.items()
    ]
    return "Métricas por pod: " + "; ".join(parts) + "."


def build_text_for_mode(pkg: EvidencePackage, text_mode: str | None = TEXT_MODE_CURRENT) -> str:
    mode = canonical_text_mode(text_mode)
    if mode == TEXT_MODE_CURRENT:
        return _build_current_embedding_text(pkg)
    if mode == TEXT_MODE_CURRENT_NO_MEMORY_WSS:
        return _build_current_embedding_text(pkg, exclude_metrics=_DEFAULT_EXCLUDED_METRICS)
    if mode == TEXT_MODE_CURRENT_WITH_MEMORY_WSS:
        return _build_current_embedding_text(pkg, exclude_metrics=frozenset())
    if mode == TEXT_MODE_BASE:
        return _base_text(pkg)
    if mode == TEXT_MODE_TINY:
        cf = _categorized_features_for_text(pkg)
        return (
            f"Logs volume: {cf.logs_volume}. "
            f"Logs desconhecidos: {pkg.log_details.unknown_count}. "
            f"Top log patterns: {_top_patterns_text(pkg)}. "
            f"Metricas categorizadas: {_categorized_metrics_text(pkg)}."
        )
    if mode == TEXT_MODE_PLUS_TOP_TEMPLATES:
        return f"Top templates brutos: {_raw_templates_text(pkg)}. {_base_text(pkg)}"
    if mode == TEXT_MODE_PLUS_METRICAS:
        return f"Metricas brutas: {_raw_metrics_text(pkg)}. {_base_text(pkg)}"
    if mode == TEXT_MODE_PLUS_LOG_DETAILS:
        return f"{_log_details_text(pkg)} {_base_text(pkg)}"
    if mode == TEXT_MODE_PURE:
        return (
            f"Logs total_count: {pkg.log_details.total_count}. "
            f"Logs unknown_count: {pkg.log_details.unknown_count}. "
            f"Unknown samples: {', '.join(pkg.log_details.unknown_samples or []) or '[]'}. "
            f"Top templates brutos: {_raw_templates_text(pkg)}. "
            f"Pods crus: {_raw_pods_text(pkg)}. "
            f"K8s events literais: {_literal_k8s_events_text(pkg)}. "
            f"Metricas brutas: {_raw_metrics_text(pkg)}. "
            f"Versao/configuracao: {pkg.versao or {}}."
        )
    if mode == TEXT_MODE_CURRENT_SAFE_VERSION:
        return _build_current_embedding_text_safe_version(pkg)
    if mode == TEXT_MODE_PLUS_TOP_TEMPLATES_SAFE_VERSION:
        return f"Top templates brutos: {_raw_templates_text(pkg)}. {_base_text_safe_version(pkg)}"
    if mode == TEXT_MODE_PURE_SAFE:
        return _build_pure_text_safe(pkg)
    if mode == TEXT_MODE_PLUS_ENTITY_SUMMARY:
        return f"{_entity_summary_text(pkg)} {_build_current_embedding_text_safe_version(pkg)}"
    if mode == TEXT_MODE_PLUS_ENTITY_DETAIL:
        return f"{_entity_detail_text(pkg)} {_build_current_embedding_text_safe_version(pkg)}"
    return _build_current_embedding_text(pkg)


def build_embedding_text(pkg: EvidencePackage) -> str:
    return build_text_for_mode(pkg, TEXT_MODE_CURRENT)


def _k8s_to_old_format(raw_events: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if not raw_events:
        return []
    result = []
    seen = set()
    for ev in raw_events:
        ts = ev.get("last_timestamp") or ev.get("first_timestamp") or ev.get("ts") or ""
        kind = ev.get("kind", "Pod")
        reason = str(ev.get("reason", "Unknown"))
        res = str(ev.get("involved_object") or ev.get("res") or "")
        msg = str(ev.get("message") or ev.get("msg") or "")
        entry = {"ts": ts, "kind": kind, "reason": reason, "res": res, "msg": msg}
        js = str(sorted(entry.items()))
        if js not in seen:
            seen.add(js)
            result.append(entry)
    return result


def _top_templates_to_dict(templates: list[Any]) -> dict[str, int]:
    result: dict[str, int] = {}
    for t in templates:
        if hasattr(t, "template") and hasattr(t, "count"):
            result[str(t.template)] = t.count
        elif isinstance(t, dict):
            result[str(t.get("template", ""))] = int(t.get("count", 1))
        elif isinstance(t, tuple):
            result[str(t[0])] = int(t[1])
    return result


def s4_represent(
    data: NormalizedAggregated,
    system_id: str,
    cenario: str = "",
    anomaly_type: str = "modelo",
    anomaly_detected: bool = False,
    severity_score: float = 0.0,
    failure_id: str | None = None,
    window_start: str | None = None,
    window_end: str | None = None,
    k8s_events_raw: list[dict[str, Any]] | None = None,
    version_context: dict[str, Any] | None = None,
    source_run_id: str | None = None,
    config: CollectConfig | None = None,
) -> EvidencePackage | None:
    if data is None:
        return None

    k8s_events = k8s_events_raw or data.k8s_events

    templates_dict = _top_templates_to_dict(data.templates)
    versao = dict(version_context) if version_context else {}

    top_k_value = config.top_k_templates if config else 10

    # topology/categorized_features.normalized_pods vinham só de pod_counts
    # (derivado de menções a pod nos LOGS) -- num chunk sem log nenhum
    # (comum em janelas curtas, ex. package_window_seconds=2), ficavam vazios
    # mesmo com metrics_by_entity confirmando pods ativos de verdade (fonte
    # mais confiável, vem da coleta rotulada por pod, não de parsing de
    # texto). Regressão encontrada revisando pacotes de uma coleta de 2s
    # (2026-09-09) -- mesclado aqui, entidade só-em-métricas entra com
    # contagem de log 0 (não inventa contagem, só presença).
    combined_pod_counts: dict[str, int] = dict(data.pod_counts)
    for entity in data.metrics_by_entity or {}:
        combined_pod_counts.setdefault(entity, 0)

    cf = build_categorized_features(
        templates_dict,
        data.metrics_raw or None,
        data.unknown_count,
        combined_pod_counts,
        k8s_events,
        versao,
        top_k=top_k_value,
    )

    if anomaly_detected or (failure_id and failure_id != system_id):
        pipeline_version = cenario or failure_id or system_id
    elif failure_id:
        pipeline_version = "baseline"
    else:
        pipeline_version = "baseline"

    metrics_by_entity_raw = dict(data.metrics_by_entity) if data.metrics_by_entity else {}
    entity_state = derive_entity_state(k8s_events, metrics_by_entity_raw.keys())
    metrics_by_entity: dict[str, dict[str, float]] = {}
    for entity, entity_metrics in metrics_by_entity_raw.items():
        merged = dict(entity_metrics)
        merged.update(entity_state.get(entity, {}))
        metrics_by_entity[entity] = merged
    # Aditivo: schema_version só sobe quando a coleta de fato
    # trouxe dado por entidade — pacotes sem coleta rotulada (Podman
    # monolítico ou fonte indisponível) continuam bit-a-bit "1.0".
    schema_version = "1.1" if metrics_by_entity else "1.0"

    return EvidencePackage(
        schema_version=schema_version,
        pipeline_version=pipeline_version,
        drain_template_version="manual",
        source_run_id=source_run_id or cenario or system_id,
        categorized_features=cf,
        metadata=MetadataEvidencia(
            cenario=cenario or system_id,
            minute=window_start or "",
            anomaly_detected=anomaly_detected,
            anomaly_type=anomaly_type,
            severity_score=severity_score,
            timestamp_exec=datetime.now(UTC).isoformat(),
        ),
        k8s_infrastructure_events=_k8s_to_old_format(k8s_events),
        log_details=LogDetails(
            total_count=sum(templates_dict.values()) or data.total_log_count,
            unknown_count=data.unknown_count,
            unknown_samples=list(data.unknown_samples),
            top_templates=templates_dict,
        ),
        topology=Topology(active_pods=combined_pod_counts),
        metrics=dict(data.metrics_raw) if data.metrics_raw else {},
        metrics_by_entity=metrics_by_entity,
        baseline=BaselineInfo(historical_mean_unknown=0, baseline_mocked=True),
        versao=versao,
        evidence_id=uuid4().hex,
        system_id=system_id,
        failure_id=failure_id,
        window_start=window_start,
        window_end=window_end,
        collection_policy=CollectionPolicy(
            window_seconds=config.window_seconds if config else 60,
            max_raw_logs=config.max_lines_per_chunk if config else 5000,
            parser="drain",
            sampling_applied=False,
            profile_hash="",
        ),
    )
