"""Entrada do Stage 3: enfileiramento no momento do incidente e handler do job."""

import dataclasses
import datetime
import importlib.metadata
import json
import logging
import os
import socket
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any

from sqlalchemy.exc import IntegrityError

from src.application.stage3.attribution import (
    assign_certainty,
    attribute_entity,
    check_metric_temporal,
    metric_series,
    most_anomalous_entity,
    observed_metrics,
)
from src.application.stage3.audit_package import (
    SELECTION_RULE,
    baseline_section,
    build_audit_package,
    contract_levels,
    describe_incident,
    describe_log,
    freeze_audit_package,
    jsonable,
    known_limitations,
    traces_section,
    validation_report,
)
from src.application.stage3.baseline import CollectionBaseline, load_baseline
from src.application.stage3.config import Stage3Config, resolve_config
from src.application.stage3.conformance import (
    build_entity_candidates,
    deviation_dict,
    find_error_spans,
    find_temporal_deviations,
    select_representative,
)
from src.application.stage3.entities import normalize_entity
from src.application.stage3.llm_synthesis import (
    LLMSynthesisResult,
    RestrictedEvidence,
    build_llm_client,
    build_restricted_evidence,
    synthesize,
)
from src.application.stage3.localizacao import Anomalia, localizar, metricas_observadas
from src.application.stage3.problem_map import build_problem_map
from src.application.stage3.process_models import deserialize_petri_net
from src.application.stage3.traces import JaegerClient, TraceEventLog, recover_incident_trace
from src.application.stage3.types import (
    AttributionResult,
    ConformanceResult,
    EntityCandidate,
    ErrorSpan,
    TemporalDeviation,
)
from src.application.stage3.votes import (
    EntityVotes,
    TraceSignals,
    health_events_window,
    latency_outliers,
    lider_so_estrutural,
    rank_candidates,
    vote_entities,
)

# Provedor de eventos K8s da janela: `(system, start, end) -> eventos no formato do coletor`
# (`{ts, kind, reason, res, msg}`). Injetável para testes e para o replay offline.
K8sEventsProvider = Callable[[Any, datetime.datetime, datetime.datetime], list[dict[str, Any]]]

logger = logging.getLogger(__name__)

STAGE3_JOB_KIND = "stage3_diagnosis"
STAGE3_JOB_PRIORITY = 5
# Monitoramento online (plano de melhoria, 21/09/2026): job efêmero, mesmo handler
# (`run_stage3_online`) que roda no job-runner porque o Conformance Checking real
# precisa de PM4Py (`conformance.py`), que só existe nessa imagem -- o processo `web`
# não tem. Resultado só em `jobs.result_json`, nunca em `stage3_diagnoses`.
STAGE3_ONLINE_JOB_KIND = "stage3_online_preview"


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.UTC).replace(tzinfo=None)


def enqueue_stage3_job(repo: Any, incident: Any) -> Any | None:
    """Cria o diagnóstico `pending` e o job `stage3_diagnosis` do incidente.

    Devolve o job, ou None se o sistema não tem Stage 3 habilitado ou se já existe execução
    para o incidente (uma por incidente).
    """
    system = repo.get_system(incident.system_id)
    if system is None or not system.stage3_enabled:
        return None
    if repo.get_stage3_diagnosis(incident.incident_id) is not None:
        return None
    cfg = resolve_config(dict(system.stage3_config or {}))
    try:
        diagnosis = repo.create_stage3_diagnosis(incident.incident_id, incident.system_id)
    except IntegrityError:  # corrida entre dois ciclos: quem perdeu não enfileira
        return None
    now = _utcnow()
    available_at = now
    if incident.window_end is not None:
        available_at = max(now, incident.window_end + datetime.timedelta(seconds=cfg.trace_settle_seconds))
    logs = repo.get_monitoring_logs(json.loads(incident.log_ids_json or "[]"))
    collection_id = next((log.collection_id for log in reversed(logs) if log.collection_id), None)
    job = repo.enqueue(
        STAGE3_JOB_KIND,
        incident.system_id,
        {
            "incident_id": incident.incident_id,
            "collection_id": collection_id,
            "profile_id": incident.profile_id,
        },
        priority=STAGE3_JOB_PRIORITY,
        dedupe_key=f"stage3:{incident.incident_id}",
        available_at=available_at,
    )
    repo.update_stage3_diagnosis(diagnosis.diagnosis_id, job_id=job.job_id)
    logger.info("stage3 job %s enfileirado para o incidente %s", job.job_id, incident.incident_id)
    return job


def payload_from_job(payload_json: str | dict[str, Any]) -> dict[str, Any]:
    return payload_json if isinstance(payload_json, dict) else json.loads(payload_json)


# --- handler do job `stage3_diagnosis` ---


@dataclass
class _Run:
    """Estado acumulado da execução: alimenta as colunas de `stage3_diagnoses` e o pacote de auditoria."""

    incident: Any
    system: Any
    cfg: Stage3Config
    logs: list[Any]
    collection_id: str | None
    started_at: datetime.datetime
    baseline: CollectionBaseline | None = None
    # Janela de referência do mesmo cenário (Etapa F): `None` quando a coleta é anterior a ela.
    baseline_referencia: CollectionBaseline | None = None
    trace_log: TraceEventLog | None = None
    conformance: ConformanceResult | None = None
    candidates: list[EntityCandidate] = field(default_factory=list)
    error_spans: list[ErrorSpan] = field(default_factory=list)
    span_temporal: list[TemporalDeviation] = field(default_factory=list)
    metric_temporal: list[TemporalDeviation] = field(default_factory=list)
    attributions: dict[str, AttributionResult | None] = field(default_factory=dict)
    attribution: AttributionResult | None = None
    problem_map: dict[str, Any] | None = None
    evidence: RestrictedEvidence | None = None
    synthesis: LLMSynthesisResult | None = None
    localizacao_abstain_reason: str | None = None
    # M3: quem o ranking estrutural apontaria, quando não há sinal de sintoma para confirmar.
    structural_only_leader: str | None = None
    trace_signals: TraceSignals | None = None
    k8s_events: list[dict[str, Any]] = field(default_factory=list)
    votes: list[EntityVotes] = field(default_factory=list)
    structural_candidates: list[dict[str, Any]] = field(default_factory=list)
    # M8 (localization_mode="anomalias"): anomalias detectadas e se o líder tem sintoma não explicado
    anomalias: list[Anomalia] = field(default_factory=list)
    lider_tem_sintoma: bool = True
    provider: str = ""
    model: str = ""


def _pm4py_version() -> str | None:
    try:
        return importlib.metadata.version("pm4py")
    except importlib.metadata.PackageNotFoundError:
        return None


def execute_stage3_diagnosis(
    system_id: str,
    payload: dict[str, Any],
    *,
    repo: Any,
    jaeger_client: JaegerClient | None = None,
    llm_client: Any | None = None,
    hostname: str | None = None,
    k8s_events_provider: K8sEventsProvider | None = None,
) -> dict[str, Any]:
    """Executa o Stage 3 de um incidente e persiste resultado + pacote de auditoria.

    Abstenção não é falha: o job termina normalmente e o diagnóstico fica `abstained`. Só exceção
    (rede/HTTP do Jaeger, bug) vira `failed` e propaga para a retentativa do runner.
    """
    incident_id = str(payload["incident_id"])
    incident = repo.get_incident(system_id, incident_id)
    if incident is None:
        raise ValueError(f"incident not found: {incident_id}")
    diagnosis = repo.get_stage3_diagnosis(incident_id)
    if diagnosis is None:
        diagnosis = repo.create_stage3_diagnosis(incident_id, system_id)
    if diagnosis.status in ("completed", "abstained"):
        return {"incident_id": incident_id, "status": diagnosis.status, "skipped": True}
    system = repo.get_system(system_id)
    cfg = resolve_config(dict(system.stage3_config or {}) if system else {})
    logs = repo.get_monitoring_logs(json.loads(incident.log_ids_json or "[]"))
    collection_id = payload.get("collection_id") or next(
        (log.collection_id for log in reversed(logs) if log.collection_id), None
    )
    run = _Run(incident=incident, system=system, cfg=cfg, logs=logs, collection_id=collection_id,
               started_at=_utcnow())
    repo.update_stage3_diagnosis(diagnosis.diagnosis_id, status="running", error_message=None)
    try:
        abstain = _run_pipeline(run, repo, jaeger_client, llm_client, k8s_events_provider)
        return _persist(run, repo, diagnosis, abstain, hostname)
    except Exception as exc:
        logger.exception("stage3 falhou para o incidente %s", incident_id)
        repo.mark_stage3_failed(diagnosis.diagnosis_id, f"{type(exc).__name__}: {exc}")
        raise


def default_k8s_events(system: Any, start: datetime.datetime, end: datetime.datetime) -> list[dict[str, Any]]:
    """Eventos do namespace do sistema na janela (mesmo coletor da coleta offline)."""
    try:
        from src.collector.tasks import _fetch_orchestration_events
        from src.infra.settings import get_settings

        return list(_fetch_orchestration_events(
            get_settings(), system, start.isoformat() + "Z", end.isoformat() + "Z",
        ) or [])
    except Exception as exc:  # evento é sinal auxiliar: nunca derruba o Stage 3
        logger.warning("stage3: eventos K8s indisponiveis (%s)", exc)
        return []


def _known_services(run: _Run) -> set[str]:
    assert run.baseline is not None
    known = set(run.baseline.metric_stats)
    for graph in run.baseline.service_graph.values():
        for key in graph:
            known.update(part for part in str(key).split("->") if ":" not in part)  # `mysql:teadb` é banco
    return {normalize_entity(k.strip()) for k in known if k.strip()}


def _run_votes(
    run: _Run, k8s_events_provider: K8sEventsProvider | None, observed: dict[str, dict[str, float]]
) -> None:
    """Localização por votos (votes.py): roda também quando o Conformance se absteve."""
    assert run.baseline is not None
    cfg, incident = run.cfg, run.incident
    if run.trace_log is not None and run.trace_log.signals:
        run.trace_signals = TraceSignals.from_dict(run.trace_log.signals)
    else:
        start = incident.window_start - datetime.timedelta(seconds=cfg.lookback_sec)
        run.trace_signals = TraceSignals(window_seconds=(incident.window_end - start).total_seconds())
    start, end = health_events_window(
        incident.window_start, incident.window_end, cfg.k8s_event_lookback_sec, cfg.trace_settle_seconds,
    )
    run.k8s_events = (
        k8s_events_provider(run.system, start, end)
        if k8s_events_provider is not None and run.system is not None else []
    )
    run.structural_candidates = [c.to_dict() for c in run.candidates]
    if cfg.localization_mode == "anomalias":
        ref_stats = (run.baseline_referencia.service_stats or None) if run.baseline_referencia else None
        run.votes, run.anomalias, run.lider_tem_sintoma = localizar(
            base_stats=run.baseline.service_stats or None,
            janela_stats=run.trace_log.window_stats if run.trace_log is not None else None,
            metric_stats=run.baseline.metric_stats, observadas=metricas_observadas(run.logs),
            eventos_k8s=run.k8s_events, ranking_estrutural=[c.pod_name for c in run.candidates], cfg=cfg,
            base_referencia=ref_stats,
        )
        run.candidates = rank_candidates(run.votes, run.candidates, cfg.top_k_candidates)
        return
    endpoint_traces = (
        run.trace_log.traces_by_endpoint().get(run.conformance.endpoint)
        if run.conformance is not None and run.trace_log is not None else None
    )
    latency = (
        latency_outliers(
            endpoint_traces, run.baseline.span_stats.get(run.conformance.endpoint),
            factor=cfg.latency_p95_factor, min_samples=cfg.latency_min_samples,
        ) if run.conformance is not None and cfg.vote_weights.get("latencia") else []
    )
    run.votes = vote_entities(
        signals=run.trace_signals, candidates=run.candidates,
        deviations=run.conformance.deviations if run.conformance else [], k8s_events=run.k8s_events, cfg=cfg,
        known_services=_known_services(run),
        endpoint_traces=endpoint_traces, latency=latency,
        metric_leader=most_anomalous_entity(
            {e: {m: v for m, v in obs.items() if m not in cfg.metric_vote_excluded} for e, obs in observed.items()},
            run.baseline.metric_stats, cfg.delta_threshold,
        ),
    )
    run.candidates = rank_candidates(run.votes, run.candidates, cfg.top_k_candidates)


def _run_pipeline(
    run: _Run,
    repo: Any,
    jaeger_client: JaegerClient | None,
    llm_client: Any | None,
    k8s_events_provider: K8sEventsProvider | None = None,
) -> str | None:
    """Passos 2–6 do diagnóstico. Devolve o `abstain_reason`, ou None se concluiu.

    Com `localization_votes`, abstenções do Conformance (sem trace, sem modelo de
    processo, sem desvio) deixam de encerrar a execução: viram `localizacao_abstain_reason` e a
    localização segue pelos votos.
    """
    cfg, incident = run.cfg, run.incident

    # 2–3. baseline de métricas e de traces
    run.baseline = load_baseline(run.collection_id, repo) if run.collection_id else None
    if run.baseline is None:
        return "baseline_nao_calculado"
    if not run.baseline.process_models:
        return "traces_baseline_nao_coletados"
    # Referência do mesmo cenário, coletada antes da injeção (Etapa F). Opcional: incidentes sem
    # referência continuam sendo localizados só contra a baseline global.
    ref_id = getattr(run.incident, "referencia_collection_id", None)
    run.baseline_referencia = load_baseline(ref_id, repo) if ref_id else None

    # 4a. traces do incidente
    endpoint = cfg.resolved_jaeger_endpoint()
    if jaeger_client is None and not endpoint:
        raise ValueError("Jaeger nao configurado: defina stage3_config.jaeger_endpoint ou JAEGER_QUERY_URL")
    if not cfg.entry_services:
        raise ValueError("stage3_config.entry_services e obrigatorio para o Stage 3")
    # P5 (plano de melhoria, 21/09/2026): o onset real da falha pode ter sido escrito antes do
    # primeiro monitoring_log anômalo (ex. F14/log-bomb) -- ou a janela do incidente é curta demais
    # pra acumular traces suficientes pra um Conformance Checking estável (F1). `lookback_sec`
    # estende só o INÍCIO da busca de traces, não a janela do incidente em si (window_start/window_end
    # continuam sendo o que o incidente registrou -- o pacote de auditoria e o resto do pipeline
    # não mudam); o efetivo fica registrado em stage3.traces.query.window_start.
    trace_window_start = incident.window_start - datetime.timedelta(seconds=cfg.lookback_sec)
    run.trace_log = recover_incident_trace(
        incident.incident_id, (trace_window_start, incident.window_end), endpoint or "",
        list(cfg.entry_services), cfg.excluded_services, cfg.entry_operation_regex, cfg.trace_limit,
        client=jaeger_client, discovery_service=cfg.discovery_service,
        discovery_route_regex=cfg.discovery_route_regex, discovery_bucket_sec=cfg.discovery_bucket_sec,
        known_services=tuple(_known_services(run)),
    )
    if run.trace_log is None:
        if not cfg.localization_votes:
            return "trace_incidente_indisponivel"
        run.localizacao_abstain_reason = "trace_incidente_indisponivel"
    elif run.trace_log.n_complete_traces < cfg.min_traces_incidente:
        run.localizacao_abstain_reason = "traces_insuficientes_no_incidente"
    if run.trace_log is not None and run.trace_log.n_rejected:
        # A distinção que a contagem bruta não fazia. `orfao_nao_server:<svc>` nomeia o serviço que
        # EMITIU o span órfão (o span que faltou é desconhecido por definição), então é indício de queda
        # a jusante; `sem_span_de_entrada` é perda da raiz, ou seja, perda de rastreamento. Fica no log do
        # job para o número não ser lido como "302 traces jogados fora" sem saber o motivo.
        logger.info(
            "traces recusados no incidente %s: %d de %d -- %s",
            run.incident.incident_id if run.incident else None, run.trace_log.n_rejected,
            run.trace_log.n_recovered, run.trace_log.rejection_reasons or {},
        )

    # observado por entidade (também usado pela seleção de candidatos, abaixo: corroboração por métrica)
    observed = observed_metrics(run.logs)

    span_stats: dict[str, Any] = {}
    models: dict[str, Any] = {}
    if run.localizacao_abstain_reason is None:
        assert run.trace_log is not None
        by_endpoint = run.trace_log.traces_by_endpoint()
        models = {
            ep: deserialize_petri_net(run.baseline.process_models[ep])
            for ep in by_endpoint if ep in run.baseline.process_models
        }
        if not models:
            if not cfg.localization_votes:
                return "endpoint_sem_modelo_de_processo"
            run.localizacao_abstain_reason = "endpoint_sem_modelo_de_processo"
    if run.localizacao_abstain_reason is None:
        # 4b–4e. Conformance e suspeitos
        assert run.trace_log is not None
        by_endpoint = run.trace_log.traces_by_endpoint()
        run.conformance = select_representative(by_endpoint, models)
        assert run.conformance is not None
        rep_events = run.trace_log.traces()[run.conformance.trace_id]
        span_stats = dict(run.baseline.span_stats.get(run.conformance.endpoint, {}))
        run.error_spans = find_error_spans(rep_events)
        run.span_temporal = find_temporal_deviations(
            rep_events, by_endpoint[run.conformance.endpoint], span_stats,
            z_outlier=cfg.z_outlier, p95_factor=cfg.p95_factor, cusum_window=cfg.cusum_window,
        )
        run.candidates = build_entity_candidates(
            rep_events, run.conformance.deviations, run.error_spans, run.span_temporal, cfg.top_k_candidates,
            observed_metrics_by_entity=observed, metric_stats=run.baseline.metric_stats,
            delta_threshold=cfg.delta_threshold,
        )
        if not run.candidates and not cfg.localization_votes:
            return "sem_desvio_detectado"

    # 4f. votos de localização (votes.py): o ranking do Conformance vira um voto entre vários
    if cfg.localization_votes:
        _run_votes(run, k8s_events_provider, observed)

    # 5. atributo, checagem temporal e certeza
    if run.candidates:
        for cand in run.candidates:
            run.attributions[cand.pod_name] = attribute_entity(
                cand.pod_name, observed.get(cand.pod_name, {}), run.baseline.metric_stats, cfg.delta_threshold,
            )
        run.attribution = run.attributions[run.candidates[0].pod_name]
    else:  # localização absteve parcialmente: a entidade mais anômala por |δ| é o suspeito
        run.attribution = most_anomalous_entity(observed, run.baseline.metric_stats, cfg.delta_threshold)
        if run.attribution is not None:
            entity = normalize_entity(run.attribution.pod_name)
            run.attributions[entity] = run.attribution
            run.candidates = [EntityCandidate(
                rank=1, pod_name=entity, service=entity, activity=run.attribution.dominant_metric,
                deviation_type="metric", deviation_types=["metric"], depth=None, position=-1, n_spans=0,
            )]
    if run.attribution is not None and run.candidates:
        _metric_temporal(run, repo, observed)
    assign_certainty(
        run.candidates, deviations=run.conformance.deviations if run.conformance else [],
        error_spans=run.error_spans, span_temporal=run.span_temporal, attributions=run.attributions,
        signal_weights=cfg.signal_weights, z_outlier=cfg.z_outlier,
    )

    # 5e. mapa do problema
    if run.trace_log is not None and run.trace_log.n_complete_traces:
        run.problem_map = build_problem_map(
            run.trace_log.traces(), window=(incident.window_start, incident.window_end),
            conformance=run.conformance, candidates=run.candidates, error_spans=run.error_spans,
            attributions=run.attributions,
            span_stats={run.conformance.endpoint: span_stats} if run.conformance else None,
            service_graph=run.baseline.service_graph or None, z_outlier=cfg.z_outlier,
            max_nodes=cfg.map_max_nodes, max_edges=cfg.map_max_edges,
        )

    if not run.candidates:
        return "sem_desvio_detectado"

    # 4g. M3: o líder é só do ranking estrutural. Não é "sem desvio" -- houve desvio, mas nenhum sinal
    # de sintoma o sustenta, e publicar o primeiro colocado seria nomear um serviço sem evidência
    # contra ele (auth em F4/F8/F10/F14). Encerra aqui: o próximo passo é a síntese, que é justamente
    # onde a ausência de evidência viraria uma hipótese confiante.
    # Depois de `assign_certainty`: os sinais do span suspeito (erro/duração/métrica) também contam como
    # evidência, e só existem a partir daqui.
    # M8: no modo "anomalias" o líder precisa de sintoma não explicado por outro serviço.
    if cfg.localization_votes and cfg.localization_mode == "anomalias" and not run.lider_tem_sintoma:
        run.localizacao_abstain_reason = "sem_sintoma_nao_explicado"
        return "sem_sintoma_nao_explicado"
    if cfg.localization_votes and cfg.localization_mode != "anomalias" and cfg.structural_only_abstains:
        so_estrutural = lider_so_estrutural(run.votes, cfg, run.candidates)
        if so_estrutural is not None and so_estrutural.entity == normalize_entity(run.candidates[0].pod_name):
            run.localizacao_abstain_reason = "evidencia_apenas_estrutural"
            run.structural_only_leader = so_estrutural.entity
            return "evidencia_apenas_estrutural"

    # 6. síntese LLM
    run.evidence = build_restricted_evidence(
        system_name=run.system.name if run.system else incident.system_id,
        incident_hypothesis=str(incident.hypothesis), incident_created_at=_iso(incident.created_at) or "",
        conformance=run.conformance, candidates=run.candidates, attribution=run.attribution,
        attributions=run.attributions, error_spans=run.error_spans, span_temporal=run.span_temporal,
        metric_temporal=run.metric_temporal, problem_map=run.problem_map, z_outlier=cfg.z_outlier,
        fitness_threshold=cfg.fitness_threshold,
    )
    llm_config = repo.get_llm_config()
    run.provider = str(llm_config.get("provider") or "mock")
    run.model = str(llm_config.get("model") or "")
    client = llm_client or build_llm_client(llm_config)
    run.synthesis = synthesize(run.evidence, client, provider=run.provider, model=run.model)
    return run.synthesis.abstain_reason if run.synthesis.abstain else None


def _metric_temporal(run: _Run, repo: Any, observed: dict[str, dict[str, float]]) -> None:
    """Série das métricas anômalas do suspeito 1: até `series_packages` logs anteriores + os do incidente."""
    assert run.attribution is not None and run.baseline is not None
    entity = normalize_entity(run.attribution.pod_name)
    previous = repo.list_monitoring_logs_before(
        run.incident.system_id, run.logs[0].run_id if run.logs else None, run.incident.window_start,
        run.cfg.series_packages,
    )
    for metric in run.attribution.anomalous_metrics[:5]:
        stats = (run.baseline.metric_stats.get(entity) or {}).get(metric)
        if not stats:
            continue
        values, times = metric_series(previous, run.logs, entity, metric)
        dev = check_metric_temporal(
            entity, metric, values, times, stats, z_outlier=run.cfg.z_outlier, p95_factor=run.cfg.p95_factor,
            cusum_window=run.cfg.cusum_window,
        )
        if dev is not None:
            run.metric_temporal.append(dev)


def _iso(value: datetime.datetime | None) -> str | None:
    return value.isoformat() if value else None


def run_stage3_online(
    system_id: str,
    collection_id: str,
    *,
    repo: Any,
    jaeger_client: JaegerClient | None = None,
    llm_client: Any | None = None,
    now: datetime.datetime | None = None,
    k8s_events_provider: K8sEventsProvider | None = None,
) -> dict[str, Any]:
    """Monitoramento online do Stage 3 (plano de melhoria, 21/09/2026): roda o mesmo `_run_pipeline`
    de um incidente real sobre uma janela rolante `[now - package_window_seconds, now]` -- a janela
    é sempre herdada de `collection.package_window_seconds` (a mesma janela usada pra montar a
    baseline dessa coleção), nunca um valor fixo à parte. Não abre incidente, não enfileira job e
    **não persiste nada** (nenhuma escrita em `stage3_diagnoses`, nenhum pacote de auditoria
    congelado) -- é uma pré-visualização pra validar o Stage 3 contra o fluxo real da aplicação, não
    substitui o fluxo de incidente real."""
    system = repo.get_system(system_id)
    if system is None:
        raise ValueError(f"system not found: {system_id}")
    collection = repo.get_collection(collection_id)
    if collection is None or str(collection.system_id) != system_id:
        raise ValueError(f"collection not found for system {system_id}: {collection_id}")

    now = now or _utcnow()
    window_start = now - datetime.timedelta(seconds=collection.package_window_seconds)
    incident = SimpleNamespace(
        system_id=system_id, incident_id=f"online:{uuid.uuid4()}", window_start=window_start,
        window_end=now, hypothesis="monitoramento_online", created_at=now, profile_id=None,
    )
    cfg = resolve_config(dict(system.stage3_config or {}))
    logs = repo.list_monitoring_logs_in_window(system_id, window_start, now)
    run = _Run(incident=incident, system=system, cfg=cfg, logs=logs, collection_id=collection_id, started_at=now)
    abstain_reason = _run_pipeline(run, repo, jaeger_client, llm_client, k8s_events_provider)
    status = "abstained" if abstain_reason else "completed"
    return {
        "system_id": system_id, "collection_id": collection_id,
        "window_start": _iso(window_start), "window_end": _iso(now),
        "status": status, "abstain_reason": abstain_reason, "n_logs_in_window": len(logs),
        "diagnosis": _result_fields(run), "stage3": _stage3_section(run, status, abstain_reason),
    }


def _result_fields(run: _Run) -> dict[str, Any]:
    """Colunas de `stage3_diagnoses` a partir do estado da execução."""
    cfg = run.cfg
    fields: dict[str, Any] = {
        "theta_snapshot": cfg.to_dict(), "localizacao_abstain_reason": run.localizacao_abstain_reason,
        "structural_only_leader": run.structural_only_leader,
        "baseline_n_samples": run.baseline.n_samples if run.baseline else None,
    }
    if run.trace_log is not None:
        fields["n_traces_recuperados"] = run.trace_log.n_complete_traces
    if run.conformance is not None:
        fields.update(endpoint=run.conformance.endpoint, trace_id=run.conformance.trace_id,
                      top_candidate_score=run.conformance.fitness)
    if run.candidates:
        top = run.candidates[0]
        fields.update(
            entity_candidates=[c.to_dict() for c in run.candidates], top_candidate_pod=top.pod_name,
            top_candidate_service=top.service, top_candidate_activity=top.activity,
            top_candidate_confidence=top.confidence, t_start=top.t_start,
        )
    if run.attribution is not None:
        a = run.attribution
        fields.update(anomaly_type=a.anomaly_type, dominant_metric=a.dominant_metric, dominant_delta=a.dominant_delta,
                      anomalous_metrics=list(a.anomalous_metrics), metric_deltas=dict(a.metric_deltas))
    fields["temporal_deviations"] = jsonable([*run.span_temporal, *run.metric_temporal])
    if run.problem_map is not None:
        fields["problem_map"] = run.problem_map
    if run.evidence is not None:
        fields["restricted_evidence"] = run.evidence.to_dict()
    if run.synthesis is not None:
        s = run.synthesis
        fields.update(
            llm_abstain=s.abstain, llm_prompt=s.prompt_used, llm_raw_response=s.raw_response,
            llm_provider=s.llm_provider, llm_model=s.llm_model, llm_abstain_reason=s.abstain_reason,
        )
        if not s.abstain:
            fields.update(
                llm_fault=s.fault, llm_error=s.error, llm_failure=s.failure, llm_hypothesis=s.hypothesis,
                llm_confidence=s.confidence, llm_confidence_reason=s.confidence_reason,
                llm_supporting_evidence=s.supporting_evidence, llm_alternatives=s.alternative_hypotheses,
                llm_missing_evidence=s.missing_evidence,
            )
    return fields


def _attr_dict(attribution: AttributionResult | None) -> dict[str, Any] | None:
    return dataclasses.asdict(attribution) if attribution is not None else None


SELECTION_RULE_ANOMALIAS = "anomalias(escore robusto × baseline, k)+propagacao(grafo de chamadas)/v6"


def _stage3_section(run: _Run, status: str, abstain_reason: str | None) -> dict[str, Any]:
    cfg = run.cfg
    window = [_iso(run.incident.window_start), _iso(run.incident.window_end)]
    traces = run.trace_log.traces() if run.trace_log else {}
    conformance = run.conformance
    fitness = dict(conformance.fitness_by_trace) if conformance else {}
    endpoints = {tid: run.trace_log.endpoint_of(tid) or "" for tid in traces} if run.trace_log else {}
    entities = [c.pod_name for c in run.candidates] or ([run.attribution.pod_name] if run.attribution else [])
    localization = {
        "fitness": conformance.fitness if conformance else None,
        "n_traces_aligned": conformance.n_traces_aligned if conformance else 0,
        "representative_trace_id": conformance.trace_id if conformance else None,
        "endpoint": conformance.endpoint if conformance else None,
        "deviations": [deviation_dict(d) for d in conformance.deviations] if conformance else [],
        "suspects": [c.to_dict() for c in run.candidates],
        "selection_rule": SELECTION_RULE if cfg.localization_mode != "anomalias" else SELECTION_RULE_ANOMALIAS,
        "mode": cfg.localization_mode,
        "votes": [v.to_dict() for v in run.votes],
        "anomalias": [a.to_dict() for a in run.anomalias],
        "structural_suspects": run.structural_candidates,
        "trace_signals": run.trace_signals.to_dict() if run.trace_signals else None,
        "k8s_events": run.k8s_events,
    }
    attribute = {
        "per_suspect": [
            {"entity": c.pod_name,
             "attribution": _attr_dict(run.attributions.get(c.pod_name)),
             "temporal_deviations": [dataclasses.asdict(t) for t in [*run.span_temporal, *run.metric_temporal]
                                     if normalize_entity(t.pod_name) == c.pod_name],
             "error_spans": [dataclasses.asdict(e) for e in run.error_spans if normalize_entity(e.pod) == c.pod_name]}
            for c in run.candidates
        ],
        "h_4": dataclasses.asdict(run.attribution) if run.attribution else None,
    }
    synthesis = None
    if run.synthesis is not None and run.evidence is not None:
        s = run.synthesis
        synthesis = {
            "restricted_evidence": run.evidence.to_dict(), "prompt": s.prompt_used, "raw_response": s.raw_response,
            "output": {k: getattr(s, k) for k in (
                "fault", "error", "failure", "hypothesis", "confidence", "confidence_reason",
                "supporting_evidence", "alternative_hypotheses", "missing_evidence", "abstain")},
            "provider": s.llm_provider, "model": s.llm_model, "parameters": {"temperature": 0.0},
            "validation": validation_report(s.validation_errors),
            "hypothesis": s.hypothesis, "confidence": s.confidence, "supporting_evidence": s.supporting_evidence,
            "missing_evidence": s.missing_evidence, "abstain": s.abstain,
        }
    top_entity = entities[0] if entities else None
    return {
        "status": status, "abstain_reason": abstain_reason,
        "localizacao_abstain_reason": run.localizacao_abstain_reason, "parameters": cfg.to_dict(),
        "baseline": baseline_section(
            run.baseline, entities=entities, endpoint=conformance.endpoint if conformance else None,
        ),
        "traces": traces_section(
            jaeger_endpoint=cfg.resolved_jaeger_endpoint(), log=run.trace_log, fitness_by_trace=fitness,
            endpoint_by_trace=endpoints, traces=traces,
            representative_id=conformance.trace_id if conformance else None, n_snapshots=cfg.audit_trace_snapshots,
        ),
        "localization": localization, "attribute": attribute, "problem_map": run.problem_map, "synthesis": synthesis,
        "contract_levels": contract_levels(
            candidates=[c.to_dict() for c in run.candidates],
            attribution=dataclasses.asdict(run.attribution) if run.attribution else None,
            synthesis=synthesis, window=window, theta=cfg.to_dict(), conformance=localization if conformance else None,
        ),
        "top_entity": top_entity,
    }


def _persist(run: _Run, repo: Any, diagnosis: Any, abstain_reason: str | None, hostname: str | None) -> dict[str, Any]:
    """Passo 7/7b: resultado + pacote de auditoria congelado na mesma transação."""
    incident, cfg = run.incident, run.cfg
    status = "abstained" if abstain_reason else "completed"
    snapshot = json.loads(incident.profile_snapshot_json) if incident.profile_snapshot_json else None
    if snapshot is None:
        snapshot = repo.capture_profile_snapshot(incident.system_id, "stage3_start")
    job = repo.get_job(diagnosis.job_id) if diagnosis.job_id else None
    now = _utcnow()
    stage3 = _stage3_section(run, status, abstain_reason)
    n_orphans = run.trace_log.n_orphans_attached if run.trace_log else 0
    map_inferred = bool(run.problem_map and (
        any(n.get("inferred") for n in run.problem_map["nodes"])
        or any(e["kind"] == "inferred_call" for e in run.problem_map["edges"])
    ))
    package = build_audit_package(
        incident=describe_incident(incident), logs=[describe_log(log) for log in run.logs],
        profile_snapshot=snapshot, stage3=stage3,
        execution={
            "job_id": diagnosis.job_id, "attempts": job.attempts if job else None,
            "started_at": _iso(run.started_at), "completed_at": _iso(now),
            "worker": hostname or socket.gethostname(), "code_version": os.environ.get("CODE_VERSION"),
            "pm4py_version": _pm4py_version(), "jaeger_version": os.environ.get("JAEGER_VERSION"),
        },
        limitations=known_limitations(
            rules_engine_used="rules" in {str(snapshot.get("stage1_engine")), str(snapshot.get("stage2_engine"))},
            profile_source=snapshot.get("source"), n_orphans_attached=n_orphans, has_inferred_map=map_inferred,
            n_traces_recovered=run.trace_log.n_complete_traces if run.trace_log else 0,
            n_snapshots=cfg.audit_trace_snapshots,
        ),
    )
    frozen = freeze_audit_package(package, system_id=incident.system_id, hostname=hostname)
    sha = frozen["integrity"]["package_sha256"]
    fields = _result_fields(run)
    if abstain_reason:
        repo.mark_stage3_abstained(diagnosis.diagnosis_id, abstain_reason, fields,
                                   audit_package=frozen, audit_sha256=sha)
    else:
        repo.mark_stage3_completed(diagnosis.diagnosis_id, fields, audit_package=frozen, audit_sha256=sha)
    return {"incident_id": incident.incident_id, "status": status, "abstain_reason": abstain_reason,
            "audit_sha256": sha, "top_candidate": run.candidates[0].pod_name if run.candidates else None}
