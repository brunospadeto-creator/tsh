"""Tipos compartilhados do Stage 3."""

import datetime
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Deviation:
    type: str            # "missing" | "unexpected" | "wrong_order"
    activity: str        # "<serviço>: <operação>"
    pod: str
    position: int        # ordem de início do span no trace (-1 em "missing")
    depth: int | None    # profundidade na árvore de chamadas; None em "missing"
    span_id: str | None = None


@dataclass
class ErrorSpan:
    activity: str
    pod: str
    depth: int
    t_start: datetime.datetime
    exception: str | None
    span_id: str | None = None
    position: int = 0


@dataclass
class TemporalDeviation:
    """Desvio temporal de uma métrica de entidade ou da duração de uma atividade (spans)."""

    metric_name: str          # nome da métrica, ou a atividade quando é um span
    pod_name: str
    outlier_indices: list[int] = field(default_factory=list)
    change_point_indices: list[int] = field(default_factory=list)
    is_anomalous_ts: bool = False
    t_start: datetime.datetime | None = None
    magnitude: float = 0.0    # |δ| no instante t_start (|z| para spans)
    span_id: str | None = None
    depth: int | None = None
    position: int | None = None
    via_percentile: bool = False  # disparou por p95×fator, não pelo z-score (baseline assimétrica/bimodal)


@dataclass
class ConformanceResult:
    fitness: float
    deviations: list[Deviation]
    trace_id: str
    endpoint: str
    n_traces_aligned: int
    fitness_by_trace: dict[str, float] = field(default_factory=dict)   # todos os traces alinhados


@dataclass
class EntityCandidate:
    """Suspeito de entidade com a certeza calculada depois."""

    rank: int
    pod_name: str                     # entidade normalizada
    service: str
    activity: str
    deviation_type: str               # "error" | "unexpected" | "wrong_order" | "temporal" | "missing"
    deviation_types: list[str]
    depth: int | None
    position: int
    n_spans: int
    t_start: datetime.datetime | None = None
    signals: list[str] = field(default_factory=list)
    score: float | None = None
    confidence: str | None = None
    confidence_reason: str | None = None
    vote_score: float | None = None   # soma dos votos (votes.py)
    votes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "rank": self.rank, "pod_name": self.pod_name, "service": self.service, "activity": self.activity,
            "deviation_type": self.deviation_type, "deviation_types": list(self.deviation_types),
            "depth": self.depth, "position": self.position, "n_spans": self.n_spans,
            "t_start": self.t_start.isoformat() if self.t_start else None,
            "signals": list(self.signals), "score": self.score,
            "confidence": self.confidence, "confidence_reason": self.confidence_reason,
            "vote_score": self.vote_score, "votes": list(self.votes),
        }


@dataclass
class AttributionResult:
    pod_name: str
    metric_deltas: dict[str, float]
    anomalous_metrics: list[str]
    anomaly_type: str
    dominant_metric: str
    dominant_delta: float
