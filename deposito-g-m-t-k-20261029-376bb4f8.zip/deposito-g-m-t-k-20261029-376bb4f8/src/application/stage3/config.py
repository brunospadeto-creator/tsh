"""Parâmetros θ do Stage 3, resolvidos a partir de `systems.stage3_config`."""

import os
from dataclasses import asdict, dataclass, field
from typing import Any

DEFAULT_SIGNAL_WEIGHTS: dict[str, float] = {"erro": 0.35, "duração": 0.25, "métrica": 0.25, "fluxo": 0.15}
DEFAULT_EXCLUDED_SERVICES = ("jaeger-all-in-one", "teastore-registry")
# Localização por votos (votes.py). Pesos provisórios, calibrados offline sobre o
# lote F1-F14 (replay) -- revalidar a cada lote novo.
DEFAULT_VOTE_WEIGHTS: dict[str, float] = {
    # descoberta 2.5 (não 2.0): consultas ao registry nomeiam o serviço inalcançável e devem vencer os erros
    # propagados no chamador (estrutural + taxa_erro); replay de 56 casos: Top-1 71% -> 82%
    # chamada_ausente 2.0 (não 1.0) desde que exige ausência em >= 50% dos traces: F7 (persistence ausente em
    # 99%) perdia para o webui (estrutural + taxa_erro). Calibrado só nos lotes de calibração
    "estrutural": 1.0, "descoberta": 2.5, "inanicao": 2.0, "fronteira": 1.0,
    "taxa_erro": 1.0, "chamada_ausente": 2.0, "k8s": 2.0,
    # desligado: no replay dos 3 lotes o líder de |δ| é quase sempre drift da baseline ou resíduo do
    # cenário anterior (Top-2 95% -> 83-93% com o voto ligado); religar após recoletar a baseline
    "metrica": 0.0,
    # desligado pelo mesmo motivo: a baseline de traces é do sistema saturado
    "latencia": 0.0,
    # respostas >= 400 no serviço mais profundo abaixo da entrada (F8, F13); replay dos lotes de calibração:
    # 8 ganhos, 0 perdas, Top-1 58% -> 69% junto com chamada_ausente 2.0
    "erro_http": 2.0,
}
# Motivos de evento K8s que indicam saúde ruim do pod. Ficam de fora os de ciclo de vida
# (Scheduled/Pulled/Created/Started/Killing/ScalingReplicaSet): o próprio deploy da injeção os gera.
DEFAULT_K8S_HEALTH_REASONS = ("Unhealthy", "BackOff", "OOMKilling", "OOMKilled", "Evicted", "ProbeWarning")


@dataclass(frozen=True)
class Stage3Config:
    fitness_threshold: float = 0.8
    delta_threshold: float = 2.0
    z_outlier: float = 3.0
    p95_factor: float = 1.5  # detector por percentil; provisório, a calibrar com F1-F14
    cusum_window: int = 5
    series_packages: int = 20
    min_baseline_samples: int = 5
    min_traces_per_endpoint: int = 30
    noise_threshold: float = 0.2
    top_k_candidates: int = 3
    audit_trace_snapshots: int = 3
    map_max_nodes: int = 50
    map_max_edges: int = 200
    excluded_services: tuple[str, ...] = DEFAULT_EXCLUDED_SERVICES
    trace_limit: int = 200
    trace_settle_seconds: int = 30
    entry_services: tuple[str, ...] = ()
    entry_operation_regex: str = r"^[A-Z]+ /"
    min_traces_incidente: int = 1
    lookback_sec: int = 0
    signal_weights: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_SIGNAL_WEIGHTS))
    jaeger_endpoint: str | None = None
    # --- localização por votos (votes.py) ---
    localization_votes: bool = True
    vote_weights: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_VOTE_WEIGHTS))
    discovery_service: str | None = None  # ex.: "teastore-registry"; None desliga o voto de descoberta
    discovery_route_regex: str = r"/services/([^/?]+)"
    discovery_min_lookups: int = 10
    # consultas / requisições de entrada na janela; 0 desliga. Com janela longa (5 min) o piso
    # absoluto de 10 consultas deixa passar ruído (F14: 27 consultas em 3062 requisições, 0,9%)
    discovery_min_rate: float = 0.0
    discovery_dominant_share: float = 0.6
    # fração mínima dos intervalos de `discovery_bucket_sec` com consulta ao alvo; 0 desliga. Exclui a
    # rajada de redescoberta do pod recriado pela injeção (F3/F8/F10 acertavam só por ela, nos 5 lotes)
    # e o ruído periódico de consultas ao auth -- o mesmo vazamento que tirou os eventos de ciclo de vida
    # do voto k8s
    discovery_bucket_sec: int = 30
    discovery_min_bucket_share: float = 0.5
    discovery_uniform_min_targets: int = 3
    discovery_uniform_min_share: float = 0.2
    starve_min_roots_per_min: float = 15.0
    error_rate_min_spans: int = 5
    error_rate_low: float = 0.1
    error_rate_high: float = 0.5
    missing_min_activities: int = 3
    # fração mínima dos traces do endpoint em que o serviço também falta; 0 = só o trace representativo.
    # Só o representativo acusava o persistence em 10/14 cenários, inclusive falhas do webui
    missing_min_trace_share: float = 0.5
    http_error_min_share: float = 0.1  # ruído máximo visto fora da falha: auth 8,4%
    http_error_min_spans: int = 20
    latency_p95_factor: float = 2.0
    latency_min_samples: int = 20
    k8s_health_reasons: tuple[str, ...] = DEFAULT_K8S_HEALTH_REASONS
    k8s_event_lookback_sec: int = 30
    # métricas fora do voto `metrica`: o nível de memória reflete a idade do pod (recriado pela própria
    # injeção) mais que a falha -- mesmo vazamento já visto em `memoria_working_set_mb`
    metric_vote_excluded: tuple[str, ...] = ("memoria_usage_mb", "memoria_working_set_mb")
    # --- M3: `estrutural` sozinho não accuse ninguém ---
    # O voto `estrutural` sai do ranking do Conformance, que compara o incidente com a baseline sem
    # olhar para nenhum sintoma. Ele existe para desempatar e para ranquear, não para provar que um
    # serviço quebrou. Quando ele era o único voto do líder, o Stage 3 nomeava o auth como suspeito em
    # falhas que não eram dele (F4/F8/F10/F14 no lote `081432Z`) -- e, pior, sem se abster: publicava
    # um nome com confiança alta. Ligado por padrão; desligar volta ao comportamento anterior.
    structural_only_abstains: bool = True
    # --- M8: localização sem pesos ---
    # "votos" = soma ponderada de votes.py (v5); "anomalias" = localizacao.py: desvio robusto contra a
    # baseline do próprio sistema + propagação pelo grafo de chamadas. Os três números abaixo são os únicos
    # ajustes do modo "anomalias": quantos desvios robustos contam como anomalia, amostra mínima, e a variação
    # relativa abaixo da qual duração/métrica não é sintoma (piso do desvio).
    #
    # O default é "anomalias", e não "votos", porque é o modo que a calibração escolheu com os 28 casos de
    # `exp-v1.1.0` (Top-1 22/28 contra 17/28 do modo de votos nos mesmos casos).
    # Com o default antigo, um sistema novo nasceria decidindo pelo modo que a calibração mediu como inferior,
    # em silêncio e sem nenhum aviso no config. Mudar o default não decide nada sozinho: um `stage3_config`
    # gravado sempre manda, e o do TeaStore já grava "anomalias".
    localization_mode: str = "anomalias"
    anomaly_k: float = 3.0
    min_amostras: int = 5
    piso_relativo: float = 0.05
    # Peso mínimo (z-score robusto) para o `indisponivel` contar como DOIS tipos de evidência livre
    # no ranqueamento, em vez de um. `indisponivel` é o detector de descoberta: as consultas por um
    # serviço saltam em relação à referência. Isso indica que o serviço sumiu, mas também pode ser
    # efeito de quem chama ter falhado antes -- nos 28 casos de calibração ele cai em vítima
    # (recommender, em f1-latency e f10-cpu-contention) e na causa (persistence em f6/f7/f11,
    # registry em f9). Os dois papéis se separam por magnitude, sem sobreposição: vítima 83.0 e 83.5;
    # causa 185, 196, 701, 718, 728, 728.5, 734. Acima deste peso o sinal conta como causa direta;
    # abaixo, como efeito de quem chama. É um platô: a medição é a mesma (24/28) em toda a faixa de
    # ~90 a ~700, e cai para 22/28 nas pontas.
    #
    # Por que 250 e não o meio aritmético: o que se quer é margem dos dois lados, porque o critério de
    # robustez do plano é "nenhuma perturbação muda mais de 1 caso" e a perturbação padrão é ×0.5 e
    # ×2. Com 150, ×0.5 dava 75, abaixo da banda, e movia 2 casos. O centro geométrico da banda
    # insensível (83.5 e 734) é ~247; 250 deixa ×0.5 (125) e ×2 (500) dentro dela.
    #
    # O que se perde: com 250 o `registry` da F9 (185 e 196) deixa de receber o incremento. A
    # medição diz que isso não muda nada -- o F9 já era 1º com dois tipos livres, `indisponivel` e
    # `metrica` -- mas é uma escolha, não um acaso: o limiar fica tuned pela robustez, não pela
    # semântica de "185 já é causa".
    #
    # Ressalva do parâmetro: o peso é `(valor − mediana) / sigma(q1, q3, piso)`, e o sigma vem da
    # referência do próprio serviço. Então o limiar não depende do tráfego absoluto, mas depende da
    # dispersão daquela referência — o mesmo surto absoluto dá z menor num serviço naturalmente
    # ruidoso. Os números acima são de uma distribuição concreta (28 casos de `exp-v1.1.0`), não uma
    # constante do detector; se um lote novo mostrar `indisponivel` de vítima acima de 250, é este
    # parâmetro que precisa ser revisto, não o detector.
    indisponivel_min_z: float = 250.0
    # Como a janela de referência do cenário (antes da injeção) entra na detecção: "uniao" roda os detectores de
    # traces contra a baseline global E a referência e soma as anomalias (a deriva de ambiente contra a global
    # continua valendo); "substitui" usa só a referência quando ela existe (a global vira fallback) -- é o que
    # remove a deriva. A escolha sai do lote de calibração, que ficou em "substitui"
    # (Top-1 12/14 contra 9/14 de "uniao" no lote de calibração).
    #
    # O default é "substitui" pelo mesmo motivo do `localization_mode`: "uniao" não remove a deriva, e foi
    # medido como inferior. Atenção: a referência só cobre os traces -- as métricas ainda comparam contra a
    # baseline global, o que é a pendência "referência também para métricas".
    referencia_modo: str = "substitui"
    # Votos que contam como evidência de que algo *está* errado. Qualquer um deles presente no líder
    # dispensa a abstenção. `estrutural` fica de fora de propósito; `fronteira` também, porque é
    # posição na cadeia de chamadas e não um sintoma -- sozinho ele não distingue causa de vítima.
    structural_evidence_votes: tuple[str, ...] = (
        "descoberta", "inanicao", "taxa_erro", "chamada_ausente", "erro_http", "k8s", "metrica", "latencia",
    )

    def resolved_jaeger_endpoint(self) -> str | None:
        """`jaeger_endpoint` do sistema, ou a variável de ambiente `JAEGER_QUERY_URL`."""
        return self.jaeger_endpoint or os.environ.get("JAEGER_QUERY_URL") or None

    def to_dict(self) -> dict[str, Any]:
        """θ resolvido (defaults incluídos), serializável — vai para o pacote de auditoria."""
        data = asdict(self)
        data["excluded_services"] = list(self.excluded_services)
        data["entry_services"] = list(self.entry_services)
        data["k8s_health_reasons"] = list(self.k8s_health_reasons)
        data["metric_vote_excluded"] = list(self.metric_vote_excluded)
        data["structural_evidence_votes"] = list(self.structural_evidence_votes)
        data["jaeger_endpoint"] = self.resolved_jaeger_endpoint()
        return data


_TUPLE_FIELDS = {"excluded_services", "entry_services", "k8s_health_reasons", "metric_vote_excluded",
                 "structural_evidence_votes"}
_MERGED_DICTS = {"signal_weights": DEFAULT_SIGNAL_WEIGHTS, "vote_weights": DEFAULT_VOTE_WEIGHTS}


def resolve_config(raw: dict[str, Any] | None) -> Stage3Config:
    """Aplica os defaults aos campos ausentes; ignora chaves desconhecidas e valores nulos."""
    defaults = Stage3Config()
    values: dict[str, Any] = {}
    for key, value in (raw or {}).items():
        if not hasattr(defaults, key) or value is None:
            continue
        if key in _TUPLE_FIELDS:
            value = tuple(str(v) for v in value)
        elif key in _MERGED_DICTS:
            merged = dict(_MERGED_DICTS[key])
            merged.update({str(k): float(v) for k, v in dict(value).items()})
            value = merged
        else:
            value = type(getattr(defaults, key))(value) if not isinstance(
                getattr(defaults, key), str | type(None)
            ) else value
        values[key] = value
    return Stage3Config(**values)
