"""Localização por anomalias relativas à baseline e propagação pelo grafo de chamadas
(`localization_mode="anomalias"`).

Substitui a soma de votos com pesos calibrados (votes.py) por dois princípios gerais:

1. **Anomalia = desvio robusto contra a baseline do próprio sistema.** Cada grandeza é medida em intervalos
   de 30 s; a janela é resumida pela mediana dos intervalos (sustentada por construção) e comparada com a
   distribuição dos intervalos normais: `escore = (janela − mediana) / σ`, `σ = max(IQR/1,349, piso)`. O piso
   é o ruído de amostragem (Poisson para contagens, binomial para proporções) ou `piso_relativo` × o valor
   típico para durações e métricas. Um único `k` decide o que é anômalo.
2. **Culpado = anomalia não explicada.** Erro e latência sobem pela cadeia de chamadas: a anomalia de quem
   chama é explicada por uma anomalia compatível num serviço que ele chama (direto ou indireto). Ausência
   desce: um serviço some dos traces quando quem o chama falha antes de chamá-lo. Os suspeitos são os
   serviços com anomalia não explicada, ordenados pelo número de tipos de sintoma independentes (fusão sem
   pesos) e, no empate, pelo maior escore e pela posição no ranking estrutural (Conformance).

Tipos de anomalia: `inanicao` (a entrada quase não recebe requisições), `indisponivel` (consultas
sustentadas ao serviço de descoberta procurando o serviço; várias procuras simultâneas apontam o próprio
serviço de descoberta), `ausencia` (o serviço some dos traces dos endpoints que o chamam), `erro` (fração de
respostas >= 500 ou de spans com erro), `erro_4xx`, `latencia` (duração por operação), `metrica` (métrica do
pod) e `k8s` (eventos de saúde do pod).
"""

from __future__ import annotations

import math
import statistics
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any

from src.application.stage3.entities import normalize_entity
from src.application.stage3.service_stats import call_graph, reachable
from src.application.stage3.votes import EntityVotes, Vote

# Quem pode explicar erro/latência em quem chama: um sintoma do próprio serviço chamado.
CAUSA_PARA_CIMA = frozenset({"erro", "erro_4xx", "latencia", "indisponivel", "k8s"})
EXPLICAVEL_POR_BAIXO = frozenset({"erro", "erro_4xx", "latencia"})
# Ausência é explicada por qualquer sintoma em quem chama (ele falhou antes de chamar).
EXPLICAVEL_POR_CIMA = frozenset({"ausencia"})
IQR_PARA_SIGMA = 1.349
# Resolução prática da duração de um span: abaixo disso é jitter de medição, não sintoma (health checks de
# microssegundos variavam 0,0 × 0,0 ms e davam escore alto com piso relativo zero). Constante de medição,
# não ajustada nas falhas.
PISO_ABSOLUTO_MS = 0.1


@dataclass
class Anomalia:
    servico: str
    tipo: str
    escore: float
    detalhe: str
    explicada_por: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --- escore robusto -------------------------------------------------------------------------------


def sigma(q1: float, q3: float, piso: float) -> float:
    return max((q3 - q1) / IQR_PARA_SIGMA, piso, 1e-9)


def piso_contagem(mediana: float) -> float:
    """Ruído de Poisson de uma contagem por intervalo."""
    return math.sqrt(max(mediana, 1.0))


def piso_fracao(p: float, n: float) -> float:
    """Ruído binomial de uma fração medida sobre `n` eventos por intervalo."""
    n = max(n, 1.0)
    p0 = min(max(p, 1.0 / (n + 1.0)), 0.5)
    return math.sqrt(p0 * (1.0 - p0) / n)


def escore(valor: float, dist: Sequence[float], piso: float) -> float:
    """`(valor − mediana) / σ` contra `dist = [mediana, q1, q3, n]`."""
    mediana, q1, q3 = float(dist[0]), float(dist[1]), float(dist[2])
    return (valor - mediana) / sigma(q1, q3, piso)


def _mediana(dist: Sequence[float] | None) -> float | None:
    return float(dist[0]) if dist and len(dist) >= 4 and dist[3] > 0 else None


# --- detectores -----------------------------------------------------------------------------------


def _servicos(stats: Mapping[str, Any]) -> Mapping[str, Mapping[str, Sequence[float]]]:
    return stats.get("servicos") or {}


def detectar_inanicao(base: Mapping[str, Any], janela: Mapping[str, Any], entrada: str, k: float) -> list[Anomalia]:
    b = (base.get("entrada") or {}).get("raizes_por_intervalo")
    w = _mediana((janela.get("entrada") or {}).get("raizes_por_intervalo"))
    if not b or w is None:
        return []
    z = escore(w, b, piso_contagem(b[0]))
    if z > -k:
        return []
    return [Anomalia(entrada, "inanicao", z, f"{w:.0f} requisições por intervalo × {b[0]:.0f} na baseline")]


def detectar_erros(base: Mapping[str, Any], janela: Mapping[str, Any], k: float, min_amostras: int) -> list[Anomalia]:
    out = []
    for servico, w in _servicos(janela).items():
        b = _servicos(base).get(servico) or {}
        n = _mediana(w.get("http_por_intervalo")) or 0.0
        for tipo, chave in (("erro", "http5_fracao"), ("erro", "erro_fracao"), ("erro_4xx", "http4_fracao")):
            valor = _mediana(w.get(chave))
            if valor is None or n < min_amostras:
                continue
            ref = b.get(chave) or [0.0, 0.0, 0.0, 0.0]
            z = escore(valor, ref, piso_fracao(float(ref[0]), n))
            if z >= k:
                out.append(Anomalia(servico, tipo, z, f"{chave} {valor:.1%} × {float(ref[0]):.1%} na baseline"))
    return _melhor_por_tipo(out)


def _serie_operacao(stats: Mapping[str, Any] | None) -> tuple[list, list, str]:
    """`(amostras, medianas por intervalo, rótulo)` da duração de uma operação, preferindo a própria.

    A duração total do span do chamador inclui a espera pelos filhos, então uma lentidão no chamado aparece
    como lentidão em todo mundo acima dele na árvore. A duration própria (span − filhos diretos) separa os
    dois. Quando não há própria (traces sem árvore, ou baseline antiga), cai na total — degradação segura.
    """
    stats = stats or {}
    if stats.get("duracao_propria_ms") and stats.get("mediana_propria_por_intervalo"):
        return stats["duracao_propria_ms"], stats["mediana_propria_por_intervalo"], "própria"
    return stats.get("duracao_ms") or [], stats.get("mediana_por_intervalo") or [], "total"


def detectar_latencia(
    base: Mapping[str, Any], janela: Mapping[str, Any], k: float, min_amostras: int, piso_relativo: float
) -> list[Anomalia]:
    out = []
    base_ops = base.get("operacoes") or {}
    for chave, w in (janela.get("operacoes") or {}).items():
        b = base_ops.get(chave)
        if not b:
            continue
        w_dur, w_med, rotulo = _serie_operacao(w)
        b_dur, b_med, _ = _serie_operacao(b)
        if len(w_dur) < 4 or len(b_dur) < 4 or w_dur[3] < min_amostras or b_dur[3] < min_amostras:
            continue
        valor = _mediana(w_med)
        ref = b_med
        if valor is None or not ref:
            continue
        z = escore(valor, ref, max(piso_relativo * abs(float(ref[0])), PISO_ABSOLUTO_MS))
        if z >= k:
            servico, _, operacao = chave.partition("|")
            out.append(Anomalia(servico, "latencia", z,
                                f"{operacao}: mediana {valor:.1f} ms × {float(ref[0]):.1f} ms na baseline "
                                f"(duração {rotulo})"))
    return _melhor_por_tipo(out)


def detectar_ausencia(
    base: Mapping[str, Any], janela: Mapping[str, Any], entrada: str, k: float, min_amostras: int
) -> list[Anomalia]:
    out = []
    base_presenca = base.get("presenca") or {}
    w_endpoints = janela.get("endpoints") or {}
    for servico, por_endpoint in base_presenca.items():
        if servico == entrada:
            continue
        w_presenca = (janela.get("presenca") or {}).get(servico) or {}
        for endpoint, ref in por_endpoint.items():
            n = _mediana(w_endpoints.get(endpoint))
            if n is None or n < min_amostras or not ref or float(ref[0]) <= 0:
                continue
            valor = _mediana(w_presenca.get(endpoint)) or 0.0
            z = escore(valor, ref, piso_fracao(float(ref[0]), n))
            if z <= -k:
                out.append(Anomalia(servico, "ausencia", z,
                                    f"presente em {valor:.0%} dos traces de {endpoint} × {float(ref[0]):.0%}"))
    return _melhor_por_tipo(out)


def detectar_descoberta(
    base: Mapping[str, Any], janela: Mapping[str, Any], descoberta: str | None, k: float
) -> list[Anomalia]:
    alvos = []
    for servico, w in _servicos(janela).items():
        valor = _mediana(w.get("consultas_por_intervalo"))
        if valor is None or valor <= 0:
            continue
        ref = (_servicos(base).get(servico) or {}).get("consultas_por_intervalo") or [0.0, 0.0, 0.0, 0.0]
        z = escore(valor, ref, piso_contagem(float(ref[0])))
        if z >= k:
            alvos.append((servico, z, valor))
    if not alvos:
        return []
    if len(alvos) >= 2 and descoberta:
        # causa comum: vários serviços "somem" ao mesmo tempo para quem pergunta -- o que falha é a descoberta
        nomes = ", ".join(sorted(a[0] for a in alvos))
        return [Anomalia(normalize_entity(descoberta), "indisponivel", max(a[1] for a in alvos),
                         f"consultas sustentadas a {len(alvos)} alvos ao mesmo tempo ({nomes})")]
    return [Anomalia(s, "indisponivel", z, f"{v:.0f} consultas por intervalo ao serviço de descoberta procurando {s}")
            for s, z, v in alvos]


def metricas_observadas(logs: Sequence[Any]) -> dict[str, dict[str, float]]:
    """Mediana de cada métrica por entidade entre os logs do incidente (não só o último)."""
    from src.application.stage3.attribution import _parse_metrics

    valores: dict[str, dict[str, list[float]]] = {}
    for log in logs:
        for entidade, metricas in _parse_metrics(getattr(log, "metrics_by_entity_json", None)).items():
            for nome, valor in (metricas or {}).items():
                if isinstance(valor, (int, float)):
                    valores.setdefault(normalize_entity(entidade), {}).setdefault(nome, []).append(float(valor))
    return {e: {m: statistics.median(v) for m, v in ms.items()} for e, ms in valores.items()}


def _dist_metrica(stats: Sequence[float]) -> list[float] | None:
    """`[mediana, q1, q3, n]` de `metric_stats` (`[mean, std, min, max, p95, mediana, q1, q3]`); sem os
    quartis (baseline antiga), aproxima pela média ± 0,6745 σ (normal)."""
    if len(stats) >= 8:
        return [float(stats[5]), float(stats[6]), float(stats[7]), 1.0]
    if len(stats) >= 2:
        mean, std = float(stats[0]), float(stats[1])
        return [mean, mean - 0.6745 * std, mean + 0.6745 * std, 1.0]
    return None


# Metricas em que subir e piorar. Nenhuma das faults injetadas melhora um servico,
# entao uma queda dessas nao e sintoma (F10 do piloto: latencia 0,83 ms contra 2,02 ms
# da baseline, contabilizada como manifesta pelo teste bilateral). Queda so conta em
# throughput (F6/F13 matam o servico e fs_reads/fs_writes caindo e a assinatura), que
# fica bidirecional por padrao. Metrica desconhecida tambem fica bidirecional.
_MELHOR_PIOR = ("latencia", "cpu", "memoria", "erro", "error", "falha")


def direcao_metrica(nome: str) -> int:
    """+1 quando subir e pior (so subida e anomalia), 0 quando o teste e bilateral."""
    n = (nome or "").lower()
    return 1 if any(p in n for p in _MELHOR_PIOR) else 0


def detectar_metricas(
    observadas: Mapping[str, Mapping[str, float]], metric_stats: Mapping[str, Mapping[str, Sequence[float]]],
    excluidas: Iterable[str], k: float, piso_relativo: float,
) -> list[Anomalia]:
    excl = set(excluidas)
    out = []
    for entidade, metricas in observadas.items():
        base = metric_stats.get(entidade) or {}
        for nome, valor in metricas.items():
            ref = _dist_metrica(base.get(nome) or [])
            if nome in excl or ref is None:
                continue
            z = escore(valor, ref, piso_relativo * abs(ref[0]))
            direcao = direcao_metrica(nome)
            if (direcao * z >= k) if direcao else (abs(z) >= k):
                out.append(Anomalia(entidade, "metrica", z,
                                    f"{nome} {valor:.3g} × mediana {ref[0]:.3g} na baseline"
                                    + ("" if direcao else " [bilateral]")))
    return _melhor_por_tipo(out)


def detectar_k8s(eventos: Iterable[Mapping[str, Any]], motivos: Iterable[str]) -> list[Anomalia]:
    motivos = set(motivos)
    contagem: dict[str, int] = {}
    for ev in eventos:
        if str(ev.get("reason")) in motivos and ev.get("res"):
            entidade = normalize_entity(str(ev["res"]))
            contagem[entidade] = contagem.get(entidade, 0) + int(ev.get("count") or 1)
    return [Anomalia(e, "k8s", float(n), f"{n} eventos de saúde do pod") for e, n in contagem.items()]


def _melhor_por_tipo(anomalias: Iterable[Anomalia]) -> list[Anomalia]:
    melhor: dict[tuple[str, str], Anomalia] = {}
    for a in anomalias:
        chave = (a.servico, a.tipo)
        if chave not in melhor or abs(a.escore) > abs(melhor[chave].escore):
            melhor[chave] = a
    return list(melhor.values())


# --- explicação e ranking -------------------------------------------------------------------------


def explicar(anomalias: list[Anomalia], grafo: Mapping[str, set[str]]) -> None:
    """Marca `explicada_por` em cada anomalia explicada por outro serviço (in-place)."""
    por_servico: dict[str, set[str]] = {}
    for a in anomalias:
        por_servico.setdefault(a.servico, set()).add(a.tipo)
    # Evidência de que cada serviço é a causa. A escolha era o primeiro serviço por NOME alfabético
    # com sinal de causa a jusante, o que fazia o resultado depender do nome: em 20260927T051757Z o
    # `erro` e a `latencia` do webui eram explicados por `auth` (que vem antes de `persistence`)
    # quando a causa é `persistence`, e em 20260926T203024Z a atribuição saía certa só porque `auth`
    # não tinha sinal naquela janela. Agora é o de maior evidência. Nos 28 casos isso não move
    # nenhuma posição -- é correção deorrectness, não de precisão -- mas a atribuição deixa de ser
    # um artefato da ordenação alfabética dos nomes.
    peso_causa: dict[str, float] = {}
    for a in anomalias:
        if a.tipo in CAUSA_PARA_CIMA:
            peso_causa[a.servico] = max(peso_causa.get(a.servico, 0.0), abs(a.escore))
    chamadores: dict[str, set[str]] = {}
    for chamador, chamados in grafo.items():
        for chamado in chamados:
            chamadores.setdefault(chamado, set()).add(chamador)
    for a in anomalias:
        if a.tipo in EXPLICAVEL_POR_BAIXO:
            candidatos = [b for b in sorted(reachable(grafo, a.servico))
                          if por_servico.get(b, set()) & CAUSA_PARA_CIMA]
            if candidatos:
                a.explicada_por = max(candidatos, key=lambda b: (peso_causa.get(b, 0.0), b))
        elif a.tipo in EXPLICAVEL_POR_CIMA:
            acima = reachable(chamadores, a.servico)
            for c in sorted(acima):
                if por_servico.get(c):
                    a.explicada_por = c
                    break


def ranquear(
    anomalias: Sequence[Anomalia], ranking_estrutural: Sequence[str], top_k: int,
    indisponivel_min_z: float = 150.0,
) -> tuple[list[EntityVotes], bool]:
    """Serviços na ordem de suspeita; o booleano diz se o primeiro tem anomalia não explicada."""
    por_servico: dict[str, list[Anomalia]] = {}
    for a in anomalias:
        por_servico.setdefault(a.servico, []).append(a)
    pos = {normalize_entity(s): i for i, s in enumerate(ranking_estrutural)}

    def chave(servico: str) -> tuple[Any, ...]:
        # Só a evidência NÃO explicada ordena: anomalia explicada por outro serviço é efeito, e contar o total
        # de tipos premiava a vítima -- no ensaio G (F9) o webui, com erro/latência explicados pelo registry,
        # passava na frente do registry por ter 4 tipos contra 2.
        itens = por_servico[servico]
        livres = [a for a in itens if a.explicada_por is None]
        # `indisponivel` com peso alto é sinal direto de que o serviço não resolve, e vale dois tipos:
        # a contagem é um proxy de "quantas coisas independentes apontam para cá", e esse detector
        # sozinho já afirma duas (o serviço sumiu, e é a causa mais profunda da cadeia). Sem o limiar
        # o incremento premia a vítima -- `recommender` recebia `indisponivel` em f1-latency e
        # f10-cpu-contention por estar a jusante de quem falhou, e passava à frente da causa. O peso separa os papéis: vítima ~83, causa ≥185.
        direto = any(a.tipo == "indisponivel" and abs(a.escore) >= indisponivel_min_z for a in livres)
        return (
            -(len({a.tipo for a in livres}) + (1 if direto else 0)),
            -max((abs(a.escore) for a in livres), default=0.0), pos.get(servico, len(pos)), servico,
        )

    ordem = sorted(por_servico, key=chave)
    saida = []
    for i, servico in enumerate(ordem[:top_k]):
        votos = [
            Vote(a.tipo, servico, round(abs(a.escore), 2),
                 a.detalhe + (f" [explicada por {a.explicada_por}]" if a.explicada_por else ""))
            for a in sorted(por_servico[servico], key=lambda a: -abs(a.escore))
        ]
        saida.append(EntityVotes(servico, float(top_k - i), votos))
    tem_livre = bool(ordem) and any(a.explicada_por is None for a in por_servico[ordem[0]])
    return saida, tem_livre


def localizar(
    *,
    base_stats: Mapping[str, Any] | None,
    janela_stats: Mapping[str, Any] | None,
    metric_stats: Mapping[str, Mapping[str, Sequence[float]]],
    observadas: Mapping[str, Mapping[str, float]],
    eventos_k8s: Iterable[Mapping[str, Any]],
    ranking_estrutural: Sequence[str],
    cfg: Any,
    base_referencia: Mapping[str, Any] | None = None,
) -> tuple[list[EntityVotes], list[Anomalia], bool]:
    """Anomalias, explicação e ranking. Devolve `(ranking, anomalias, lider_tem_sintoma_nao_explicado)`.

    `base_referencia` é a `service_stats` da janela de referência do **mesmo cenário**, coletada antes da
    injeção da falha (Etapa F do plano de rastros). Com `cfg.referencia_modo="uniao"` a detecção roda contra as
    duas bases e soma as anomalias (a global pega também a deriva de ambiente); com `"substitui"` os
    detectores de traces rodam só contra a referência, que é o mesmo ambiente e a mesma carga logo antes da
    falha -- a deriva sai. Métricas e eventos continuam contra a baseline global. Sem referência o
    comportamento é o de antes, então incidentes antigos continuam sendo localizados igual.
    """
    k, n_min, piso = float(cfg.anomaly_k), int(cfg.min_amostras), float(cfg.piso_relativo)
    entrada = normalize_entity(cfg.entry_services[0]) if cfg.entry_services else ""
    anomalias: list[Anomalia] = []
    arestas: list[Any] = []
    modo = str(getattr(cfg, "referencia_modo", "uniao"))
    bases = (base_referencia,) if (modo == "substitui" and base_referencia) else (base_stats, base_referencia)
    for base in bases:
        if not base or not janela_stats:
            continue
        anomalias += detectar_inanicao(base, janela_stats, entrada, k)
        anomalias += detectar_erros(base, janela_stats, k, n_min)
        anomalias += detectar_latencia(base, janela_stats, k, n_min, piso)
        anomalias += detectar_ausencia(base, janela_stats, entrada, k, n_min)
        anomalias += detectar_descoberta(base, janela_stats, cfg.discovery_service, k)
        arestas = [*(base.get("arestas") or []), *(janela_stats.get("arestas") or [])]
    anomalias += detectar_metricas(observadas, metric_stats, cfg.metric_vote_excluded, k, piso)
    anomalias += detectar_k8s(eventos_k8s, cfg.k8s_health_reasons)
    explicar(anomalias, call_graph(arestas))
    # Sem `getattr` com default: a constante duplicada aqui já divergiu uma vez do valor em
    # `config.py` (150 no código, 250 no default). `Stage3Config` tem o campo, e `resolve_config`
    # completa o que falta em configs gravados antes dele existir.
    ranking, livre = ranquear(anomalias, ranking_estrutural, int(cfg.top_k_candidates),
                              float(cfg.indisponivel_min_z))
    return ranking, anomalias, livre
