"""Identificação de atributo, checagem temporal de métricas e certeza por suspeito."""

import datetime
import json
from collections.abc import Mapping, Sequence
from typing import Any

from src.application.stage3 import egads
from src.application.stage3.entities import normalize_entity
from src.application.stage3.types import (
    AttributionResult,
    Deviation,
    EntityCandidate,
    ErrorSpan,
    TemporalDeviation,
)

_RESOURCE = {"cpu_usage", "cpu_throttled", "memoria_usage_mb", "fs_writes_bytes", "fs_reads_bytes", "oomkill_count"}
_LATENCY = {"latencia_pura_ms"}
_ERRORS = {"restart_count", "not_ready_flags"}

SIGNAL_ORDER = ("erro", "duração", "métrica", "fluxo")
_LEVELS = ("baixa", "média", "alta")


def anomaly_type_of(metric: str) -> str:
    """Vocabulário Soldani 2022 a partir da métrica dominante."""
    if metric in _RESOURCE:
        return "resource_exhaustion"
    if metric in _LATENCY:
        return "latency_degradation"
    if metric in _ERRORS:
        return "error_rate_spike"
    return "mixed"


def attribute_entity(
    entity: str,
    observed: Mapping[str, float],
    metric_stats: Mapping[str, Mapping[str, Sequence[float]]] | None,
    delta_threshold: float = 2.0,
) -> AttributionResult | None:
    """δ(m) = (x_obs − μ) / (σ + ε) por métrica da entidade. None se não há métrica comparável."""
    stats = (metric_stats or {}).get(normalize_entity(entity)) or {}
    deltas: dict[str, float] = {}
    for metric, value in observed.items():
        entry = stats.get(metric)
        if not entry:
            continue
        deltas[metric] = egads.z_score(float(value), float(entry[0]), float(entry[1]))
    if not deltas:
        return None
    anomalous = sorted((m for m, d in deltas.items() if abs(d) > delta_threshold), key=lambda m: -abs(deltas[m]))
    dominant = max(deltas, key=lambda m: abs(deltas[m]))
    return AttributionResult(
        pod_name=entity, metric_deltas=deltas, anomalous_metrics=anomalous,
        anomaly_type=anomaly_type_of(dominant) if anomalous else "mixed",
        dominant_metric=dominant, dominant_delta=deltas[dominant],
    )


def most_anomalous_entity(
    observed_by_entity: Mapping[str, Mapping[str, float]],
    metric_stats: Mapping[str, Mapping[str, Sequence[float]]] | None,
    delta_threshold: float = 2.0,
) -> AttributionResult | None:
    """Entidade de maior |δ| dominante (fallback sem candidato do Conformance)."""
    results = [
        r for entity, obs in observed_by_entity.items()
        if (r := attribute_entity(entity, obs, metric_stats, delta_threshold)) is not None
    ]
    if not results:
        return None
    return max(results, key=lambda r: (abs(r.dominant_delta), r.pod_name))


def _parse_metrics(raw: str | None) -> dict[str, dict[str, float]]:
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return {}
    return {normalize_entity(e): m for e, m in data.items() if isinstance(m, dict)} if isinstance(data, dict) else {}


def observed_metrics(logs: Sequence[Any]) -> dict[str, dict[str, float]]:
    """Valor observado por entidade × métrica: o último log do incidente."""
    for log in reversed(list(logs)):
        parsed = _parse_metrics(getattr(log, "metrics_by_entity_json", None))
        if parsed:
            return parsed
    return {}


def metric_series(
    previous_logs: Sequence[Any], incident_logs: Sequence[Any], entity: str, metric: str
) -> tuple[list[float], list[datetime.datetime | None]]:
    """Série `(valores, instantes)` da métrica: logs anteriores + logs do incidente, por window_start."""
    key = normalize_entity(entity)
    rows: list[tuple[datetime.datetime | None, float]] = []
    for log in [*previous_logs, *incident_logs]:
        value = _parse_metrics(getattr(log, "metrics_by_entity_json", None)).get(key, {}).get(metric)
        if value is not None:
            rows.append((log.window_start or log.collected_at, float(value)))
    rows.sort(key=lambda r: (r[0] is None, r[0]))
    return [v for _, v in rows], [t for t, _ in rows]


def check_metric_temporal(
    entity: str,
    metric: str,
    series: Sequence[float],
    times: Sequence[datetime.datetime | None],
    stats: Sequence[float],
    *,
    z_outlier: float = 3.0,
    p95_factor: float = 1.5,
    cusum_window: int = 5,
) -> TemporalDeviation | None:
    """Outlier / CUSUM / série anômala sobre a série da métrica.

    Além do outlier por z-score, testa `valor > p95 * p95_factor` — mais
    robusto que o z fixo em métricas com baseline ruidosa/assimétrica (ex. `fs_writes_bytes`,
    onde `std` já é ~3x a `mean`), sem depender de uma distribuição gaussiana.
    """
    mean, std = float(stats[0]), float(stats[1])
    p95 = float(stats[4]) if len(stats) > 4 else 0.0
    outliers = egads.detect_outlier(series, mean, std, z_outlier)
    percentile_outliers = egads.detect_percentile_outlier(series, p95, p95_factor)
    changes = egads.detect_change_point(series, std, cusum_window)
    anomalous_ts = egads.detect_anomalous_ts(series, mean, std, z_outlier)
    if not (outliers or percentile_outliers or changes or anomalous_ts):
        return None
    first = min([*outliers, *percentile_outliers, *changes], default=0)
    all_outliers = sorted(set(outliers) | set(percentile_outliers))
    return TemporalDeviation(
        metric_name=metric, pod_name=entity, outlier_indices=all_outliers, change_point_indices=changes,
        is_anomalous_ts=anomalous_ts, t_start=times[first] if first < len(times) else None,
        magnitude=abs(egads.z_score(series[first], mean, std)),
        via_percentile=bool(percentile_outliers) and not outliers and not changes and not anomalous_ts,
    )


def assign_certainty(
    candidates: list[EntityCandidate],
    *,
    deviations: Sequence[Deviation],
    error_spans: Sequence[ErrorSpan],
    span_temporal: Sequence[TemporalDeviation],
    attributions: Mapping[str, AttributionResult | None],
    signal_weights: Mapping[str, float],
    z_outlier: float = 3.0,
) -> None:
    """Sinais, escore não calibrado, rótulo e motivo de cada suspeito. Edita in place."""
    for cand in candidates:
        entity = cand.pod_name
        signals: list[str] = []
        if any(normalize_entity(e.pod) == entity for e in error_spans):
            signals.append("erro")
        if any(
            normalize_entity(t.pod_name) == entity and (t.magnitude >= z_outlier or t.via_percentile)
            for t in span_temporal
        ):
            signals.append("duração")
        attribution = attributions.get(entity)
        if attribution is not None and attribution.anomalous_metrics:
            signals.append("métrica")
        if any(d.type in ("unexpected", "wrong_order") and normalize_entity(d.pod) == entity for d in deviations):
            signals.append("fluxo")
        cand.signals = [s for s in SIGNAL_ORDER if s in signals]
        cand.score = round(sum(float(signal_weights.get(s, 0.0)) for s in cand.signals), 4)

    _label(candidates)


def _label(candidates: list[EntityCandidate]) -> None:
    for cand in candidates:
        n = len(cand.signals)
        cand.confidence = "alta" if n >= 3 else "média" if n == 2 else "baixa"
        joined = " + ".join(cand.signals) if cand.signals else "nenhum sinal"
        cand.confidence_reason = f"{joined} ({n} sinal{'is' if n != 1 else ''})"
        if cand.deviation_type == "missing":
            cand.confidence = "baixa"
            cand.confidence_reason = "sem desvio observado; suspeito é o chamador do trecho ausente"
    if len(candidates) < 2 or candidates[0].deviation_type == "missing":
        return
    first, second = candidates[0], candidates[1]
    n1, n2 = len(first.signals), len(second.signals)
    if n2 >= n1:
        lowered = _LEVELS[max(0, _LEVELS.index(str(first.confidence)) - 1)]
        first.confidence_reason = f"{first.confidence_reason}; suspeito 2 tem {n2} sinal(is), sem margem"
        if lowered != first.confidence:
            first.confidence_reason += f" — rebaixada de {first.confidence} para {lowered}"
            first.confidence = lowered
    else:
        first.confidence_reason = f"{first.confidence_reason}; margem de {n1 - n2} sinal(is) sobre o suspeito 2"
