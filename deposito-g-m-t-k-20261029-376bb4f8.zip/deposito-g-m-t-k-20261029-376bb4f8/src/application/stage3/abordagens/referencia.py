"""Referência recente da mesma sessão e dano na entrada.

Utilitário, sem decisão: só mede. A decisão continua em `decidir()` de cada modo.

Por que existe. A validação inicial mostrou que o problema dominante do Stage 3 é de **referência**:
contra a baseline de outro dia tudo parece anômalo (a deriva normal entre sessões é de 3–4×), mas
contra o **passado recente da própria sessão** normal e falha se separam com folga. Este módulo é o
único lugar que constrói essa referência e mede o "dano na entrada" (o segundo sinal), para
que os modos que dela dependem (d5, d7) não reinventem o corte nem divirjam na definição de raiz,
mediana e taxa de erro.

Independência: nada aqui lê gabarito, nem outro modo. `entrada.traces` e
`entrada.traces_lookback` são o insumo; a janela de referência é sempre a da própria sessão.
"""
from __future__ import annotations

import datetime
import statistics
from collections import defaultdict
from collections.abc import Iterable, Sequence
from typing import Any

from src.application.stage3.abordagens import processo as proc

__all__ = [
    "DEFAULT_CFG",
    "PESO_ERRO",
    "dano_na_entrada",
    "efeitos_por_atividade",
    "escore_efeito",
    "estatisticas",
    "eventos_referencia",
    "janela_referencia",
    "raizes_de",
    "ranking_por_efeito",
]

# Os defaults vêm da validação inicial (referência = primeiros 150 s; limiar de dano 1,2×) e do diagnóstico inicial
# (min_eventos_atividade = 20). São ponto de partida de exploração, a re-fixar por validação cruzada
# antes de virar versão pré-registrada.
DEFAULT_CFG: dict[str, Any] = {
    "ref_seg": 150,             # tamanho da janela de referência
    "ref_modo": "janela_inicial",  # "janela_inicial" (offline) | "lookback" (produto)
    "entry_services": [],       # raízes de entrada (ex.: ["teastore-webui"]); vazio = todo depth 0
    "limiar_dano_lat": 1.2,     # dano na entrada > 1,2×
    "limiar_dano_err": 0.02,
    "min_eventos_atividade": 20,
}

# Peso do efeito de erro ao virar escore relativo: +10 pontos de erro valem o mesmo que dobrar a
# mediana de duração. É a forma que a validação inicial usou para ordenar o ranking de efeito.
PESO_ERRO = 10.0


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


# --- acesso uniforme aos campos do `TraceEvent` (mesmos nomes de `processo.py`) ---


def _duracao(evento: Any) -> int:
    return int(getattr(evento, "duration_us", 0))


def _erro(evento: Any) -> bool:
    return bool(getattr(evento, "is_error", False))


def _inicio(evento: Any) -> int:
    return int(getattr(evento, "start_us", 0))


def _profundidade(evento: Any) -> int:
    return int(getattr(evento, "depth", 0))


def _atividade(evento: Any) -> str:
    return str(getattr(evento, "activity", "") or "")


def _servico(evento: Any) -> str:
    """`service` do evento; na falta, o serviço derivado da atividade (`serviço: operação`)."""
    nome = str(getattr(evento, "service", "") or "")
    return nome or proc.servico_da_atividade(_atividade(evento))


# --- medidas ---


def _resumo(eventos: Sequence[Any]) -> dict[str, Any]:
    duracoes = [_duracao(e) for e in eventos]
    n = len(eventos)
    return {
        "n": n,
        "mediana_us": statistics.median(duracoes) if duracoes else 0.0,
        "taxa_erro": (sum(_erro(e) for e in eventos) / n) if n else 0.0,
    }


def raizes_de(eventos: Iterable[Any], servicos: Sequence[str] | None = None) -> list[Any]:
    """Spans de profundidade 0 (a entrada), opcionalmente restritos a serviços de entrada.

    Sem o filtro, "raiz" é qualquer span que não tem pai no trace — que no insumo inteiro é a
    entrada do sistema. Com `servicos`, só as raízes daqueles serviços entram, que é o que separa
    o dano do usuário do dano em um serviço interno.
    """
    alvos = set(servicos or [])
    raizes = [
        e for e in eventos
        if _profundidade(e) == 0 and (not alvos or _servico(e) in alvos)
    ]
    return sorted(raizes, key=_inicio)


def estatisticas(eventos: Iterable[Any], *, servicos_raiz: Sequence[str] | None = None,
                 min_eventos: int = 1) -> dict[str, Any]:
    """Resumo de uma população de eventos: raiz (entrada) e por atividade.

    `raiz` usa `raizes_de` (profundidade 0, filtrado por `servicos_raiz`). `ativ` agrega por
    atividade (`serviço: operação`) com mediana de duração, taxa de erro e contagem — a
    granularidade em que a validação inicial mede o tamanho de efeito. Atividades com menos de `min_eventos`
    ficam de fora (ruído de amostra pequena).
    """
    eventos = list(eventos)
    por_ativ: dict[str, list[Any]] = defaultdict(list)
    for evento in eventos:
        atividade = _atividade(evento)
        if atividade:
            por_ativ[atividade].append(evento)
    ativ: dict[str, dict[str, Any]] = {}
    for atividade in sorted(por_ativ):
        grupo = por_ativ[atividade]
        if len(grupo) < int(min_eventos):
            continue
        ativ[atividade] = {**_resumo(grupo), "servico": _servico(grupo[0])}
    return {
        "n": len(eventos),
        "raiz": _resumo(raizes_de(eventos, servicos_raiz)),
        "ativ": ativ,
    }


# --- janela de referência ---


def janela_referencia(entrada: Any, cfg: dict[str, Any]) -> tuple[datetime.datetime, datetime.datetime]:
    """A janela `[inicio, inicio + ref_seg)` da própria sessão.

    `"janela_inicial"` (usado na validação inicial): os primeiros `ref_seg` segundos da própria janela do
    incidente. `"lookback"` (produto, sem janela de referência de experimento): os `ref_seg`
    segundos imediatamente antes da janela.
    """
    cfg = _cfg(cfg)
    inicio = entrada.janela[0]
    if cfg["ref_modo"] == "lookback":
        return (inicio - datetime.timedelta(seconds=float(cfg["ref_seg"])), inicio)
    return (inicio, inicio + datetime.timedelta(seconds=float(cfg["ref_seg"])))


def eventos_referencia(entrada: Any, cfg: dict[str, Any]) -> list[Any]:
    """Eventos da janela de referência, cortados da fonte certa.

    Em `"janela_inicial"` a fonte é o próprio `entrada.traces` (subconjunto inicial); em
    `"lookback"`, é `entrada.traces_lookback`. O corte é o `proc.cortar_janela` comum, para não
    criar uma segunda definição de "evento dentro da janela".
    """
    cfg = _cfg(cfg)
    fonte = entrada.traces_lookback if cfg["ref_modo"] == "lookback" else entrada.traces
    return proc.cortar_janela(fonte, janela_referencia(entrada, cfg))


# --- dano na entrada (segundo sinal, ideia 2) ---


def dano_na_entrada(inc_stats: dict[str, Any], ref_stats: dict[str, Any],
                    cfg: dict[str, Any]) -> dict[str, Any]:
    """Compara a raiz do incidente com a da referência: latência relativa e diferença de erro.

    Devolve `abre` = houve dano ao usuário (latência ≥ `limiar_dano_lat` **ou** erro ≥
    `limiar_dano_err`). Sem raízes de um dos lados, `abre` é `False` e `disponivel` é `False` — o
    portão não abre por ausência de medida, para não transformar falta de dado em alarme.
    """
    cfg = _cfg(cfg)
    ref, inc = (ref_stats.get("raiz") or {}), (inc_stats.get("raiz") or {})
    n_ref, n_inc = int(ref.get("n") or 0), int(inc.get("n") or 0)
    if not n_ref or not n_inc:
        return {"disponivel": False, "ratio_lat": None, "delta_erro": None, "abre": False,
                "n_incidente": n_inc, "n_referencia": n_ref}
    mediana_ref = float(ref.get("mediana_us") or 0.0)
    ratio = (float(inc.get("mediana_us") or 0.0) / mediana_ref) if mediana_ref > 0 else 1.0
    delta = float(inc.get("taxa_erro") or 0.0) - float(ref.get("taxa_erro") or 0.0)
    abre = ratio >= float(cfg["limiar_dano_lat"]) or delta >= float(cfg["limiar_dano_err"])
    return {"disponivel": True, "ratio_lat": ratio, "delta_erro": delta, "abre": abre,
            "n_incidente": n_inc, "n_referencia": n_ref}


# --- tamanho de efeito por atividade (ideia 1) e ranking de efeito ---


def efeitos_por_atividade(inc_stats: dict[str, Any], ref_stats: dict[str, Any], *,
                          min_eventos: int | None = None,
                          cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Tamanho de efeito relativo por atividade: `mediana_inc / mediana_ref` e Δtaxa de erro.

    Só entram atividades presentes nos dois lados com pelo menos `min_eventos` cada e mediana de
    referência > 0. É a ideia 1 (Weber: decide por diferença **relativa**) aplicada à referência da
    mesma sessão (ideia 7) — a comparação que a validação inicial aprovou.
    """
    if min_eventos is None:
        min_eventos = int(_cfg(cfg)["min_eventos_atividade"])
    min_eventos = int(min_eventos)
    ref_ativ = ref_stats.get("ativ") or {}
    inc_ativ = inc_stats.get("ativ") or {}
    saida: list[dict[str, Any]] = []
    for atividade in sorted(ref_ativ):
        iref = ref_ativ[atividade]
        iinc = inc_ativ.get(atividade)
        if not iinc:
            continue
        if int(iinc.get("n") or 0) < min_eventos or int(iref.get("n") or 0) < min_eventos:
            continue
        mediana_ref = float(iref.get("mediana_us") or 0.0)
        if mediana_ref <= 0:
            continue
        saida.append({
            "atividade": atividade,
            "servico": iinc.get("servico") or iref.get("servico") or proc.servico_da_atividade(atividade),
            "ratio_mediana": float(iinc.get("mediana_us") or 0.0) / mediana_ref,
            "delta_erro": float(iinc.get("taxa_erro") or 0.0) - float(iref.get("taxa_erro") or 0.0),
            "n_incidente": int(iinc.get("n") or 0),
            "n_referencia": int(iref.get("n") or 0),
        })
    return saida


def escore_efeito(efeito: dict[str, Any]) -> float:
    """Escore relativo de um efeito: o maior entre a razão de mediana e `1 + 10·Δerro`.

    As duas escalas (tempo e erro) não são somáveis — convertê-las em um só número pelo máximo é o
    que a validação inicial fez para ordenar; não é uma estatística, é uma ordem de apresentação.
    """
    return max(float(efeito.get("ratio_mediana") or 0.0),
               1.0 + PESO_ERRO * float(efeito.get("delta_erro") or 0.0),
               0.0)


def ranking_por_efeito(efeitos: Iterable[dict[str, Any]], *,
                       topo: int | None = None) -> list[dict[str, Any]]:
    """Agrega efeitos por serviço (maior escore) e ordena decrescente; empate desempata pelo nome.

    É a localização de primeira ordem do portão: o serviço com o maior efeito relativo.
    Guarda a atividade e as medidas do efeito que venceu, para a tela e a auditoria.
    """
    por_servico: dict[str, dict[str, Any]] = {}
    for efeito in efeitos:
        servico = efeito.get("servico")
        if not servico:
            continue
        escore = escore_efeito(efeito)
        atual = por_servico.get(servico)
        if atual is None or escore > atual["escore"]:
            por_servico[servico] = {
                "servico": servico,
                "escore": escore,
                "atividade": efeito.get("atividade"),
                "ratio_mediana": efeito.get("ratio_mediana"),
                "delta_erro": efeito.get("delta_erro"),
            }
    linhas = sorted(por_servico.values(), key=lambda linha: (-linha["escore"], linha["servico"]))
    return linhas if topo is None else linhas[:topo]
