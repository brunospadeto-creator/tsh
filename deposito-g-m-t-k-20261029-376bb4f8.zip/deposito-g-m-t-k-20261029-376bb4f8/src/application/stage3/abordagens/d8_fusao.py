"""d8 — fusão: portão de detecção da d5 + localização de outro modo.

A d5 detecta bem (referência da mesma sessão) e localiza mal (o maior efeito relativo é o sintoma, na entrada);
d2c/d6 localizam melhor. A d8 decide **só quando o portão da d5 abre** e, nesse caso, publica o ranking do
localizador (`d2c` ou `d6`) rodado sem o limiar de detecção dele. Nenhum dos dois modos é alterado: a d8 chama
os `decidir` deles como utilitários e combina as duas decisões com `combinar`, a mesma função que o avaliador
por instante usa sobre as saídas já gravadas.

`cfg["portao"]` leva os parâmetros da d5; o resto da `cfg` vai para o localizador.
"""
from __future__ import annotations

from typing import Any

from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import d5_portao as d5
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

NOME = "d8"
VERSAO = "d8-v1"

LOCALIZADORES = {"d2c": d2c, "d6": d6}

DEFAULT_CFG: dict[str, Any] = {**d6.DEFAULT_CFG, "localizador": "d2c", "portao": {}}

MOTIVOS = {"localizador_sem_ranking": "o portão abriu, mas o localizador não produziu ranking"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def combinar(portao: Decisao, local: Decisao | None, parametros: dict[str, Any] | None = None) -> Decisao:
    """Portão fechado → abstenção do portão; aberto → ranking do localizador (ou `localizador_sem_ranking`)."""
    parametros = {**(portao.parametros or {}), **(parametros or {})}
    if portao.status != "decidiu":
        return Decisao(status="absteve", motivo_abstencao=portao.motivo_abstencao, evidencias=portao.evidencias,
                       parametros=parametros, versao=VERSAO)
    if local is None or local.status != "decidiu" or not local.ranking:
        return Decisao(status="absteve", motivo_abstencao="localizador_sem_ranking",
                       evidencias={"portao": portao.evidencias,
                                   "localizador_motivo": getattr(local, "motivo_abstencao", None)},
                       parametros=parametros, versao=VERSAO)
    return Decisao(status="decidiu", ranking=list(local.ranking),
                   evidencias={"portao": portao.evidencias, "localizador": local.evidencias},
                   parametros={**(local.parametros or {}), **parametros}, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    nome_local = str(cfg["localizador"])
    if nome_local not in LOCALIZADORES:
        raise ValueError(f"localizador desconhecido: {nome_local!r}; conhecidos: {sorted(LOCALIZADORES)}")
    portao = d5.decidir(entrada, {}, {**(cfg.get("portao") or {})})
    parametros = {"localizador": nome_local}
    if portao.status != "decidiu":
        return combinar(portao, None, parametros)
    cfg_local = {k: v for k, v in cfg.items() if k not in ("portao", "localizador")}
    return combinar(portao, LOCALIZADORES[nome_local].decidir(entrada, artefato, cfg_local), parametros)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """O artefato da d2c (o portão não tem baseline), com a identidade da d8."""
    cfg_local = {k: v for k, v in _cfg(cfg).items() if k not in ("portao", "localizador")}
    artefato = d2c.preparar_baseline(traces_normais, janelas, cfg_local)
    return {**artefato, "modo": NOME, "versao": VERSAO}


class _ModoD8:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD8()
