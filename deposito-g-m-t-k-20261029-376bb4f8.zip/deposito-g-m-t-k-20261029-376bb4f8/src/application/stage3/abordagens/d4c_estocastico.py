"""d4c — d4 (modelo estocástico) com atribuição causal.

Mesmo modelo (padrões de filhas + faixas de duração própria, Laplace), mesmo escore BINet e mesmo gate
de endpoint da d4-v1. Muda a **unidade do teste**: a d4-v1 mistura num só σ médio por serviço a surpresa
de padrão (creditada ao pai: quem decidiu chamar) e a de duração (do próprio serviço) — e o serviço de
entrada, pai de quase tudo, ganhava por padrão. Aqui cada serviço tem dois testes, com nulos próprios:

- `duracao` → **intrínseco** (span cliente de banco → o banco, por `dependencias_sem_span`);
- `padrao`  → **comportamental**.

BH sobre todos os testes; ranking por `causal.ranquear`. O artefato ganha `nulo_servico_tipo`; o resto é
o da d4-v1. A d4-v1 continua congelada e intocada.
"""
from __future__ import annotations

import bisect
import datetime
from collections import defaultdict
from collections.abc import Sequence
from typing import Any

from src.application.stage3.abordagens import calibracao as _calibracao
from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d4_estocastico as d4
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

NOME = "d4c"
VERSAO = "d4c-v1"

DEFAULT_CFG: dict[str, Any] = {**d4.DEFAULT_CFG, "dependencias_sem_span": {}}
_CLASSE = {"duracao": causal.INTRINSECA, "padrao": causal.COMPORTAMENTAL}


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def pontuar(
    feats: Sequence[dict[str, Any]], mod: dict[str, Any], dependencias: dict[str, str]
) -> dict[str, list[float]]:
    """σ por `"<serviço>|<tipo>"` (o mesmo σ da d4-v1, separado por tipo)."""
    laplace = float(mod["laplace"])
    saida: dict[str, list[float]] = defaultdict(list)
    for f in feats:
        for pai, padrao, servico in f["padroes"]:
            conhecidos = mod["padroes"].get(pai)
            if not conhecidos:
                continue
            nomes = sorted(conhecidos)
            indice = nomes.index(padrao) if padrao in conhecidos else None
            s, _ = d4._sigma([conhecidos[n] for n in nomes], indice, laplace)
            saida[f"{servico}|padrao"].append(s)
        for atividade, valor, servico in f["duracoes"]:
            faixa = mod["faixas"].get(atividade)
            if not faixa:
                continue
            s, _ = d4._sigma(faixa["contagem"], bisect.bisect_right(faixa["limites"], valor), laplace)
            saida[f"{dependencias.get(atividade, servico)}|duracao"].append(s)
    return dict(saida)


def _dependencias_do_modelo(eventos: list[Any], cfg: dict[str, Any]) -> dict[str, str]:
    return causal.dependencias_por_atividade(eventos, cfg.get("dependencias_sem_span") or {})


def construir_artefato(traces_normais: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    artefato = d4.construir_artefato(traces_normais, cfg)
    dependencias = _dependencias_do_modelo(traces_normais, cfg)
    feats = d4.features_de(traces_normais)
    nulos: dict[str, list[float]] = defaultdict(list)
    if feats:
        tamanho = int(float(cfg["tamanho_janela_seg"]) * 1e6)
        primeiro, ultimo = min(f["inicio"] for f in feats), max(f["inicio"] for f in feats)
        inicio = primeiro
        while inicio + tamanho <= ultimo + 1:
            dentro = [f for f in feats if inicio <= f["inicio"] < inicio + tamanho]
            fora = [f for f in feats if not inicio <= f["inicio"] < inicio + tamanho]
            if len(dentro) >= int(cfg["min_traces"]) and fora:
                for chave, valores in pontuar(dentro, d4.modelo(fora, float(cfg["laplace"])), dependencias).items():
                    if len(valores) >= int(cfg["min_eventos_servico"]):
                        nulos[chave].append(d4._media(valores))
            inicio += tamanho // 2
    return {**artefato, "modo": NOME, "versao": VERSAO, "nulo_servico_tipo": dict(nulos)}


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    artefato = construir_artefato(traces_normais, cfg)
    if not janelas:
        janelas = _calibracao.janelas_de_normal(
            traces_normais, datetime.timedelta(seconds=float(cfg["tamanho_janela_seg"])))
    artefato["calibracao"] = _calibracao.calibrar_cruzado(
        lambda fora: construir_artefato(fora, cfg), decidir, traces_normais, list(janelas), cfg,
        fp_alvo=float(cfg.get("fp_alvo") or 0.05),
    )
    return artefato


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    q = _calibracao.q_do_artefato(artefato, cfg)
    fp_alvo = float((artefato.get("calibracao") or {}).get("fp_alvo") or cfg.get("fp_alvo") or 0.05)
    parametros = {"q": q, "fp_alvo": fp_alvo, "cortes_faixa": list(d4.CORTES_FAIXA)}
    mod = artefato.get("modelo")
    feats = d4.features_de(entrada.traces)
    if not mod or len(feats) < int(cfg["min_traces"]):
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_traces": len(feats)}, parametros=parametros)

    r = d4.pontuar(feats, mod)  # gate de endpoint idêntico ao da d4-v1
    gate: dict[str, Any] = {}
    for endpoint, valores in r["bits"].items():
        limite = d4._limite_gate((artefato.get("nulo_bits") or {}).get(endpoint) or [], fp_alvo)
        if limite is not None and valores:
            gate[endpoint] = {"bits": d4._media(valores), "limite": limite, "fora": d4._media(valores) > limite}
    evidencias: dict[str, Any] = {"n_traces": len(feats), "gate": gate}
    if not any(g["fora"] for g in gate.values()):
        return Decisao(status="absteve", motivo_abstencao="comportamento_estocastico_normal",
                       versao=VERSAO, evidencias=evidencias, parametros=parametros)

    dependencias = _dependencias_do_modelo(entrada.traces, cfg)
    testes: list[dict[str, Any]] = []
    for chave, valores in sorted(pontuar(feats, mod, dependencias).items()):
        if len(valores) < int(cfg["min_eventos_servico"]):
            continue
        nulos = (artefato.get("nulo_servico_tipo") or {}).get(chave) or []
        t = est.predicao(d4._media(valores), nulos, alternative="greater")
        if t is not None:
            servico, tipo = chave.rsplit("|", 1)
            testes.append({"servico": servico, "tipo": tipo, "elemento": chave, "media": d4._media(valores),
                           "media_normal": d4._media(nulos), "n_eventos": len(valores), "n_janelas_nor": t.n,
                           "p": t.p, "forca": causal.forca_t(t.estatistica, int(t.n) - 1)})
    if not testes:
        return Decisao(status="absteve", motivo_abstencao="sem_servico_significativo", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)
    ajustados, significativos = est.benjamini_hochberg([t["p"] for t in testes], q)
    evidencias["p_min_ajustado"] = min(ajustados)
    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for teste, p_adj, sig in zip(testes, ajustados, significativos):
        teste["p_ajustado"], teste["significante"] = p_adj, sig
        if sig:
            por_servico[teste["servico"]].append({**teste, "classe": _CLASSE[teste["tipo"]]})
    evidencias["testes"] = testes
    if not por_servico:
        return Decisao(status="absteve", motivo_abstencao="sem_servico_significativo", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)
    evidencias["dependencias_sem_span"] = sorted(set(dependencias.values()))
    return Decisao(status="decidiu", ranking=causal.ranquear(dict(por_servico)), evidencias=evidencias,
                   parametros=parametros, versao=VERSAO)


class _ModoD4c:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD4c()
