"""Utilitario, sem decisao. Quem decide e o `decidir()` de cada modo.

`EntradaIncidente` e definida **uma vez**, aqui, para os cinco modos. Isso nao e
organizacao: e o que torna a independencia verificavel. Se cada modo montasse o proprio insumo, cada
um teria o proprio trilho de dados e a comparacao entre eles deixaria de significar alguma coisa.

Duas invariantes, checadas em `conftest` e em `tests/test_stage3/test_abordagens_base.py`:

- **Nada de gabarito.** Nem o nome da falha, nem o instante da injecao, nem o servico-alvo chegam no
  `EntradaIncidente`. O `traces` e filtrado por tempo, nunca por conteudo.
- **O insumo recusado continua presente.** `metricas` e `eventos_k8s` existem para todos os modos,
  inclusive os que nao os leem — d1-d4 so traces, por desenho. Deixa-los no mesmo
  objeto e o que torna essa recusa auditavel: o insumo estava la, e o modo passou por cima.
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from src.store.models import MODOS_DECISORIOS_STAGE3, MODOS_STAGE3

__all__ = [
    "MODOS_DECISORIOS_STAGE3",
    "MODOS_STAGE3",
    "Decisao",
    "EntradaIncidente",
    "ItemRanking",
    "Modo",
    "MODOS_ABSTAIN",
]

# Nenhum gate de quantidade fixa aqui: cada modo tem o seu (`min_traces_incidente`,
# `min_oportunidades`, ...). O que existe e o vocabulario comum de motivo de abstencao, para a tela e
# para o avaliador lerem igual em vez de comparar string solta.
STATUS_DECISAO: frozenset[str] = frozenset({"decidiu", "absteve", "falhou"})

MODOS_ABSTAIN: dict[str, str] = {
    "poucos_traces": "traces insuficientes para a janela",
    "sem_modelo": "nenhum endpoint com modelo de processo",
    "sem_desvio_significativo": "nenhum desvio passou do limiar calibrado",
    "sem_diferenca_significativa": "nenhuma diferenca passou do limiar calibrado",
    "sem_mudanca": "nenhuma mudanca confirmada nas tres perspectivas",
    "inicio_fora_da_janela": "a mudanca mais antiga cai no primeiro intervalo",
    "comportamento_estocastico_normal": "nenhum endpoint fora do quantil do normal",
    "sem_servico_significativo": "nenhum servico passou do limiar calibrado",
    "modo_nao_implementado": "modo ainda sem implementacao de decisao",
}


@dataclass(frozen=True)
class EntradaIncidente:
    """Insumo dos cinco modos. Montado uma vez, pelo despacho, antes de qualquer `decidir()`."""

    # --- identidade da janela, nunca o gabarito ---
    incidente_id: str
    janela: tuple[datetime.datetime, datetime.datetime]
    abertura_incidente: datetime.datetime

    # --- insumos brutos ---
    traces: list[Any]
    traces_lookback: list[Any]
    metricas: dict[str, Any]
    eventos_k8s: list[Any]
    config_sistema: dict[str, Any]

    # --- o que cada modo le ---
    cfg: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def _servico_de(trace: Any) -> str | None:
        """`servico` no `TraceEvent`, `service_name` em trace cru. Os dois nomes aparecem."""
        nome = getattr(trace, "servico", None) or getattr(trace, "service_name", None)
        if nome is None and isinstance(trace, dict):
            nome = trace.get("servico") or trace.get("service_name")
        return str(nome) if nome else None

    @property
    def servicos(self) -> list[str]:
        """Servicos distintos do incidente, para os modos que so traces precisarem."""
        nomes = {self._servico_de(t) for t in self.traces}
        return sorted(n for n in nomes if n is not None)


@dataclass(frozen=True)
class ItemRanking:
    servico: str
    escore: float  # menor = melhor
    p_valor: float | None = None
    evidencias: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Decisao:
    """Saida comum dos cinco modos. A a0 devolve exatamente este formato, via `a0.py`."""

    status: str  # "decidiu" | "absteve" | "falhou"
    ranking: list[ItemRanking] = field(default_factory=list)
    motivo_abstencao: str | None = None
    evidencias: dict[str, Any] = field(default_factory=dict)
    parametros: dict[str, Any] = field(default_factory=dict)
    versao: str = ""
    segundos: float = 0.0

    def para_dict(self) -> dict[str, Any]:
        """Forma gravada em `stage3_abordagens.ranking` / `parametros` / `evidencias`."""
        return {
            "status": self.status,
            "motivo_abstencao": self.motivo_abstencao,
            "ranking": [
                {"servico": i.servico, "escore": i.escore, "p_valor": i.p_valor,
                 "evidencias": i.evidencias}
                for i in self.ranking
            ],
            "evidencias": self.evidencias,
            "parametros": self.parametros,
            "versao": self.versao,
            "segundos": self.segundos,
        }

    @classmethod
    def de_dict(cls, dados: dict[str, Any]) -> Decisao:
        """Le da forma gravada. E caminho de leitura do banco e da tela, entao valida.

        Sem essa checagem, um `status` fora do vocabulario so apareceria quando a tela tentasse
        formatar a linha -- longe do ponto onde o dado entrou.
        """
        status = dados.get("status")
        if status not in STATUS_DECISAO:
            raise ValueError(f"status invalido: {status!r}, esperado um de {sorted(STATUS_DECISAO)}")
        return cls(
            status=status,
            motivo_abstencao=dados.get("motivo_abstencao"),
            ranking=[ItemRanking(**i) for i in dados.get("ranking") or []],
            evidencias=dados.get("evidencias") or {},
            parametros=dados.get("parametros") or {},
            versao=dados.get("versao", ""),
            segundos=float(dados.get("segundos") or 0.0),
        )


@runtime_checkable
class Modo(Protocol):
    """O que o despacho exige de qualquer modo, inclusive da a0 pelo adaptador."""

    nome: str
    versao: str

    def janela_traces(
        self, entrada: EntradaIncidente, cfg: dict[str, Any]
    ) -> tuple[datetime.datetime, datetime.datetime]: ...

    def preparar_baseline(
        self, traces_normais: list[Any], janelas: list[tuple[datetime.datetime, datetime.datetime]],
        cfg: dict[str, Any],
    ) -> dict[str, Any]: ...

    def decidir(
        self, entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]
    ) -> Decisao: ...
