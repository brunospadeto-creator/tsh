"""d2c-cp — Ponto-Mudança.

A d2c pergunta se *uma janela inteira* difere da referência. O defeito conhecido é o do início: um
serviço que passou a ficar lento no meio da janela entra na média como "um pouco mais lento", e o
teste de janela fraca. A d2c-cp troca a pergunta por *"onde o processo mudou de regime, e quem
mudou?"*, à la BARO: ponto de mudança por intervalo (PELT/CUSUM) e, do ponto para frente, o efeito
relativo que decide a localização.

- **Série**: por atividade, mediana da duração em intervalos de `bucket_seg` (60 s) com origem no
  início do lookback. O ponto de mudança vem de `estatistica.pelt` com variância conhecida (a do
  trecho de referência), não reestimada por segmento.
- **Efeito**: mediana depois / mediana antes do ponto; só passa com o limiar relativo (Weber) da
  `referencia`. O limiar é sobre o **efeito**, não sobre o p — a d2c mede efeito por teste; aqui, por
  regime.
- **Atribuição**: `causal.ranquear`, com o mesmo vocabulário da d2c — tempo próprio é intrínseco,
  relação nova/perdida e erro herdado são comportamentais; span cliente de banco vai para o banco
  (`dependencias_sem_span`) e a atividade que sumiu entra pela ausência.

Sem artefato de baseline: a referência (o "antes") é o trecho de lookback da própria sessão.
"""
from __future__ import annotations

import datetime
import statistics
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import causal, referencia
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

NOME = "d2c-cp"
VERSAO = "d2c-cp-v1"

DEFAULT_CFG: dict[str, Any] = {
    **referencia.DEFAULT_CFG,
    "bucket_seg": 60,
    "ref_seg": 300,
    "ref_modo": "lookback",
    "limiar_efeito": 1.5,      # Weber: efeito relativo mínimo para o regime contar
    "min_eventos": 10,
    "dependencias_sem_span": {},
}

MOTIVOS = {
    "sem_referencia_recente": "a janela não tem passado recente utilizável na própria sessão",
    "sem_mudanca": "nenhuma mudança de regime confirmada",
}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _serie(eventos: list[Any], atividade: str, bucket_s: float,
           origem_s: float) -> list[tuple[int, float]]:
    """Mediana da duração por bucket de `bucket_s` segundos, com índice relativo a `origem_s`."""
    pares = [(referencia._inicio(e) / 1e6, referencia._duracao(e))
             for e in eventos if referencia._atividade(e) == atividade]
    if len(pares) < 2:
        return []
    buckets: dict[int, list[float]] = defaultdict(list)
    for t, v in pares:
        buckets[int((t - origem_s) // bucket_s)].append(v)
    return [(b, statistics.median(vs)) for b, vs in sorted(buckets.items()) if vs]


def detectar(entrada: EntradaIncidente, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """Mudanças de regime significativas: `{atividade, servico, indice, ratio, p, forca, antes_da_janela}`.

    `antes_da_janela` marca o ponto de mudança que caiu no trecho de lookback; ele continua valendo (a janela
    segue no regime novo), mas fica registrado como evidência.
    """
    cfg = _cfg(cfg)
    bucket_s = float(cfg["bucket_seg"])
    ini_janela, fim_janela = entrada.janela
    ini_lb = ini_janela - datetime.timedelta(seconds=float(cfg["ref_seg"]))
    eventos = proc.cortar_janela(list(entrada.traces_lookback) + list(entrada.traces),
                                 (ini_lb, fim_janela))
    origem_s = ini_lb.timestamp()
    corte_ref = int((ini_janela - ini_lb).total_seconds() // bucket_s)
    deps = cfg.get("dependencias_sem_span") or {}
    contagem: dict[str, int] = defaultdict(int)
    for e in eventos:
        if referencia._atividade(e):
            contagem[referencia._atividade(e)] += 1
    atividades = sorted(a for a, n in contagem.items() if n >= int(cfg["min_eventos"]))
    saida: list[dict[str, Any]] = []
    for atividade in atividades:
        serie = _serie(eventos, atividade, bucket_s, origem_s)
        if len(serie) < 3:
            continue
        valores = [v for _, v in serie]
        valores_ref = [v for b, v in serie if b < corte_ref] or valores
        variancia = est.variancia_ruido(valores_ref)
        res = est.pelt(valores, variancia, beta=variancia * float(cfg["limiar_efeito"]),
                       forcar_pelo_menos_um=False, min_segmento=1)
        indice = res.primeiro
        if indice is None:
            continue
        antes = valores[:indice]
        depois = valores[indice:]
        if not antes or not depois:
            continue
        med_antes, med_depois = statistics.median(antes), statistics.median(depois)
        if med_antes <= 0 or med_depois / med_antes < float(cfg["limiar_efeito"]):
            continue
        servico = next((referencia._servico(e) for e in eventos
                        if referencia._atividade(e) == atividade), "")
        saida.append({
            "atividade": atividade, "servico": deps.get(atividade) or servico,
            "indice": indice, "ratio": med_depois / med_antes,
            "p": est.mann_whitney(depois, antes, alternative="greater").p,
            "forca": causal.forca_mann_whitney(depois, antes),
            "antes_da_janela": indice < corte_ref,
        })
    return saida


def _itens(mudancas: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for m in mudancas:
        if not m["servico"]:
            continue
        por_servico[m["servico"]].append({
            "elemento": m["atividade"], "classe": causal.INTRINSECA, "forca": m["forca"],
            "tipo": "tempo_proprio_da_atividade", "regra": "tempo_proprio_da_atividade",
            "ratio": m["ratio"], "p": m["p"], "indice": m["indice"]})
    return dict(por_servico)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    parametros = {k: cfg[k] for k in ("bucket_seg", "ref_seg", "ref_modo", "limiar_efeito", "min_eventos")}
    if not entrada.traces_lookback:
        return Decisao(status="absteve", motivo_abstencao="sem_referencia_recente", versao=VERSAO,
                       parametros=parametros)
    mudancas = detectar(entrada, cfg)
    if not mudancas:
        return Decisao(status="absteve", motivo_abstencao="sem_mudanca", versao=VERSAO,
                       evidencias={"n_mudancas": 0}, parametros=parametros)
    ranking = causal.ranquear(_itens(mudancas))
    if not ranking:
        return Decisao(status="absteve", motivo_abstencao="sem_mudanca", versao=VERSAO,
                       evidencias={"n_mudancas": len(mudancas)}, parametros=parametros)
    return Decisao(status="decidiu", ranking=ranking,
                   evidencias={"n_mudancas": len(mudancas), "bucket_seg": cfg["bucket_seg"],
                               "n_mudancas_antes_da_janela": sum(m["antes_da_janela"] for m in mudancas)},
                   parametros=parametros, versao=VERSAO)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "limiares_por_validacao_cruzada"},
            "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("bucket_seg", "ref_seg", "limiar_efeito")}}


class _ModoD2ccp:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD2ccp()
