"""Adaptador da a0: a localização legada vista como um modo, **sem editar** nenhum dos
17 arquivos dela (`congelamento_modos.py`, lista `a0`).

A a0 não implementa `decidir(EntradaIncidente)`: ela precisa do repositório (baseline, logs
anteriores, referência), do Jaeger e dos eventos do Kubernetes, que é o que `_run_pipeline` consome.
Por isso o adaptador **não** reimplementa nada; ele só traduz o resultado de uma execução legada
(`stage3_diagnosis` ao vivo, ou `replay.replay_case` offline, que roda o mesmo `_run_pipeline`) para a
`Decisao` comum. Os insumos são os mesmos gravados para os outros modos — o caso inteiro em disco.

Fica fora de `registro.MODOS` de propósito: o despacho só cria job de modo para d1–d4; a a0 roda
pelo job legado.
"""
from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from src.application.stage3.abordagens.base import Decisao, ItemRanking

NOME = "a0"
VERSAO = "a0-v1"  # o hash do código fica no congelamento por modo (be26258c…), não aqui

# Abstenções do legado que vêm **depois** da síntese: o ranking foi publicado (replay.py, mesma regra).
_ABSTEM_DEPOIS_DO_RANKING = frozenset({"invalid_llm_output", "llm_abstained"})


def decisao_do_legado(
    ranking: Sequence[str],
    abstain_reason: str | None,
    *,
    respondeu: bool | None = None,
    evidencias: dict[str, Any] | None = None,
    segundos: float = 0.0,
) -> Decisao:
    """Traduz o resultado do `_run_pipeline` para a `Decisao` comum.

    `escore` é a posição (1 = primeiro), porque a a0 ordena por regra lexicográfica e não produz um
    escore comparável entre casos; `p_valor` fica `None` pelo mesmo motivo.
    """
    if respondeu is None:
        respondeu = not abstain_reason or abstain_reason in _ABSTEM_DEPOIS_DO_RANKING
    ev = {"abstain_reason_legado": abstain_reason, **(evidencias or {})}
    if not respondeu or not ranking:
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo",
                       evidencias=ev, versao=VERSAO, segundos=segundos)
    itens = [ItemRanking(servico=str(s), escore=float(i + 1)) for i, s in enumerate(ranking)]
    return Decisao(status="decidiu", ranking=itens, evidencias=ev, versao=VERSAO, segundos=segundos)
