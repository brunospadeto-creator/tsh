"""d3 — drift de processo com precedência temporal.

Pergunta: *qual serviço mudou de comportamento de processo **primeiro**?* A causa precede o efeito na
propagação; a d3 usa só a ordem temporal das mudanças, sem regra de grafo.

Insumo: traces de `[abertura − L, abertura]` (`L` = 1800 s), em intervalos de 30 s. "Abertura" é o
`abertura_incidente` da entrada (o `created_at` do incidente), **nunca** o instante da injeção.

Três perspectivas por serviço `s`, fixas:

- **fluxo** — contagens das relações directly-calls em que `s` é chamador ou chamado. Janela de
  referência `[t−W, t)` × janela de detecção `[t, t+W)`, teste G de independência (k × 2), confirmado
  por |resíduo ajustado| > 1,96 em alguma relação e por `m` posições consecutivas. A tabela é
  simétrica nas duas janelas, então relação que surge e relação que some entram igual (busca nos
  dois sentidos);
- **desempenho** — log da mediana da duração própria dos spans de `s`; PELT de mudança de média;
- **erro** — fração de spans de `s` com erro; PELT.

Calibração (decisão de 2026-10-03): a baseline normal tem 25 min, menos que `L`, então
não há janelas normais do tamanho do insumo. A d3 calibra **por série**: a baseline é partida em duas
metades; a variância de cada série vem de uma metade e a detecção roda na outra (e vice-versa). Os
parâmetros `(c, m, α)` escolhidos são os mais sensíveis da grade em que **nenhuma** série normal
acusa mudança. `β = c · ln(n)`. Limite declarado: a série do incidente (60 intervalos) é mais longa que
a meia-baseline (25), e o `ln(n)` só compensa em parte.

Cuidado: a recriação de pod pela injeção também é mudança. A d3 vai apontá-la.
"""
from __future__ import annotations

import datetime
import math
from collections import defaultdict
from collections.abc import Sequence
from typing import Any

import numpy as np
from scipy import stats

from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking
from src.application.stage3.traces import to_epoch_us

NOME = "d3"
VERSAO = "d3-v1"

DEFAULT_CFG: dict[str, Any] = {
    "lookback_seg": 1800,
    "intervalo_seg": 30,
    "janela_fluxo": 4,       # W, em intervalos (2 min de cada lado)
    "min_segmento": 3,       # PELT: regime de pelo menos 1,5 min
    "min_spans_intervalo": 3,
    "min_traces": 30,
}
# Grade da calibração, da mais sensível para a menos. Cada eixo é monotônico na sensibilidade.
GRADE_C = (2.0, 3.0, 4.0, 6.0, 8.0, 12.0, 16.0, 24.0, 32.0, 48.0, 64.0)
GRADE_M = (2, 3, 4, 6)
GRADE_ALFA = (1e-3, 1e-6, 1e-10, 1e-20, 1e-40)
PISO_VARIANCIA = {"desempenho": 1e-4, "erro": 1e-4}
PERSPECTIVAS_PELT = ("desempenho", "erro")


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


# --- séries ---


def series(eventos: Sequence[Any], inicio_us: int, fim_us: int, intervalo_us: int,
           min_spans: int) -> dict[str, Any]:
    """Séries por serviço e intervalo. Valores ausentes (intervalo sem spans) ficam `None`."""
    n = max(0, (fim_us - inicio_us) // intervalo_us)
    duracoes: dict[str, list[list[float]]] = defaultdict(lambda: [[] for _ in range(n)])
    erros: dict[str, list[list[int]]] = defaultdict(lambda: [[] for _ in range(n)])
    relacoes: dict[str, list[dict[str, int]]] = defaultdict(lambda: [defaultdict(int) for _ in range(n)])
    for sequencia in proc.sequencias_por_trace(list(eventos)).values():
        for evento in sequencia:
            inicio = int(evento.start_us)
            if not inicio_us <= inicio < fim_us:
                continue
            k = (inicio - inicio_us) // intervalo_us
            if k >= n:
                continue
            servico = str(evento.service)
            duracoes[servico][k].append(float(proc.duracao_propria(evento, sequencia)))
            erros[servico][k].append(1 if getattr(evento, "is_error", False) else 0)
            pai = proc.pai_de(evento, sequencia)
            if pai is not None and str(pai.service) != servico:
                rel = f"{pai.activity} -> {evento.activity}"
                relacoes[servico][k][rel] += 1
                relacoes[str(pai.service)][k][rel] += 1
    saida: dict[str, Any] = {"n": n, "servicos": {}}
    for servico in sorted(set(duracoes) | set(relacoes)):
        des = [math.log(max(est.mediana(d), 1.0)) if len(d) >= min_spans else None
               for d in duracoes[servico]]
        err = [sum(e) / len(e) if len(e) >= min_spans else None for e in erros[servico]]
        saida["servicos"][servico] = {
            "desempenho": des, "erro": err,
            "fluxo": [dict(c) for c in relacoes[servico]],
        }
    return saida


def _preencher(serie: Sequence[float | None]) -> list[float] | None:
    """Preenche lacunas com o último valor (e o primeiro valor para trás). `None` se < metade com dado."""
    validos = [v for v in serie if v is not None]
    if len(validos) < max(2, len(serie) // 2):
        return None
    saida: list[float] = []
    ultimo = validos[0]
    for v in serie:
        ultimo = v if v is not None else ultimo
        saida.append(float(ultimo))
    return saida


def variancia_robusta(serie: Sequence[float | None], piso: float) -> float:
    """(1,4826 · MAD)² da série normal, com piso. Inclui a deriva lenta do normal de propósito."""
    valores = [float(v) for v in serie if v is not None]
    if len(valores) < 3:
        return piso
    med = float(np.median(valores))
    mad = float(np.median([abs(v - med) for v in valores]))
    return max((1.4826 * mad) ** 2, piso)


# --- detectores ---


def _primeira_mudanca_pelt(serie: list[float], variancia: float, c: float,
                           min_seg: int) -> tuple[int, float] | None:
    beta = c * math.log(max(len(serie), 2))
    r = est.pelt(serie, variancia, beta, min_segmento=min_seg)
    if not r.pontos:
        return None
    t = r.pontos[0]
    antes, depois = serie[max(0, t - min_seg):t], serie[t:t + min_seg]
    forca = abs(float(np.mean(depois)) - float(np.mean(antes))) / math.sqrt(variancia)
    return t, forca


def _primeira_mudanca_fluxo(contagens: list[dict[str, int]], w: int, m: int,
                            alfa: float) -> tuple[int, float, str] | None:
    """Primeira posição `t` de uma sequência de `m` posições com G significativo e |ASR| > 1,96."""
    n = len(contagens)
    seguidas = 0
    inicio_seq: tuple[int, float, str] | None = None
    for t in range(w, n - w + 1):
        ref: dict[str, int] = defaultdict(int)
        det: dict[str, int] = defaultdict(int)
        for k in range(t - w, t):
            for rel, v in contagens[k].items():
                ref[rel] += v
        for k in range(t, t + w):
            for rel, v in contagens[k].items():
                det[rel] += v
        rels = sorted(set(ref) | set(det))
        tabela = np.array([[ref.get(r, 0), det.get(r, 0)] for r in rels], dtype=float)
        ok = False
        if len(rels) >= 2 and tabela.sum() > 0 and (tabela.sum(axis=1) > 0).all() and (tabela.sum(axis=0) > 0).all():
            g, p, _, esperado = stats.chi2_contingency(tabela, lambda_="log-likelihood", correction=False)
            if p < alfa:
                total = tabela.sum()
                linhas = tabela.sum(axis=1, keepdims=True)
                colunas = tabela.sum(axis=0, keepdims=True)
                with np.errstate(divide="ignore", invalid="ignore"):
                    asr = (tabela - esperado) / np.sqrt(esperado * (1 - linhas / total) * (1 - colunas / total))
                asr = np.nan_to_num(asr)
                i_max = int(np.argmax(np.abs(asr[:, 1])))
                if abs(asr[i_max, 1]) > 1.96:
                    ok = True
                    candidato = (t, float(abs(asr[i_max, 1])), rels[i_max])
        if ok:
            seguidas += 1
            if seguidas == 1:
                inicio_seq = candidato
            if seguidas >= m:
                return inicio_seq
        else:
            seguidas = 0
            inicio_seq = None
    return None


def detectar(series_servicos: dict[str, Any], variancias: dict[str, dict[str, float]],
             params: dict[str, Any], cfg: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """`{servico: {"t", "perspectiva", "forca", "detalhe"}}` da primeira mudança confirmada."""
    achados: dict[str, dict[str, Any]] = {}
    for servico, s in series_servicos.items():
        candidatos: list[dict[str, Any]] = []
        for perspectiva in PERSPECTIVAS_PELT:
            serie = _preencher(s[perspectiva])
            if serie is None:
                continue
            var = (variancias.get(servico) or {}).get(perspectiva) or PISO_VARIANCIA[perspectiva]
            r = _primeira_mudanca_pelt(serie, var, float(params["c"]), int(cfg["min_segmento"]))
            if r is not None:
                candidatos.append({"t": r[0], "perspectiva": perspectiva, "forca": r[1], "detalhe": None})
        r_f = _primeira_mudanca_fluxo(s["fluxo"], int(cfg["janela_fluxo"]), int(params["m"]),
                                      float(params["alfa"]))
        if r_f is not None:
            candidatos.append({"t": r_f[0], "perspectiva": "fluxo", "forca": r_f[1], "detalhe": r_f[2]})
        if candidatos:
            achados[servico] = sorted(candidatos, key=lambda c: (c["t"], -c["forca"]))[0]
    return achados


# --- artefato e calibração ---


def _limites_baseline(eventos: Sequence[Any]) -> tuple[int, int]:
    inicios = [int(e.start_us) for e in eventos]
    return min(inicios), max(inicios) + 1


def _variancias(series_servicos: dict[str, Any]) -> dict[str, dict[str, float]]:
    return {
        servico: {p: variancia_robusta(s[p], PISO_VARIANCIA[p]) for p in PERSPECTIVAS_PELT}
        for servico, s in series_servicos.items()
    }


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    if not traces_normais:
        return {"modo": NOME, "versao": VERSAO, "variancias": {}, "calibracao": {"motivo": "sem_traces"}}
    intervalo_us = int(float(cfg["intervalo_seg"]) * 1e6)
    inicio, fim = _limites_baseline(traces_normais)
    completo = series(traces_normais, inicio, fim, intervalo_us, int(cfg["min_spans_intervalo"]))
    meio = inicio + ((fim - inicio) // intervalo_us // 2) * intervalo_us
    metades = [series(traces_normais, inicio, meio, intervalo_us, int(cfg["min_spans_intervalo"])),
               series(traces_normais, meio, fim, intervalo_us, int(cfg["min_spans_intervalo"]))]
    # validação cruzada: variância de uma metade, detecção na outra
    dobras = [(metades[1], _variancias(metades[0]["servicos"])),
              (metades[0], _variancias(metades[1]["servicos"]))]
    n_series = sum(len(m["servicos"]) for m in metades)

    escolhido: dict[str, Any] | None = None
    tentativas: list[dict[str, Any]] = []
    for c in GRADE_C:
        for m in GRADE_M:
            for alfa in GRADE_ALFA:
                params = {"c": c, "m": m, "alfa": alfa}
                com_mudanca = sum(len(detectar(dobra["servicos"], var, params, cfg)) for dobra, var in dobras)
                tentativas.append({**params, "n_com_mudanca": com_mudanca})
                if com_mudanca == 0:
                    escolhido = params
                    break
            if escolhido:
                break
        if escolhido:
            break
    calibracao: dict[str, Any] = {
        "metodo": "validacao_cruzada_por_metade;mais_sensivel_sem_mudanca_no_normal",
        "n_series": n_series, "n_intervalos_metade": metades[0]["n"],
        "fp_alvo": float(cfg.get("fp_alvo") or 0.05), "tentativas": len(tentativas),
    }
    if escolhido is None:
        escolhido = {"c": GRADE_C[-1], "m": GRADE_M[-1], "alfa": GRADE_ALFA[-1]}
        calibracao["motivo"] = "nenhuma_configuracao_quieta_no_normal"
    calibracao.update(escolhido)
    return {
        "modo": NOME, "versao": VERSAO,
        "variancias": _variancias(completo["servicos"]),
        "n_intervalos_baseline": completo["n"],
        "calibracao": calibracao,
    }


# --- decisão ---


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    calib = artefato.get("calibracao") or {}
    params = {k: calib.get(k) for k in ("c", "m", "alfa")}
    if any(v is None for v in params.values()):
        params = {"c": GRADE_C[-1], "m": GRADE_M[-1], "alfa": GRADE_ALFA[-1]}  # estrito sem calibração
    parametros = {**params, "lookback_seg": cfg["lookback_seg"], "intervalo_seg": cfg["intervalo_seg"],
                  "calibrado": "c" in calib}

    fim = entrada.abertura_incidente
    inicio = fim - datetime.timedelta(seconds=float(cfg["lookback_seg"]))
    eventos = [e for e in list(entrada.traces_lookback) + list(entrada.traces)
               if to_epoch_us(inicio) <= int(e.start_us) < to_epoch_us(fim)]
    n_traces = len({e.case_id for e in eventos})
    if n_traces < int(cfg["min_traces"]):
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_traces": n_traces}, parametros=parametros)

    intervalo_us = int(float(cfg["intervalo_seg"]) * 1e6)
    s = series(eventos, to_epoch_us(inicio), to_epoch_us(fim), intervalo_us, int(cfg["min_spans_intervalo"]))
    achados = detectar(s["servicos"], artefato.get("variancias") or {}, params, cfg)
    evidencias: dict[str, Any] = {"n_traces": n_traces, "n_intervalos": s["n"],
                                  "inicio": inicio.isoformat(), "fim": fim.isoformat()}
    if not achados:
        return Decisao(status="absteve", motivo_abstencao="sem_mudanca", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)

    ordem = sorted(achados.items(), key=lambda kv: (kv[1]["t"], -kv[1]["forca"], kv[0]))
    t_hat = ordem[0][1]["t"]
    instante = inicio + datetime.timedelta(seconds=t_hat * float(cfg["intervalo_seg"]))
    evidencias["t_hat"] = instante.isoformat()
    evidencias["t_hat_intervalo"] = t_hat
    menor_detectavel = min(int(cfg["min_segmento"]), int(cfg["janela_fluxo"]))
    if t_hat <= menor_detectavel:
        evidencias["achados"] = {k: v for k, v in ordem}
        return Decisao(status="absteve", motivo_abstencao="inicio_fora_da_janela", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)

    ranking = []
    for servico, achado in ordem:
        t_s = inicio + datetime.timedelta(seconds=achado["t"] * float(cfg["intervalo_seg"]))
        ranking.append(ItemRanking(servico=servico, escore=float(achado["t"]), evidencias={
            "t_s": t_s.isoformat(), "intervalo": achado["t"], "perspectiva": achado["perspectiva"],
            "forca": round(achado["forca"], 4), "relacao": achado["detalhe"],
        }))
    return Decisao(status="decidiu", ranking=ranking, evidencias=evidencias, parametros=parametros,
                   versao=VERSAO)


class _ModoD3:
    nome = NOME
    versao = VERSAO

    @staticmethod
    def janela_traces(entrada: EntradaIncidente, cfg: dict[str, Any]) -> tuple[datetime.datetime, datetime.datetime]:
        fim = entrada.abertura_incidente
        return fim - datetime.timedelta(seconds=float(_cfg(cfg)["lookback_seg"])), fim

    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD3()
