"""d9-k — d9 com canal de eventos do Kubernetes de sintoma (PROTOCOLO-CONSENSO.md §3).

Solução definitiva do Stage 3 (decisão de 14/10/2026), junto com o v-cons-b. Configuração
escolhida em dev (f + h) e lida uma vez em g:

1. **Portão** = o da d9 (`limiar` 1,5, `limiar_erro` 0,10, dano desligado, `ref_seg` 150), aberto **também** por
   evento K8s de sintoma na janela (`abre_portao_k8s`).
2. **Ranking** = `residuo_1` da d9, completado até o top-3 pela ordem de efeito da d5 e, se ainda faltar, pela
   localização `profundo` da d9.
3. **Canal K8s**: o serviço com mais eventos de sintoma na janela (motivos de `k8s_sintoma`; os de operação —
   `Pulled`, `Created`, `Started`, `Killing` de rollout... — são rastro do harness e ficam de fora) vai para o 1º.
   `count` de evento agregado é rateado pela fração do intervalo `[first_ts, ts]` que cai na janela; sem `first_ts`
   (o coletor do produto só traz o último carimbo) o evento é pontual em `ts`; sem `ts`, conta na janela.
4. **Ranking forçado** (sabendo que é falha): o mesmo ranking, com o portão permissivo da d5 quando o da d9 fecha.
   Vai sempre em `evidencias["ranking_forcado"]` (o v-cons-b vota com ele); `forcar=True` o devolve como decisão.

A persistência do 1º da grade (n ∈ {1, 3, 5}) ficou em n = 1, isto é, nenhuma: o modo não guarda estado.
Nenhum arquivo da d5/d9 muda: as funções deles são usadas como utilitários.
"""
from __future__ import annotations

import datetime
from typing import Any

from src.application.stage3.abordagens import a0k_k8s as a0k
from src.application.stage3.abordagens import d5_portao as d5
from src.application.stage3.abordagens import d9_portao_grafo as d9
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d9-k"
VERSAO = "d9-k-v1"

K8S_SINTOMA = ("OOMKilled", "OOMKilling", "BackOff", "Unhealthy", "Evicted", "Failed", "FailedScheduling",
               "ProbeWarning")

DEFAULT_CFG: dict[str, Any] = {
    "limiar": 1.5,
    "limiar_erro": 0.10,
    "limiar_dano_lat": None,
    "ref_seg": 150,
    "dependencias_sem_span": {"mysql": "teastore-db"},
    "abre_portao_k8s": True,
    "k8s_sintoma": list(K8S_SINTOMA),
    "top_k": 3,
    "forcar": False,
}

# Portão permissivo da d5 para o ranking forçado (o mesmo do protocolo rápido).
PERMISSIVO: dict[str, Any] = {"limiar": 1.0, "limiar_erro": 0.0, "limiar_dano_lat": None, "min_traces": 0}

MOTIVOS: dict[str, str] = {**d5.MOTIVOS}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def contagem_k8s(eventos: list[Any], janela: tuple[datetime.datetime, datetime.datetime],
                 motivos: set[str]) -> dict[str, int]:
    """`{serviço: nº de eventos de sintoma na janela}`, com o `count` agregado rateado no tempo.

    Primeiro corta o evento no fim da janela (o que o coletor veria nesse instante), depois no início; cada
    corte guarda pelo menos uma ocorrência, como no avaliador.
    """
    ini, fim = janela
    cont: dict[str, int] = {}
    for e in eventos:
        if a0k._motivo(e) not in motivos:
            continue
        servico, ts = a0k._servico(e), a0k._ts(e)
        if not servico:
            continue
        n = a0k._peso(e)
        if ts is None:   # o provedor que não carimba o evento o entregou porque ele é da janela (como a a0-k)
            cont[servico] = cont.get(servico, 0) + n
            continue
        primeiro = a0k._ts(e, "first_ts") or ts
        if primeiro > fim:
            continue
        ts_v = min(ts, fim)
        dur = (ts - primeiro).total_seconds()
        n = max(1, round(n * ((ts_v - primeiro).total_seconds() / dur if dur > 0 else 1.0)))
        if ts_v < ini:
            continue
        dur_v = (ts_v - primeiro).total_seconds()
        novo_ini = max(primeiro, ini)
        n = max(1, round(n * ((ts_v - novo_ini).total_seconds() / dur_v if dur_v > 0 else 1.0)))
        cont[servico] = cont.get(servico, 0) + n
    return cont


def servico_k8s(entrada: EntradaIncidente, cfg: dict[str, Any] | None = None) -> str | None:
    """Serviço com mais eventos de sintoma na janela (empate: o maior nome, como no avaliador)."""
    cfg = _cfg(cfg)
    cont = contagem_k8s(list(entrada.eventos_k8s), entrada.janela, set(cfg["k8s_sintoma"]))
    return max(cont, key=lambda s: (cont[s], s)) if cont else None


def ranking_base(entrada: EntradaIncidente, cfg: dict[str, Any]) -> list[str]:
    """`residuo_1` da d9 → efeito da d5 → `profundo` da d9, sem repetir, até `top_k`."""
    top_k = int(cfg.get("top_k") or 3)
    saida: list[str] = []
    for decidir, extra in ((d9.decidir, {"localizacao": "residuo_1"}), (d5.decidir, {}),
                           (d9.decidir, {"localizacao": "profundo"})):
        try:
            d = decidir(entrada, {}, {**cfg, **extra})
        except Exception:  # noqa: BLE001 - uma fonte quebrada não derruba as outras
            continue
        saida += [i.servico for i in d.ranking if i.servico not in saida]
        if len(saida) >= top_k:
            break
    return saida[:top_k]


def _promover(ranking: list[str], servico: str | None, top_k: int) -> list[str]:
    return ([servico] + [s for s in ranking if s != servico])[:top_k] if servico else ranking[:top_k]


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    top_k = int(cfg["top_k"])
    portao = d9.decidir(entrada, {}, cfg)
    aberto_d9 = portao.status == "decidiu" and bool(portao.ranking)
    final = ranking_base(entrada, cfg) if aberto_d9 else []
    forcado = final or ranking_base(entrada, {**cfg, **PERMISSIVO})
    k8s = servico_k8s(entrada, cfg)
    forcado = _promover(forcado, k8s, top_k)
    aberto = aberto_d9 or bool(cfg["abre_portao_k8s"] and k8s)
    parametros = {**(portao.parametros or {}), **{k: cfg[k] for k in ("abre_portao_k8s", "top_k", "forcar")}}
    evidencias = {**(portao.evidencias or {}), "ranking_forcado": forcado, "k8s_sintoma": k8s,
                  "portao_d9": aberto_d9, "aberto_por_k8s": aberto and not aberto_d9}
    if not (aberto or cfg["forcar"]) or not forcado:
        return Decisao(status="absteve", motivo_abstencao=portao.motivo_abstencao or "portao_fechado",
                       evidencias=evidencias, parametros=parametros, versao=VERSAO)
    ranking = [ItemRanking(servico=s, escore=float(i), evidencias={"k8s_sintoma": s == k8s})
               for i, s in enumerate(forcado)]
    return Decisao(status="decidiu", ranking=ranking, evidencias=evidencias, parametros=parametros, versao=VERSAO)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Sem artefato de baseline: referência da própria sessão, como a d5/d9."""
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("limiar", "limiar_erro", "ref_seg", "abre_portao_k8s", "k8s_sintoma")}}


class _ModoD9k:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD9k()
