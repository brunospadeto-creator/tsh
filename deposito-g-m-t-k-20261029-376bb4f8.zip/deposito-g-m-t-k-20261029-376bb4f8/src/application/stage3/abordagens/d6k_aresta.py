"""d6-k — Aresta.

Mesma decisão, mesmos testes, mesmo `q` e mesma atribuição da d2c (chamados como utilitário). Muda só
o ranking, e por um motivo específico: a d6 atenua a força intrínseca de um serviço pela **maior**
força intrínseca entre todos os seus descendentes (`max(0, f − α·max_desc)`). Isso ignora que uma
chamada de baixo explica o pai **na proporção em que o pai a chama**.

Aqui a propagação é por aresta e recursiva no DAG:

1. Para cada aresta `p → c` da referência, `ρ(p, c)` = chamadas de `c` por chamada de `p` (contagem de
   spans por serviço na referência). Uma aresta pouco usada propaga pouco.
2. O resíduo é recursivo: `r(c)` é calculado primeiro e `r(p) = max(0, f(p) − max_c ρ(p,c)·r(c))`.
   Assim a explicação desce a cadeia inteira (`webui → auth → persistence → db`) sem que o `db` fique
   com crédito que na verdade é do `persistence`.
3. Ciclos do grafo de chamadas são rompidos pela marca de visita (com serviços reais o DAG tem
   ciclos por retry), devolvendo resíduo zero no nó revisitado — melhor que recursão infinita.

Ordem final como em `causal.ranquear`: resíduo intrínseco > 0 antes; maior força; nome só apresenta.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d2_diferencial as d2
from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d6-k"
VERSAO = "d6-k-v1"

DEFAULT_CFG: dict[str, Any] = {**d2c.DEFAULT_CFG, "rho_padrao": 1.0}

MOTIVOS = {"sem_residuo_atribuivel": "todos os desvios foram explicados pelos filhos (propagação pura)"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _contagem_por_servico(eventos: list[Any]) -> dict[str, int]:
    contagem: dict[str, int] = defaultdict(int)
    for evento in eventos:
        servico = str(getattr(evento, "service", "") or "")
        if servico:
            contagem[servico] += 1
    return contagem


def razoes_por_aresta(eventos_ref: list[Any], filhos: dict[str, set[str]]) -> dict[tuple[str, str], float]:
    """`ρ(p, c)` = chamadas de `c` por chamada de `p`, das contagens de spans da referência."""
    contagem = _contagem_por_servico(eventos_ref)
    razoes: dict[tuple[str, str], float] = {}
    for pai, chamados in filhos.items():
        n_pai = contagem.get(pai, 0)
        for filho in chamados:
            n_filho = contagem.get(filho, 0)
            razoes[(pai, filho)] = (n_filho / n_pai) if n_pai > 0 else 0.0
    return razoes


def _residuo(servico: str, fi: dict[str, float], filhos: dict[str, set[str]],
             rho: dict[tuple[str, str], float], padrao: float,
             memo: dict[str, float], visitados: set[str]) -> float:
    """Resíduo recursivo com ρ por aresta; nó revisitado (ciclo) devolve 0.0."""
    if servico in memo:
        return memo[servico]
    if servico in visitados:
        return 0.0
    visitados.add(servico)
    maior = 0.0
    for filho in filhos.get(servico, ()):
        if filho == servico:
            continue
        r_filho = _residuo(filho, fi, filhos, rho, padrao, memo, visitados)
        maior = max(maior, rho.get((servico, filho), padrao) * r_filho)
    memo[servico] = max(0.0, fi.get(servico, 0.0) - maior)
    visitados.discard(servico)
    return memo[servico]


def reordenar(ranking: list[ItemRanking], filhos: dict[str, set[str]],
              rho: dict[tuple[str, str], float], sumidos: list[str], padrao: float) -> list[dict[str, Any]]:
    """Linhas `{servico, fi, fc, r, ...}` na ordem do resíduo por aresta."""
    linhas: dict[str, dict[str, Any]] = {i.servico: {"servico": i.servico,
                          "fi": float(i.evidencias.get("forca_intrinseca") or 0.0),
                          "fc": float(i.evidencias.get("forca_comportamental") or 0.0),
                          "itens": i.evidencias.get("itens") or []} for i in ranking}
    maior = max([lin["fi"] for lin in linhas.values()] + [lin["fc"] for lin in linhas.values()] + [0.0])
    for servico in sumidos:
        lin = linhas.setdefault(servico, {"servico": servico, "fi": 0.0, "fc": 0.0, "itens": []})
        lin["fi"] = max(lin["fi"], maior or causal.FORCA_MAXIMA)
        lin["sumiu"] = True
    fi: dict[str, float] = {s: float(lin["fi"]) for s, lin in linhas.items()}
    memo: dict[str, float] = {}
    for lin in linhas.values():
        lin["r"] = _residuo(lin["servico"], fi, filhos, rho, padrao, memo, set())
    return sorted(linhas.values(), key=lambda lin: (lin["r"] <= 0, -lin["r"], -lin["fc"], lin["servico"]))


def decidir_de_base(base: Decisao, entrada: EntradaIncidente, artefato: dict[str, Any],
                    cfg: dict[str, Any]) -> Decisao:
    """A regra sobre a decisão da d2c já calculada (o avaliador calcula a d2c uma vez por instante)."""
    cfg = _cfg(cfg)
    parametros = {**base.parametros, "rho_padrao": float(cfg["rho_padrao"])}
    if base.status != "decidiu":
        return Decisao(status=base.status, motivo_abstencao=base.motivo_abstencao,
                       evidencias=base.evidencias, parametros=parametros, versao=VERSAO)
    dependencias = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    filhos = d6.grafo_de_servicos(list(entrada.traces), dependencias)
    rho = razoes_por_aresta(list(entrada.traces_lookback) or list(entrada.traces), filhos)  # ρ da referência
    nomes = {**((artefato or {}).get("servicos") or {}), **d2.nomes_de_servico(entrada.traces)}
    presentes = {str(getattr(e, "service", "") or "") for e in entrada.traces}
    sumidos = sorted({nomes.get(c, c) for c in d6.servicos_do_normal(artefato or {})} - presentes - {""})
    linhas = reordenar(base.ranking, filhos, rho, sumidos, float(cfg["rho_padrao"]))
    if not any(lin["r"] > 0 or lin["fc"] > 0 for lin in linhas):
        return Decisao(status="absteve", motivo_abstencao="sem_residuo_atribuivel",
                       evidencias=base.evidencias, parametros=parametros, versao=VERSAO)
    chave = [(lin["r"] <= 0, -lin["r"], -lin["fc"]) for lin in linhas]
    ranking = []
    for pos, lin in enumerate(linhas):
        escore = lin["r"] if lin["r"] > 0 else lin["fc"]
        ranking.append(ItemRanking(
            servico=lin["servico"], escore=escore, p_valor=10.0 ** (-min(escore, 300.0)),
            evidencias={"forca_intrinseca": lin["fi"], "residuo_aresta": lin["r"],
                        "forca_comportamental": lin["fc"], "sumiu": bool(lin.get("sumiu")),
                        "empate_com_seguinte": pos + 1 < len(linhas) and chave[pos + 1] == chave[pos],
                        "itens": lin["itens"][:10]}))
    return Decisao(status="decidiu", ranking=ranking, evidencias={**base.evidencias, "sumidos": sumidos},
                   parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    return decidir_de_base(d2c.decidir(entrada, artefato, cfg), entrada, artefato, cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    artefato = d2c.preparar_baseline(traces_normais, janelas, _cfg(cfg))
    return {**artefato, "modo": NOME, "versao": VERSAO}


class _ModoD6k:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD6k()
