"""d9+m — Multissinal.

O mesmo portão da d5/d9 decide *quando* há alarme. O que muda é a **evidência por serviço**, que deixa
de ser só o efeito de tempo/erro em traces e passa a combinar canais independentes:

- **traces**: tempo/erro da janela contra a referência da sessão, por serviço (Mann-Whitney à direita
  sobre as durações dos spans do serviço);
- **K8s**: o resultado do `a0-k` (Poisson de eventos por serviço × motivo), chamado como utilitário;
- **métricas**: quando o insumo traz `metric_stats` + `observadas`, o teste empírico bilateral de cada
  métrica observada contra a distribuição da referência.

Os p-valores dos canais de um serviço entram na combinação de **Fisher** (`estatistica.fisher`), que é
o "três testes fracos pesam mais que um só médio" do plano do modo. Nenhum item ajustado nas F entra aqui —
nada de lista de exclusão de métricas, de direção melhor/pior nem de piso fixo (os vieses 5/6/8/9 da
a0): toda métrica é bilateral e toda referência vem da própria sessão.

Sem artefato de baseline: as referências são a janela lookback da própria sessão.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import a0k_k8s as a0k
from src.application.stage3.abordagens import causal, referencia
from src.application.stage3.abordagens import d5_portao as d5
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d9+m"
VERSAO = "d9+m-v1"

DEFAULT_CFG: dict[str, Any] = {
    **d5.DEFAULT_CFG,
    "min_amostras_canal": 5,   # mínimo de observações para um canal de traces valer
    "ref_seg": 150,
    "ref_modo": "lookback",
    "dependencias_sem_span": {"mysql": "teastore-db"},
}

MOTIVOS = {"sem_servico_significativo": "o portão abriu, mas nenhum canal tem evidência por serviço"}

CANAIS = ("traces", "k8s", "metricas")


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _duracoes_por_servico(eventos: list[Any], deps: dict[str, str] | None = None) -> dict[str, list[float]]:
    """Durações por serviço; span cliente de banco (`dependencias_sem_span`) conta para o banco, como na d9."""
    por: dict[str, list[float]] = defaultdict(list)
    for evento in eventos:
        servico = (deps or {}).get(referencia._atividade(evento)) or referencia._servico(evento)
        if servico:
            por[servico].append(float(referencia._duracao(evento)))
    return {s: v for s, v in por.items()}


def canal_traces(entrada: EntradaIncidente, eventos_ref: list[Any], cfg: dict[str, Any]) -> dict[str, float]:
    deps = causal.dependencias_por_atividade(list(entrada.traces) + list(eventos_ref),
                                             cfg.get("dependencias_sem_span") or {})
    inc = _duracoes_por_servico(list(entrada.traces), deps)
    ref = _duracoes_por_servico(eventos_ref, deps)
    minimo = int(cfg["min_amostras_canal"])
    saida: dict[str, float] = {}
    for servico, valores in inc.items():
        if len(valores) < minimo or len(ref.get(servico) or []) < minimo:
            continue
        saida[servico] = est.mann_whitney(valores, ref[servico], alternative="greater").p
    return saida


def canal_k8s(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, float]:
    """p por serviço a partir do `a0-k` (Poisson de eventos), sem reimplementar o teste."""
    decisao = a0k.decidir_de_medida(a0k.separar(entrada, cfg), cfg)
    return {item.servico: float(item.p_valor if item.p_valor is not None else 1.0)
            for item in decisao.ranking}


def canal_metricas(entrada: EntradaIncidente) -> dict[str, float]:
    """p bilateral por entidade, do teste empírico contra `metric_stats`.

    Só existe quando o insumo traz as duas metades (`observadas` e `metric_stats`); sem elas o canal
    fica ausente em vez de virar evidência falsa. Para cada entidade toma o menor p entre as métricas
    (bilateral, sem lista de exclusão nem direção).
    """
    dados = entrada.metricas if isinstance(entrada.metricas, dict) else {}
    observadas = dados.get("observadas") or {}
    stats = dados.get("metric_stats") or {}
    if not observadas or not stats:
        return {}
    saida: dict[str, float] = {}
    for entidade, metricas in observadas.items():
        base = stats.get(entidade) or {}
        valores = []
        for nome, valor in (metricas or {}).items():
            amostra = base.get(nome)
            if not amostra:
                continue
            nulos = [float(v) for v in amostra]
            p_sup = est.p_empirico(float(valor), nulos, maior_e_melhor=True)
            p_inf = est.p_empirico(float(valor), nulos, maior_e_melhor=False)
            valores.append(min(1.0, 2.0 * min(p_sup, p_inf)))  # bilateral
        if valores:
            saida[str(entidade)] = min(valores)
    return saida


def evidencia_por_servico(entrada: EntradaIncidente, eventos_ref: list[Any],
                          cfg: dict[str, Any]) -> dict[str, dict[str, float]]:
    """`{serviço: {canal: p}}` com os canais disponíveis."""
    por_servico: dict[str, dict[str, float]] = defaultdict(dict)
    for canal, valores in (("traces", canal_traces(entrada, eventos_ref, cfg)),
                           ("k8s", canal_k8s(entrada, cfg)),
                           ("metricas", canal_metricas(entrada))):
        for servico, p in valores.items():
            por_servico[servico][canal] = float(p)
    return dict(por_servico)


def _forca(p: float) -> float:
    return min(1e6, max(0.0, -math.log10(min(1.0, max(est.P_MIN, float(p))))))


def decidir_de_medida(entrada: EntradaIncidente, medida: dict[str, Any], eventos_ref: list[Any],
                      cfg: dict[str, Any]) -> Decisao:
    """O portão da d5; se abrir, o ranking pela evidência combinada (Fisher) por serviço."""
    cfg = _cfg(cfg)
    portao = d5.decidir_de_medida(medida, cfg)
    parametros = {**portao.parametros, "min_amostras_canal": cfg["min_amostras_canal"]}
    if portao.status != "decidiu":
        return Decisao(status=portao.status, motivo_abstencao=portao.motivo_abstencao,
                       evidencias=portao.evidencias, parametros=parametros, versao=VERSAO)
    evidencia = evidencia_por_servico(entrada, eventos_ref, cfg)
    if not evidencia:
        return Decisao(status="absteve", motivo_abstencao="sem_servico_significativo",
                       evidencias=portao.evidencias, parametros=parametros, versao=VERSAO)
    combinados = {s: est.fisher(list(p.values())) for s, p in evidencia.items()}
    nomes = sorted(combinados, key=lambda s: (-_forca(combinados[s]), s))
    ranking = [ItemRanking(servico=s, escore=_forca(combinados[s]), p_valor=combinados[s],
                           evidencias={"canais": evidencia[s], "n_canais": len(evidencia[s])})
               for s in nomes]
    return Decisao(status="decidiu", ranking=ranking,
                   evidencias={**portao.evidencias, "canais_disponiveis":
                               sorted({c for v in evidencia.values() for c in v})},
                   parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    servicos_raiz = d5._entradas(entrada, cfg)
    eventos_ref = d5._eventos_ref(entrada, cfg)
    inc = referencia.estatisticas(entrada.traces, servicos_raiz=servicos_raiz)
    ref = referencia.estatisticas(eventos_ref, servicos_raiz=servicos_raiz)
    medida = {"n_traces": len({getattr(e, "case_id", None) for e in entrada.traces}),
              "n_eventos_ref": len(eventos_ref), **d5.medir(inc, ref, cfg)}
    return decidir_de_medida(entrada, medida, eventos_ref, cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "limiares_por_validacao_cruzada"},
            "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("limiar", "limiar_erro", "ref_seg", "min_amostras_canal")}}


class _ModoD9m:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD9m()
