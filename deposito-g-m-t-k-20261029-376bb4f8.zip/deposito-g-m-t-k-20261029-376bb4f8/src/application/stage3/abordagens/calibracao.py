"""Calibração normal × normal.

*"Limiar = meta de falso positivo medida em dado normal."* Nenhum modo escolhe o próprio `q`, e
nenhum gabarito entra — nem nome de falha, nem instante de injeção, nem serviço-alvo. Entram
**traces normais**, cortados em janelas do tamanho de um incidente, e a pergunta é: *"com que limiar
este modo decide em no máximo `fp_alvo` das janelas normais?"*.

Três escolhas, cada uma corrigindo um defeito medido em 2026-10-03:

1. **Estatística de decisão única por janela: `p_min_ajustado`.** É o menor p ajustado por
   Benjamini-Hochberg entre todos os testes da janela. O BH rejeita alguma coisa ao nível `q` **se e
   só se** `p_min_ajustado ≤ q`, então calibrar essa estatística calibra exatamente a decisão. A versão
   anterior misturava p bruto e p combinado por Fisher, que não correspondem à regra que decide.
2. **Cauda inferior.** `q` fica abaixo do `(⌊fp_alvo·n⌋+1)`-ésimo menor `p_min_ajustado` das janelas
   normais: no máximo `⌊fp_alvo·n⌋` delas decidiriam. A versão anterior tomava o quantil `1 − fp_alvo`,
   o que fazia o modo decidir em ~95% das janelas normais; só o teto de `q` escondia isso.
3. **Validação cruzada (deixa a janela de fora).** O artefato contra o qual uma janela é testada é
   construído **sem** os traces dela. Testar uma janela contra uma amostra que a contém compara o
   normal consigo mesmo e devolve p ≈ 1 em quase todas, o que não mede ruído nenhum.

Contrato com os modos:

- `cfg["_calibrando"] = True` pede ao modo o limiar **permissivo** (`q = 1`), para que ele rode
  todos os testes e grave `evidencias["p_min_ajustado"]` em vez de parar no primeiro abstain;
- sem essa chave, o modo usa o `q` calibrado do artefato.

Limite declarado: as janelas normais vêm de uma baseline de ~25 min, e um incidente chega horas
depois. A calibração mede o ruído **dentro** da baseline, não a deriva entre a baseline e o incidente.
"""

from __future__ import annotations

import datetime
import math
from collections.abc import Callable, Sequence
from typing import Any

from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

__all__ = [
    "CHAVE_CALIBRANDO",
    "CHAVE_ESTATISTICA",
    "Q_PERMISSIVA",
    "calibrar_cruzado",
    "estatistica_da_decisao",
    "janelas_de_normal",
    "q_do_artefato",
    "quantil_q",
]

# A chave que o modo lê para saber que está em janela de calibração.
CHAVE_CALIBRANDO = "_calibrando"

# Onde cada modo grava a estatística de decisão da janela (ver item 1 do docstring).
CHAVE_ESTATISTICA = "p_min_ajustado"

# Durante a calibração nada é descartado. `1.0` é o único valor que BH nunca deixa de rejeitar.
Q_PERMISSIVA = 1.0

# Teto do `q` calibrado: com `q` alto demais o modo decide sobre qualquer diferença. Com a cauda
# inferior o teto só atua quando quase nenhuma janela normal produz p pequeno.
Q_MAXIMO_CALIBRADO = 0.5

# Default só para artefato sem calibração. Não é um limiar "bom": existe para que o modo não decida.
Q_PADRAO_ESTRETA = 0.001

# Abaixo disso a estimativa do `q` é ruído. Com baseline de 25 min e janela de 5 min, o passo de meia
# janela dá 9 janelas — o mínimo fica logo abaixo.
MIN_JANELAS_CALIBRACAO = 8


def q_do_artefato(artefato: dict[str, Any], cfg: dict[str, Any]) -> float:
    """`q` efetivo de uma decisão. Só a calibração pode pedir o limiar permissivo.

    Artefato sem `calibracao.q` cai no padrão **estrito**: um artefato não calibrado decidindo com
    `q = 1` transformaria ruído em achado. O `parametros` da decisão registra o `q` usado.
    """
    if cfg.get(CHAVE_CALIBRANDO):
        return Q_PERMISSIVA
    calibracao = (artefato or {}).get("calibracao") or {}
    q = calibracao.get("q")
    if isinstance(q, (int, float)) and 0.0 < float(q) <= 1.0:
        return float(q)
    return Q_PADRAO_ESTRETA


def quantil_q(estatisticas: Sequence[float], fp_alvo: float) -> float:
    """`q` estritamente abaixo do `(⌊fp_alvo·n⌋+1)`-ésimo menor valor, limitado pelo teto.

    Com `n = 9` e `fp_alvo = 0.05`, `⌊0.45⌋ = 0`: o `q` fica abaixo do **menor** `p_min_ajustado`
    normal, e nenhuma janela normal decide. É conservador por construção — com 9 janelas não dá para
    afirmar uma taxa de 5%, só "0 de 9" (IC 95% de Wilson até ~30%), e isso vai para o registro.
    """
    ordenados = sorted(float(p) for p in estatisticas)
    if not ordenados:
        return Q_PADRAO_ESTRETA
    k = int(math.floor(fp_alvo * len(ordenados) + 1e-12))
    if k >= len(ordenados):
        return Q_MAXIMO_CALIBRADO
    abaixo = math.nextafter(ordenados[k], 0.0)
    return float(min(Q_MAXIMO_CALIBRADO, max(abaixo, 1e-300)))


def janelas_de_normal(
    eventos: list[Any],
    tamanho: datetime.timedelta,
    *,
    passo: datetime.timedelta | None = None,
    max_janelas: int = 40,
) -> list[tuple[datetime.datetime, datetime.datetime]]:
    """Janelas do tamanho de um incidente sobre os traces normais, com passo de meia janela.

    O meio passo dobra o número de janelas sem mudar o tamanho de cada uma (o poder dos testes
    depende do tamanho, então janela menor calibraria outra coisa). Janelas vizinhas se sobrepõem;
    isso torna as estatísticas correlacionadas, o que vai declarado — não as torna erradas.
    """
    from src.application.stage3.abordagens import processo

    if tamanho.total_seconds() <= 0:
        return []
    passo = passo or tamanho / 2
    inicios: list[int] = []
    for sequencia in processo.sequencias_por_trace(eventos).values():
        if sequencia:
            inicios.append(min(int(e.start_us) for e in sequencia))
    if not inicios:
        return []
    primeiro = datetime.datetime.fromtimestamp(min(inicios) / 1e6, tz=datetime.UTC)
    ultimo = datetime.datetime.fromtimestamp(max(inicios) / 1e6, tz=datetime.UTC)
    janelas: list[tuple[datetime.datetime, datetime.datetime]] = []
    inicio = primeiro
    while inicio + tamanho <= ultimo + datetime.timedelta(microseconds=1) and len(janelas) < max_janelas:
        janelas.append((inicio, inicio + tamanho))
        inicio = inicio + passo
    return janelas


def entrada_da_janela(
    janela: tuple[datetime.datetime, datetime.datetime],
    eventos_da_janela: list[Any],
    cfg: dict[str, Any],
    indice: int,
    lookback: list[Any] | None = None,
) -> EntradaIncidente:
    """Entrada comum de uma janela normal. `abertura_incidente` é o fim da janela (não há injeção)."""
    return EntradaIncidente(
        incidente_id=f"calibracao-{indice:03d}",
        janela=janela,
        abertura_incidente=janela[1],
        traces=eventos_da_janela,
        traces_lookback=list(lookback or []),
        metricas={},
        eventos_k8s=[],
        config_sistema=cfg.get("config_sistema") or {},
        cfg=cfg,
    )


def estatistica_da_decisao(decisao: Decisao) -> float | None:
    """`p_min_ajustado` da janela; `1.0` quando o modo rodou e não teve teste; `None` sem insumo.

    Abster por `poucos_traces` é ausência de informação (`None`, fora da conta). Abster sem nenhum
    teste com insumo presente é "não decidiria" (`1.0`, dentro da conta) — tirá-la da conta
    inflaria a taxa de falso positivo medida.
    """
    valor = (decisao.evidencias or {}).get(CHAVE_ESTATISTICA)
    if isinstance(valor, (int, float)) and not math.isnan(float(valor)):
        return float(valor)
    if decisao.status == "absteve" and decisao.motivo_abstencao == "poucos_traces":
        return None
    return 1.0


def _ids_de_trace(eventos: Sequence[Any]) -> set[str]:
    return {str(getattr(e, "case_id", "")) for e in eventos}


def calibrar_cruzado(
    construir: Callable[[list[Any]], dict[str, Any]],
    decidir: Callable[[EntradaIncidente, dict[str, Any], dict[str, Any]], Decisao],
    eventos: list[Any],
    janelas: list[tuple[datetime.datetime, datetime.datetime]],
    cfg: dict[str, Any],
    *,
    fp_alvo: float = 0.05,
    lookback_seg: float = 0.0,
) -> dict[str, Any]:
    """Calibra o `q` de um modo por validação cruzada nas janelas normais.

    `construir(traces)` devolve o artefato do modo **sem** calibração; ele é chamado uma vez por
    janela, com os traces normais menos os da janela. `lookback_seg > 0` entrega à janela os traces
    anteriores a ela (D3), também tirados do artefato da vez.

    Devolve o bloco que vai para `artefato["calibracao"]`. Não levanta com poucas janelas: devolve
    `q = None` e o motivo, e o modo decide com o padrão estrito.
    """
    from src.application.stage3.abordagens import processo

    if len(janelas) < MIN_JANELAS_CALIBRACAO:
        return {"q": None, "n_janelas": len(janelas), "motivo": "poucas_janelas",
                "min_janelas": MIN_JANELAS_CALIBRACAO}

    cfg_calibrando = {**cfg, CHAVE_CALIBRANDO: True}
    estatisticas: list[float | None] = []
    for indice, janela in enumerate(janelas):
        dentro = processo.cortar_janela(eventos, janela)
        if not dentro:
            estatisticas.append(None)
            continue
        lookback: list[Any] = []
        if lookback_seg > 0:
            inicio_lb = janela[0] - datetime.timedelta(seconds=lookback_seg)
            lookback = processo.cortar_janela(eventos, (inicio_lb, janela[0]))
        excluir = _ids_de_trace(dentro) | _ids_de_trace(lookback)
        fora = [e for e in eventos if str(getattr(e, "case_id", "")) not in excluir]
        try:
            artefato = construir(fora)
            decisao = decidir(entrada_da_janela(janela, dentro, cfg_calibrando, indice, lookback),
                              artefato, cfg_calibrando)
        except Exception:  # noqa: BLE001 - uma janela que quebra não calibra as demais
            estatisticas.append(None)
            continue
        estatisticas.append(estatistica_da_decisao(decisao))

    validas = [s for s in estatisticas if s is not None]
    if len(validas) < MIN_JANELAS_CALIBRACAO:
        return {"q": None, "n_janelas": len(janelas), "n_validas": len(validas),
                "motivo": "poucas_janelas_validas", "min_janelas": MIN_JANELAS_CALIBRACAO,
                "estatistica_por_janela": estatisticas}

    q = quantil_q(validas, fp_alvo)
    n_decidindo = sum(1 for s in validas if s <= q)
    return {
        "q": q,
        "n_janelas": len(janelas),
        "n_validas": len(validas),
        "n_decidindo": n_decidindo,
        "taxa_decisao": n_decidindo / len(validas),
        "fp_alvo": fp_alvo,
        "q_teto": Q_MAXIMO_CALIBRADO,
        "nulos_distintos": len({round(s, 12) for s in validas}),
        "estatistica_por_janela": estatisticas,
        "metodo": "validacao_cruzada_deixa_janela_fora;cauda_inferior_de_p_min_ajustado",
        "min_janelas": MIN_JANELAS_CALIBRACAO,
    }
