"""D2 — comparação de processos com significância.

**Pergunta:** *quais elementos do processo de cada endpoint — relações de chamada e atividades —
mudaram de frequência, presença, tempo ou erro entre o normal e o incidente?*

Base: Bolt et al. (B1: sistema de transições anotado, teste por elemento), Lu et al. (B3: G com
resíduo ajustado), Cecconi et al. (B2: permutação como alternativa sem suposição).

O que faz a D2 ser a mais simples das quatro é que ela **não precisa de modelo**: compara o
incidente contra amostras do normal, elemento a elemento. É também a que dá o exemplo mais
concreto de que o mecanismo existe, medido no lote `20261002T013953Z`: no F1 a relação
`webui → persistence` em `GET /webui/category` passou de 4 para 5 chamadas por trace, e pela
regra de atribuição isso é evidência contra o `webui` — enquanto a A0, que não vê mudança de
fluxo, culpou o `persistence`. Esse exemplo é da especificação da D2 e **não** foi usado para ajustar nada aqui.

Duas regras de atribuição merecem a justificativa, porque são elas que decidem quem é culpado:

- relação `a → b` **nova** ou com contagem maior → serviço de **`a`**, quem decidiu chamar. A
  atribuição oposta (culpar `b`, quem foi chamado) seria a leitura ingênua, e ela erra o sentido
  da causalidade: um serviço que recebe chamada a mais está reacts, não causando;
- relação `a → b` **sumida** ou com contagem menor → serviço de `b` **se `b` sumiu do endpoint**,
  senão de `a`. A distinção existe porque "deixou de chamar" e "deixou de ser chamado" são o mesmo
  número com causas opostas, e o desempate é se `b` ainda aparece.

Nenhuma delas olha o gabarito. Ambas foram fixadas antes de qualquer replay (regra de
procedimento), que é o que faz delas evidência e não ajuste.
"""

from __future__ import annotations

import datetime
import random
from collections import defaultdict
from collections.abc import Sequence
from typing import Any

from src.application.stage3.abordagens import calibracao as _calibracao
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d2"
VERSAO = "d2-v3"

DEFAULT_CFG: dict[str, Any] = {
    "max_amostra": 1000,
    "min_traces": 30,
    "tamanho_janela_seg": 300,  # janela do incidente no sistema (5 min); só define a janela normal
}


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


# --- medidas por trace (a "representação" da D2) ---


def medidas_por_trace(sequencias: list[list[Any]]) -> dict[str, Any]:
    """Nível 1 (`contagem` por trace) e nível 2 (`presença`) das relações; presença, tempo e erro
    das atividades.

    Todas as medidas são **por trace**, nunca somadas: a soma perderia a variância, e sem variância
    não há Mann-Whitney. Um endpoint com 100 traces de 4 chamadas e um de 100 traces de 40 têm a
    mesma média e são populistamente o mesmo processo; a distribuição por trace é o que separa.

    Duas passagens, e a ordem importa. Primeiro cada trace vira um dicionário de contadores; só
    depois as chaves viram vetores, sobre a **união** de todas as chaves. Fazer isso numa
    passagem só deixa a chave que apareceu no trace 5 com 55 valores e a que apareceu no trace 1
    com 60 — e o Mann-Whitney compararia listas de tamanhos diferentes como se fossem a mesma
    medida, que é um p-value errado sem nenhum sinal visível.
    """
    contagens_por_trace: list[dict[str, int]] = []
    atividades_por_trace: list[dict[str, dict[str, Any]]] = []

    for sequencia in sequencias:
        contagem: dict[str, int] = defaultdict(int)
        for origem, destino in proc.arestas_atividade_com_multiplicidade(sequencia):
            contagem[f"{origem} -> {destino}"] += 1
        contagens_por_trace.append(dict(contagem))

        atividades: dict[str, dict[str, Any]] = {}
        for evento in sequencia:
            atividade = str(getattr(evento, "activity", "") or "")
            if not atividade:
                continue
            registro = atividades.setdefault(atividade, {"n": 0, "soma_duracao": 0, "erros": 0})
            registro["n"] += 1
            registro["soma_duracao"] += proc.duracao_propria(evento, sequencia)
            registro["erros"] += 1 if getattr(evento, "is_error", False) else 0
        atividades_por_trace.append(atividades)

    chaves_rel = sorted({c for contagem in contagens_por_trace for c in contagem})
    chaves_ativ = sorted({a for atividades in atividades_por_trace for a in atividades})

    contagem_rel: dict[str, list[int]] = {}
    presenca_rel: dict[str, list[int]] = {}
    presenca_ativ: dict[str, list[int]] = {}
    duracao_ativ: dict[str, list[int]] = {}
    erro_ativ: dict[str, list[int]] = {}
    for chave in chaves_rel:
        valores = [contagem.get(chave, 0) for contagem in contagens_por_trace]
        contagem_rel[chave] = valores
        presenca_rel[chave] = [1 if v else 0 for v in valores]
    for chave in chaves_ativ:
        presenca_ativ[chave] = [1 if chave in atividades else 0 for atividades in atividades_por_trace]
        for i, atividades in enumerate(atividades_por_trace):
            ocorrencia = atividades.get(chave)
            if ocorrencia is None:
                duracao_ativ.setdefault(chave, []).append(0)
                erro_ativ.setdefault(chave, []).append(0)
            else:
                # Média por trace: uma atividade que ocorre 10 vezes num trace não pode ter peso
                # 10 na comparação com uma que ocorre uma vez em cada trace.
                duracao_ativ.setdefault(chave, []).append(
                    ocorrencia["soma_duracao"] // max(1, ocorrencia["n"])
                )
                erro_ativ.setdefault(chave, []).append(ocorrencia["erros"])

    return {
        "contagem_rel": contagem_rel,
        "presenca_rel": presenca_rel,
        "presenca_ativ": presenca_ativ,
        "duracao_ativ": duracao_ativ,
        "erro_ativ": erro_ativ,
    }


# Mínimo de ocorrências para uma mediana de janela (normal ou incidente) valer como observação.
MIN_OCORRENCIAS_JANELA = 5


def medianas_por_janela(sequencias: list[list[Any]], tamanho_us: int) -> dict[str, list[float]]:
    """Por atividade, a mediana da duração própria (média por trace) em cada janela normal.

    Grade comum a todas as atividades (início/fim dos traces do endpoint), tamanho da janela do
    incidente e passo de meia janela. É a amostra do `est.predicao_log`.
    """
    pares: dict[str, list[tuple[int, float]]] = defaultdict(list)
    inicios: list[int] = []
    for sequencia in sequencias:
        if not sequencia:
            continue
        inicio = min(int(e.start_us) for e in sequencia)
        inicios.append(inicio)
        acumulado: dict[str, list[int]] = defaultdict(list)
        for evento in sequencia:
            atividade = str(getattr(evento, "activity", "") or "")
            if atividade:
                acumulado[atividade].append(proc.duracao_propria(evento, sequencia))
        for atividade, valores in acumulado.items():
            media = sum(valores) / len(valores)
            if media:
                pares[atividade].append((inicio, media))
    if not inicios:
        return {}
    saida = {
        atividade: est.medianas_por_janela(p, tamanho_us, minimo=MIN_OCORRENCIAS_JANELA,
                                           inicio_us=min(inicios), fim_us=max(inicios))
        for atividade, p in pares.items()
    }
    return {a: m for a, m in saida.items() if m}


def _nomes_de_elementos(medidas: dict[str, Any]) -> tuple[set[str], set[str], set[str]]:
    return (
        set(medidas["contagem_rel"]),
        set(medidas["duracao_ativ"]),
        set(medidas["erro_ativ"]),
    )


def _agregados(medidas: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Contagens agregadas dos traces normais, para a tabela do teste G.

    O G precisa das contagens na forma ``[[a, b], [c, d]]`` por elemento (presente vs. presente),
    com linha 0 = incidente e linha 1 = normal. O agregado vem do normal; o incidente entra na
    hora do teste.
    """
    agregado: dict[str, dict[str, float]] = {}
    for chave, valores in medidas["presenca_rel"].items():
        agregado[chave] = {"presente": float(sum(valores)), "n": float(len(valores))}
    return agregado


# --- a comparação ---


def _testes_elemento(
    endpoint: str,
    rel: str,
    inc: dict[str, Any],
    nor: dict[str, Any],
    n_inc: int,
    n_nor: int,
) -> list[dict[str, Any]]:
    """Os testes de uma relação `origem -> destino`, nos dois níveis (contagem e presença).

    Os dois níveis são preenchidos com zero onde a relação não existe na outra população, e é
    justamente aí que está o requisito da especificação: "relação **nova** (zero no normal) e **sumida** (zero
    no incidente) entram pelo mesmo teste". Sem o preenchimento, `.get(rel, [])` devolve lista vazia,
    o teste é pulado, e `nova`/`sumida` viram código morto — a D2 passaria ao largo dos dois
    cenários que a spec nomeia.
    """
    testes: list[dict[str, Any]] = []
    origem, destino = rel.split(" -> ")

    cont_inc = _vetor(inc, "contagem_rel", rel, n_inc)
    cont_nor = _vetor(nor, "contagem_rel", rel, n_nor)
    if n_inc >= 3 and n_nor >= 3 and max(cont_nor or [0]) > 0:
        # Contagem: bilateral, porque o sinal da mudança vem do resíduo, não do sentido do p.
        r = est.mann_whitney(cont_inc, cont_nor, alternative="two-sided")
        testes.append({
            "tipo": "contagem_relacao", "elemento": rel, "endpoint": endpoint,
            "n_inc": r.n, "media_inc": _media(cont_inc), "media_nor": _media(cont_nor),
            "p": r.p,
        })

    pres_inc = _vetor(inc, "presenca_rel", rel, n_inc)
    pres_nor = _vetor(nor, "presenca_rel", rel, n_nor)
    soma_inc, soma_nor = sum(pres_inc), sum(pres_nor)
    if n_inc and n_nor:
        a, b = soma_inc, n_inc - soma_inc
        c, d = soma_nor, n_nor - soma_nor
        g = est.g_2x2(a, b, c, d, alternative="two-sided")
        resid = est.residuo_ajustado(a, b, c, d)
        testes.append({
            "tipo": "presenca_relacao", "elemento": rel, "endpoint": endpoint,
            "n_inc": n_inc, "n_nor": n_nor,
            "presenca_inc": soma_inc / n_inc, "presenca_nor": soma_nor / n_nor,
            "p": g.p, "residuo": resid["r00"],
            "nova": soma_nor == 0 and soma_inc > 0,
            "sumida": soma_inc == 0 and soma_nor > 0,
        })
    return testes


def _vetor(medidas: dict[str, Any], familia: str, chave: str, n: int) -> list[int]:
    """Vetor de `n` observações da medida, com zero onde a chave não existe naquela população.

    Uma atividade que **só** aparece no incidente não tem medidas no baseline. Sem o
    preenchimento com zero, o teste seria pulado — e "chamada nova" e "chamada que sumiu" são dois
    dos cenários que a especificação exige detectar. Sem zero, a ausência vira exclusão silenciosa em vez de
    medida, que é o pior dos dois: o modo fica mais confiante do que o dado permite.
    """
    return list(medidas.get(familia, {}).get(chave, []))[:n] + [0] * max(
        0, n - len(medidas.get(familia, {}).get(chave, []))
    )


def _testes_atividade(
    endpoint: str,
    atividade: str,
    inc: dict[str, Any],
    nor: dict[str, Any],
    n_inc: int,
    n_nor: int,
    janelas_nor: dict[str, list[float]] | None = None,
) -> list[dict[str, Any]]:
    testes: list[dict[str, Any]] = []
    pres_inc = _vetor(inc, "presenca_ativ", atividade, n_inc)
    pres_nor = _vetor(nor, "presenca_ativ", atividade, n_nor)
    if sum(pres_inc) or sum(pres_nor):
        a, b = sum(pres_inc), n_inc - sum(pres_inc)
        c, d = sum(pres_nor), n_nor - sum(pres_nor)
        g = est.g_2x2(a, b, c, d, alternative="two-sided")
        testes.append({
            "tipo": "presenca_atividade", "elemento": atividade, "endpoint": endpoint,
            "n_inc": n_inc, "n_nor": n_nor,
            "g": g.estatistica, "p": g.p,
            "media_inc": sum(pres_inc) / max(1, n_inc), "media_nor": sum(pres_nor) / max(1, n_nor),
        })
    # Tempo: mediana do incidente contra as medianas das janelas normais (d2-v2). A
    # unidade do teste é a janela, não o trace: traces da mesma janela não são independentes.
    dur_inc = [v for v in _vetor(inc, "duracao_ativ", atividade, n_inc) if v]
    medianas_nor = (janelas_nor or {}).get(atividade) or []
    if len(dur_inc) >= MIN_OCORRENCIAS_JANELA:
        r = est.predicao_log(est.mediana(dur_inc), medianas_nor, alternative="greater")
        if r is not None:
            testes.append({
                "tipo": "duracao_atividade", "elemento": atividade, "endpoint": endpoint,
                "n_inc": len(dur_inc), "n_janelas_nor": r.n,
                "mediana_inc": est.mediana(dur_inc), "mediana_nor": est.mediana(medianas_nor),
                "t": r.estatistica, "p": r.p,
            })
    erro_inc = _vetor(inc, "erro_ativ", atividade, n_inc)
    erro_nor = _vetor(nor, "erro_ativ", atividade, n_nor)
    n_erro_inc, n_erro_nor = len(erro_inc), len(erro_nor)
    if n_erro_inc and n_erro_nor:
        a, b = sum(erro_inc), n_erro_inc - sum(erro_inc)
        c, d = sum(erro_nor), n_erro_nor - sum(erro_nor)
        g = est.g_2x2(a, b, c, d, alternative="greater")
        resid = est.residuo_ajustado(a, b, c, d)
        testes.append({
            "tipo": "erro_atividade", "elemento": atividade, "endpoint": endpoint,
            "n_inc": n_erro_inc, "n_nor": n_erro_nor,
            "erro_inc": sum(erro_inc) / n_erro_inc, "erro_nor": sum(erro_nor) / n_erro_nor,
            "p": g.p, "residuo": resid["r00"],
        })
    return testes


def _media(valores: Sequence[float]) -> float:
    return float(sum(valores) / len(valores)) if valores else 0.0


def _atribuir(
    testes: dict[str, dict[str, Any]],
    medidas_inc: dict[str, Any],
    servicos_endpoint: set[str],
) -> dict[str, list[dict[str, Any]]]:
    """Aplica a regra 4 de atribuição da D2. Devolve `{servico: [testes atribuídos]}`.

    Cada atribuição guarda **qual regra** decidiu, porque a evidência gravada é "o elemento, a
    medida, o p e a regra" — sem a regra, o resultado não é auditável nem reproduzível.
    """
    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for chave, teste in testes.items():
        tipo = teste["tipo"]
        if tipo == "duracao_atividade":
            servico = proc.servico_da_atividade(teste["elemento"])
            por_servico[servico].append({**teste, "regra": "tempo_proprio_da_atividade"})
        elif tipo == "erro_atividade":
            servico = proc.servico_da_atividade(teste["elemento"])
            por_servico[servico].append({**teste, "regra": "erro_na_atividade"})
        elif tipo == "presenca_relacao":
            origem, destino = teste["elemento"].split(" -> ")
            servico_origem = proc.servico_da_atividade(origem)
            servico_destino = proc.servico_da_atividade(destino)
            if teste.get("nova") or (teste.get("residuo", 0) or 0) > 0:
                por_servico[servico_origem].append({**teste, "regra": "relacao_nova_ou_mais_frequente"})
            elif teste.get("sumida") or (teste.get("residuo", 0) or 0) < 0:
                # Regra 4: relação `a -> b` sumida → serviço de `b` **se `b` não aparece mais no
                # endpoint**; senão o serviço de `a`. A segunda metade importa: com `b` ainda
                # presente no endpoint, o desaparecimento da relação é mudança de comportamento do
                # chamador, e culpar `b` seria atribuir ao chamado uma decisão do chamador.
                if servico_destino not in servicos_endpoint:
                    por_servico[servico_destino].append({**teste, "regra": "destino_sumiu_do_endpoint"})
                else:
                    por_servico[servico_origem].append({**teste, "regra": "relacao_sumida_ou_menos_frequente"})
            else:
                por_servico[servico_origem].append({**teste, "regra": "presenca_relacao"})
        elif tipo == "contagem_relacao":
            origem, destino = teste["elemento"].split(" -> ")
            servico_origem = proc.servico_da_atividade(origem)
            servico_destino = proc.servico_da_atividade(destino)
            if teste["media_inc"] > teste["media_nor"]:
                por_servico[servico_origem].append(
                    {**teste, "regra": "contagem_por_trace_aumentou"}
                )
            elif servico_destino not in servicos_endpoint:
                por_servico[servico_destino].append(
                    {**teste, "regra": "contagem_menor_e_destino_sumiu_do_endpoint"}
                )
            else:
                por_servico[servico_origem].append(
                    {**teste, "regra": "contagem_por_trace_diminuiu"}
                )

    # Segunda parte da regra 4 de atribuição da D2: uma relação `a -> b` também é evidência contra `b`
    # quando `b` tem tempo ou erro significativo. Sem esta atribuição, um `b` que ficou lento **e**
    # passou a ser chamado mais vezes apareceria só sob `a`, e o chamador levaria a culpa de um
    # defeito que era do chamado.
    com_tempo_ou_erro = {
        proc.servico_da_atividade(t["elemento"])
        for t in testes.values()
        if t["tipo"] in {"duracao_atividade", "erro_atividade"}
    }
    for teste in list(testes.values()):
        if teste["tipo"] not in {"presenca_relacao", "contagem_relacao"}:
            continue
        destino = teste["elemento"].split(" -> ")[1]
        servico_destino = proc.servico_da_atividade(destino)
        if servico_destino in com_tempo_ou_erro and servico_destino not in por_servico:
            por_servico[servico_destino].append(
                {**teste, "regra": "destino_com_tempo_ou_erro_significativo"}
            )
    return por_servico


def _servicos_presentes(sequencias: list[list[Any]]) -> set[str]:
    """Serviços do endpoint pelo **nome curto do rótulo da atividade** — o mesmo nome que
    `_atribuir` tira de `a -> b`. Comparar o curto (`db`) com o nome do trace (`teastore-db`) fazia
    "destino sumiu do endpoint" valer sempre (d2-v2; corrigido em d2-v3)."""
    servicos: set[str] = set()
    for sequencia in sequencias:
        for evento in sequencia:
            curto = proc.servico_da_atividade(str(getattr(evento, "activity", "") or ""))
            if curto:
                servicos.add(curto)
    return servicos


def nomes_de_servico(eventos: list[Any]) -> dict[str, str]:
    """Nome curto do rótulo da atividade → nome do serviço no trace (o que a saída comum usa)."""
    nomes: dict[str, str] = {}
    for evento in eventos:
        curto = proc.servico_da_atividade(str(getattr(evento, "activity", "") or ""))
        servico = str(getattr(evento, "service", "") or "")
        if curto and servico:
            nomes.setdefault(curto, servico)
    return nomes


def decidir(
    entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]
) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    q = _calibracao.q_do_artefato(artefato, cfg)
    parametros = {"q": q, "fp_alvo": artefato.get("calibracao", {}).get("fp_alvo")}

    if not artefato:
        # Sem artefato a D2 não tem contra o que comparar. Ela se abstém, e a ausência é
        # distinguível de "comparou e não achou nada".
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       parametros={**parametros, "artefato": "ausente"})

    por_endpoint_inc = proc.sequencias_por_endpoint(entrada.traces)
    por_endpoint_nor = artefato.get("endpoints", {})
    n_traces = sum(len(v) for v in por_endpoint_inc.values())
    if n_traces < cfg["min_traces"]:
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_traces": n_traces}, parametros=parametros)

    # Todos os testes primeiro; BH depois, sobre o conjunto inteiro do incidente.
    testes: list[dict[str, Any]] = []
    medidas_por_endpoint: dict[str, dict[str, Any]] = {}
    for endpoint, traces in por_endpoint_inc.items():
        nor = por_endpoint_nor.get(endpoint)
        if not nor:
            continue
        sequencias = list(traces.values())
        inc = medidas_por_trace(sequencias)
        medidas_por_endpoint[endpoint] = inc
        nor_med = nor["medidas"]
        n_nor_endpoint = int(nor.get("n_traces") or 0)
        for chave in sorted(set(inc["contagem_rel"]) | set(nor_med["contagem_rel"])):
            testes.extend(
                _testes_elemento(endpoint, chave, inc, nor_med, len(sequencias), n_nor_endpoint)
            )
        for atividade in sorted(set(inc["duracao_ativ"]) | set(nor_med["duracao_ativ"])):
            testes.extend(
                _testes_atividade(endpoint, atividade, inc, nor_med, len(sequencias), n_nor_endpoint,
                                  nor.get("duracao_janelas"))
            )

    if not testes:
        return Decisao(status="absteve", motivo_abstencao="sem_diferenca_significativa",
                       versao=VERSAO, evidencias={"n_testes": 0}, parametros=parametros)

    ps = [t["p"] for t in testes]
    ajustados, significativos = est.benjamini_hochberg(ps, q)
    # Estatística de decisão: o BH rejeita algo ao nível q sse min(ajustados) ≤ q.
    p_min_ajustado = min(ajustados)

    # Só os significativos entram na atribuição; os outros ficam gravados como medida, que é o
    # que permite auditar "o que foi testado e o que não passou".
    if not any(significativos):
        return Decisao(status="absteve", motivo_abstencao="sem_diferenca_significativa",
                       versao=VERSAO,
                       evidencias={"n_testes": len(testes), "p_min_ajustado": p_min_ajustado,
                                   "testes": sorted(testes, key=lambda t: t["p"])[:20]},
                       parametros=parametros)

    for teste, p_adj, sig in zip(testes, ajustados, significativos):
        teste["p_ajustado"] = p_adj
        teste["significante"] = sig

    # Atribui por endpoint: as regras usam o contexto do endpoint (quais serviços aparecem nele).
    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)
    testes_por_endpoint: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for teste in testes:
        if teste.get("significante"):
            testes_por_endpoint[teste["endpoint"]].append(teste)
    for endpoint, sig_testes in testes_por_endpoint.items():
        atribuidos = _atribuir(
            {f"{i}": t for i, t in enumerate(sig_testes)},
            medidas_por_endpoint.get(endpoint, {}),
            _servicos_presentes(list(por_endpoint_inc[endpoint].values())),
        )
        for servico, itens in atribuidos.items():
            por_servico[servico].extend(itens)

    # Saída no nome do serviço do trace, como os outros modos; o normal cobre quem sumiu do incidente
    nomes = {**(artefato.get("servicos") or {}), **nomes_de_servico(entrada.traces)}
    ranking: list[ItemRanking] = []
    for servico, itens in por_servico.items():
        if not servico:
            continue
        p_comb = est.fisher([i["p_ajustado"] for i in itens])
        ranking.append(ItemRanking(
            servico=nomes.get(servico, servico),
            escore=p_comb,
            p_valor=p_comb,
            evidencias={
                "n_testes": len(itens),
                "itens": sorted(
                    itens,
                    key=lambda i: (i.get("p_ajustado", 1.0), i["tipo"], i["elemento"]),
                )[:10],
            },
        ))

    ranking.sort(key=lambda i: (i.escore, i.servico))
    return Decisao(
        status="decidiu",
        ranking=ranking,
        versao=VERSAO,
        evidencias={
            "n_testes": len(testes),
            "p_min_ajustado": p_min_ajustado,
            "n_significativos": int(sum(significativos)),
            "n_endpoints": len(medidas_por_endpoint),
            "q": q,
        },
        parametros=parametros,
    )


def construir_artefato(traces_normais: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Artefato da D2 **sem** calibração: por endpoint, a amostra das medidas do normal.

    O artefato é **amostra**, não agregado: sem a variância o Mann-Whitney da decisão não tem contra
    o que comparar. É também o que a calibração cruzada reconstrói sem os traces de cada janela.
    """
    cfg = _cfg(cfg)
    por_endpoint = proc.sequencias_por_endpoint(traces_normais)
    max_amostra = int(cfg["max_amostra"])
    semente = 42  # semente fixa: o artefato tem de ser reprodutível entre execuções

    endpoints: dict[str, Any] = {}
    for endpoint, traces in por_endpoint.items():
        sequencias = [traces[k] for k in sorted(traces)]
        if len(sequencias) > max_amostra:
            sequencias = random.Random(semente).sample(sequencias, max_amostra)
        medidas = medidas_por_trace(sequencias)
        endpoints[endpoint] = {
            "n_traces": len(sequencias),
            "medidas": medidas,
            "agregado": _agregados(medidas),
            # todas as sequências (não a amostra): a variação entre janelas precisa de todas elas
            "duracao_janelas": medianas_por_janela(
                [traces[k] for k in sorted(traces)], int(float(cfg["tamanho_janela_seg"]) * 1e6)),
        }
    return {
        "modo": NOME,
        "versao": VERSAO,
        "endpoints": endpoints,
        "servicos": nomes_de_servico(traces_normais),
        "max_amostra": max_amostra,
        "semente": semente,
    }


def preparar_baseline(
    traces_normais: list[Any],
    janelas: list[Any],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Artefato completo: amostra do normal + `q` calibrado por validação cruzada.

    Sem `janelas`, as janelas normais saem dos próprios traces, com o tamanho da janela de incidente
    do sistema (`tamanho_janela_seg`) e passo de meia janela.
    """
    cfg = _cfg(cfg)
    artefato = construir_artefato(traces_normais, cfg)
    if not janelas:
        janelas = _calibracao.janelas_de_normal(
            traces_normais, datetime.timedelta(seconds=float(cfg["tamanho_janela_seg"])))
    artefato["calibracao"] = _calibracao.calibrar_cruzado(
        lambda fora: construir_artefato(fora, cfg),
        decidir,
        traces_normais,
        list(janelas),
        cfg,
        fp_alvo=float(cfg.get("fp_alvo") or 0.05),
    )
    return artefato


class _ModoD2:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD2()
