"""Atribuição causal comum às versões `c` dos modos (d1c, d2c, d4c).

Por que existe. O diagnóstico do hold-out de 11-12/10 mediu três defeitos de **ranking** nas
v1, todos fora da decisão (decidir/abster continua igual):

1. **Piso.** `est.p_seguro` corta em `1e-300`; com milhares de traces os testes de fluxo batem no piso e
   serviços diferentes empatam. O desempate era `sort` por nome, e `teastore-webui` é o último no
   alfabeto — a d2 "acertava" perdendo o empate para o culpado.
2. **Soma de evidência.** Fisher sobre todos os testes de um serviço premia quem tem mais atividades. O
   serviço de entrada participa de quase todas e vence por contagem.
3. **Sintoma × causa.** Mudança no que um serviço *chama* (relação nova, contagem menor) é efeito do
   que acontece abaixo dele; tempo próprio, erro que nasce nele e "sumiu do trace" são dele.

O que esta camada faz, e nada mais: força em `−log10 p` calculada na cauda logarítmica (sem piso), escore
do serviço = o teste **mais forte** (Tippett, não Fisher), e ordem lexicográfica: quem tem evidência
intrínseca vem antes de quem só tem comportamental. Empate exato fica marcado, não escondido.

Este arquivo é novo de propósito: nada das v1 congeladas (`congelamento.json`) é alterado.
"""
from __future__ import annotations

import math
from collections.abc import Iterable, Sequence
from typing import Any

from scipy import stats

from src.application.stage3.abordagens.base import ItemRanking

INTRINSECA = "intrinseca"
COMPORTAMENTAL = "comportamental"
_LN10 = math.log(10.0)


# --- força sem piso (−log10 p pela cauda em log) ---


FORCA_MAXIMA = 1e6  # cauda que transborda até em log: força finita, para caber em JSON do banco


def _de_logp(logp: float) -> float:
    if math.isnan(logp):
        return 0.0
    if not math.isfinite(logp):
        return FORCA_MAXIMA if logp < 0 else 0.0
    return min(FORCA_MAXIMA, max(0.0, -float(logp) / _LN10))


def forca_g_2x2(a: float, b: float, c: float, d: float, *, alternative: str = "two-sided") -> float:
    """−log10 p do G de independência 2×2 (linha 0 = incidente). `greater`: taxa do incidente maior."""
    a, b, c, d = (max(0.0, float(v)) for v in (a, b, c, d))
    n = a + b + c + d
    linhas, colunas = (a + b, c + d), (a + c, b + d)
    if n <= 0 or 0 in linhas or 0 in colunas:
        return 0.0
    if alternative == "greater" and a / linhas[0] <= c / linhas[1]:
        return 0.0
    if alternative == "less" and a / linhas[0] >= c / linhas[1]:
        return 0.0
    g = 0.0
    for o, (i, j) in zip((a, b, c, d), ((0, 0), (0, 1), (1, 0), (1, 1))):
        if o > 0:
            g += o * math.log(o * n / (linhas[i] * colunas[j]))
    g *= 2.0
    # χ²(1) = Z²: sf(G) = 2·Φ̄(√G), e o `norm.logsf` do scipy é exato na cauda (o `chi2.logsf` vira −∞)
    logp = math.log(2.0) + float(stats.norm.logsf(math.sqrt(max(g, 0.0))))
    if alternative in {"greater", "less"}:
        logp += math.log(0.5)
    return _de_logp(logp)


def forca_mann_whitney(x: Sequence[float], y: Sequence[float]) -> float:
    """−log10 p bilateral do Mann-Whitney pela aproximação normal com correção de empates."""
    n1, n2 = len(x), len(y)
    if n1 < 1 or n2 < 1:
        return 0.0
    juntos = list(x) + list(y)
    postos = stats.rankdata(juntos)
    u = float(sum(postos[:n1]) - n1 * (n1 + 1) / 2.0)
    n = n1 + n2
    _, contagens = _contagens_empate(juntos)
    correcao = sum(t ** 3 - t for t in contagens) / (n * (n - 1)) if n > 1 else 0.0
    variancia = n1 * n2 / 12.0 * ((n + 1) - correcao)
    if variancia <= 0:
        return 0.0
    z = (abs(u - n1 * n2 / 2.0) - 0.5) / math.sqrt(variancia)
    return _de_logp(math.log(2.0) + float(stats.norm.logsf(max(z, 0.0))))


def _contagens_empate(valores: Iterable[float]) -> tuple[list[float], list[int]]:
    vistos: dict[float, int] = {}
    for v in valores:
        vistos[v] = vistos.get(v, 0) + 1
    return list(vistos), list(vistos.values())


def forca_t(t: float | None, graus: int, *, alternative: str = "greater") -> float:
    """−log10 p de um t de Student (o `predicao`/`predicao_log` da v1 devolve `t` e `W` janelas)."""
    if t is None or graus < 1:
        return 0.0
    valor = float(t) if alternative == "greater" else -float(t)
    logp = float(stats.t.logsf(valor, graus))
    if not math.isfinite(logp) and valor > 0:
        # cauda de Student: sf(t) ≈ Γ((ν+1)/2) ν^((ν−1)/2) / (√(νπ) Γ(ν/2)) · t^(−ν), para t ≫ √ν
        nu = float(graus)
        logp = (math.lgamma((nu + 1) / 2) - math.lgamma(nu / 2) - 0.5 * math.log(nu * math.pi)
                + (nu - 1) / 2 * math.log(nu) - nu * math.log(valor))
    return _de_logp(logp)


# --- ranking ---


def _chave(linha: dict[str, Any]) -> tuple[float, float]:
    return (round(linha["forca_intrinseca"], 9), round(linha["forca_comportamental"], 9))


def ranquear(itens_por_servico: dict[str, list[dict[str, Any]]], nomes: dict[str, str] | None = None,
             maximo_itens: int = 10) -> list[ItemRanking]:
    """Ordem: tem evidência intrínseca? → maior força intrínseca → maior comportamental → nome.

    Cada item precisa de `classe` (`INTRINSECA`|`COMPORTAMENTAL`) e `forca` (−log10 p). `escore` do
    `ItemRanking` = força do teste que decidiu a posição (maior = mais forte); `p_valor` = `10^−escore`.
    `evidencias.empate_com_seguinte` marca empate exato na chave — o nome só desempata a apresentação.
    """
    nomes = nomes or {}
    linhas: list[dict[str, Any]] = []
    for servico, itens in itens_por_servico.items():
        if not servico or not itens:
            continue
        fi = max((float(i["forca"]) for i in itens if i["classe"] == INTRINSECA), default=0.0)
        fc = max((float(i["forca"]) for i in itens if i["classe"] == COMPORTAMENTAL), default=0.0)
        linhas.append({"servico": nomes.get(servico, servico), "forca_intrinseca": fi,
                       "forca_comportamental": fc, "itens": itens})
    linhas.sort(key=lambda lin: (lin["forca_intrinseca"] <= 0, -lin["forca_intrinseca"],
                                 -lin["forca_comportamental"], lin["servico"]))
    ranking = []
    for pos, linha in enumerate(linhas):
        escore = linha["forca_intrinseca"] if linha["forca_intrinseca"] > 0 else linha["forca_comportamental"]
        empate = pos + 1 < len(linhas) and _chave(linhas[pos + 1]) == _chave(linha)
        ranking.append(ItemRanking(
            servico=linha["servico"], escore=escore, p_valor=10.0 ** (-min(escore, 300.0)),
            evidencias={
                "forca_intrinseca": linha["forca_intrinseca"],
                "forca_comportamental": linha["forca_comportamental"],
                "empate_com_seguinte": empate,
                "n_testes": len(linha["itens"]),
                "itens": sorted(linha["itens"], key=lambda i: (-float(i["forca"]), str(i.get("tipo"))))[:maximo_itens],
            },
        ))
    return ranking


# --- dependência sem span próprio (banco) ---


def dependencias_por_atividade(eventos: Iterable[Any], mapa: dict[str, str]) -> dict[str, str]:
    """`{atividade: serviço da dependência}` para spans cliente de banco (`db.system` no mapa).

    O banco não emite span próprio: o span cliente JDBC (`persistence: SELECT …`) é a única medida dele.
    O tempo próprio desse span cliente é o tempo gasto **no banco**, então é evidência intrínseca do
    banco, não do chamador. O nome do serviço vem da configuração do sistema (`dependencias_sem_span`),
    como `entry_services`: o trace guarda `db.system`, não o nome do serviço do banco.
    """
    if not mapa:
        return {}
    saida: dict[str, str] = {}
    for evento in eventos:
        atributos = getattr(evento, "attributes", None) or {}
        sistema = atributos.get("db.system") if isinstance(atributos, dict) else None
        if sistema and str(sistema) in mapa:
            saida.setdefault(str(evento.activity), str(mapa[str(sistema)]))
    return saida
