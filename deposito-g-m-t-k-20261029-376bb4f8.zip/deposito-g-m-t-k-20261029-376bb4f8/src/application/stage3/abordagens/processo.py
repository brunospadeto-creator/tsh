"""Utilitários de processo, compartilhados pelos modos.

D1–D4 usam **só** traces, e todos precisam das mesmas três operações: ordenar eventos numa sequência,
cortar a janela, e agrupar por serviço/entidade. Juntar isso aqui é o que impede cada modo de
reinventar o corte — e o corte é justamente onde um erro passa despercebido, porque o resultado
continua sendo um ranking plausível.

O corte merece uma observação. `cortar_janela` compara em microssegundos, e um evento que começa
antes da janela mas termina dentro dela **entra inteiro**, com o começo original. Recortar o começo
para a borda da janela fabricaria uma duração que ninguém mediu, e a d4 compara durações contra um
modelo — ela mediria o artefato do corte em vez do processo.
"""

from __future__ import annotations

import datetime
from collections import defaultdict
from collections.abc import Iterable, Sequence
from typing import Any

from src.application.stage3.abordagens.estatistica import assinatura_multiconjunto
from src.application.stage3.traces import to_epoch_us


def ordenar(eventos: Iterable[Any]) -> list[Any]:
    """Ordena por início, com desempate estável por span.

    O desempate por `span_id` não é enfeite: dois eventos com o mesmo `start_us` são indistinguíveis
    numa ordenação estável por posição de entrada, e a ordem entre eles muda a forma da árvore de
    processo.
    """
    return sorted(eventos, key=lambda e: (int(getattr(e, "start_us", 0)), str(getattr(e, "span_id", ""))))


def _janela_us(janela: tuple[datetime.datetime, datetime.datetime]) -> tuple[int, int]:
    inicio, fim = janela
    return to_epoch_us(inicio), to_epoch_us(fim)


def cortar_janela(
    eventos: Sequence[Any], janela: tuple[datetime.datetime, datetime.datetime]
) -> list[Any]:
    """Eventos que **terminam** dentro da janela. Início original preservado (ver docstring)."""
    inicio_us, fim_us = _janela_us(janela)
    dentro = [
        evento
        for evento in eventos
        if inicio_us <= int(evento.start_us) + int(evento.duration_us) <= fim_us
    ]
    return ordenar(dentro)


def sobrepoe_janelas(
    janela: tuple[datetime.datetime, datetime.datetime],
    outra: tuple[datetime.datetime, datetime.datetime],
) -> bool:
    """Sobreposição semiaberta [inicio, fim). Encostar não é sobrepor."""
    return janela[0] < outra[1] and outra[0] < janela[1]


def por_servico(eventos: Iterable[Any]) -> dict[str, list[Any]]:
    """Agrupa por serviço, com os grupos ordenados por nome e os eventos ordenados por início."""
    grupos: dict[str, list[Any]] = defaultdict(list)
    for evento in eventos:
        grupos[str(getattr(evento, "service", "") or "")].append(evento)
    return {servico: ordenar(grupos[servico]) for servico in sorted(grupos)}


def por_atividade(eventos: Iterable[Any]) -> dict[str, list[Any]]:
    """Agrupa por atividade. É a granularidade em que a d1 compara padrões de filha."""
    grupos: dict[str, list[Any]] = defaultdict(list)
    for evento in eventos:
        grupos[str(getattr(evento, "activity", "") or "")].append(evento)
    return {atividade: ordenar(grupos[atividade]) for atividade in sorted(grupos)}


def servicos_presentes(eventos: Iterable[Any]) -> list[str]:
    return sorted({str(getattr(e, "service", "") or "") for e in eventos} - {""})


def duracoes_us(eventos: Iterable[Any]) -> list[int]:
    return [int(getattr(e, "duration_us", 0)) for e in eventos]


def sequencias_por_trace(eventos: Sequence[Any]) -> dict[str, list[Any]]:
    """Agrupa por `case_id`, que é o trace.

    Sem isso, "sequência" significaria a concatenação de traces diferentes, e qualquer transição entre
    atividades seria entre traces, não dentro de um.
    """
    por_trace: dict[str, list[Any]] = defaultdict(list)
    for evento in eventos:
        por_trace[str(getattr(evento, "case_id", "") or "")].append(evento)
    return {trace: ordenar(vals) for trace, vals in sorted(por_trace.items())}


def arestas_de_chamada(eventos: Sequence[Any]) -> list[tuple[str, str]]:
    """Pares (servório de origem, serviço de destino) a partir da profundidade.

    A aresta vem do `depth`, que o `build_trace_events` já calcula. Inferir aresta por sobreposição
    de tempo daria aresta onde houve concorrência, que em microsserviços é a regra e não a exceção.
    """
    arestas: set[tuple[str, str]] = set()
    for sequencia in sequencias_por_trace(eventos).values():
        # Pilha indexada pela profundidade: o pai de um evento em `d` e o ultimo serviço visto em
        # `d - 1`. Ordenar por (profundidade, inicio) garante que o pai ja foi registrado quando o
        # filho aparece, mesmo com varios traces de entrada fora de ordem.
        pilha: dict[int, str] = {}
        for evento in sorted(sequencia, key=lambda e: (int(e.depth), int(e.start_us))):
            profundidade = int(evento.depth)
            servico = str(evento.service or "")
            pai = pilha.get(profundidade - 1)
            if pai and profundidade > 0:
                arestas.add((pai, servico))
            pilha[profundidade] = servico
            # A pilha e por profundidade: um evento mais fundo invalida os niveis abaixo dele.
            for nivel in [n for n in pilha if n > profundidade]:
                del pilha[nivel]
    return sorted(arestas)


def resumir_insumo(eventos: Sequence[Any]) -> dict[str, Any]:
    """Contagens que o pacote de auditoria e a tela mostram do insumo."""
    por_trace = sequencias_por_trace(eventos)
    return {
        "n_eventos": len(eventos),
        "n_traces": len(por_trace),
        "servicos": servicos_presentes(eventos),
        "n_erros": sum(1 for e in eventos if bool(getattr(e, "is_error", False))),
    }


# --- utilidades que os modos D1–D4 precisam ("notação comum") ---


def pai_de(evento: Any, sequencia: Sequence[Any]) -> Any | None:
    """Span pai pelo `parent_span_id`, com queda para o pai por profundidade.

    O `parent_span_id` é explícito e é o que a notação da spec pede ("pai explícito"). A queda por
    profundidade só entra quando o pai declarado não está na sequência — span órfão, que o
    `build_trace_events` marca com `orphan=True`. Sem essa queda, um órfão viraria raiz, e a raiz
    inventada muda o endpoint do trace inteiro.
    """
    pai_id = str((getattr(evento, "attributes", None) or {}).get("parent_span_id") or "")
    if pai_id:
        for candidato in sequencia:
            if str(getattr(candidato, "span_id", "")) == pai_id:
                return candidato
    profundidade = int(getattr(evento, "depth", 0))
    if profundidade <= 0:
        return None
    melhor: Any | None = None
    for candidato in sequencia:
        if int(getattr(candidato, "depth", -1)) != profundidade - 1:
            continue
        if melhor is None or int(getattr(candidato, "start_us", 0)) < int(getattr(melhor, "start_us", 0)):
            melhor = candidato
    return melhor


def filhos_de(evento: Any, sequencia: Sequence[Any]) -> list[Any]:
    """Filhos diretos, pela referência de pai. Ordenados por início."""
    pai_id = str(getattr(evento, "span_id", ""))
    filhos = [
        candidato
        for candidato in sequencia
        if str((getattr(candidato, "attributes", None) or {}).get("parent_span_id") or "") == pai_id
    ]
    return ordenar(filhos)


def duracao_propria(evento: Any, sequencia: Sequence[Any]) -> int:
    """Duração do span menos a soma dos filhos diretos, recortada à própria duração.

    É a "duração própria" da notação da spec, e é o que separa "levou 200 ms" de "esperou 180 ms
    pelo banco". Medir a duração bruta faria uma folha e um nó com quatro chamadas parecerem iguais,
    que é exatamente o caso que a D2 e a D4 precisam separar.

    O `max(0, ...)` é deliberate: filhos concorrentes podem somar mais que o pai, e nesse caso a
    diferença é do relógio, não do processo. Negativo viraria duração negativa, que entra no
    Mann-Whitney como outlier e falseia a comparação de tempo.
    """
    total = int(getattr(evento, "duration_us", 0))
    soma = sum(int(getattr(filho, "duration_us", 0)) for filho in filhos_de(evento, sequencia))
    return max(0, total - soma)


def arestas_atividade_com_multiplicidade(sequencia: Sequence[Any]) -> list[tuple[str, str]]:
    """Cada par (pai, filho) como uma ocorrência, **sem deduplicar**.

    A multiplicidade é o que separa "chamou uma vez" de "chamou cinco vezes": para o exemplo da
    D2 — a relação `webui → persistence` indo de 4 para 5 — as duas Populations têm o
    *mesmo conjunto* de arestas e só diferem na contagem. Uma função que devolvesse o conjunto
    deduplicado faria as duas populações parecerem idênticas, e o caso de exemplo da spec seria
    indetectável por construção, sem erro algum.
    """
    arestas: list[tuple[str, str]] = []
    for evento in sequencia:
        pai = pai_de(evento, sequencia)
        if pai is None:
            continue
        origem = str(getattr(pai, "activity", "") or "")
        destino = str(getattr(evento, "activity", "") or "")
        if origem and destino and origem != destino:
            arestas.append((origem, destino))
    return arestas


def arestas_atividade(sequencia: Sequence[Any]) -> list[tuple[str, str]]:
    """Relação directly-calls **entre atividades** (`serviço: operação`), sem repetição.

    A spec define `a → b` com `a` e `b` atividades, não serviços: é a abstração de estado
    "atividade atual" de Bolt, que é o grafo que a D2 compara. `arestas_de_chamada` (acima) fica
    com a versão por serviço, que é a da A0.

    Use `arestas_atividade_com_multiplicidade` quando a repetição for a informação — contar
    chamadas por trace é o caso "4 → 5" da D2.
    """
    return sorted(set(arestas_atividade_com_multiplicidade(sequencia)))


def servico_da_atividade(atividade: str) -> str:
    """`serviço: operação` → `serviço`. O nome vem antes dos dois pontos; com a notação da spec
    (`TraceEvent.activity`) é sempre o serviço curto."""
    return str(atividade).split(":", 1)[0].strip() if atividade else ""


def atividade_de(atividade: str) -> str:
    """`serviço: operação` → `operação`."""
    partes = str(atividade).split(":", 1)
    return partes[1].strip() if len(partes) == 2 else ""


def traces_com_endpoint(eventos: Sequence[Any]) -> dict[str, list[Any]]:
    """Agrupa por endpoint = atividade do span de menor profundidade de cada trace.

    Reimplementa aqui, e não chama `TraceEventLog.endpoint_of`, porque os modos recebem **listas de
    eventos** e não o log: a entrada comum é a lista, e exigir o log só para ler o endpoint
    obrigaria o despacho a remontar uma estrutura que ele não tem por que ter.
    """
    grupos: dict[str, list[Any]] = defaultdict(list)
    for trace, sequencia in sequencias_por_trace(eventos).items():
        raiz = min(sequencia, key=lambda e: (int(getattr(e, "depth", 0)), int(getattr(e, "start_us", 0))))
        endpoint = str(getattr(raiz, "activity", "") or "")
        if endpoint:
            grupos[endpoint].extend(sequencia)
    return {endpoint: ordenar(vals) for endpoint, vals in sorted(grupos.items())}


def sequencias_por_endpoint(eventos: Sequence[Any]) -> dict[str, dict[str, list[Any]]]:
    """`{endpoint: {trace: sequencia}}`. É a granularidade em que os quatro modos trabalham: a
    comparação é sempre "dentro deste endpoint, o que mudou"."""
    por_trace = sequencias_por_trace(eventos)
    saida: dict[str, dict[str, list[Any]]] = defaultdict(dict)
    for trace, sequencia in por_trace.items():
        raiz = min(sequencia, key=lambda e: (int(getattr(e, "depth", 0)), int(getattr(e, "start_us", 0))))
        endpoint = str(getattr(raiz, "activity", "") or "")
        if endpoint:
            saida[endpoint][trace] = sequencia
    return {endpoint: dict(traces) for endpoint, traces in sorted(saida.items())}


def padroes_de_filhas(sequencia: Sequence[Any]) -> dict[str, tuple[Any, ...]]:
    """Por atividade-pai, o multiconjunto ordenado das atividades chamadas por ela.

    É a linguagem estocástica por nó de chamada da D4. A chave é a atividade do pai, e a chave de
    um span raiz é o próprio endpoint — sem essa chave, o padrão do span que dá entrada no
    sistema não teria modelo nenhum, e seria justamente o span mais enfatizado numa falha de
    entrada quem ficaria sem distribuição.
    """
    chamadas: dict[str, list[str]] = defaultdict(list)
    for evento in sequencia:
        pai = pai_de(evento, sequencia)
        if pai is None:
            continue
        pai_atividade = str(getattr(pai, "activity", "") or "")
        filho_atividade = str(getattr(evento, "activity", "") or "")
        if pai_atividade and filho_atividade:
            chamadas[pai_atividade].append(filho_atividade)
    return {pai: assinatura_multiconjunto(itens) for pai, itens in sorted(chamadas.items())}


def eventos_de_traces_brutos(
    traces_brutos: dict[str, dict[str, Any]],
    entry_services: Sequence[str],
    entry_operation_regex: str = r"^[A-Z]+ /",
) -> list[Any]:
    """Traces no formato do Jaeger (`/api/traces`) → `TraceEvent`, com o mesmo filtro de completude
    do pipeline legado (`traces.build_event_log`, por import). É o insumo comum dos modos d1–d4,
    ao vivo e offline: os dois caminhos passam pela mesma função, então não divergem no corte."""
    from src.application.stage3.traces import build_event_log

    return list(build_event_log(traces_brutos, list(entry_services), entry_operation_regex).events)
