"""d2c-r — Nulo-Rolante.

A d2c compara a janela com um artefato de baseline **fixo** (outra coleção, preparado antes). A validação inicial
mostrou que o problema dominante do Stage 3 é de referência: contra a baseline de outro dia tudo
parece anômalo (a deriva normal entre sessões é de 3–4×). A d2c-r troca o denominador por um **nulo
rolante** — o passado recente da própria sessão, `ref_seg` segundos imediatamente antes da janela.

O que se mantém, deliberadamente: os mesmos testes, o mesmo BH e a mesma atribuição causal da d2c
(tudo chamado como utilitário — a d2c segue congelada). O que muda: a fonte do lado "normal"
(`entrada.traces_lookback`, não o artefato) e o limiar. Sem baseline para calibrar `q`, o limiar é
**fixo** e explícito (`q = 1e-50`): só diferenças extremas decidem, o que é o que substitui a
calibração normal × normal ausente.

Sem artefato de baseline (`preparar_baseline = {}`): a referência é reconstruída a cada decisão, na
medida da janela. O preço declarado é o custo — o artefato da referência é reconstruído no `decidir`.
"""
from __future__ import annotations

import datetime
from typing import Any

from src.application.stage3.abordagens import d2_diferencial as d2
from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

NOME = "d2c-r"
VERSAO = "d2c-r-v1"

DEFAULT_CFG: dict[str, Any] = {
    **d2c.DEFAULT_CFG,
    "q": 1e-50,      # limiar fixo (sem calibração): só diferenças extremas decidem
    "ref_seg": 150,
    "ref_modo": "lookback",
}

MOTIVOS = {"sem_referencia_recente": "a janela não tem passado recente utilizável na própria sessão"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def artefato_rolante(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, Any]:
    """Constrói o artefato do normal a partir do passado recente da própria sessão."""
    inicio, fim = entrada.janela
    ref_seg = float(cfg["ref_seg"])
    janela_ref = ((inicio, inicio + datetime.timedelta(seconds=ref_seg))
                  if cfg["ref_modo"] == "janela_inicial"
                  else (inicio - datetime.timedelta(seconds=ref_seg), inicio))
    eventos_ref = proc.cortar_janela(list(entrada.traces_lookback), janela_ref)
    if not eventos_ref:
        return {}
    artefato = d2.construir_artefato(eventos_ref, cfg)
    artefato["calibracao"] = {"q": float(cfg["q"]), "ref_seg": ref_seg, "ref_modo": cfg["ref_modo"],
                              "metodo": "nulo_rolante_da_propria_sessao"}
    artefato["modo"] = NOME
    artefato["versao"] = VERSAO
    return artefato


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    rolante = artefato_rolante(entrada, cfg) if entrada.traces_lookback else {}
    if not rolante:  # sem lookback, ou o recorte de `ref_seg` não tem nenhum evento
        return Decisao(status="absteve", motivo_abstencao="sem_referencia_recente", versao=VERSAO,
                       parametros={"q": cfg["q"], "ref_seg": cfg["ref_seg"], "ref_modo": cfg["ref_modo"]})
    return d2c.decidir(entrada, rolante, cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Sem artefato de baseline: a referência é o nulo rolante, reconstruído em cada `decidir`."""
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "nulo_rolante_da_propria_sessao"},
            "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("q", "ref_seg", "ref_modo")}}


class _ModoD2cr:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD2cr()
