"""d9 — d5 com localização pelo grafo de chamadas.

Mesmo portão, mesma referência e mesmo estado da d5: a d9 decide exatamente quando a d5 decide. Muda só o
ranking. Na d5 o topo é o maior efeito relativo, que costuma ser o **sintoma** na entrada (o `webui` acumula o
atraso e os erros de quem ele chama). Aqui os efeitos que passaram do portão são lidos sobre o grafo:

1. **Banco pelo span cliente**: efeito de atividade com `db.system` mapeado em `dependencias_sem_span` conta
   para o banco (ele não emite span), como nas versões `c`.
2. **Sumiço**: serviço com atividade na referência e nenhuma na janela entra com o maior escore da janela.
3. `s(v)` = maior `escore_efeito − 1` do serviço entre os efeitos que passaram.
4. Grafo de chamadas da janela ∪ referência (`d6_residuo.grafo_de_servicos`, banco como filho).
5. `localizacao`: `residuo_1` / `residuo_05` — `r(v) = max(0, s(v) − α·max_desc s)`, ordem por `r` (> 0 antes) e
   depois `s`; `profundo` — primeiro quem passou e não tem descendente que passou (fronteira da anomalia).

Nenhum arquivo da d5/d6 muda: as funções deles são usadas como utilitários.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import causal, referencia
from src.application.stage3.abordagens import d5_portao as d5
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d9"
VERSAO = "d9-v1"

LOCALIZACOES = {"residuo_1": 1.0, "residuo_05": 0.5, "profundo": None}

DEFAULT_CFG: dict[str, Any] = {
    **d5.DEFAULT_CFG,
    "localizacao": "residuo_1",
    "dependencias_sem_span": {"mysql": "teastore-db"},
}

MOTIVOS: dict[str, str] = {}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def contexto(eventos_inc: list[Any], eventos_ref: list[Any], ref_stats: dict[str, Any],
             cfg: dict[str, Any]) -> dict[str, Any]:
    """Dependências sem span, grafo (janela ∪ referência) e serviços que sumiram."""
    mapa = cfg.get("dependencias_sem_span") or {}
    deps = {**causal.dependencias_por_atividade(eventos_ref, mapa),
            **causal.dependencias_por_atividade(eventos_inc, mapa)}
    filhos: dict[str, set[str]] = defaultdict(set)
    for origem, fs in d6.grafo_de_servicos(list(eventos_ref) + list(eventos_inc), deps).items():
        filhos[origem] |= fs
    return {"deps": deps, "filhos": dict(filhos), "sumidos": sumidos(eventos_inc, ref_stats, cfg)}


def sumidos(eventos_inc: list[Any], ref_stats: dict[str, Any], cfg: dict[str, Any]) -> list[str]:
    """Serviços com ≥ `min_eventos_atividade` eventos na referência e nenhum na janela."""
    na_ref: dict[str, int] = defaultdict(int)
    for info in (ref_stats.get("ativ") or {}).values():
        if info.get("servico"):
            na_ref[str(info["servico"])] += int(info.get("n") or 0)
    presentes = {referencia._servico(e) for e in eventos_inc}
    minimo = int(cfg.get("min_eventos_atividade") or 0)
    return sorted(s for s, n in na_ref.items() if n >= minimo and s not in presentes)


def ranquear(passou: list[dict[str, Any]], ctx: dict[str, Any], localizacao: str) -> list[dict[str, Any]]:
    """Linhas `{servico, s, r, fronteira, atividade}` na ordem da `localizacao`."""
    if localizacao not in LOCALIZACOES:
        raise ValueError(f"localizacao desconhecida: {localizacao!r}; conhecidas: {sorted(LOCALIZACOES)}")
    deps, filhos = ctx.get("deps") or {}, ctx.get("filhos") or {}
    linhas: dict[str, dict[str, Any]] = {}
    for efeito in passou:
        servico = deps.get(efeito.get("atividade") or "") or efeito.get("servico")
        if not servico:
            continue
        s = max(0.0, referencia.escore_efeito(efeito) - 1.0)
        atual = linhas.get(servico)
        if atual is None or s > atual["s"]:
            linhas[servico] = {"servico": servico, "s": s, "atividade": efeito.get("atividade"),
                               "ratio_mediana": efeito.get("ratio_mediana"), "delta_erro": efeito.get("delta_erro")}
    maior = max([lin["s"] for lin in linhas.values()] + [0.0])
    for servico in ctx.get("sumidos") or []:
        lin = linhas.setdefault(servico, {"servico": servico, "s": 0.0, "atividade": None})
        lin["s"], lin["sumiu"] = max(lin["s"], maior), True
    alfa = LOCALIZACOES[localizacao]
    for lin in linhas.values():
        desc = d6._descendentes(lin["servico"], filhos) & set(linhas)
        max_desc = max((linhas[d]["s"] for d in desc), default=0.0)
        lin["fronteira"] = not any(linhas[d]["s"] > 0 for d in desc)
        lin["r"] = max(0.0, lin["s"] - (alfa if alfa is not None else 0.0) * max_desc)
    if alfa is None:
        chave = lambda lin: (not lin["fronteira"], -lin["s"], lin["servico"])  # noqa: E731
    else:
        chave = lambda lin: (lin["r"] <= 0, -lin["r"], -lin["s"], lin["servico"])  # noqa: E731
    return sorted(linhas.values(), key=chave)


def decidir_de_medida(medida: dict[str, Any], ctx: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    """O portão da d5 sobre a medida; se abrir, o ranking pelo grafo (mesma função no avaliador sequencial)."""
    cfg = _cfg(cfg)
    portao = d5.decidir_de_medida(medida, cfg)
    parametros = {**(portao.parametros or {}), "localizacao": cfg["localizacao"]}
    if portao.status != "decidiu":
        return Decisao(status=portao.status, motivo_abstencao=portao.motivo_abstencao,
                       evidencias=portao.evidencias, parametros=parametros, versao=VERSAO)
    linhas = ranquear(medida["passou"], ctx, str(cfg["localizacao"]))
    ranking = [ItemRanking(servico=lin["servico"], escore=-float(lin["r"] if cfg["localizacao"] != "profundo"
                                                                 else lin["s"]),
                           evidencias={k: v for k, v in lin.items() if k != "servico"})
               for lin in linhas]
    return Decisao(status="decidiu", ranking=ranking,
                   evidencias={**portao.evidencias, "sumidos": ctx.get("sumidos") or []},
                   parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    servicos_raiz = d5._entradas(entrada, cfg)
    eventos_ref = d5._eventos_ref(entrada, cfg)
    inc = referencia.estatisticas(entrada.traces, servicos_raiz=servicos_raiz)
    ref = referencia.estatisticas(eventos_ref, servicos_raiz=servicos_raiz)
    medida = {"n_traces": len({getattr(e, "case_id", None) for e in entrada.traces}),
              "n_eventos_ref": len(eventos_ref), **d5.medir(inc, ref, cfg)}
    return decidir_de_medida(medida, contexto(list(entrada.traces), eventos_ref, ref, cfg), cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Sem artefato de baseline (referência da própria sessão, como a d5)."""
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "limiares_por_validacao_cruzada"},
            "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("limiar", "limiar_erro", "localizacao")}}


class _ModoD9:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD9()
