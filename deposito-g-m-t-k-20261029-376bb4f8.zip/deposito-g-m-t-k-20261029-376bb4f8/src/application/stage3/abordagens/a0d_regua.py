"""a0-d — Régua-Dinâmica.

A a0 localiza por três sinais (métrica anômala, evento do Kubernetes, descoberta de serviço) somados
em votos. O que a auditoria mostrou é que quase tudo que decide na a0 está **ajustado nas F**:
lista de métricas excluídas, direção melhor/pior por nome de série, bônus de indisponibilidade, piso
fixo e `k` fixo. Numa régua isso é aceitável (ela é a referência congelada); como método comparável,
não — o limiar não sobrevive a outro cenário.

A a0-d é a **mesma localização multissinal, com a régua derivada da própria sessão**:

1. `k` por detector = quantil `1 − α/N` da estatística de referência (N = nº de testes da janela), em
   vez de constante fixa;
2. piso = resolução medida na referência, em vez de valor absoluto;
3. sem bônus de indisponibilidade (`indisponivel_min_z`);
4. toda métrica é **bilateral** — sem `metric_vote_excluded` e sem `_MELHOR_PIOR`;
5. eventos do Kubernetes entram por todos os motivos, no teste de taxa do `a0-k`;
6. participação de descoberta = quantil da própria referência (quando o insumo traz a série);
7. ranking por evidência combinada (soma de `−log10 p` por serviço);
8. abstenção se o líder não tem evidência **não explicada** pelos descendentes.

Nada aqui lê a a0 ao vivo: a localização multissinal é reconstruída sobre o insumo comum
(`metricas`, `eventos_k8s`, `traces`) com utilitários congelados (`estatistica`, `d6`). α ∈ {0,01;0,05},
`ref_seg` ∈ {150,300} são os pontos de exploração declarados no plano do modo.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np

from src.application.stage3.abordagens import a0k_k8s as a0k
from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "a0-d"
VERSAO = "a0-d-v1"

DEFAULT_CFG: dict[str, Any] = {
    "alpha": 0.05,
    "ref_seg": 150,
    "ref_modo": "lookback",
    "min_amostras": 5,
    "dependencias_sem_span": {},
}

MOTIVOS = {
    "sem_desvio_significativo": "nenhum detector passou da régua da própria sessão",
    "sem_evidencia_nao_explicada": "o líder não tem evidência própria (tudo explicado pelos filhos)",
}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _forca(p: float) -> float:
    return min(causal.FORCA_MAXIMA, max(0.0, -math.log10(min(1.0, max(est.P_MIN, float(p))))))


def _robusto_z(valor: float, amostra: list[float]) -> tuple[float, list[float]]:
    """`(|z| do valor, |z| de cada valor da referência)`, com mediana e MAD (robustos)."""
    arr = np.asarray([float(v) for v in amostra], dtype=float)
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med)))
    escala = max(1.4826 * mad, 1e-9)
    z_ref = [abs((float(v) - med) / escala) for v in arr]
    return abs((float(valor) - med) / escala), z_ref


def _k_quantil(referencia_zs: list[float], alpha: float, n_testes: int) -> float:
    """`k = quantil(1 − α/N)` da estatística de referência (item 1 do plano do modo)."""
    if not referencia_zs:
        return float("inf")
    q = max(0.0, 1.0 - alpha / max(1, n_testes))
    return float(np.quantile(np.asarray(referencia_zs, dtype=float), q))


def _observadas_e_stats(entrada: EntradaIncidente) -> tuple[dict[str, Any], dict[str, Any]]:
    """Separa o observado da referência. O insumo do produto traz só o observado (`{ent: {métrica: v}}`);
    a referência por métrica acompanha quando o chamador a fornece (`observadas`/`metric_stats` ou
    `config_sistema.metric_stats`). Sem referência, o canal de métrica fica indisponível.
    """
    dados = entrada.metricas if isinstance(entrada.metricas, dict) else {}
    if "observadas" in dados or "metric_stats" in dados:
        return dados.get("observadas") or {}, dados.get("metric_stats") or {}
    planas = {k: v for k, v in dados.items()
              if isinstance(v, dict) and all(isinstance(x, (int, float)) for x in v.values())}
    stats = (entrada.config_sistema or {}).get("metric_stats") or {}
    return planas, stats


def _metricas(entrada: EntradaIncidente, alpha: float, minimo: int) -> list[tuple[str, float]]:
    """Testes de métrica bilaterais, já filtrados pelo `k` do detector. `(serviço, força)`."""
    observadas, stats = _observadas_e_stats(entrada)
    candidatos: list[tuple[str, float, list[float]]] = []
    for entidade, metricas in observadas.items():
        base = stats.get(entidade) or {}
        for nome, valor in (metricas or {}).items():
            amostra = [float(v) for v in (base.get(nome) or [])]
            if len(amostra) < minimo:
                continue
            z, z_ref = _robusto_z(float(valor), amostra)
            candidatos.append((str(entidade), z, z_ref))
    if not candidatos:
        return []
    todos = [z for _, _, zs in candidatos for z in zs]
    k = _k_quantil(todos, alpha, len(candidatos))
    saida: list[tuple[str, float]] = []
    for entidade, z, z_ref in candidatos:
        if z >= k:
            p = est.p_empirico(z, z_ref, maior_e_melhor=True)
            saida.append((entidade, _forca(p)))
    return saida


def _descoberta(entrada: EntradaIncidente, alpha: float) -> list[tuple[str, float]]:
    """Participação de descoberta contra o quantil da referência, quando o insumo traz a série."""
    dados = entrada.metricas if isinstance(entrada.metricas, dict) else {}
    obs = dados.get("descoberta") or {}
    ref = dados.get("descoberta_ref") or {}
    if not obs or not ref:
        return []
    k = _k_quantil([float(v) for v in ref.values()], alpha, len(obs))
    return [(str(alvo), _forca(est.p_empirico(float(v), [float(x) for x in ref.values()])))
            for alvo, v in obs.items() if float(v) >= k]


def evidencia(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, list[tuple[str, float]]]:
    """`{serviço: [(canal, força)]}` dos três detectores."""
    por_servico: dict[str, list[tuple[str, float]]] = {}
    metricas = _metricas(entrada, float(cfg["alpha"]), int(cfg["min_amostras"]))
    decidido_k8s = a0k.decidir_de_medida(a0k.separar(entrada, cfg), cfg)
    k8s = [(i.servico, _forca(i.p_valor if i.p_valor is not None else 1.0)) for i in decidido_k8s.ranking]
    descoberta = _descoberta(entrada, float(cfg["alpha"]))
    for canal, itens in (("metrica", metricas), ("k8s", k8s), ("descoberta", descoberta)):
        for servico, forca in itens:
            if forca > 0:
                por_servico.setdefault(servico, []).append((canal, forca))
    return por_servico


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    parametros = {k: cfg[k] for k in ("alpha", "ref_seg", "ref_modo", "min_amostras")}
    por_servico = evidencia(entrada, cfg)
    if not por_servico:
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", versao=VERSAO,
                       evidencias={"servicos_com_evidencia": []}, parametros=parametros)
    fi = {s: sum(f for _, f in itens) for s, itens in por_servico.items()}
    dependencias = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    filhos = d6.grafo_de_servicos(list(entrada.traces), dependencias)
    linhas: dict[str, dict[str, Any]] = {}
    for servico, total in fi.items():
        desc = d6._descendentes(servico, filhos) & set(fi)
        max_desc = max((fi[d] for d in desc), default=0.0)
        linhas[servico] = {"servico": servico, "total": total, "residuo": max(0.0, total - max_desc),
                           "explicado_por": max_desc, "canais": por_servico[servico]}
    if not any(lin["residuo"] > 0 for lin in linhas.values()):
        return Decisao(status="absteve", motivo_abstencao="sem_evidencia_nao_explicada", versao=VERSAO,
                       evidencias={"servicos_com_evidencia": sorted(fi)}, parametros=parametros)
    ordenadas = sorted(linhas.values(), key=lambda lin: (lin["residuo"] <= 0, -lin["residuo"], lin["servico"]))
    ranking = [ItemRanking(servico=lin["servico"], escore=lin["residuo"], p_valor=10.0 ** (-min(lin["residuo"], 300.0)),
                           evidencias={"forca_total": lin["total"], "residuo": lin["residuo"],
                                       "explicado_por_descendentes": lin["explicado_por"],
                                       "canais": [c for c, _ in lin["canais"]],
                                       "empate_com_seguinte": i + 1 < len(ordenadas)
                                       and ordenadas[i + 1]["residuo"] == lin["residuo"]})
               for i, lin in enumerate(ordenadas)]
    return Decisao(status="decidiu", ranking=ranking,
                   evidencias={"servicos_com_evidencia": sorted(fi)},
                   parametros=parametros, versao=VERSAO)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """A referência das métricas/eventos é da própria sessão; não há artefato a preparar."""
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "regua_da_propria_sessao"},
            "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("alpha", "ref_seg", "ref_modo")}}


class _ModoA0d:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoA0d()
