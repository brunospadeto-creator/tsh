"""d1 — conformance populacional com localização por desalinhamento.

Pergunta: *em que atividades do modelo normal os traces do incidente passaram a desviar — no fluxo
ou no tempo — mais do que os traces normais desviam?*

Diferença para o uso atual do Conformance na a0: lá se alinha tudo e se usa **um** trace (o de menor
fitness). Aqui a unidade é a **população**: por atividade, a taxa de movimentos de log (executou fora
do modelo) e de modelo (era esperada e não executou), contra a mesma taxa nos traces normais
alinhados ao mesmo modelo.

Independência: o modelo é descoberto **aqui**, dos traces normais, e guardado no artefato
da d1. `process_models` entra só como utilitário (descoberta IMf e PNML); `conformance.py` da a0 não é
importado.

Tempo (decisão de 2026-10-03): a duração própria nos movimentos síncronos é testada com
uma observação por janela (`est.predicao_log`), pelo mesmo motivo medido na d2: traço a
traço, a deriva normal entre janelas de 5 min vira p < 1e-20.
"""
from __future__ import annotations

import datetime
import random
from collections import Counter, defaultdict
from collections.abc import Sequence
from typing import Any

from src.application.stage3 import process_models
from src.application.stage3.abordagens import calibracao as _calibracao
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d1"
VERSAO = "d1-v1"

DEFAULT_CFG: dict[str, Any] = {
    "min_traces_modelo": 30,
    "max_traces_endpoint": 2000,
    "min_oportunidades": 20,
    "min_traces": 30,
    "tamanho_janela_seg": 300,
    "noise_threshold": 0.2,  # o mesmo IMf da baseline de processo (process_models.discover_petri_net)
    "max_align_seg": 10,     # teto por variante; variante que estoura conta como não alinhada
}
MIN_OCORRENCIAS_JANELA = 5
_SEM_MOVIMENTO = ">>"
SEMENTE = 42


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


# --- alinhamento (pm4py direto; nada da a0) ---


def _alinhar(atividades: Sequence[str], modelo: Any, max_seg: float) -> tuple[float, list[tuple[str, Any]]] | None:
    from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments
    from pm4py.objects.log.obj import Event, Trace

    net, im, fm = modelo
    resultado = alignments.apply_trace(
        Trace([Event({"concept:name": a}) for a in atividades]), net, im, fm,
        parameters={"max_align_time_trace": max_seg},
    )
    if not resultado or resultado.get("alignment") is None:
        return None
    return float(resultado.get("fitness") or 0.0), [(str(lg), md) for lg, md in resultado["alignment"]]


def _movimentos(
    ordenados: list[Any], alinhamento: list[tuple[str, Any]]
) -> tuple[list[tuple[Any, str]], list[str]]:
    """`[(evento, 'sync'|'log')]` na ordem do trace e a lista de rótulos só-de-modelo (visíveis)."""
    eventos: list[tuple[Any, str]] = []
    so_modelo: list[str] = []
    cursor = 0
    for rotulo_log, rotulo_modelo in alinhamento:
        if rotulo_log != _SEM_MOVIMENTO:
            if cursor < len(ordenados):
                eventos.append((ordenados[cursor], "log" if rotulo_modelo == _SEM_MOVIMENTO else "sync"))
            cursor += 1
        elif rotulo_modelo is not None and rotulo_modelo != _SEM_MOVIMENTO:
            so_modelo.append(str(rotulo_modelo))
    return eventos, so_modelo


def contar(
    sequencias: list[list[Any]], modelo: Any, cfg: dict[str, Any],
    cache: dict[tuple[str, ...], Any] | None = None,
) -> dict[str, Any]:
    """Contagens de desalinhamento de uma população de traces contra um modelo.

    Por atividade `x`: `ocorrencias` (eventos de `x` no log), `log` (desses, quantos vieram como
    movimento de log), `oportunidades` (vezes em que o modelo esperou `x`: síncronos + só-modelo),
    `modelo` (desses, só-modelo). Mais as durações próprias síncronas com o instante do trace, os
    serviços-pai dos movimentos de log e, para os só-modelo, se o serviço de `x` sumiu do trace.
    """
    cache = {} if cache is None else cache
    ocorrencias: Counter[str] = Counter()
    mov_log: Counter[str] = Counter()
    oportunidades: Counter[str] = Counter()
    mov_modelo: Counter[str] = Counter()
    duracoes: dict[str, list[tuple[int, float]]] = defaultdict(list)
    pais_log: dict[str, Counter[str]] = defaultdict(Counter)
    pais_obs: dict[str, Counter[str]] = defaultdict(Counter)
    servico_de: dict[str, Counter[str]] = defaultdict(Counter)
    sumiu: dict[str, Counter[bool]] = defaultdict(Counter)
    fitness: list[float] = []
    nao_alinhados = 0
    for sequencia in sequencias:
        ordenados = proc.ordenar(sequencia)
        chave = tuple(str(e.activity) for e in ordenados)
        if chave not in cache:
            cache[chave] = _alinhar(chave, modelo, float(cfg["max_align_seg"]))
        alinhado = cache[chave]
        if alinhado is None:
            nao_alinhados += 1
            continue
        fit, alinhamento = alinhado
        fitness.append(fit)
        inicio = min(int(e.start_us) for e in ordenados)
        servicos_no_trace = {proc.servico_da_atividade(str(e.activity)) for e in ordenados}
        eventos, so_modelo = _movimentos(ordenados, alinhamento)
        for evento, tipo in eventos:
            x = str(evento.activity)
            servico_de[x][str(evento.service)] += 1
            pai = proc.pai_de(evento, ordenados)
            servico_pai = str(pai.service) if pai is not None else ""
            pais_obs[x][servico_pai] += 1
            ocorrencias[x] += 1
            if tipo == "log":
                mov_log[x] += 1
                pais_log[x][servico_pai] += 1
            else:
                oportunidades[x] += 1
                duracao = proc.duracao_propria(evento, ordenados)
                if duracao:
                    duracoes[x].append((inicio, float(duracao)))
        for x in so_modelo:
            oportunidades[x] += 1
            mov_modelo[x] += 1
            # "o serviço de x não aparece em nenhum outro ponto do trace"
            sumiu[x][proc.servico_da_atividade(x) not in servicos_no_trace] += 1
    return {
        "n_traces": len(sequencias) - nao_alinhados, "nao_alinhados": nao_alinhados,
        "ocorrencias": dict(ocorrencias), "log": dict(mov_log),
        "oportunidades": dict(oportunidades), "modelo": dict(mov_modelo),
        "duracoes": {x: v for x, v in duracoes.items()},
        "pais_log": {x: dict(c) for x, c in pais_log.items()},
        "pais_obs": {x: dict(c) for x, c in pais_obs.items()},
        "servico_de": {x: c.most_common(1)[0][0] for x, c in servico_de.items()},
        "sumiu": {x: {"sim": c[True], "nao": c[False]} for x, c in sumiu.items()},
        "fitness": fitness,
    }


# --- artefato ---


def _amostra(traces: dict[str, list[Any]], maximo: int) -> list[list[Any]]:
    sequencias = [traces[k] for k in sorted(traces)]
    if len(sequencias) > maximo:
        sequencias = random.Random(SEMENTE).sample(sequencias, maximo)
    return sequencias


def construir_artefato(traces_normais: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Modelo por endpoint (IMf) + contagens do normal alinhado ao próprio modelo. Sem calibração."""
    cfg = _cfg(cfg)
    tamanho_us = int(float(cfg["tamanho_janela_seg"]) * 1e6)
    endpoints: dict[str, Any] = {}
    for endpoint, traces in proc.sequencias_por_endpoint(traces_normais).items():
        if len(traces) < int(cfg["min_traces_modelo"]):
            continue
        sequencias = _amostra(traces, int(cfg["max_traces_endpoint"]))
        atividades = [[str(e.activity) for e in proc.ordenar(s)] for s in sequencias]
        modelo = process_models.discover_petri_net(atividades, float(cfg["noise_threshold"]))
        contagem = contar(sequencias, modelo, cfg)
        inicios = [min(int(e.start_us) for e in s) for s in sequencias if s]
        janelas = {
            x: est.medianas_por_janela(pares, tamanho_us, minimo=MIN_OCORRENCIAS_JANELA,
                                       inicio_us=min(inicios), fim_us=max(inicios))
            for x, pares in contagem.pop("duracoes").items()
        }
        endpoints[endpoint] = {
            "pnml": process_models.serialize_petri_net(*modelo),
            "contagem": contagem,
            "duracao_janelas": {x: m for x, m in janelas.items() if m},
            "fitness_quantis": est.quantis(contagem["fitness"], [5, 25, 50, 75, 95])
            if contagem["fitness"] else [],
        }
    return {"modo": NOME, "versao": VERSAO, "endpoints": endpoints, "semente": SEMENTE}


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    artefato = construir_artefato(traces_normais, cfg)
    if not janelas:
        janelas = _calibracao.janelas_de_normal(
            traces_normais, datetime.timedelta(seconds=float(cfg["tamanho_janela_seg"])))
    artefato["calibracao"] = _calibracao.calibrar_cruzado(
        lambda fora: construir_artefato(fora, cfg), decidir, traces_normais, list(janelas), cfg,
        fp_alvo=float(cfg.get("fp_alvo") or 0.05),
    )
    return artefato


# --- decisão ---


def _taxa_g(a_ev: int, a_tot: int, n_ev: int, n_tot: int) -> tuple[float, float]:
    """G 2×2 unilateral (incidente maior) e o efeito (diferença de taxas)."""
    g = est.g_2x2(a_ev, a_tot - a_ev, n_ev, n_tot - n_ev, alternative="greater")
    efeito = a_ev / max(1, a_tot) - n_ev / max(1, n_tot)
    return g.p, efeito


def _testes_endpoint(endpoint: str, inc: dict[str, Any], nor: dict[str, Any],
                     janelas_nor: dict[str, list[float]], cfg: dict[str, Any]) -> list[dict[str, Any]]:
    minimo = int(cfg["min_oportunidades"])
    testes: list[dict[str, Any]] = []
    total_ocorr_nor = sum(nor["ocorrencias"].values())
    total_log_nor = sum(nor["log"].values())
    total_oport_nor = sum(nor["oportunidades"].values())
    total_mod_nor = sum(nor["modelo"].values())
    for x in sorted(set(inc["ocorrencias"]) | set(inc["oportunidades"])):
        # fluxo — movimento de log: referência da atividade, ou do endpoint se ela é rara no normal
        ocorr = int(inc["ocorrencias"].get(x, 0))
        if ocorr >= minimo:
            ref_ev, ref_tot = int(nor["log"].get(x, 0)), int(nor["ocorrencias"].get(x, 0))
            if ref_tot < minimo:
                ref_ev, ref_tot = total_log_nor, total_ocorr_nor
            p, efeito = _taxa_g(int(inc["log"].get(x, 0)), ocorr, ref_ev, ref_tot)
            testes.append({"tipo": "movimento_log", "elemento": x, "endpoint": endpoint, "p": p,
                           "efeito": efeito, "observado": int(inc["log"].get(x, 0)), "de": ocorr,
                           "esperado": ref_ev / max(1, ref_tot) * ocorr})
        oport = int(inc["oportunidades"].get(x, 0))
        if oport >= minimo:
            ref_ev, ref_tot = int(nor["modelo"].get(x, 0)), int(nor["oportunidades"].get(x, 0))
            if ref_tot < minimo:
                ref_ev, ref_tot = total_mod_nor, total_oport_nor
            p, efeito = _taxa_g(int(inc["modelo"].get(x, 0)), oport, ref_ev, ref_tot)
            testes.append({"tipo": "movimento_modelo", "elemento": x, "endpoint": endpoint, "p": p,
                           "efeito": efeito, "observado": int(inc["modelo"].get(x, 0)), "de": oport,
                           "esperado": ref_ev / max(1, ref_tot) * oport})
        # tempo — mediana síncrona do incidente contra as medianas por janela do normal
        duracoes = [v for _, v in inc["duracoes"].get(x, [])]
        if len(duracoes) >= MIN_OCORRENCIAS_JANELA:
            r = est.predicao_log(est.mediana(duracoes), janelas_nor.get(x) or [], alternative="greater")
            if r is not None:
                testes.append({"tipo": "tempo", "elemento": x, "endpoint": endpoint, "p": r.p,
                               "efeito": float(r.estatistica or 0.0), "mediana_inc": est.mediana(duracoes),
                               "mediana_nor": est.mediana(janelas_nor.get(x) or [0.0]), "n_janelas_nor": r.n})
    return testes


def _mais_comum(contagem: dict[str, int]) -> str:
    return sorted(contagem.items(), key=lambda kv: (-kv[1], kv[0]))[0][0] if contagem else ""


def _atribuir(teste: dict[str, Any], inc: dict[str, Any], nor: dict[str, Any]) -> list[str]:
    """Regras fixas do modo (texto final)."""
    x = teste["elemento"]
    servico_x = inc["servico_de"].get(x) or nor["servico_de"].get(x) or proc.servico_da_atividade(x)
    if teste["tipo"] == "tempo":
        return [servico_x]
    if teste["tipo"] == "movimento_log":
        return [_mais_comum(inc["pais_log"].get(x, {})) or servico_x]
    # movimento de modelo: o serviço de x se ele sumiu do trace; senão quem deixou de chamar
    sumiu = inc["sumiu"].get(x, {})
    if sumiu.get("sim", 0) > sumiu.get("nao", 0):
        return [servico_x]
    pai = _mais_comum(nor["pais_obs"].get(x, {})) or _mais_comum(inc["pais_obs"].get(x, {}))
    return [pai or servico_x]


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    q = _calibracao.q_do_artefato(artefato, cfg)
    parametros = {"q": q, "fp_alvo": (artefato.get("calibracao") or {}).get("fp_alvo"),
                  "min_oportunidades": cfg["min_oportunidades"]}
    modelos = artefato.get("endpoints") or {}
    if not modelos:
        return Decisao(status="absteve", motivo_abstencao="sem_modelo", versao=VERSAO, parametros=parametros)

    por_endpoint = proc.sequencias_por_endpoint(entrada.traces)
    com_modelo = [ep for ep in por_endpoint if ep in modelos]
    if not com_modelo:
        return Decisao(status="absteve", motivo_abstencao="sem_modelo", versao=VERSAO, parametros=parametros,
                       evidencias={"endpoints_incidente": sorted(por_endpoint)})

    testes: list[dict[str, Any]] = []
    contagens: dict[str, dict[str, Any]] = {}
    n_alinhados = 0
    fitness_inc: list[float] = []
    for endpoint in com_modelo:
        nor = modelos[endpoint]
        modelo = process_models.deserialize_petri_net(nor["pnml"])
        inc = contar(_amostra(por_endpoint[endpoint], int(cfg["max_traces_endpoint"])), modelo, cfg)
        contagens[endpoint] = inc
        n_alinhados += int(inc["n_traces"])
        fitness_inc.extend(inc["fitness"])
        testes.extend(_testes_endpoint(endpoint, inc, nor["contagem"], nor.get("duracao_janelas") or {}, cfg))

    if n_alinhados < int(cfg["min_traces"]):
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_alinhados": n_alinhados}, parametros=parametros)
    if not testes:
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", versao=VERSAO,
                       evidencias={"n_testes": 0, "n_alinhados": n_alinhados}, parametros=parametros)

    ajustados, significativos = est.benjamini_hochberg([t["p"] for t in testes], q)
    p_min_ajustado = min(ajustados)
    for teste, p_adj, sig in zip(testes, ajustados, significativos):
        teste["p_ajustado"] = p_adj
        teste["significante"] = sig
    evidencias: dict[str, Any] = {
        "n_testes": len(testes), "p_min_ajustado": p_min_ajustado, "n_alinhados": n_alinhados,
        "endpoints": com_modelo,
        "fitness_incidente": est.quantis(fitness_inc, [5, 25, 50]) if fitness_inc else [],
        "fitness_normal": {ep: modelos[ep].get("fitness_quantis") for ep in com_modelo},
    }
    if not any(significativos):
        evidencias["testes"] = sorted(testes, key=lambda t: t["p"])[:20]
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)

    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for teste in testes:
        if not teste["significante"]:
            continue
        ep = teste["endpoint"]
        for servico in _atribuir(teste, contagens[ep], modelos[ep]["contagem"]):
            if servico:
                por_servico[servico].append({**teste, "servico_creditado": servico})

    ranking = []
    for servico, itens in por_servico.items():
        p_comb = est.fisher([i["p_ajustado"] for i in itens])
        efeito = max(abs(float(i.get("efeito") or 0.0)) for i in itens)
        ranking.append((p_comb, -efeito, servico, itens))
    ranking.sort(key=lambda r: (r[0], r[1], r[2]))
    evidencias["n_significativos"] = int(sum(significativos))
    return Decisao(
        status="decidiu",
        ranking=[ItemRanking(servico=s, escore=p, p_valor=p,
                             evidencias={"n_testes": len(itens), "efeito_max": -e,
                                         "itens": sorted(itens, key=lambda i: (i["p_ajustado"], i["tipo"]))[:10]})
                 for p, e, s, itens in ranking],
        evidencias=evidencias, parametros=parametros, versao=VERSAO,
    )


class _ModoD1:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD1()
