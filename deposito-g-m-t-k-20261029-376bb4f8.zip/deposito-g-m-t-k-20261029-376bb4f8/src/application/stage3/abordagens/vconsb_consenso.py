"""v-cons-b — consenso por votos entre d9-k, a0-b e d6 (PROTOCOLO-CONSENSO.md §4).

Solução definitiva do Stage 3 (decisão de 14/10/2026), junto com a d9-k. É o v-cons
com a **a0-b** (calibrada só pela baseline) no lugar da a0-p, cujos votos tinham constantes tiradas de falhas.

- **Portão** = o da d9-k (d9 ou evento K8s de sintoma). Com o portão fechado o modo se abstém; o ranking do voto
  vai mesmo assim em `evidencias["ranking_forcado"]` (leitura "sabendo que é falha"; `forcar=True` o devolve).
- **Votantes** (cada um com o ranking **forçado**, top-3):
  - d9-k — `evidencias["ranking_forcado"]`;
  - a0-b — o ranking ao `alpha` 0,05; se abstiver, ao `alpha` 1; com o 1º já persistido (n = 5) sobre os 1ºs
    brutos da a0-b, como o votante `a0-b-p` avaliado (`a0b_analise.py`) — a persistência do voto vem por cima;
  - d6 — sobre a d2c com o artefato do `fp_alvo` 0,20; se a d6 não decidir, sobre a d2c com `q` = 1.
- **Persistência** (n = 5): o 1º de cada votante é o mais frequente entre os 1ºs dele nos últimos n instantes do
  mesmo incidente, incluindo o atual (empate: o mais recente). O histórico entra por `cfg["historico"]`
  (`{votante: [1º mais antigo, ..., 1º mais recente]}`, `None` no instante em que o votante não votou);
  `ConsensoVConsB` guarda isso entre chamadas. No avaliador os instantes eram espaçados de 60 s.
- **Voto**: Borda no top-3 (3, 2, 1) × peso do votante. Pesos por confiabilidade, `logit(acerto) + 1` (piso 0,1),
  com o acerto top-1 sabendo que é falha de cada votante nos tipos de dev (f + h). Fixados aqui: não se recalibram
  em produção.
- **Desempate**, em ordem: serviço com evento K8s de sintoma; mais vezes 1º na persistência; mais votantes com o
  serviço no top-3; ordem da d9-k; ordem de aparição percorrendo d6, d9-k, a0-b (`ORDEM_APARICAO`).
- **Confiança** = margem da Borda (1º − 2º) / total; faixas pelos tercis da margem nos instantes estáveis de dev.

Nenhum arquivo dos votantes muda: este módulo só os chama.
"""
from __future__ import annotations

import copy
from collections import Counter, deque
from typing import Any

from src.application.stage3.abordagens import a0b_baseline as a0b
from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "v-cons-b"
VERSAO = "v-cons-b-v1"

VOTANTES = ("d9-k", "a0-b", "d6")
# Último desempate (empate exato depois dos quatro critérios; a0-b e d6 têm o mesmo peso): a ordem em que os
# serviços aparecem percorrendo os votantes nesta ordem — a da avaliação offline, agora explícita.
ORDEM_APARICAO = ("d6", "d9-k", "a0-b")

DEFAULT_CFG: dict[str, Any] = {
    "n_persistencia": 5,
    "n_persistencia_a0b": 5,     # a0-b-p: persistência própria do votante a0-b, antes da do voto
    # logit(acerto top-1 sabendo que é falha, dev) + 1 — consenso.py `_pesos_conf`, base limpa de 14/10/2026
    "pesos": {"d9-k": 1.4842, "a0-b": 0.9500, "d6": 0.9500},
    # tercis da margem da Borda nos estáveis de dev (baixa < 1º corte ≤ média < 2º corte ≤ alta)
    "cortes_confianca": [0.1462, 0.2808],
    "top_k": 3,
    "forcar": False,
    "historico": None,
    "historico_a0b_bruto": None,
    "cfg_d9k": {},
    "cfg_a0b": {},
    "cfg_d6": {"atenuacao": 1.0, "dependencias_sem_span": {"mysql": "teastore-db"}},
    # artefato da d6 como o avaliado (`-w120`, q do fp 0,20): janelas normais de 120 s
    "preparo_d6": {"tamanho_janela_seg": 120, "fp_alvo": 0.20},
}

MOTIVOS: dict[str, str] = {**d9k.MOTIVOS}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _sistema(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, Any]:
    """O que todo votante recebe do sistema (serviços de entrada), sob a cfg própria dele."""
    entradas = cfg.get("entry_services") or (entrada.config_sistema or {}).get("entry_services")
    return {"entry_services": entradas} if entradas else {}


def _nomes(d: Decisao, top_k: int) -> list[str]:
    return [i.servico for i in d.ranking][:top_k]


def votos(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Ranking forçado de cada votante (top-k), o portão e o serviço K8s da d9-k."""
    top_k = int(cfg["top_k"])
    base = _sistema(entrada, cfg)
    saida: dict[str, Any] = {"rankings": {}, "falhas": {}}
    try:
        dk = d9k.decidir(entrada, {}, {**base, **cfg["cfg_d9k"], "top_k": top_k, "forcar": False})
        saida["rankings"]["d9-k"] = list(dk.evidencias.get("ranking_forcado") or [])[:top_k]
        saida["aberto"], saida["k8s"] = dk.status == "decidiu", dk.evidencias.get("k8s_sintoma")
        saida["motivo"] = dk.motivo_abstencao
    except Exception as exc:  # noqa: BLE001 - sem a d9-k não há portão: o modo falha
        saida["falhas"]["d9-k"] = f"{type(exc).__name__}: {exc}"[:200]
        saida["aberto"], saida["k8s"], saida["rankings"]["d9-k"] = None, None, []
    try:
        art_a0b = (artefato or {}).get("a0-b") or {}
        cfg_a0b = {**base, **cfg["cfg_a0b"]}
        da = a0b.decidir(entrada, art_a0b, cfg_a0b)
        if da.status != "decidiu" or not da.ranking:
            da = a0b.decidir(entrada, art_a0b, {**cfg_a0b, "alpha": 1.0})
        bruto = _nomes(da, top_k)
        n = int(cfg["n_persistencia_a0b"])
        anteriores = list(cfg.get("historico_a0b_bruto") or [])[-(n - 1):] if n > 1 else []
        pf = persistir([s for s in anteriores if s] + bruto[:1])
        saida["a0b_bruto"] = bruto
        saida["rankings"]["a0-b"] = ([pf] + [s for s in bruto if s != pf])[:top_k] if pf else bruto
    except Exception as exc:  # noqa: BLE001 - votante quebrado vota vazio
        saida["falhas"]["a0-b"], saida["rankings"]["a0-b"] = f"{type(exc).__name__}: {exc}"[:200], []
        saida["a0b_bruto"] = []
    try:
        art_d6 = (artefato or {}).get("d6") or {}
        cfg_d6 = {**base, **cfg["cfg_d6"]}
        dd = d6.decidir_de_base(d2c.decidir(entrada, art_d6, cfg_d6), entrada, art_d6, cfg_d6)
        if dd.status != "decidiu":
            permissivo = copy.deepcopy(art_d6)
            permissivo.setdefault("calibracao", {})["q"] = 1.0
            dd = d6.decidir_de_base(d2c.decidir(entrada, permissivo, cfg_d6), entrada, permissivo, cfg_d6)
        saida["rankings"]["d6"] = _nomes(dd, top_k)
    except Exception as exc:  # noqa: BLE001
        saida["falhas"]["d6"], saida["rankings"]["d6"] = f"{type(exc).__name__}: {exc}"[:200], []
    return saida


def persistir(primeiros: list[str]) -> str | None:
    """O mais frequente da janela de 1ºs (empate: o mais recente)."""
    if not primeiros:
        return None
    cont = Counter(primeiros)
    mx = max(cont.values())
    return next(s for s in reversed(primeiros) if cont[s] == mx)


def votar(rankings: dict[str, list[str]], historico: dict[str, list[str | None]] | None, k8s: str | None,
          cfg: dict[str, Any]) -> dict[str, Any]:
    """Borda ponderada com o 1º persistido. `historico` não inclui o instante atual."""
    n = int(cfg["n_persistencia"])
    pesos, top_k = cfg["pesos"], int(cfg["top_k"])
    escore: dict[str, float] = {}
    persist: Counter[str] = Counter()
    n_vot: Counter[str] = Counter()
    efetivos: dict[str, list[str]] = {}
    ordem_v = [v for v in ORDEM_APARICAO if v in rankings] + [v for v in rankings if v not in ORDEM_APARICAO]
    for v in ordem_v:
        rk = rankings[v]
        anteriores = list((historico or {}).get(v) or [])[-(n - 1):] if n > 1 else []
        jan = [s for s in anteriores if s] + (rk[:1] if rk else [])   # instante sem voto ocupa a vaga
        pf = persistir(jan)
        rk_v = ([pf] + [s for s in rk if s != pf])[:top_k] if pf else rk[:top_k]
        efetivos[v] = rk_v
        for i, s in enumerate(rk_v):
            escore[s] = escore.get(s, 0.0) + (top_k - i) * float(pesos.get(v, 1.0))
            n_vot[s] += 1
        for s in jan:
            persist[s] += 1
    ordem_d9k = efetivos.get("d9-k") or []

    def chave(s: str) -> tuple[float, bool, int, int, int]:
        return (escore[s], s == k8s, persist[s], n_vot[s], -(ordem_d9k.index(s) if s in ordem_d9k else 9))

    ordem = sorted(escore, key=chave, reverse=True)   # estável: empate total fica na ordem de aparição
    total = sum(escore.values())
    margem = (escore[ordem[0]] - (escore[ordem[1]] if len(ordem) > 1 else 0.0)) / total if total else 0.0
    baixo, alto = cfg["cortes_confianca"]
    faixa = "baixa" if margem < baixo else ("media" if margem < alto else "alta")
    return {"ordem": ordem[:top_k], "escore": dict(escore), "margem": margem, "confianca": faixa,
            "votos_efetivos": efetivos}


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    parametros = {k: cfg[k] for k in ("n_persistencia", "pesos", "top_k", "forcar")}
    vs = votos(entrada, artefato, cfg)
    if vs["aberto"] is None:
        return Decisao(status="falhou", evidencias={"falhas": vs["falhas"]}, parametros=parametros, versao=VERSAO)
    v = votar(vs["rankings"], cfg.get("historico"), vs["k8s"], cfg)
    evidencias = {"ranking_forcado": v["ordem"], "votos": vs["rankings"], "a0b_bruto": vs.get("a0b_bruto", []),
                  "votos_efetivos": v["votos_efetivos"],
                  "borda": v["escore"], "margem": v["margem"], "confianca": v["confianca"], "k8s_sintoma": vs["k8s"],
                  "portao_d9k": vs["aberto"], "falhas": vs["falhas"]}
    if not (vs["aberto"] or cfg["forcar"]) or not v["ordem"]:
        return Decisao(status="absteve", motivo_abstencao=vs["motivo"] or "portao_fechado", evidencias=evidencias,
                       parametros=parametros, versao=VERSAO)
    ranking = [ItemRanking(servico=s, escore=-float(v["escore"][s]),
                           evidencias={"borda": v["escore"][s], "k8s_sintoma": s == vs["k8s"]})
               for s in v["ordem"]]
    return Decisao(status="decidiu", ranking=ranking, evidencias=evidencias, parametros=parametros, versao=VERSAO)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Os artefatos dos votantes que têm baseline: a0-b e d6 (janelas de 120 s, `fp_alvo` 0,20). A d9-k não tem."""
    cfg = _cfg(cfg)
    base = {k: v for k, v in cfg.items() if k == "entry_services"}
    return {"modo": NOME, "versao": VERSAO,
            "a0-b": a0b.preparar_baseline(traces_normais, janelas, {**base, **cfg["cfg_a0b"]}),
            "d6": d6.preparar_baseline(traces_normais, janelas, {**base, **cfg["cfg_d6"], **cfg["preparo_d6"]})}


class ConsensoVConsB:
    """O v-cons-b com memória: um objeto por incidente, chamado a cada instante em ordem de tempo.

    Guarda os 1ºs forçados dos votantes dos últimos `n_persistencia − 1` instantes (`historico`) e os 1ºs brutos
    da a0-b (`historico_a0b_bruto`), e os passa a cada chamada.
    """

    def __init__(self, artefato: dict[str, Any], cfg: dict[str, Any] | None = None) -> None:
        self.artefato = artefato
        self.cfg = _cfg(cfg)
        n = max(1, int(self.cfg["n_persistencia"]) - 1)
        self._hist: dict[str, deque[str | None]] = {v: deque(maxlen=n) for v in VOTANTES}
        self._hist_a0b: deque[str | None] = deque(maxlen=max(1, int(self.cfg["n_persistencia_a0b"]) - 1))

    def decidir(self, entrada: EntradaIncidente) -> Decisao:
        historico = {v: list(h) for v, h in self._hist.items()}
        d = decidir(entrada, self.artefato, {**self.cfg, "historico": historico,
                                             "historico_a0b_bruto": list(self._hist_a0b)})
        votos_ = d.evidencias.get("votos") or {}
        for v, h in self._hist.items():
            rk = votos_.get(v) or []
            h.append(rk[0] if rk else None)
        bruto = d.evidencias.get("a0b_bruto") or []
        self._hist_a0b.append(bruto[0] if bruto else None)
        return d


class _ModoVConsB:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoVConsB()
