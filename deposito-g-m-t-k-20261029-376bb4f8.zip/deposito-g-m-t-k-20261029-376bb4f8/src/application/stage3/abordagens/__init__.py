"""Modos de decisão do Stage 3.

`a0` é a localização legada, congelada, exposta pelo adaptador `a0.py`. `d1`–`d4` são modos
independentes que usam só traces. `d0_nula` não decide nada e existe para exercitar o caminho
inteiro. Utilitário sem decisão vive em `base.py` e `processo.py`.
"""

from src.application.stage3.abordagens.base import (
    MODOS_ABSTAIN,
    Decisao,
    EntradaIncidente,
    ItemRanking,
    Modo,
)

__all__ = ["MODOS_ABSTAIN", "Decisao", "EntradaIncidente", "ItemRanking", "Modo"]
