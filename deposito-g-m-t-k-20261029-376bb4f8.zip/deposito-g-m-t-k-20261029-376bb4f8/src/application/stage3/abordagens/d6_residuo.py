"""d6 — localização por resíduo dado os filhos.

Ideia 4 do dossiê (Budhathoki: ruído próprio dado os pais; codificação preditiva: só o resíduo sobe;
MYT: termo condicional). **Mesma decisão e mesmo `q` da d2c**: os testes, o BH e a atribuição das versões `c`
são reaproveitados chamando a função da d2c como utilitário (nenhum resultado gravado de outro modo é
lido). Muda **só o ranking**:

1. **Resíduo dado os descendentes.** A força intrínseca de cada serviço é atenuada pela maior força intrínseca
   entre os seus descendentes no grafo de chamadas da janela: `max(0, f − α·max_desc)` (v1). Um pai
   lento só porque o filho ficou lento perde a evidência intrínseca; o filho fica com ela. O banco (sem span)
   entra no grafo como filho de quem tem span cliente de banco (`dependencias_sem_span`).
2. **Ausência.** Serviço que aparece nas relações do normal (artefato) e não aparece em nenhum trace da
   janela "sumiu": recebe evidência intrínseca com a maior força da janela.

Ordem final como em `causal.ranquear` (intrínseco residual > 0 antes; maior força; nome só apresenta).
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d6"
VERSAO = "d6-v1"

DEFAULT_CFG: dict[str, Any] = {**d2c.DEFAULT_CFG, "atenuacao": 1.0}

MOTIVOS = {"sem_residuo_atribuivel": "todos os desvios foram explicados pelos filhos (propagação pura)"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def grafo_de_servicos(eventos: list[Any], dependencias: dict[str, str]) -> dict[str, set[str]]:
    """`{serviço: filhos}` da janela, com o banco como filho de quem tem span cliente de banco."""
    filhos: dict[str, set[str]] = defaultdict(set)
    for origem, destino in proc.arestas_de_chamada(eventos):
        if origem != destino:
            filhos[origem].add(destino)
    for evento in eventos:
        alvo = dependencias.get(str(getattr(evento, "activity", "") or ""))
        servico = str(getattr(evento, "service", "") or "")
        if alvo and servico and alvo != servico:
            filhos[servico].add(alvo)
    return filhos


def _descendentes(servico: str, filhos: dict[str, set[str]]) -> set[str]:
    vistos: set[str] = set()
    pilha = list(filhos.get(servico, ()))
    while pilha:
        x = pilha.pop()
        if x not in vistos and x != servico:
            vistos.add(x)
            pilha.extend(filhos.get(x, ()))
    return vistos


def servicos_do_normal(artefato: dict[str, Any]) -> set[str]:
    """Nomes curtos dos serviços que aparecem nas relações do normal (artefato da d2)."""
    curtos: set[str] = set()
    for nor in (artefato.get("endpoints") or {}).values():
        for rel in ((nor.get("medidas") or {}).get("contagem_rel") or {}):
            for lado in rel.split(" -> "):
                curtos.add(proc.servico_da_atividade(lado))
    return {c for c in curtos if c}


def reordenar(ranking: list[ItemRanking], filhos: dict[str, set[str]], sumidos: list[str],
              alfa: float) -> list[dict[str, Any]]:
    """Linhas `{servico, fi, fc, fi_residual, ...}` na nova ordem."""
    linhas = {i.servico: {"servico": i.servico,
                          "fi": float(i.evidencias.get("forca_intrinseca") or 0.0),
                          "fc": float(i.evidencias.get("forca_comportamental") or 0.0),
                          "itens": i.evidencias.get("itens") or []} for i in ranking}
    maior = max([lin["fi"] for lin in linhas.values()] + [lin["fc"] for lin in linhas.values()] + [0.0])
    for servico in sumidos:
        lin = linhas.setdefault(servico, {"servico": servico, "fi": 0.0, "fc": 0.0, "itens": []})
        lin["fi"] = max(lin["fi"], maior or causal.FORCA_MAXIMA)
        lin["sumiu"] = True
    for lin in linhas.values():
        desc = _descendentes(lin["servico"], filhos)
        max_desc = max((linhas[d]["fi"] for d in desc if d in linhas), default=0.0)
        lin["max_intrinseca_descendentes"] = max_desc
        lin["fi_residual"] = max(0.0, lin["fi"] - alfa * max_desc)
    return sorted(linhas.values(), key=lambda lin: (lin["fi_residual"] <= 0, -lin["fi_residual"],
                                                    -lin["fc"], lin["servico"]))


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    return decidir_de_base(d2c.decidir(entrada, artefato, cfg), entrada, artefato, cfg)


def decidir_de_base(base: Decisao, entrada: EntradaIncidente, artefato: dict[str, Any],
                    cfg: dict[str, Any]) -> Decisao:
    """A regra sobre a decisão da d2c já calculada (o avaliador calcula a d2c uma vez por instante)."""
    cfg = _cfg(cfg)
    parametros = {**base.parametros, "atenuacao": float(cfg["atenuacao"])}
    if base.status != "decidiu":
        return Decisao(status=base.status, motivo_abstencao=base.motivo_abstencao, evidencias=base.evidencias,
                       parametros=parametros, versao=VERSAO)
    dependencias = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    filhos = grafo_de_servicos(entrada.traces, dependencias)
    nomes = {**((artefato or {}).get("servicos") or {}), **d2c.d2.nomes_de_servico(entrada.traces)}
    presentes = {str(getattr(e, "service", "") or "") for e in entrada.traces}
    sumidos = sorted({nomes.get(c, c) for c in servicos_do_normal(artefato or {})} - presentes - {""})
    linhas = reordenar(base.ranking, filhos, sumidos, float(cfg["atenuacao"]))
    if not any(lin["fi_residual"] > 0 or lin["fc"] > 0 for lin in linhas):
        return Decisao(status="absteve", motivo_abstencao="sem_residuo_atribuivel", evidencias=base.evidencias,
                       parametros=parametros, versao=VERSAO)
    chave = [(lin["fi_residual"] <= 0, -lin["fi_residual"], -lin["fc"]) for lin in linhas]
    ranking = []
    for pos, lin in enumerate(linhas):
        escore = lin["fi_residual"] if lin["fi_residual"] > 0 else lin["fc"]
        ranking.append(ItemRanking(
            servico=lin["servico"], escore=escore, p_valor=10.0 ** (-min(escore, 300.0)),
            evidencias={"forca_intrinseca": lin["fi"], "forca_intrinseca_residual": lin["fi_residual"],
                        "explicado_por_descendentes": lin["max_intrinseca_descendentes"],
                        "forca_comportamental": lin["fc"], "sumiu": bool(lin.get("sumiu")),
                        "empate_com_seguinte": pos + 1 < len(linhas) and chave[pos + 1] == chave[pos],
                        "itens": lin["itens"][:10]}))
    return Decisao(status="decidiu", ranking=ranking, evidencias={**base.evidencias, "sumidos": sumidos},
                   parametros=parametros, versao=VERSAO)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """O artefato da d2c (mesmos testes, mesmo `q`), com a identidade da d6."""
    artefato = d2c.preparar_baseline(traces_normais, janelas, _cfg(cfg))
    return {**artefato, "modo": NOME, "versao": VERSAO}


class _ModoD6:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD6()
