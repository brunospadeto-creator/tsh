"""a0-b — a localização por evidência da a0, calibrada **só pela baseline normal**.

A a0 soma votos com pesos e limiares fixos (+2/+1, 60%, 15 req/min, ≥ 3 atividades, ≥ 50%, `anomaly_k` = 3)
desenhados olhando falhas do catálogo f. Aqui cada voto vira um teste contra a distribuição das janelas da
coleção normal, e o único parâmetro é o nível de significância `alpha` — nenhuma constante vem de falha.

Canais por serviço (z robusto contra as janelas normais, `σ = max(1,4826·MAD, desvio-padrão)`):

- `erro` — fração de spans do serviço com erro (maior);
- `latencia` — log da mediana de duração dos spans do serviço (maior);
- `volume` — spans do serviço por requisição de entrada (bilateral);
- `descoberta` — consultas ao serviço de descoberta que nomeiam o serviço, por requisição de entrada (maior);
- `ausente` — atividades do serviço presentes no normal e ausentes na janela: `p = exp(−n·f)`, Bonferroni;
- `entrada` — requisições de entrada por segundo, atribuída ao serviço de entrada (menor);
- `k8s` — eventos do Kubernetes **de sintoma** contra a referência da sessão (teste da a0-k);
- `metrica` — z robusto de cada métrica do serviço contra a baseline, quando a entrada traz métricas.

Spans cliente de banco (`db.system` em `dependencias_sem_span`) são creditados ao serviço da dependência.
Fisher dos canais por serviço; Benjamini–Hochberg entre serviços; decide se algum é significativo. Ranking pela
força (−log10 p) descontada do maior descendente no grafo de chamadas (resíduo, como a a0-d).
"""
from __future__ import annotations

import math
import re
import statistics
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import a0k_k8s as a0k
from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "a0-b"
VERSAO = "a0-b-v1"

DEFAULT_CFG: dict[str, Any] = {
    "alpha": 0.05,                       # único parâmetro
    "janela_seg": 120,
    "passo_seg": 30,
    "entry_services": ["teastore-webui"],
    "discovery_service": "teastore-registry",
    "discovery_route_regex": r"/services/([^/?]+)",
    "dependencias_sem_span": {"mysql": "teastore-db"},
    "k8s_sintoma": ["OOMKilled", "OOMKilling", "BackOff", "Unhealthy", "Evicted", "Failed",
                    "FailedScheduling", "ProbeWarning"],
    "ref_seg": 150,
    "ref_modo": "lookback",
}

MOTIVOS = {
    "sem_baseline": "artefato da baseline ausente ou sem janelas normais",
    "poucos_traces": "a janela não tem requisição de entrada completa",
    "sem_desvio_significativo": "nenhum serviço passou do nível de significância contra a baseline",
}

CANAIS_Z = {"erro": "maior", "latencia": "maior", "volume": "bilateral", "descoberta": "maior"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _forca(p: float) -> float:
    return min(1e6, max(0.0, -math.log10(min(1.0, max(est.P_MIN, float(p))))))


def _p_normal(z: float, lado: str) -> float:
    if lado == "maior":
        return 0.5 * math.erfc(z / math.sqrt(2))
    if lado == "menor":
        return 0.5 * math.erfc(-z / math.sqrt(2))
    return math.erfc(abs(z) / math.sqrt(2))


def _servico(evento: Any, deps: dict[str, str]) -> str:
    alvo = deps.get(str(getattr(evento, "activity", "") or ""))
    return alvo or str(getattr(evento, "service", "") or "")


def _alvo_descoberta(caminho: str, regex: re.Pattern[str], servicos: set[str]) -> str | None:
    m = regex.search(caminho or "")
    if not m:
        return None
    nome = m.group(1).lower()
    for s in sorted(servicos, key=len, reverse=True):
        curto = s.split("-", 1)[-1].lower()
        if curto and curto in nome:
            return s
    return None


def estatisticas(eventos: list[Any], cfg: dict[str, Any], servicos: set[str] | None = None) -> dict[str, Any]:
    """Medidas de uma janela: por serviço (erro, latência, volume, descoberta, atividades) e entrada."""
    cfg = _cfg(cfg)
    deps = causal.dependencias_por_atividade(eventos, cfg.get("dependencias_sem_span") or {})
    entradas = set(cfg["entry_services"])
    regex = re.compile(cfg["discovery_route_regex"])
    casos = {e.case_id for e in eventos}
    n = max(1, len(casos))
    spans: dict[str, int] = defaultdict(int)
    erros: dict[str, int] = defaultdict(int)
    dur: dict[str, list[int]] = defaultdict(list)
    ativ: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    todos = set(servicos or ()) | {_servico(e, deps) for e in eventos}
    descoberta: dict[str, int] = defaultdict(int)
    for e in eventos:
        s = _servico(e, deps)
        if not s:
            continue
        spans[s] += 1
        erros[s] += bool(e.is_error)
        dur[s].append(int(e.duration_us))
        ativ[s][str(e.activity)].add(e.case_id)
        if s == cfg["discovery_service"]:
            alvo = _alvo_descoberta(str((e.attributes or {}).get("url.path") or ""), regex, todos)
            if alvo:
                descoberta[alvo] += 1
    por = {}
    for s in todos:
        por[s] = {"erro": erros[s] / spans[s] if spans[s] else None,
                  "latencia": math.log(max(1.0, statistics.median(dur[s]))) if dur[s] else None,
                  "volume": spans[s] / n, "descoberta": descoberta[s] / n,
                  "atividades": {a: len(c) / n for a, c in ativ[s].items()},
                  "contagens": {"spans": spans[s], "erros": erros[s], "descoberta": descoberta[s]}}
    seg = float(cfg["janela_seg"])
    raizes = {e.case_id for e in eventos if getattr(e, "service", "") in entradas and e.depth == 0}
    return {"n": len(casos), "por_servico": por, "entrada_por_seg": len(raizes) / seg}


def _robusto(valores: list[float]) -> dict[str, float] | None:
    v = [x for x in valores if x is not None]
    if len(v) < 3:
        return None
    med = statistics.median(v)
    mad = statistics.median([abs(x - med) for x in v])
    sd = statistics.pstdev(v)
    return {"mediana": med, "sigma": max(1.4826 * mad, sd, 1e-12), "n": len(v)}


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Janelas deslizantes da coleção normal → mediana e σ robusto de cada canal, por serviço."""
    cfg = _cfg(cfg)
    if not traces_normais:
        return {"modo": NOME, "versao": VERSAO, "janelas": 0}
    eventos = sorted(traces_normais, key=lambda e: e.start_us)
    ini, fim = eventos[0].start_us, eventos[-1].start_us
    w, p = int(cfg["janela_seg"] * 1e6), int(cfg["passo_seg"] * 1e6)
    medidas, t = [], ini + w
    servicos = {str(getattr(e, "service", "")) for e in eventos} | set((cfg.get("dependencias_sem_span") or {})
                                                                      .values())
    while t <= fim:
        dentro = [e for e in eventos if t - w <= e.start_us < t]
        if dentro:
            medidas.append(estatisticas(dentro, cfg, servicos))
        t += p
    canais: dict[str, dict[str, Any]] = {}
    for s in sorted({s for m in medidas for s in m["por_servico"]}):
        canais[s] = {}
        for c in CANAIS_Z:
            r = _robusto([m["por_servico"].get(s, {}).get(c) for m in medidas])
            if r:
                canais[s][c] = r
        freq: dict[str, list[float]] = defaultdict(list)
        for m in medidas:
            for a, f in (m["por_servico"].get(s, {}).get("atividades") or {}).items():
                freq[a].append(f)
        canais[s]["atividades"] = {a: sum(v) / len(medidas) for a, v in freq.items()}
    total = estatisticas(eventos, cfg, servicos)   # taxas agregadas: piso amostral dos canais de contagem
    for s, o in total["por_servico"].items():
        if s in canais:
            canais[s]["totais"] = {**o["contagens"], "n": total["n"]}
    return {"modo": NOME, "versao": VERSAO, "janelas": len(medidas), "servicos": sorted(canais),
            "canais": canais, "entrada": _robusto([m["entrada_por_seg"] for m in medidas]),
            "cfg": {k: cfg[k] for k in ("alpha", "janela_seg", "passo_seg")}}


def _metricas(entrada: EntradaIncidente) -> dict[str, list[float]]:
    """`{serviço: [p]}` do z robusto de cada métrica com série de referência na entrada."""
    saida: dict[str, list[float]] = defaultdict(list)
    for ent, mets in (entrada.metricas or {}).items():
        if not isinstance(mets, dict):
            continue
        for _nome, valor in mets.items():
            if isinstance(valor, dict) and isinstance(valor.get("referencia"), list):
                r = _robusto([float(x) for x in valor["referencia"] if isinstance(x, (int, float))])
                obs = valor.get("valor")
                if r and isinstance(obs, (int, float)):
                    saida[str(ent)].append(_p_normal((obs - r["mediana"]) / r["sigma"], "bilateral"))
    return saida


def evidencia(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> dict[str, dict[str, float]]:
    """`{serviço: {canal: p}}` da janela contra a baseline."""
    cfg = _cfg(cfg)
    servicos = set(artefato.get("servicos") or ())
    obs = estatisticas(list(entrada.traces), cfg, servicos)
    n = obs["n"]
    saida: dict[str, dict[str, float]] = defaultdict(dict)
    for s, base in (artefato.get("canais") or {}).items():
        o = obs["por_servico"].get(s) or {}
        for c, lado in CANAIS_Z.items():
            r, x = base.get(c), o.get(c)
            if r and x is not None:
                saida[s][c] = _p_normal((x - r["mediana"]) / r["sigma"], lado)
        # Canais de contagem: o p é o maior entre o da variação entre janelas e o do ruído amostral (binomial
        # para erro, Poisson para descoberta, taxa agregada da baseline com prior de Jeffreys) — uma janela
        # normal sem nenhum erro não pode transformar um único erro em evidência infinita.
        tot, cont = base.get("totais") or {}, o.get("contagens") or {}
        if tot and cont.get("spans") and "erro" in saida[s]:
            p0 = (tot["erros"] + 0.5) / (tot["spans"] + 1.0)
            pb = est.binominal(int(cont["erros"]), int(cont["spans"]), p0, alternative="greater").p
            saida[s]["erro"] = max(saida[s]["erro"], pb)
        if tot and n and "descoberta" in saida[s]:
            lam = (tot["descoberta"] + 0.5) / (tot["n"] + 1.0) * n
            k = int(cont.get("descoberta") or 0)
            pp = 1.0 - sum(math.exp(-lam) * lam ** i / math.factorial(i) for i in range(k)) if k < 170 else 0.0
            saida[s]["descoberta"] = max(saida[s]["descoberta"], max(0.0, pp))
        # atividade do normal ausente na janela: Poisson com média n·f, Bonferroni no nº de atividades
        presentes = set(o.get("atividades") or {})
        normais = base.get("atividades") or {}
        if normais and n:
            ausentes = [math.exp(-n * f) for a, f in normais.items() if a not in presentes and f > 0]
            if ausentes:
                saida[s]["ausente"] = min(1.0, min(ausentes) * len(normais))
    r = artefato.get("entrada")
    if r:
        for s in cfg["entry_services"]:
            saida[s]["entrada"] = _p_normal((obs["entrada_por_seg"] - r["mediana"]) / r["sigma"], "menor")
    # K8s: só sintoma, mesmo teste de Poisson da a0-k (referência da sessão)
    sintoma = set(cfg["k8s_sintoma"])
    eventos_k8s = [e for e in (entrada.eventos_k8s or []) if isinstance(e, dict) and e.get("reason") in sintoma]
    if eventos_k8s:
        med = a0k.separar(EntradaIncidente(
            incidente_id=entrada.incidente_id, janela=entrada.janela, abertura_incidente=entrada.abertura_incidente,
            traces=entrada.traces, traces_lookback=entrada.traces_lookback, metricas={}, eventos_k8s=eventos_k8s,
            config_sistema=entrada.config_sistema), {**a0k.DEFAULT_CFG, "ref_seg": cfg["ref_seg"],
                                                     "ref_modo": cfg["ref_modo"]})
        p0 = med["t_inc"] / (med["t_inc"] + med["t_ref"])
        for s, inc in med["inc"].items():
            testes = a0k._p_servico(inc, med["ref"].get(s) or {}, p0)
            if testes:
                saida[s]["k8s"] = est.fisher([t[1] for t in testes])
    for s, ps in _metricas(entrada).items():
        saida[s]["metrica"] = est.fisher(ps)
    return {s: dict(v) for s, v in saida.items()}


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    parametros = {"alpha": cfg["alpha"], "janelas_baseline": (artefato or {}).get("janelas", 0)}
    if not artefato or not artefato.get("canais"):
        return Decisao(status="absteve", motivo_abstencao="sem_baseline", parametros=parametros, versao=VERSAO)
    if not entrada.traces:
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", parametros=parametros, versao=VERSAO)
    ev = evidencia(entrada, artefato, cfg)
    nomes = sorted(s for s, c in ev.items() if c)
    if not nomes:
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", parametros=parametros,
                       versao=VERSAO)
    combinados = [est.fisher(list(ev[s].values())) for s in nomes]
    ajustados, signif = est.benjamini_hochberg(combinados, float(cfg["alpha"]))
    evid = {"por_servico": {s: {"p": p, "p_ajustado": pa, "canais": ev[s]}
                            for s, p, pa in zip(nomes, combinados, ajustados)}}
    if not any(signif):
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", evidencias=evid,
                       parametros=parametros, versao=VERSAO)
    forca = {s: _forca(p) for s, p in zip(nomes, combinados)}
    deps = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    filhos = d6.grafo_de_servicos(list(entrada.traces), deps)
    linhas = []
    for s in nomes:
        desc = d6._descendentes(s, filhos) & set(forca)
        max_desc = max((forca[d] for d in desc), default=0.0)
        linhas.append({"servico": s, "forca": forca[s], "residuo": max(0.0, forca[s] - max_desc)})
    linhas.sort(key=lambda x: (-x["residuo"], -x["forca"], x["servico"]))
    ranking = [ItemRanking(servico=x["servico"], escore=x["residuo"],
                           p_valor=dict(zip(nomes, combinados))[x["servico"]],
                           evidencias={"forca": x["forca"], "residuo": x["residuo"],
                                       "canais": ev[x["servico"]]}) for x in linhas]
    return Decisao(status="decidiu", ranking=ranking, evidencias=evid, parametros=parametros, versao=VERSAO)


class _ModoA0b:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoA0b()
