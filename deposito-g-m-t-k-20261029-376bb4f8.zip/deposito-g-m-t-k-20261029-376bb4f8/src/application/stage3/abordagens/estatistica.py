"""Testes estatísticos, sem decisão.

Os quatro modos precisam dos mesmos testes, e a tentação é cada um importar `scipy` e chamar a
função por conta própria. Isso seria um erro concreto, não só duplicação: `mannwhitneyu` com
`alternative="greater"` e com `"two-sided"` devolve o mesmo p quando os empates são todos, o `G`
de 2×2 tem uma correção (Williams) que só vale para 2×2, e o resíduo ajustado tem uma convenção
de sinal que decide para que lado o "aumento" aponta. Se cada modo escolher a sua, o ranking de um
vira medido contra um normal e o ranking de outro contra outro, e a comparação das quatro deixa
de significar alguma coisa.

Por isso tudo está aqui, com **uma** escolha declarada por função:

| função | o que decide |
|---|---|
| `g_2x2` | correção de Williams e o p de qui-quadrado com 1 gl |
| `residuo_ajustado` | resíduo de Anderson-Sweeney-Williams (divergência de Pearson), sinal = direção |
| `mann_whitney` | `alternative` explícita; exato só onde cabe |
| `binominal` | unilateral à direita: mede "a fração observada é maior que `p0`" |
| `benjamini_hochberg` | step-up com monotonicidade; devolve p ajustado e significantemente |
| `fisher` | p combinado por Fisher, com o piso de `p = 0` tratado |
| `p_empirico` | +1 no numerador e no denominador (Phipson & Smyth) |
| `pelt` | ponto de mudança de média com variância conhecida |

Duas decisões que valem estar escritas, porque as duas têm um modo de falha silencioso:

**Por que Williams.** O `G` de 2×2 sem correção anti-conservador: com `n` pequeno, tabela de
contingência muito desbalanceada, o p sai pequeno demais. A correção de Williams é a que a
literatura de drift de processo (B3) usa, e é o que torna o limiar calibrado transferível entre
modos.

**Por que PELT e não uma varredura de pontos.** `pelt` devolve o ponto de mudança *mais antigo que
passa*, que é o que a D3 precisa (`t_s`), e faz isso em O(n) com poda. Uma varredura gulosa
acharia o mesmo ponto em O(n²) e, com taxa de falso positivo mal calibrada, escolheria um ponto
diferente — porque "o mais antigo que passa" não é o mesmo que "o primeiro que a varredura
encontrar". A poda é o que torna os dois o mesmo.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy import stats

__all__ = [
    "PeltResult",
    "binominal",
    "benjamini_hochberg",
    "fisher",
    "g_2x2",
    "mann_whitney",
    "p_empirico",
    "pelt",
    "residuo_ajustado",
]

# Abaixo disso o p do qui-quadrado sai exatamente 0, e `log(0)` na combinação de Fisher quebra.
P_MIN = 1e-300


@dataclass(frozen=True)
class ResultadoTeste:
    """Saída comum dos testes. `p` é sempre o p bruto; o ajuste fica por fora, no BH."""

    p: float
    estatistica: float | None = None
    n: int = 0


def _sanear_p(p: float | None) -> float:
    if p is None or not math.isfinite(p):
        return 1.0
    return float(min(1.0, max(P_MIN, p)))


def g_2x2(
    a: float, b: float, c: float, d: float, *, alternative: str = "two-sided"
) -> ResultadoTeste:
    """Teste de independência numa tabela 2×2, com correção de continuidade.

    A tabela é ``[[a, b], [c, d]]``: linha 0 é o grupo 1 (onde `alternative="greater"` quer mais
    massa), linha 1 é o grupo 2.

    A estatística é o Pearson com correção de Yates,

    ``chi2 = n * max(0, |ad − bc| − n/2)² / (r₁ r₂ c₁ c₂)``

    que é a forma equivalente ao G de Williams para 2×2. A correção importa aqui porque os
    primeiros testes da especificação são de amostra pequena: sem ela, uma tabela 2×2 em que só mudou a
    presença de uma relação fica muito menos sensível, e o falso negativo aparece como "o processo
    mudou e o modo não viu".

    Quando alguma célula esperada fica abaixo de 5, ou uma observada é zero, a aproximação qui-quadrado
    não vale mais e o p vem do **Fisher exato**. Esse desvio importa no caso mais importante da D2: a
    relação que passou de 4 para 5 chamadas tem contagens concentradas, e é exatamente ali que a
    aproximação erra mais.
    """
    n = a + b + c + d
    if n <= 0:
        return ResultadoTeste(p=1.0, estatistica=0.0, n=0)
    linha0, linha1 = a + b, c + d
    coluna0, coluna1 = a + c, b + d
    denominador = linha0 * linha1 * coluna0 * coluna1
    if denominador <= 0:
        return ResultadoTeste(p=1.0, estatistica=0.0, n=int(n))

    det = abs(a * d - b * c)
    excedente = max(0.0, det - n / 2.0)
    chi2 = n * excedente**2 / denominador
    esperado_min = min(
        linha0 * coluna0 / n, linha0 * coluna1 / n, linha1 * coluna0 / n, linha1 * coluna1 / n
    )

    if min(a, b, c, d) == 0 or esperado_min < 5:
        _, p_bruto = stats.fisher_exact([[a, b], [c, d]])
    else:
        p_bruto = float(stats.chi2.sf(chi2, 1))

    positivo = _det_positivo(a, b, c, d)
    if alternative == "greater":
        p = p_bruto if positivo else min(1.0, 2.0 * p_bruto)
    elif alternative == "less":
        p = p_bruto if not positivo else min(1.0, 2.0 * p_bruto)
    else:
        p = p_bruto
    return ResultadoTeste(p=_sanear_p(p), estatistica=float(chi2), n=int(n))


def _det_positivo(a: float, b: float, c: float, d: float) -> bool:
    """Associação positiva: mais massa em (0,0) e (1,1) do que a independência previa."""
    return (a * d - b * c) > 0


def residuo_ajustado(a: float, b: float, c: float, d: float) -> dict[str, float]:
    """Resíduo ajustado (divergência de Pearson) das quatro células.

    Serve para a **direção**, não para o p: é o que separa "a relação `a → b` ficou mais frequente"
    de "a relação `b → a` ficou mais frequente". O sinal vem do observado menos esperado, e o
    quadrado da soma dos quatro resíduos dá a estatística de Pearson (aqui, do G, por construção da
    tabela) — por isso a checagem de 1,96 na D3 é sobre `|r|` e não sobre o p.
    """
    n = a + b + c + d
    if n <= 0:
        return {"r00": 0.0, "r01": 0.0, "r10": 0.0, "r11": 0.0}
    linha = (a + b, c + d)
    coluna = (a + c, b + d)
    observados = ((a, b), (c, d))
    saida: dict[str, float] = {}
    for i in range(2):
        for j in range(2):
            esperado = linha[i] * coluna[j] / n
            variancia = esperado * (1 - linha[i] / n) * (1 - coluna[j] / n)
            if variancia <= 0:
                saida[f"r{i}{j}"] = 0.0
                continue
            saida[f"r{i}{j}"] = (observados[i][j] - esperado) / math.sqrt(variancia)
    return saida


def mann_whitney(
    amostra: Sequence[float], referencia: Sequence[float], *, alternative: str = "greater"
) -> ResultadoTeste:
    """Mann-Whitney U. `alternative="greater"` mede "a amostra é maior que a referência".

    Empate total entre as duas amostras (mesmo conjunto de valores) dá p = 1 sem chamar o SciPy: o
    teste é degenerado e o SciPy emite aviso. Tratar isso como p = 1 é o que evita um p pequeno e
    falso quando o "incidente" tem a mesma distribuição do normal.
    """
    x = [float(v) for v in amostra]
    y = [float(v) for v in referencia]
    if len(x) == 0 or len(y) == 0:
        return ResultadoTeste(p=1.0, n=0)
    if set(x) == set(y):
        return ResultadoTeste(p=1.0, estatistica=0.0, n=len(x) + len(y))
    try:
        res = stats.mannwhitneyu(x, y, alternative=alternative, method="asymptotic")
    except ValueError:
        return ResultadoTeste(p=1.0, n=len(x) + len(y))
    return ResultadoTeste(p=_sanear_p(float(res.pvalue)), estatistica=float(res.statistic),
                          n=len(x) + len(y))


def binominal(sucessos: int, n: int, p0: float, *, alternative: str = "greater") -> ResultadoTeste:
    """Binomial exato. `alternative="greater"`: a fração observada é maior que `p0`."""
    if n <= 0:
        return ResultadoTeste(p=1.0, n=0)
    res = stats.binomtest(int(sucessos), int(n), float(p0), alternative=alternative)
    return ResultadoTeste(p=_sanear_p(float(res.pvalue)), n=int(n))


def benjamini_hochberg(p_valores: Sequence[float], q: float) -> tuple[list[float], list[bool]]:
    """BH step-up. Devolve `(p_ajustados, significativos)`.

    A monotonicidade é aplicada de trás para frente, que é a forma estável: um p ajustado que não é
    ≥ o do vizinho à direita faria o número de rejeições depender da ordem de entrada. Aqui `p`s
    já vem da mesma decisão e na mesma ordem; o que não pode variar é o número de rejeições.
    """
    p = [_sanear_p(v) for v in p_valores]
    m = len(p)
    if m == 0:
        return [], []
    ordem = sorted(range(m), key=lambda i: p[i])
    ajustado = [0.0] * m
    running = 1.0
    for pos in range(m - 1, -1, -1):
        idx = ordem[pos]
        valor = p[idx] * m / (pos + 1)
        running = min(running, valor)
        ajustado[idx] = min(1.0, running)
    significativo = [ajustado[i] <= q for i in range(m)]
    return ajustado, significativo


def fisher(p_valores: Sequence[float]) -> float:
    """Combina p-valores por Fisher. Um serviço com três testes fracos pesa mais que um só médio."""
    p = [_sanear_p(v) for v in p_valores if v is not None]
    if not p:
        return 1.0
    if len(p) == 1:
        return p[0]
    return _sanear_p(float(stats.combine_pvalues(p, method="fisher")[1]))


def p_empirico(observado: float, nulos: Sequence[float], *, maior_e_melhor: bool = True) -> float:
    """p empírico contra uma amostra de valores nulos (Phipson & Smyth, 2010).

    O `+1` no numerador **e** no denominador é o ponto: sem ele, o menor valor observado contra uma
    amostra nula nunca daria p = 0, e `p = 0` entraria na combinação de Fisher como certeza
    absoluta. Com ele, o piso é `1 / (1 + n)`, que é o piso honesto de quem viu `n` nulos.
    """
    nulos = [float(v) for v in nulos]
    if not nulos:
        return 1.0
    if maior_e_melhor:
        conta = sum(1 for v in nulos if v >= float(observado))
    else:
        conta = sum(1 for v in nulos if v <= float(observado))
    return _sanear_p((1.0 + conta) / (1.0 + len(nulos)))


@dataclass(frozen=True)
class PeltResult:
    """Segmentos e pontos de mudança. `t`s são índices (0-based) do primeiro ponto de cada segmento."""

    pontos: list[int]
    segmentos: list[tuple[int, int]]
    custo: float
    n_segmentos: int
    forcado: bool = False

    @property
    def primeiro(self) -> int | None:
        """Índice do primeiro ponto de mudança, ou `None` se nenhum ponto passou da penalidade."""
        return self.pontos[0] if self.pontos else None


def pelt(
    serie: Sequence[float],
    variancia: float,
    beta: float,
    *,
    forcar_pelo_menos_um: bool = True,
    min_segmento: int = 1,
) -> PeltResult:
    """PELT para mudança de média com variância conhecida (Killick et al., 2012).

    `serie` é a série por intervalo; `variancia` vem do artefato do modo (ruído normal), nunca é
    reestimada aqui: a D3 precisa que o custo seja o mesmo nos dois lados da comparação, e
    reestimar por segmento faria o ponto de mudança se mover conforme o próprio dado.

    `beta` é a penalidade. Devolve todos os pontos, e `primeiro` é o mais antigo que passa — que é
    o `t_s` da D3, não o mais forte.

    Se nenhum ponto passar, devolve um segmento só. `forcar_pelo_menos_um` existe para quando a
    série é degenerada (constante) e o divide-et-impera recursivo não acha partição: aí forçar um
    ponto no meio produziria uma mudança que não existe, então o padrão é **não** forçar.
    """
    y = np.asarray([float(v) for v in serie], dtype=float)
    n = y.size
    if n < 2 or beta <= 0 or not math.isfinite(beta):
        return PeltResult(pontos=[], segmentos=[(0, n)], custo=float("inf"), n_segmentos=1)

    # Custo de custo de um segmento: verossimilhança de normal com variância conhecida.
    def custo_segmento(inicio: int, fim: int) -> float:
        trecho = y[inicio:fim]
        m = trecho.size
        if m <= 0:
            return 0.0
        soma = float(np.sum(trecho * trecho)) - float(np.sum(trecho)) ** 2 / m
        return m * math.log(variancia) + soma / variancia

    f = [math.inf] * (n + 1)
    f[0] = -beta
    r = {0}
    cp = [0] * (n + 1)
    # `min_segmento`: nenhum segmento mais curto que isso — um intervalo atípico isolado não é
    # mudança de regime (d3).
    min_seg = max(1, int(min_segmento))
    for t in range(1, n + 1):
        melhor = math.inf
        melhor_tau = 0
        for tau in sorted(r):
            if t - tau < min_seg or (tau > 0 and tau < min_seg) or not math.isfinite(f[tau]):
                continue
            candidato = f[tau] + custo_segmento(tau, t) + beta
            if candidato < melhor:
                melhor, melhor_tau = candidato, tau
        f[t] = melhor
        cp[t] = melhor_tau
        # Poda de Killick: um ponto anterior só continua viável se o próprio custo do prefixo ate
        # `t` ainda for competitive.
        r = {tau for tau in r if t - tau < min_seg or f[tau] + custo_segmento(tau, t) <= f[t]} | {t}

    # backtrack
    pontos: list[int] = []
    t = n
    while t > 0:
        tau = cp[t]
        if tau > 0:
            pontos.append(tau)
        t = tau
    pontos.sort()
    limites = [0, *pontos, n]
    segmentos = [(limites[i], limites[i + 1]) for i in range(len(limites) - 1)]
    return PeltResult(
        pontos=pontos,
        segmentos=segmentos,
        custo=float(f[n]),
        n_segmentos=len(segmentos),
    )


def variancia_ruido(valores: Sequence[float], piso: float = 1e-9) -> float:
    """Variância do ruído normal, com piso. Séries de duração em microssegundos têm ordem de
    grandeza muito diferente entre endpoint; sem piso, um endpoint quase constante faria o custo
    do PELT explodir e o modo decidir mudança onde não há."""
    arr = np.asarray([float(v) for v in valores], dtype=float)
    if arr.size < 2:
        return piso
    return max(float(np.var(arr, ddof=1)), piso)


def media_absoluta(valores: Sequence[float]) -> float:
    arr = np.asarray([float(v) for v in valores], dtype=float)
    return float(np.mean(arr)) if arr.size else 0.0


def mediana(valores: Sequence[float]) -> float:
    arr = np.asarray([float(v) for v in valores], dtype=float)
    return float(np.median(arr)) if arr.size else 0.0


def quantis(valores: Sequence[float], cortes: Sequence[float]) -> list[float]:
    """Quantis de uma amostra, para discretizar. `cortes` são os percentis (0..100)."""
    arr = np.asarray([float(v) for v in valores], dtype=float)
    if arr.size == 0:
        return [0.0] * (len(cortes) + 1)
    limites = [float(np.percentile(arr, c)) for c in cortes]
    limites.append(float(np.max(arr)))
    return limites


def faixa(valor: float, limites: Sequence[float]) -> int:
    """Índice da faixa de `valor` nos `limites`. Acima do último, devolve a última faixa."""
    for i in range(len(limites) - 1):
        if valor <= limites[i]:
            return i
    return max(0, len(limites) - 2)


def contagens(items: Sequence[Any]) -> dict[Any, int]:
    """Contagem de itens, para padrão de chamadas filhas da D4."""
    saida: dict[Any, int] = {}
    for item in items:
        saida[item] = saida.get(item, 0) + 1
    return saida


def assinatura_multiconjunto(itens: Sequence[Any]) -> tuple[Any, ...]:
    """Chamada por pai, como multiconjunto ordenado. Um trace com `a→b→a` e outro com `a→a→b` têm
    a mesma distribuição de frequência e o mesmo multiconjunto — o que a linguagem estocástica da D4
    quer, porque o que distingue a chamada anômala é *quantas vezes* e *qual*, não a ordem fina."""
    return tuple(sorted(contagens(itens).items(), key=lambda par: (str(par[0]), -par[1])))


def entropia(distr: dict[Any, float]) -> float:
    """Entropia de Shannon (nats). Base natural, porque é o que a entropic relevance de Polyvyanyy
    usa: comparar entropia em bits com a de outro paper seria um erro de unidades que só apareceria
    como limiar errado."""
    h = 0.0
    for p in distr.values():
        if p > 0:
            h -= p * math.log(p)
    return h


def kl(distr_p: dict[Any, float], distr_q: dict[Any, float]) -> float:
    """KL(distr_p || distr_q) com alisamento já aplicado. `distr_q` precisa cobrir as chaves de
    `distr_p`; quem não cobre, soma sobre as chaves que cobre."""
    soma = 0.0
    for chave, p in distr_p.items():
        if p <= 0:
            continue
        q = distr_q.get(chave, 0.0)
        if q <= 0:
            return math.inf
        soma += p * math.log(p / q)
    return soma


# Resolução mínima do teste de predição em escala log: diferenças abaixo de 1% entre janelas não
# são distinguíveis de arredondamento. Evita desvio-padrão zero (janelas idênticas) virar t infinito.
PISO_DESVIO_LOG = 0.01


def predicao_log(
    valor: float, amostras_janela: Sequence[float], *, alternative: str = "greater"
) -> ResultadoTeste | None:
    """Teste de intervalo de predição (t de Student) de `valor` contra **uma amostra por janela**.

    Por que não Mann-Whitney traço a traço: dentro de uma janela os traces não são independentes —
    a duração própria deriva entre trechos de 5 min do mesmo normal (GC, JIT, cache). Com ~2.700
    traces por janela, o Mann-Whitney transforma essa deriva em p < 1e-100 em janelas **normais**
    (medido em 2026-10-03). Aqui a unidade é a janela: `valor` é a estatística do
    incidente (ex.: mediana), `amostras_janela` são a mesma estatística em cada janela normal, e a
    pergunta é se `valor` cabe na variação **entre** janelas.

    Escala log (durações são assimétricas); `t = (x − x̄) / (s·√(1 + 1/W))`, `W − 1` graus de liberdade.
    `None` com menos de 3 janelas.
    """
    return predicao(
        math.log(max(float(valor), 1.0)),
        [math.log(max(float(a), 1.0)) for a in amostras_janela if a is not None],
        alternative=alternative, piso_desvio=PISO_DESVIO_LOG,
    )


def predicao(
    valor: float, amostras_janela: Sequence[float], *, alternative: str = "greater",
    piso_desvio: float = 1e-3,
) -> ResultadoTeste | None:
    """Intervalo de predição t de `valor` contra uma amostra por janela normal (escala linear).

    `t = (x − x̄) / (s·√(1 + 1/W))`, `W − 1` graus de liberdade, desvio com piso. `None` com < 3 janelas.
    """
    amostras = [float(a) for a in amostras_janela if a is not None]
    w = len(amostras)
    if w < 3:
        return None
    media = sum(amostras) / w
    desvio = max(float(np.std(amostras, ddof=1)), piso_desvio)
    t = (float(valor) - media) / (desvio * math.sqrt(1.0 + 1.0 / w))
    if alternative == "greater":
        p = float(stats.t.sf(t, w - 1))
    elif alternative == "less":
        p = float(stats.t.cdf(t, w - 1))
    else:
        p = float(2.0 * stats.t.sf(abs(t), w - 1))
    return ResultadoTeste(p=_sanear_p(p), estatistica=t, n=w)


def medianas_por_janela(
    pares: Sequence[tuple[int, float]], tamanho_us: int, *, minimo: int = 5,
    inicio_us: int | None = None, fim_us: int | None = None,
) -> list[float]:
    """Mediana dos valores em cada janela `[t, t + tamanho)`, com passo de meia janela.

    `pares` são `(instante_us, valor)`. É a amostra "uma observação por janela" do `predicao_log`.
    Janela com menos de `minimo` valores não entra. `inicio_us`/`fim_us` fixam a grade (para várias
    atividades compartilharem as mesmas janelas); sem eles, a grade vem dos próprios pares.
    """
    if not pares or tamanho_us <= 0:
        return []
    ordenados = sorted(pares)
    primeiro = ordenados[0][0] if inicio_us is None else inicio_us
    ultimo = ordenados[-1][0] if fim_us is None else fim_us
    saida: list[float] = []
    inicio = primeiro
    while inicio + tamanho_us <= ultimo + 1:
        valores = [v for t, v in ordenados if inicio <= t < inicio + tamanho_us]
        if len(valores) >= minimo:
            saida.append(mediana(valores))
        inicio += tamanho_us // 2
    return saida
