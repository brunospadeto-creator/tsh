"""d1c — d1 (conformance populacional) com atribuição causal.

Mesmo modelo, mesmos alinhamentos, mesmos testes e mesma decisão da d1-v1. Muda só o **ranking**, por
`causal.ranquear` (força sem piso, teste mais forte do serviço, intrínseco antes de comportamental):

- `tempo` (duração própria síncrona da atividade) → **intrínseco** do serviço da atividade; se a
  atividade é span cliente de banco (`dependencias_sem_span`), do banco;
- `movimento_modelo` com o serviço de `x` sumido do trace → **intrínseco** de `x`;
- `movimento_log` (o pai executou algo fora do modelo) e `movimento_modelo` com `x` ainda presente
  (o pai deixou de chamar) → **comportamental** do pai.

A d1-v1 continua congelada e intocada; este módulo só importa funções dela.
"""
from __future__ import annotations

import datetime
from collections import defaultdict
from typing import Any

from src.application.stage3 import process_models
from src.application.stage3.abordagens import calibracao as _calibracao
from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d1_conformance as d1
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

NOME = "d1c"
VERSAO = "d1c-v1"

DEFAULT_CFG: dict[str, Any] = {**d1.DEFAULT_CFG, "dependencias_sem_span": {}}


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _testes_endpoint(endpoint: str, inc: dict[str, Any], nor: dict[str, Any],
                     janelas_nor: dict[str, list[float]], cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """Os testes da d1-v1 (mesmos p), com a força sem piso de cada um."""
    minimo = int(cfg["min_oportunidades"])
    tot = {k: sum(nor[k].values()) for k in ("ocorrencias", "log", "oportunidades", "modelo")}
    testes = d1._testes_endpoint(endpoint, inc, nor, janelas_nor, cfg)
    for teste in testes:
        x = teste["elemento"]
        if teste["tipo"] == "tempo":
            teste["forca"] = causal.forca_t(teste.get("efeito"), int(teste.get("n_janelas_nor") or 0) - 1)
            continue
        ev, base = ("log", "ocorrencias") if teste["tipo"] == "movimento_log" else ("modelo", "oportunidades")
        ref_ev, ref_tot = int(nor[ev].get(x, 0)), int(nor[base].get(x, 0))
        if ref_tot < minimo:
            ref_ev, ref_tot = tot[ev], tot[base]
        a, de = int(teste["observado"]), int(teste["de"])
        teste["forca"] = causal.forca_g_2x2(a, de - a, ref_ev, ref_tot - ref_ev, alternative="greater")
    return testes


def _atribuir(teste: dict[str, Any], inc: dict[str, Any], nor: dict[str, Any],
              dependencias: dict[str, str]) -> tuple[str, str]:
    """`(serviço, classe)`: as regras de serviço da d1-v1 + a classe causal."""
    x = teste["elemento"]
    servico = d1._atribuir(teste, inc, nor)[0]
    if teste["tipo"] == "tempo":
        return dependencias.get(x, servico), causal.INTRINSECA
    if teste["tipo"] == "movimento_modelo":
        sumiu = inc["sumiu"].get(x, {})
        if sumiu.get("sim", 0) > sumiu.get("nao", 0):
            return servico, causal.INTRINSECA
    return servico, causal.COMPORTAMENTAL


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    q = _calibracao.q_do_artefato(artefato, cfg)
    parametros = {"q": q, "fp_alvo": (artefato.get("calibracao") or {}).get("fp_alvo"),
                  "min_oportunidades": cfg["min_oportunidades"]}
    modelos = artefato.get("endpoints") or {}
    if not modelos:
        return Decisao(status="absteve", motivo_abstencao="sem_modelo", versao=VERSAO, parametros=parametros)
    por_endpoint = proc.sequencias_por_endpoint(entrada.traces)
    com_modelo = [ep for ep in por_endpoint if ep in modelos]
    if not com_modelo:
        return Decisao(status="absteve", motivo_abstencao="sem_modelo", versao=VERSAO, parametros=parametros,
                       evidencias={"endpoints_incidente": sorted(por_endpoint)})

    testes: list[dict[str, Any]] = []
    contagens: dict[str, dict[str, Any]] = {}
    n_alinhados = 0
    for endpoint in com_modelo:
        nor = modelos[endpoint]
        modelo = process_models.deserialize_petri_net(nor["pnml"])
        inc = d1.contar(d1._amostra(por_endpoint[endpoint], int(cfg["max_traces_endpoint"])), modelo, cfg)
        contagens[endpoint] = inc
        n_alinhados += int(inc["n_traces"])
        testes.extend(_testes_endpoint(endpoint, inc, nor["contagem"], nor.get("duracao_janelas") or {}, cfg))
    if n_alinhados < int(cfg["min_traces"]):
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_alinhados": n_alinhados}, parametros=parametros)
    if not testes:
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", versao=VERSAO,
                       evidencias={"n_testes": 0, "n_alinhados": n_alinhados}, parametros=parametros)

    ajustados, significativos = est.benjamini_hochberg([t["p"] for t in testes], q)
    evidencias: dict[str, Any] = {"n_testes": len(testes), "p_min_ajustado": min(ajustados),
                                  "n_alinhados": n_alinhados, "endpoints": com_modelo}
    if not any(significativos):
        evidencias["testes"] = sorted(testes, key=lambda t: t["p"])[:20]
        return Decisao(status="absteve", motivo_abstencao="sem_desvio_significativo", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)

    dependencias = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for teste, p_adj, sig in zip(testes, ajustados, significativos):
        if not sig:
            continue
        ep = teste["endpoint"]
        servico, classe = _atribuir(teste, contagens[ep], modelos[ep]["contagem"], dependencias)
        if servico:
            por_servico[servico].append({**teste, "p_ajustado": p_adj, "classe": classe})
    evidencias["n_significativos"] = int(sum(significativos))
    evidencias["dependencias_sem_span"] = sorted(set(dependencias.values()))
    return Decisao(status="decidiu", ranking=causal.ranquear(dict(por_servico)), evidencias=evidencias,
                   parametros=parametros, versao=VERSAO)


def construir_artefato(traces_normais: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    return {**d1.construir_artefato(traces_normais, _cfg(cfg)), "modo": NOME, "versao": VERSAO}


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    artefato = construir_artefato(traces_normais, cfg)
    if not janelas:
        janelas = _calibracao.janelas_de_normal(
            traces_normais, datetime.timedelta(seconds=float(cfg["tamanho_janela_seg"])))
    artefato["calibracao"] = _calibracao.calibrar_cruzado(
        lambda fora: construir_artefato(fora, cfg), decidir, traces_normais, list(janelas), cfg,
        fp_alvo=float(cfg.get("fp_alvo") or 0.05),
    )
    return artefato


class _ModoD1c:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD1c()
