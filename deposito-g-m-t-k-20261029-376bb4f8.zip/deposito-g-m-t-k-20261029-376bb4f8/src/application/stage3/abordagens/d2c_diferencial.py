"""d2c — d2 (comparação de processos) com atribuição causal.

Mesma pergunta, mesmas medidas, mesmos testes e mesma decisão da d2-v3 (BH ao nível `q` calibrado só no
normal). Muda o **ranking** e um defeito:

- **Erro binarizado por trace.** Na d2-v3 o vetor `erro_ativ` guarda *quantos* erros o trace teve na
  atividade; a tabela 2×2 usava `n − Σ` e ficava negativa com trace de vários erros (`ValueError` no
  hold-out, lote 1 / h1). Aqui a medida é "o trace teve erro nessa atividade".
- **Ranking por `causal.ranquear`:** força sem piso, teste mais forte do serviço, intrínseco antes de
  comportamental. Classe por regra de atribuição da d2: tempo próprio, erro que nasce na atividade (sem
  erro significativo numa atividade filha) e "destino sumiu do endpoint" são **intrínsecos**; relação
  nova/mais/menos frequente e erro herdado de filha são **comportamentais**.
- **Dependência sem span** (`dependencias_sem_span`, ex. `{"mysql": "teastore-db"}`): tempo próprio e
  erro de span cliente de banco vão para o banco.

A d2-v3 continua congelada e intocada; este módulo só importa funções dela.
"""
from __future__ import annotations

import datetime
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import calibracao as _calibracao
from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d2_diferencial as d2
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente

NOME = "d2c"
VERSAO = "d2c-v1"

DEFAULT_CFG: dict[str, Any] = {**d2.DEFAULT_CFG, "dependencias_sem_span": {}}

_INTRINSECAS = {"tempo_proprio_da_atividade", "erro_na_atividade", "destino_sumiu_do_endpoint",
                "contagem_menor_e_destino_sumiu_do_endpoint"}


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _testes_elemento(endpoint: str, rel: str, inc: dict[str, Any], nor: dict[str, Any],
                     n_inc: int, n_nor: int) -> list[dict[str, Any]]:
    """Os testes da d2-v3 para a relação, com a força sem piso de cada um."""
    testes = d2._testes_elemento(endpoint, rel, inc, nor, n_inc, n_nor)
    for teste in testes:
        if teste["tipo"] == "contagem_relacao":
            teste["forca"] = causal.forca_mann_whitney(d2._vetor(inc, "contagem_rel", rel, n_inc),
                                                       d2._vetor(nor, "contagem_rel", rel, n_nor))
        else:
            a = round(teste["presenca_inc"] * n_inc)
            c = round(teste["presenca_nor"] * n_nor)
            teste["forca"] = causal.forca_g_2x2(a, n_inc - a, c, n_nor - c)
    return testes


def _testes_atividade(endpoint: str, atividade: str, inc: dict[str, Any], nor: dict[str, Any],
                      n_inc: int, n_nor: int, janelas_nor: dict[str, list[float]] | None) -> list[dict[str, Any]]:
    """Como `d2._testes_atividade`, com erro binarizado por trace e força sem piso."""
    testes: list[dict[str, Any]] = []
    pres_inc = d2._vetor(inc, "presenca_ativ", atividade, n_inc)
    pres_nor = d2._vetor(nor, "presenca_ativ", atividade, n_nor)
    if sum(pres_inc) or sum(pres_nor):
        a, b = sum(pres_inc), n_inc - sum(pres_inc)
        c, d = sum(pres_nor), n_nor - sum(pres_nor)
        g = est.g_2x2(a, b, c, d, alternative="two-sided")
        testes.append({"tipo": "presenca_atividade", "elemento": atividade, "endpoint": endpoint,
                       "n_inc": n_inc, "n_nor": n_nor, "g": g.estatistica, "p": g.p,
                       "media_inc": a / max(1, n_inc), "media_nor": c / max(1, n_nor),
                       "forca": causal.forca_g_2x2(a, b, c, d)})
    dur_inc = [v for v in d2._vetor(inc, "duracao_ativ", atividade, n_inc) if v]
    medianas_nor = (janelas_nor or {}).get(atividade) or []
    if len(dur_inc) >= d2.MIN_OCORRENCIAS_JANELA:
        r = est.predicao_log(est.mediana(dur_inc), medianas_nor, alternative="greater")
        if r is not None:
            testes.append({"tipo": "duracao_atividade", "elemento": atividade, "endpoint": endpoint,
                           "n_inc": len(dur_inc), "n_janelas_nor": r.n,
                           "mediana_inc": est.mediana(dur_inc), "mediana_nor": est.mediana(medianas_nor),
                           "t": r.estatistica, "p": r.p, "forca": causal.forca_t(r.estatistica, int(r.n) - 1)})
    erro_inc = [1 if v else 0 for v in d2._vetor(inc, "erro_ativ", atividade, n_inc)]
    erro_nor = [1 if v else 0 for v in d2._vetor(nor, "erro_ativ", atividade, n_nor)]
    if erro_inc and erro_nor:
        a, b = sum(erro_inc), len(erro_inc) - sum(erro_inc)
        c, d = sum(erro_nor), len(erro_nor) - sum(erro_nor)
        g = est.g_2x2(a, b, c, d, alternative="greater")
        testes.append({"tipo": "erro_atividade", "elemento": atividade, "endpoint": endpoint,
                       "n_inc": len(erro_inc), "n_nor": len(erro_nor),
                       "erro_inc": a / len(erro_inc), "erro_nor": c / len(erro_nor), "p": g.p,
                       "residuo": est.residuo_ajustado(a, b, c, d)["r00"],
                       "forca": causal.forca_g_2x2(a, b, c, d, alternative="greater")})
    return testes


def _descendentes(atividade: str, filhas: dict[str, set[str]]) -> set[str]:
    vistos: set[str] = set()
    pilha = list(filhas.get(atividade, ()))
    while pilha:
        x = pilha.pop()
        if x not in vistos:
            vistos.add(x)
            pilha.extend(filhas.get(x, ()))
    return vistos


def _classificar(itens: list[dict[str, Any]], filhas: dict[str, set[str]], com_erro: set[str]) -> None:
    """`com_erro` = atividades com erro significativo **ou** destino que sumiu do endpoint: um erro no
    chamador com um descendente que falhou ou sumiu é a propagação do defeito de baixo, não a origem."""
    for item in itens:
        regra = item.get("regra")
        herdado = regra == "erro_na_atividade" and bool(_descendentes(item["elemento"], filhas) & com_erro)
        item["classe"] = causal.INTRINSECA if regra in _INTRINSECAS and not herdado else causal.COMPORTAMENTAL
        if herdado:
            item["regra"] = "erro_herdado_de_filha"


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    q = _calibracao.q_do_artefato(artefato, cfg)
    parametros = {"q": q, "fp_alvo": artefato.get("calibracao", {}).get("fp_alvo")}
    if not artefato:
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       parametros={**parametros, "artefato": "ausente"})

    por_endpoint_inc = proc.sequencias_por_endpoint(entrada.traces)
    por_endpoint_nor = artefato.get("endpoints", {})
    n_traces = sum(len(v) for v in por_endpoint_inc.values())
    if n_traces < cfg["min_traces"]:
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_traces": n_traces}, parametros=parametros)

    testes: list[dict[str, Any]] = []
    medidas_por_endpoint: dict[str, dict[str, Any]] = {}
    for endpoint, traces in por_endpoint_inc.items():
        nor = por_endpoint_nor.get(endpoint)
        if not nor:
            continue
        sequencias = list(traces.values())
        inc = d2.medidas_por_trace(sequencias)
        medidas_por_endpoint[endpoint] = inc
        nor_med = nor["medidas"]
        n_nor = int(nor.get("n_traces") or 0)
        for chave in sorted(set(inc["contagem_rel"]) | set(nor_med["contagem_rel"])):
            testes.extend(_testes_elemento(endpoint, chave, inc, nor_med, len(sequencias), n_nor))
        for atividade in sorted(set(inc["duracao_ativ"]) | set(nor_med["duracao_ativ"])):
            testes.extend(_testes_atividade(endpoint, atividade, inc, nor_med, len(sequencias), n_nor,
                                            nor.get("duracao_janelas")))
    if not testes:
        return Decisao(status="absteve", motivo_abstencao="sem_diferenca_significativa",
                       versao=VERSAO, evidencias={"n_testes": 0}, parametros=parametros)

    ajustados, significativos = est.benjamini_hochberg([t["p"] for t in testes], q)
    p_min_ajustado = min(ajustados)
    if not any(significativos):
        return Decisao(status="absteve", motivo_abstencao="sem_diferenca_significativa", versao=VERSAO,
                       evidencias={"n_testes": len(testes), "p_min_ajustado": p_min_ajustado,
                                   "testes": sorted(testes, key=lambda t: t["p"])[:20]},
                       parametros=parametros)
    for teste, p_adj, sig in zip(testes, ajustados, significativos):
        teste["p_ajustado"], teste["significante"] = p_adj, sig

    dependencias = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    por_servico: dict[str, list[dict[str, Any]]] = defaultdict(list)
    sig_por_endpoint: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for teste in testes:
        if teste.get("significante"):
            sig_por_endpoint[teste["endpoint"]].append(teste)
    for endpoint, sig_testes in sig_por_endpoint.items():
        # filhas pelo normal e pelo incidente: a relação com quem sumiu só existe no normal
        filhas: dict[str, set[str]] = defaultdict(set)
        relacoes = set(medidas_por_endpoint.get(endpoint, {}).get("contagem_rel", {})) | set(
            ((por_endpoint_nor.get(endpoint) or {}).get("medidas") or {}).get("contagem_rel", {}))
        for rel in relacoes:
            origem, destino = rel.split(" -> ")
            filhas[origem].add(destino)
        presentes = d2._servicos_presentes(list(por_endpoint_inc[endpoint].values()))
        com_erro = {t["elemento"] for t in sig_testes if t["tipo"] == "erro_atividade"} | {
            t["elemento"].split(" -> ")[1] for t in sig_testes
            if t["tipo"] in {"presenca_relacao", "contagem_relacao"}
            and proc.servico_da_atividade(t["elemento"].split(" -> ")[1]) not in presentes}
        # tempo/erro de span cliente de banco: o banco, não o chamador
        do_banco = [t for t in sig_testes
                    if t["tipo"] in {"duracao_atividade", "erro_atividade"} and t["elemento"] in dependencias]
        resto = [t for t in sig_testes if t not in do_banco]
        atribuidos = d2._atribuir({f"{i}": t for i, t in enumerate(resto)}, medidas_por_endpoint.get(endpoint, {}),
                                  presentes)
        for t in do_banco:
            regra = "tempo_proprio_da_atividade" if t["tipo"] == "duracao_atividade" else "erro_na_atividade"
            atribuidos.setdefault(dependencias[t["elemento"]], []).append(
                {**t, "regra": regra, "via": "dependencia_sem_span"})
        for servico, itens in atribuidos.items():
            _classificar(itens, filhas, com_erro)
            por_servico[servico].extend(itens)

    nomes = {**(artefato.get("servicos") or {}), **d2.nomes_de_servico(entrada.traces)}
    ranking = causal.ranquear(dict(por_servico), nomes)
    return Decisao(
        status="decidiu", ranking=ranking, versao=VERSAO,
        evidencias={"n_testes": len(testes), "p_min_ajustado": p_min_ajustado,
                    "n_significativos": int(sum(significativos)), "n_endpoints": len(medidas_por_endpoint),
                    "q": q, "dependencias_sem_span": sorted(set(dependencias.values()))},
        parametros=parametros,
    )


def construir_artefato(traces_normais: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    artefato = d2.construir_artefato(traces_normais, _cfg(cfg))
    return {**artefato, "modo": NOME, "versao": VERSAO}


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    artefato = construir_artefato(traces_normais, cfg)
    if not janelas:
        janelas = _calibracao.janelas_de_normal(
            traces_normais, datetime.timedelta(seconds=float(cfg["tamanho_janela_seg"])))
    artefato["calibracao"] = _calibracao.calibrar_cruzado(
        lambda fora: construir_artefato(fora, cfg), decidir, traces_normais, list(janelas), cfg,
        fp_alvo=float(cfg.get("fp_alvo") or 0.05),
    )
    return artefato


class _ModoD2c:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD2c()
