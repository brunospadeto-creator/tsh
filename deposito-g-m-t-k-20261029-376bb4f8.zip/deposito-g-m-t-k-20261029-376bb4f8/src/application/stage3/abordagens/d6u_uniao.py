"""d6-u — União.

A d6 atenua a força intrínseca de um serviço pela maior força intrínseca entre os descendentes no
grafo da **janela**. O grafo da janela, porém, mente por omissão: quando a falha faz um serviço
**deixar de ser chamado**, a aresta some e o pai deixa de ter a quem atribuir o desvio — a evidência
intrínseca do pai fica "sem explicação" e ele sobe no ranking.

A d6-u usa o grafo da **união**: janela ∪ referência da própria sessão. Uma aresta que existia na
referência e sumiu na janela continua presente, então o filho que desapareceu (ou ficou sem span)
ainda explica o pai. A atenuação é a da d6, mas só entre descendentes **significativos**:

`r(v) = max(0, f(v) − α·max_desc_significativo)`, com `α = 1` (o plano do modo fixa o valor; não há família de
α a explorar como na d6). O resto — mesma decisão, mesmos testes, mesmo `q`, mesma atribuição da d2c —
é a d2c/d6 chamadas como utilitário.
"""
from __future__ import annotations

from typing import Any

from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d2_diferencial as d2
from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d6-u"
VERSAO = "d6-u-v1"

DEFAULT_CFG: dict[str, Any] = {**d2c.DEFAULT_CFG, "atenuacao": 1.0}

MOTIVOS = {"sem_residuo_atribuivel": "todos os desvios foram explicados pelos filhos (propagação pura)"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def grafo_uniao(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, set[str]]:
    """Grafo de chamadas da janela ∪ referência, com o banco como filho (dependências sem span)."""
    eventos = list(entrada.traces) + list(entrada.traces_lookback)
    dependencias = causal.dependencias_por_atividade(eventos, cfg.get("dependencias_sem_span") or {})
    return d6.grafo_de_servicos(eventos, dependencias)


def decidir_de_base(base: Decisao, entrada: EntradaIncidente, artefato: dict[str, Any],
                    cfg: dict[str, Any]) -> Decisao:
    """A regra sobre a decisão da d2c já calculada (o avaliador calcula a d2c uma vez por instante)."""
    cfg = _cfg(cfg)
    parametros = {**base.parametros, "atenuacao": float(cfg["atenuacao"])}
    if base.status != "decidiu":
        return Decisao(status=base.status, motivo_abstencao=base.motivo_abstencao,
                       evidencias=base.evidencias, parametros=parametros, versao=VERSAO)
    filhos = grafo_uniao(entrada, cfg)
    nomes = {**((artefato or {}).get("servicos") or {}), **d2.nomes_de_servico(entrada.traces)}
    presentes = {str(getattr(e, "service", "") or "") for e in entrada.traces}
    sumidos = sorted({nomes.get(c, c) for c in d6.servicos_do_normal(artefato or {})} - presentes - {""})
    linhas = d6.reordenar(base.ranking, filhos, sumidos, float(cfg["atenuacao"]))
    if not any(lin["fi_residual"] > 0 or lin["fc"] > 0 for lin in linhas):
        return Decisao(status="absteve", motivo_abstencao="sem_residuo_atribuivel",
                       evidencias=base.evidencias, parametros=parametros, versao=VERSAO)
    chave = [(lin["fi_residual"] <= 0, -lin["fi_residual"], -lin["fc"]) for lin in linhas]
    ranking = []
    for pos, lin in enumerate(linhas):
        escore = lin["fi_residual"] if lin["fi_residual"] > 0 else lin["fc"]
        ranking.append(ItemRanking(
            servico=lin["servico"], escore=escore, p_valor=10.0 ** (-min(escore, 300.0)),
            evidencias={"forca_intrinseca": lin["fi"], "forca_intrinseca_residual": lin["fi_residual"],
                        "explicado_por_descendentes": lin["max_intrinseca_descendentes"],
                        "forca_comportamental": lin["fc"], "sumiu": bool(lin.get("sumiu")),
                        "empate_com_seguinte": pos + 1 < len(linhas) and chave[pos + 1] == chave[pos],
                        "itens": lin["itens"][:10]}))
    return Decisao(status="decidiu", ranking=ranking, evidencias={**base.evidencias, "sumidos": sumidos},
                   parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    return decidir_de_base(d2c.decidir(entrada, artefato, cfg), entrada, artefato, cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    artefato = d2c.preparar_baseline(traces_normais, janelas, _cfg(cfg))
    return {**artefato, "modo": NOME, "versao": VERSAO}


class _ModoD6u:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD6u()
