"""d7 — assinatura derivada do grafo.

Ideia 6 do dossiê (resíduos estruturados de Gertler; matriz de sensibilidade de vazamento; *não* fingerprint
aprendido do histórico, que só reconhece falha já vista). Mesma decisão e `q` da d2c; a localização é por
**semelhança de padrão**:

- **Observado**: por serviço, a força intrínseca e a comportamental da atribuição das versões `c` (serviço que
  sumiu da janela entra como intrínseco, como na d6), comprimidas por `log1p` para que um teste saturado não
  apague o padrão.
- **Assinatura de `v`** (do grafo de chamadas da janela, banco como filho de quem tem span cliente de banco):
  intrínseco em `v`; comportamental nos **ancestrais** de `v` (quem o chama, direta ou indiretamente); zero no
  resto.
- **Similaridade** = cosseno entre observado e assinatura (mais robusta que o maior teste isolado). Ranking
  pela similaridade; se a maior ficar abaixo de `limiar_similaridade`, abstém `sem_assinatura_correspondente`.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import causal
from src.application.stage3.abordagens import d2c_diferencial as d2c
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d7"
VERSAO = "d7-v1"

DEFAULT_CFG: dict[str, Any] = {**d2c.DEFAULT_CFG, "limiar_similaridade": 0.7}

MOTIVOS = {"sem_assinatura_correspondente": "nenhuma assinatura do grafo tem similaridade acima do limiar"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def ancestrais(filhos: dict[str, set[str]]) -> dict[str, set[str]]:
    """`{serviço: quem o chama, direta ou indiretamente}`."""
    pais: dict[str, set[str]] = defaultdict(set)
    for pai, fs in filhos.items():
        for f in fs:
            pais[f].add(pai)
    saida: dict[str, set[str]] = {}
    for servico in set(pais) | set(filhos):
        vistos: set[str] = set()
        pilha = list(pais.get(servico, ()))
        while pilha:
            x = pilha.pop()
            if x not in vistos and x != servico:
                vistos.add(x)
                pilha.extend(pais.get(x, ()))
        saida[servico] = vistos
    return saida


def similaridades(observado: dict[str, tuple[float, float]], anc: dict[str, set[str]],
                  candidatos: list[str]) -> dict[str, float]:
    """Cosseno entre o vetor observado (intrínseco, comportamental por serviço) e a assinatura de cada candidato."""
    servicos = sorted(set(observado) | set(candidatos) | {a for s in candidatos for a in anc.get(s, ())})
    obs = [observado.get(s, (0.0, 0.0))[k] for s in servicos for k in (0, 1)]
    norma_obs = math.sqrt(sum(x * x for x in obs))
    saida: dict[str, float] = {}
    for v in candidatos:
        sig = [(1.0 if (k == 0 and s == v) or (k == 1 and s in anc.get(v, ())) else 0.0)
               for s in servicos for k in (0, 1)]
        norma_sig = math.sqrt(sum(x * x for x in sig))
        produto = sum(a * b for a, b in zip(obs, sig))
        saida[v] = produto / (norma_obs * norma_sig) if norma_obs and norma_sig else 0.0
    return saida


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    return decidir_de_base(d2c.decidir(entrada, artefato, cfg), entrada, artefato, cfg)


def decidir_de_base(base: Decisao, entrada: EntradaIncidente, artefato: dict[str, Any],
                    cfg: dict[str, Any]) -> Decisao:
    """A regra sobre a decisão da d2c já calculada (o avaliador calcula a d2c uma vez por instante)."""
    cfg = _cfg(cfg)
    parametros = {**base.parametros, "limiar_similaridade": float(cfg["limiar_similaridade"])}
    if base.status != "decidiu":
        return Decisao(status=base.status, motivo_abstencao=base.motivo_abstencao, evidencias=base.evidencias,
                       parametros=parametros, versao=VERSAO)
    dependencias = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    filhos = d6.grafo_de_servicos(entrada.traces, dependencias)
    nomes = {**((artefato or {}).get("servicos") or {}), **d2c.d2.nomes_de_servico(entrada.traces)}
    presentes = {str(getattr(e, "service", "") or "") for e in entrada.traces}
    sumidos = sorted({nomes.get(c, c) for c in d6.servicos_do_normal(artefato or {})} - presentes - {""})
    linhas = d6.reordenar(base.ranking, filhos, sumidos, 0.0)  # sem atenuação: a assinatura já separa
    observado = {lin["servico"]: (math.log1p(lin["fi"]), math.log1p(lin["fc"])) for lin in linhas}
    anc = ancestrais(filhos)
    candidatos = sorted(observado)
    sim = similaridades(observado, anc, candidatos)
    ordem = sorted(candidatos, key=lambda s: (-sim[s], -observado[s][0], s))
    if not ordem or sim[ordem[0]] < float(cfg["limiar_similaridade"]):
        return Decisao(status="absteve", motivo_abstencao="sem_assinatura_correspondente",
                       evidencias={**base.evidencias, "similaridades": sim}, parametros=parametros, versao=VERSAO)
    ranking = [ItemRanking(servico=s, escore=-sim[s],
                           evidencias={"similaridade": sim[s], "intrinseca_log": observado[s][0],
                                       "comportamental_log": observado[s][1], "ancestrais": sorted(anc.get(s, ())),
                                       "empate_com_seguinte": i + 1 < len(ordem) and sim[ordem[i + 1]] == sim[s]})
               for i, s in enumerate(ordem)]
    return Decisao(status="decidiu", ranking=ranking, evidencias={**base.evidencias, "sumidos": sumidos},
                   parametros=parametros, versao=VERSAO)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """O artefato da d2c (mesmos testes, mesmo `q`), com a identidade da d7."""
    artefato = d2c.preparar_baseline(traces_normais, janelas, _cfg(cfg))
    return {**artefato, "modo": NOME, "versao": VERSAO}


class _ModoD7:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD7()
