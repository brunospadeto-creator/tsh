"""a0-k — Sinal-K8s.

O sinal mais barato e mais esquecido do Stage 3: os eventos do Kubernetes. Cada falha que passa por
deploy/probe/OOMKill/restart deixa evento no namespace, e hoje esse insumo entra no diagnóstico da a0
só como **voto** de um serviço (`localizacao.detectar_k8s`, restrito a `k8s_health_reasons`) — nunca
como um teste próprio, com taxa comparada à referência da mesma sessão.

Este modo é o canal: conta eventos por **serviço × motivo** na janela (todos os motivos, para não
depender de uma lista curada) e testa a taxa contra o passado recente da própria sessão com o teste
condicional de Poisson, que é exatamente um binomial à direita sobre `n_inc` dado `n_inc + n_ref` e a
razão de exposições `t_inc / (t_inc + t_ref)`. Isso é o que a referência da sessão usa para latência,
aplicado à contagem de eventos.

Por que é um modo e não um voto da a0. Como voto ele é assimétrico: só motivos de saúde contam, e um
serviço que explode em `Warning` mas não dispara nenhum motivo da lista some. Aqui a decisão é
*"algum serviço tem taxa de eventos fora do normal recente?"*, com o motivo que mais pesou na
evidência — o que serve de canal para `d9+m` e `a0-d` sem que eles reinventem o corte.

Sem artefato de baseline: a referência é sempre da própria sessão (`ref_modo="lookback"` no produto).
O `ref_seg` é ponto de partida, a fixar por validação cruzada antes de virar versão pré-registrada.
"""
from __future__ import annotations

import datetime
import math
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import referencia
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking
from src.application.stage3.entities import normalize_entity

NOME = "a0-k"
VERSAO = "a0-k-v1"

DEFAULT_CFG: dict[str, Any] = {
    "ref_seg": 150,
    "ref_modo": "lookback",
    "alpha": 0.05,       # limiar de significância do Poisson (BH entre serviços)
    "min_eventos": 1,    # menos que isto na janela: não há taxa a testar
}

MOTIVOS = {
    "sem_referencia_k8s": "a janela não tem referência de eventos do Kubernetes utilizável",
    "sem_evento_anomalo": "nenhum serviço passou do limiar de taxa de eventos",
}

_FORCA_MAXIMA = 1e6


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _forca(p: float) -> float:
    """−log10 p com piso, para caber em JSON do banco (mesma convenção de `causal`)."""
    p = min(1.0, max(est.P_MIN, float(p)))
    return min(_FORCA_MAXIMA, max(0.0, -math.log10(p)))


def _ts(evento: Any, chave: str = "ts") -> datetime.datetime | None:
    valor = evento.get(chave) if isinstance(evento, dict) else None
    if not valor:
        return None
    try:
        dt = datetime.datetime.fromisoformat(str(valor).replace("Z", "+00:00"))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=datetime.UTC)


def _servico(evento: Any) -> str:
    if not isinstance(evento, dict):
        return ""
    return normalize_entity(str(evento.get("res") or ""))


def _motivo(evento: Any) -> str:
    if not isinstance(evento, dict):
        return ""
    return str(evento.get("reason") or "")


def _peso(evento: Any) -> int:
    if not isinstance(evento, dict):
        return 1
    return max(1, int(evento.get("count") or 1))


def _contar(eventos: list[Any], inicio: datetime.datetime, fim: datetime.datetime,
           *, sem_ts_vai: bool) -> dict[str, dict[str, int]]:
    """`{serviço: {motivo: nº de eventos}}` para os eventos cujo `ts` cai em `[inicio, fim]`.

    Evento com `first_ts` (agregado pelo Kubernetes: `count` repetições até `ts`) entra pela fração do
    intervalo `[first_ts, ts]` que cai na janela.

    `sem_ts_vai` manda evento sem `ts` (ou com `ts` ilegível) para este balde: o provedor que não
    carimba o evento o entregou porque ele é da janela, então descartá-lo perderia o único sinal.
    """
    contagem: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for evento in eventos:
        servico = _servico(evento)
        if not servico:
            continue
        ts, primeiro = _ts(evento), _ts(evento, "first_ts")
        if ts is not None and primeiro is not None and primeiro < ts:
            # Evento agregado (`count` repetições entre `first_ts` e `ts`): taxa uniforme no intervalo, e a
            # janela fica com a fração que se sobrepõe. Sem isso o `count` inteiro cai no instante do último
            # registro e uma rajada de 30 min vira um ponto só.
            sobre = (min(fim, ts) - max(inicio, primeiro)).total_seconds()
            if sobre > 0:
                contagem[servico][_motivo(evento)] += _peso(evento) * sobre / (ts - primeiro).total_seconds()
            continue
        if ts is None:
            if not sem_ts_vai:
                continue
        elif not (inicio <= ts <= fim):
            continue
        contagem[servico][_motivo(evento)] += _peso(evento)
    return {s: {m: int(round(n)) for m, n in ms.items() if round(n) > 0} for s, ms in contagem.items()}


def separar(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, Any]:
    """Parte os eventos em referência e janela e devolve as exposições do teste de Poisson.

    A janela de contagem da incidência começa depois do fim da referência (`max` das duas), para que
    em `ref_modo="janela_inicial"` — onde a referência é um prefixo da própria janela — o mesmo evento
    não entre nos dois lados. Em `"lookback"` (produto) as duas não se sobrepõem e a janela é inteira.
    """
    ini_ref, fim_ref = referencia.janela_referencia(entrada, cfg)
    ini, fim = entrada.janela
    ini_inc = max(ini, fim_ref) if fim_ref <= fim else ini
    ref = _contar(list(entrada.eventos_k8s), ini_ref, fim_ref, sem_ts_vai=False)
    inc = _contar(list(entrada.eventos_k8s), ini_inc, fim, sem_ts_vai=True)
    t_ref = max(1.0, (fim_ref - ini_ref).total_seconds())
    t_inc = max(1.0, (fim - ini_inc).total_seconds())
    return {"ref": ref, "inc": inc, "t_ref": t_ref, "t_inc": t_inc,
            "n_ref": sum(sum(m.values()) for m in ref.values()),
            "n_inc": sum(sum(m.values()) for m in inc.values())}


def _p_servico(inc: dict[str, int], ref_servico: dict[str, int], p0: float) -> list[tuple[str, float, int, int]]:
    """`(motivo, p, n_inc, n_ref)` por motivo com pelo menos um evento na janela."""
    saida: list[tuple[str, float, int, int]] = []
    for motivo, n_inc in sorted(inc.items()):
        if n_inc <= 0:
            continue
        n_ref = int(ref_servico.get(motivo, 0))
        r = est.binominal(n_inc, n_inc + n_ref, p0, alternative="greater")
        saida.append((motivo, r.p, n_inc, n_ref))
    return saida


def decidir_de_medida(medida: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    """A regra sobre a partição pronta (`decidir` e o avaliador sequencial chamam esta)."""
    cfg = _cfg(cfg)
    parametros = {k: cfg[k] for k in ("ref_seg", "ref_modo", "alpha", "min_eventos")}
    evidencias_base = {"n_inc": medida["n_inc"], "n_ref": medida["n_ref"]}
    # Referência sem nenhum evento é taxa zero (cluster quieto), não referência ausente: o teste de
    # Poisson trata `n_ref = 0`. Abster aqui calaria justamente o caso típico (BackOff num namespace calmo).
    if medida["n_inc"] < int(cfg["min_eventos"]):
        return Decisao(status="absteve", motivo_abstencao="sem_evento_anomalo", versao=VERSAO,
                       evidencias=evidencias_base, parametros=parametros)

    p0 = medida["t_inc"] / (medida["t_inc"] + medida["t_ref"])
    servicos = sorted(medida["inc"])
    testes = {s: _p_servico(medida["inc"][s], medida["ref"].get(s) or {}, p0) for s in servicos}
    p_por_servico = {s: est.fisher([t[1] for t in testes[s]]) for s in servicos if testes[s]}
    if not p_por_servico:
        return Decisao(status="absteve", motivo_abstencao="sem_evento_anomalo", versao=VERSAO,
                       evidencias=evidencias_base, parametros=parametros)

    nomes = sorted(p_por_servico)
    brutos = [p_por_servico[s] for s in nomes]
    ajustados, significativos = est.benjamini_hochberg(brutos, float(cfg["alpha"]))
    evid = {**evidencias_base, "alpha": cfg["alpha"], "p_min_ajustado": min(ajustados),
            "n_servicos": len(nomes),
            "por_servico": {s: {"p": p, "p_ajustado": pa, "motivos": testes[s]}
                            for s, p, pa in zip(nomes, brutos, ajustados)}}
    if not any(significativos):
        return Decisao(status="absteve", motivo_abstencao="sem_evento_anomalo", versao=VERSAO,
                       evidencias=evid, parametros=parametros)

    linhas = sorted(zip(nomes, brutos, ajustados), key=lambda t: (_forca(t[1]) <= 0, -_forca(t[1]), t[0]))
    ranking = []
    for s, p, pa in linhas:
        relevante = min(testes[s], key=lambda t: t[1])  # o motivo mais significativo
        ranking.append(ItemRanking(
            servico=s, escore=_forca(p), p_valor=p,
            evidencias={"p_ajustado": pa, "motivo": relevante[0], "n_incidente": relevante[2],
                        "n_referencia": relevante[3], "n_motivos": len(testes[s])},
        ))
    return Decisao(status="decidiu", ranking=ranking, evidencias=evid, parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    return decidir_de_medida(separar(entrada, _cfg(cfg)), cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Sem artefato de baseline: a referência são os eventos recentes da própria sessão."""
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "limiares_por_validacao_cruzada"},
            "cfg": {k: cfg[k] for k in ("ref_seg", "ref_modo", "alpha")}}


class _ModoA0k:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoA0k()
