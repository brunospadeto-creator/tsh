"""O mapa de modos e o ponto unico de execucao.

`MODOS` e a unica lista de quem existe. Um modo entra aqui quando o arquivo dele existe — e nao antes,
porque um modo registrado sem implementacao seria pior que um modo ausente: o pre-voo exigiria
congelamento de um arquivo que nao esta la e o job penduraria.

`executar_modo()` e o unico caminho de `decidir()`. Concentrar aqui tem um motivo concreto: e o que
permite garantir, num teste, que **nenhum** modo foi chamado sem `preparar_baseline` ter rodado antes,
e que nenhum modo enxerga o resultado de outro.
"""
from __future__ import annotations

import time
from typing import Any

from src.application.stage3.abordagens import (
    d0_nula,
    d1_conformance,
    d1c_conformance,
    d2_diferencial,
    d2c_diferencial,
    d3_drift,
    d4_estocastico,
    d4c_estocastico,
    d5_portao,
    d6_residuo,
    d7_assinatura,
    d8_fusao,
    d9_portao_grafo,
    d9k_portao_grafo_k8s,
    vconsb_consenso,
)
from src.application.stage3.abordagens.base import (
    MODOS_ABSTAIN,
    Decisao,
    EntradaIncidente,
    Modo,
)
from src.store.models import MODOS_DECISORIOS_STAGE3, MODOS_STAGE3

__all__ = [
    "MODOS",
    "MODOS_ABSTAIN",
    "MODO_NULO",
    "LEEM_K8S",
    "versao_do_modo",
    "executar_modo",
    "preparar_baselines",
    "modo_desconhecido",
]

# Apenas o que existe de fato. `a0` entra pelo adaptador `a0.py`, que so existe depois que ele for
# escrito; ate la, um lote com `escolhidos=["a0"]` so enfileira o job legado `stage3_diagnosis`, que
# e o caminho de hoje e nao depende deste registro.
MODOS: dict[str, Modo] = {
    d0_nula.NOME: d0_nula.MODO,
    d1_conformance.NOME: d1_conformance.MODO,
    d2_diferencial.NOME: d2_diferencial.MODO,
    d3_drift.NOME: d3_drift.MODO,
    d4_estocastico.NOME: d4_estocastico.MODO,
    d1c_conformance.NOME: d1c_conformance.MODO,
    d2c_diferencial.NOME: d2c_diferencial.MODO,
    d4c_estocastico.NOME: d4c_estocastico.MODO,
    d5_portao.NOME: d5_portao.MODO,
    d6_residuo.NOME: d6_residuo.MODO,
    d7_assinatura.NOME: d7_assinatura.MODO,
    d8_fusao.NOME: d8_fusao.MODO,
    d9_portao_grafo.NOME: d9_portao_grafo.MODO,
    # soluções definitivas: a d9-k decide; o v-cons-b dá a lista de investigação (top-3)
    d9k_portao_grafo_k8s.NOME: d9k_portao_grafo_k8s.MODO,
    vconsb_consenso.NOME: vconsb_consenso.MODO,
}

# Modos que leem eventos do Kubernetes: só para eles o runner liga o provedor de eventos (d1–d4 recusam o
# insumo por desenho).
LEEM_K8S: frozenset[str] = frozenset({d9k_portao_grafo_k8s.NOME, vconsb_consenso.NOME})

MODO_NULO = d0_nula.MODO

# Motivos de abstenção dos modos novos. Ficam aqui, e não em `base.py`, porque
# `base.py` está no fecho de imports congelado das v1/c (congelamento.json): editá-lo mudaria o hash delas.
MOTIVOS_ABSTENCAO = {**MODOS_ABSTAIN, **d5_portao.MOTIVOS, **d6_residuo.MOTIVOS,
                     **d7_assinatura.MOTIVOS, **d8_fusao.MOTIVOS, **d9_portao_grafo.MOTIVOS,
                     **d9k_portao_grafo_k8s.MOTIVOS, **vconsb_consenso.MOTIVOS}


def modo_desconhecido(modo: str) -> str:
    if modo == "a0":
        return "a0 e o modo legado: roda pelo job stage3_diagnosis, nao por um job de modo"
    return f"modo desconhecido: {modo!r}; conhecidos: {sorted(MODOS)}"


def versao_do_modo(modo: str) -> str:
    if modo not in MODOS:
        raise ValueError(modo_desconhecido(modo))
    return MODOS[modo].versao


def executar_modo(
    nome: str,
    entrada: EntradaIncidente,
    artefato: dict[str, Any],
    cfg: dict[str, Any] | None = None,
) -> Decisao:
    """Chama `decidir()` de um modo e devolve a `Decisao` comum.

    Guarda o tempo aqui em vez de confiar no modo: `segundos` e metrica de auditoria, e um modo que
    reporta o proprio tempo errado nao pode ser conferido por ninguem.
    """
    if nome not in MODOS:
        raise ValueError(modo_desconhecido(nome))
    inicio = time.monotonic()
    decisao = MODOS[nome].decidir(entrada, artefato or {}, cfg or {})
    if decisao.status not in {"decidiu", "absteve", "falhou"}:
        raise ValueError(f"status invalido do modo {nome}: {decisao.status!r}")
    if decisao.status == "absteve":
        if not decisao.motivo_abstencao:
            raise ValueError(f"modo {nome} absteve sem motivo_abstencao")
        if decisao.motivo_abstencao not in MOTIVOS_ABSTENCAO:
            raise ValueError(
                f"motivo de abstencao fora do vocabulario: {decisao.motivo_abstencao!r}"
            )
        if decisao.ranking:
            raise ValueError(
                f"modo {nome} absteve mas devolveu ranking com {len(decisao.ranking)} item(ns)"
            )
    return Decisao(
        status=decisao.status,
        motivo_abstencao=decisao.motivo_abstencao,
        ranking=decisao.ranking,
        evidencias=decisao.evidencias,
        parametros=decisao.parametros,
        versao=decisao.versao,
        segundos=round(time.monotonic() - inicio, 4),
    )


def preparar_baselines(
    modos: list[str],
    traces_normais: list[Any],
    janelas: list[tuple[Any, Any]],
    cfg: dict[str, Any] | None = None,
) -> dict[str, dict[str, Any]]:
    """Prepara **so** os modos pedidos, cada um com seu artefato e sua versao.

    Devolve `{modo: artefato}`. Modo pedido que nao existe levanta `ValueError` em vez de virar
    `None`: um baseline "preparado" sem artefato e indistinguivel de um que nunca foi pedido.
    """
    saida: dict[str, dict[str, Any]] = {}
    for nome in modos:
        if nome not in MODOS:
            raise ValueError(modo_desconhecido(nome))
        saida[nome] = MODOS[nome].preparar_baseline(traces_normais, janelas, cfg or {})
    return saida


# Modos decorativos que a especificação dos modos exige e que ainda nao tem arquivo. Declarados aqui para o pre-voo
# e a tela dizerem "faltando" em vez de "desconhecido", que e a mesma coisa vista pelo avesso.
MODOS_ESPERADOS = ("a0",) + tuple(MODOS_DECISORIOS_STAGE3)
assert set(MODOS_ESPERADOS) == set(MODOS_STAGE3), "MODOS_STAGE3 e MODOS_ESPERADOS divergiram"
