"""Modo nulo `d0_nula` — caminho inteiro, decisão nenhuma.

Este modo existe para exercitar migração, job, repositório, API, pacote de auditoria e tela **antes**
de existir qualquer decisão real. Ele sempre abstém, e a forma do abstain é a mesma dos modos de verdade:
`status="absteve"`, `motivo_abstencao` preenchido, `ranking` **vazio** (não ausente) e `parametros`
com os efetivos.

Um modo que devolve `ranking=[]` e `status="decidiu"` seria o pior dos dois: a tela mostraria um
serviço no topo sem nenhum. Por isso a lista de motivos de abstencao é um dicionário fechado em
`base.MODOS_ABSTAIN` e este modo usa `modo_nao_implementado`.

Ele também **não** herda nada do `stage3_diagnosis`: é um `Modo` como qualquer outro, para que o
despacho, o job e a API não tenham caminho especial.
"""
from __future__ import annotations

import datetime
import time
from typing import Any

from src.application.stage3.abordagens.base import (
    MODOS_ABSTAIN,
    Decisao,
    EntradaIncidente,
)

NOME = "d0_nula"
VERSAO = "d0_nula-v1"
MOTIVO = "modo_nao_implementado"


def janela_traces(
    entrada: EntradaIncidente, cfg: dict[str, Any]
) -> tuple[datetime.datetime, datetime.datetime]:
    """Modo nulo não muda a janela. Quem muda é a d3, e só ela."""
    return entrada.janela


def preparar_baseline(
    traces_normais: list[Any],
    janelas: list[tuple[datetime.datetime, datetime.datetime]],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Artefato mínimo e versionado: existe para o caminho ser real de ponta a ponta.

    Guardar `n_traces` e `n_janelas` mesmo aqui é o que permite descobrir, no caminho de teste, que um
    baseline foi preparado sobre um conjunto diferente do que se pensava.
    """
    return {
        "modo": NOME,
        "versao": VERSAO,
        "n_traces": len(traces_normais),
        "n_janelas": len(janelas),
        "motivo_abstencao": MOTIVO,
    }


def decidir(
    entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]
) -> Decisao:
    inicio = time.monotonic()
    # Registra o que o insumo tinha, para o pacote de auditoria não ser uma caixa-preta: um caminho de
    # teste que só passa não prova nada sobre a entrada.
    evidencias = {
        "modo": NOME,
        "n_traces": len(entrada.traces),
        "n_traces_lookback": len(entrada.traces_lookback),
        "n_eventos_k8s": len(entrada.eventos_k8s),
        "tem_metricas": bool(entrada.metricas),
        "versao_artefato": (artefato or {}).get("versao"),
    }
    return Decisao(
        status="absteve",
        motivo_abstencao=MOTIVO,
        ranking=[],
        evidencias=evidencias,
        parametros={"versao": VERSAO, "motivo": MOTIVO},
        versao=VERSAO,
        segundos=round(time.monotonic() - inicio, 4),
    )


# Instancia unica e sem estado.
MODO = type(
    "ModoNulo",
    (),
    {
        "nome": NOME,
        "versao": VERSAO,
        "janela_traces": staticmethod(janela_traces),
        "preparar_baseline": staticmethod(preparar_baseline),
        "decidir": staticmethod(decidir),
    },
)()

assert MOTIVO in MODOS_ABSTAIN, f"motivo de abstencao fora do vocabulario: {MOTIVO}"
