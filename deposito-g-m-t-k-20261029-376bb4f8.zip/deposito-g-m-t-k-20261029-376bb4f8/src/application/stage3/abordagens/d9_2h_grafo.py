"""d9-2h — Horizontes.

A d9 decide com o mesmo portão da d5, mas olha a referência do passado recente em **um** tamanho de
janela. Aqui o mesmo portão é mantido e a localização passa a ler **dois horizontes** da sessão:

- **curto** (`ref_seg_curto`, 150 s): o passado imediato. É o que separa o desvio de agora do que já
  vinha acontecendo.
- **longo** (`ref_seg_longo`, 600 s): a linha de base da sessão. É o denominador da **inclinação**.

Com os dois, um serviço que piorou só na janela (curto ≫ longo) fica com evidência **recente**; um que
vinha piorando devagar aparece pela **inclinação robusta** (Theil–Sen da mediana por intervalo), que
não é arrastada por um pico isolado como a regressão por mínimos quadrados seria.

Além do efeito de tempo/erro da d9, entram dois canais que a d9 não tem, porque o plano do modo pede vazão e
sumiço explícitos:

- **vazão**: queda relativa da contagem de eventos por atividade (`1 − n_inc / n_ref`), o sinal de
  fila/represamento que não aparece na mediana quando as requisições somem em vez de ficarem lentas.
- **sumiço por atividade**: atividade com eventos na referência e nenhum na janela — a d9 já tem isto
  por **serviço** (`d9.sumidos`); aqui é por **atividade**, para uma rota que parou de responder.

A decisão (quando abrir o alarme) continua sendo a da d5, chamada como utilitário; nenhum resultado
gravado de outro modo é lido. Sem artefato de baseline: as referências são da própria
sessão.
"""
from __future__ import annotations

import statistics
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import causal, referencia
from src.application.stage3.abordagens import d5_portao as d5
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d9-2h"
VERSAO = "d9-2h-v1"

LOCALIZACOES = {"residuo_1": 1.0, "residuo_05": 0.5, "profundo": None}

DEFAULT_CFG: dict[str, Any] = {
    **d5.DEFAULT_CFG,
    "ref_seg_curto": 150,
    "ref_seg_longo": 600,
    "largura_bucket_seg": 30,
    "localizacao": "residuo_1",
    "dependencias_sem_span": {"mysql": "teastore-db"},
}

MOTIVOS = {"sem_servico_significativo": "o portão abriu, mas nenhum canal apontou um serviço"}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


# --- inclinação robusta (Theil–Sen) ---


def _slope(pares: list[tuple[float, float]], maximo_pares: int = 2000) -> float:
    """Inclinação robusta por Theil–Sen: mediana das inclinações entre pares.

    `pares` é `(t, valor)`. Quando são muitos, amostra de forma determinística para não virar O(n²) num
    serviço com milhares de eventos; a mediana das inclinações entre pares resiste a um intervalo
    atípico, que é o ponto (o plano do modo pede robustez, não a inclinação mais provável).
    """
    if len(pares) < 2:
        return 0.0
    ordenados = sorted(pares)
    if len(ordenados) > maximo_pares:
        passo = len(ordenados) / maximo_pares
        ordenados = [ordenados[int(i * passo)] for i in range(maximo_pares)]
    inclinacoes: list[float] = []
    for i in range(len(ordenados)):
        ti, vi = ordenados[i]
        for j in range(i + 1, len(ordenados)):
            tj, vj = ordenados[j]
            if tj > ti:
                inclinacoes.append((vj - vi) / (tj - ti))
    return statistics.median(inclinacoes) if inclinacoes else 0.0


def _slope_relativo(eventos: list[Any], servico: str, largura_s: float) -> dict[str, float]:
    """Por atividade do serviço: inclinação (relativa à mediana) da mediana por intervalo."""
    por_ativ: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for evento in eventos:
        if referencia._servico(evento) != servico:
            continue
        atividade = referencia._atividade(evento)
        if atividade:
            por_ativ[atividade].append((referencia._inicio(evento) / 1e6, referencia._duracao(evento)))
    saida: dict[str, float] = {}
    for atividade, pares in por_ativ.items():
        if len(pares) < 3:
            continue
        inicio = min(t for t, _ in pares)
        buckets: dict[int, list[float]] = defaultdict(list)
        for t, v in pares:
            buckets[int((t - inicio) // largura_s)].append(v)
        serie = [(float(b), statistics.median(vs)) for b, vs in sorted(buckets.items()) if vs]
        base = statistics.median([v for _, v in pares])
        if base > 0:
            saida[atividade] = _slope(serie) / base * largura_s
    return saida


def _vazao(inc_stats: dict[str, Any], ref_stats: dict[str, Any]) -> dict[str, float]:
    """Queda relativa de contagem por atividade presente na referência (`1 − n_inc/n_ref`)."""
    inc_ativ = inc_stats.get("ativ") or {}
    saida: dict[str, float] = {}
    for atividade, iref in (ref_stats.get("ativ") or {}).items():
        n_ref = int(iref.get("n") or 0)
        if n_ref > 0:
            saida[atividade] = 1.0 - int((inc_ativ.get(atividade) or {}).get("n") or 0) / n_ref
    return saida


def _sumidos_por_atividade(inc_stats: dict[str, Any], ref_stats: dict[str, Any], minimo: int) -> set[str]:
    inc_ativ = inc_stats.get("ativ") or {}
    return {a for a, iref in (ref_stats.get("ativ") or {}).items()
            if int(iref.get("n") or 0) >= minimo and a not in inc_ativ}


# --- ranking ---


def canais(entrada: EntradaIncidente, inc: dict[str, Any], ref_curto: dict[str, Any],
           ref_longo: dict[str, Any], cfg: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Por atividade: `efeito` (curto), `cronico` (longo), `inclinacao` e `vazao`."""
    efeito_curto = {e["atividade"]: referencia.escore_efeito(e) - 1.0
                    for e in referencia.efeitos_por_atividade(inc, ref_curto, cfg=cfg)}
    efeito_longo = {e["atividade"]: referencia.escore_efeito(e) - 1.0
                    for e in referencia.efeitos_por_atividade(inc, ref_longo, cfg=cfg)}
    inclinacao: dict[str, float] = {}
    largura = float(cfg["largura_bucket_seg"])
    for servico in sorted({referencia._servico(e) for e in entrada.traces}):
        inclinacao.update(_slope_relativo(list(entrada.traces), servico, largura))
    return {"efeito": efeito_curto, "cronico": efeito_longo, "inclinacao": inclinacao,
            "vazao": _vazao(inc, ref_longo)}


def _servico_da_atividade(atividade: str, inc: dict[str, Any], ref_longo: dict[str, Any],
                          deps: dict[str, str] | None = None) -> str:
    """Dono da atividade; span cliente de banco (`dependencias_sem_span`) vai para o banco, como na d9."""
    if deps and atividade in deps:
        return deps[atividade]
    info = (inc.get("ativ") or {}).get(atividade) or (ref_longo.get("ativ") or {}).get(atividade)
    return str(info.get("servico")) if info and info.get("servico") else ""


def _filhos(entrada: EntradaIncidente, cfg: dict[str, Any]) -> dict[str, set[str]]:
    deps = causal.dependencias_por_atividade(entrada.traces, cfg.get("dependencias_sem_span") or {})
    return d6.grafo_de_servicos(list(entrada.traces), deps)


def ranquear(entrada: EntradaIncidente, inc: dict[str, Any], ref_curto: dict[str, Any],
             ref_longo: dict[str, Any], cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """`{servico, s, r, ...}`: maior canal por serviço, com resíduo do grafo como na d9."""
    canais_ativ = canais(entrada, inc, ref_curto, ref_longo, cfg)
    deps = causal.dependencias_por_atividade(list(entrada.traces) + list(entrada.traces_lookback),
                                             cfg.get("dependencias_sem_span") or {})
    linhas: dict[str, dict[str, Any]] = {}
    for nome_canal, por_ativ in canais_ativ.items():
        for atividade, valor in por_ativ.items():
            servico = _servico_da_atividade(atividade, inc, ref_longo, deps)
            if not servico:
                continue
            atual = linhas.get(servico)
            if atual is None or float(valor) > atual["s"]:
                linhas[servico] = {"servico": servico, "s": max(0.0, float(valor)),
                                   "atividade": atividade, "canal": nome_canal}
    for atividade in _sumidos_por_atividade(inc, ref_longo, int(cfg["min_eventos_atividade"])):
        servico = _servico_da_atividade(atividade, inc, ref_longo, deps)
        if servico:
            lin = linhas.setdefault(servico, {"servico": servico, "s": 0.0, "atividade": atividade})
            lin["s"], lin["sumiu"] = max(lin["s"], 1.0), True
    filhos = _filhos(entrada, cfg)
    alfa = LOCALIZACOES[str(cfg["localizacao"])]
    for lin in linhas.values():
        desc = d6._descendentes(lin["servico"], filhos) & set(linhas)
        max_desc = max((linhas[d]["s"] for d in desc), default=0.0)
        lin["r"] = max(0.0, lin["s"] - (alfa if alfa is not None else 0.0) * max_desc)
        lin["fronteira"] = not any(linhas[d]["s"] > 0 for d in desc)
    if alfa is None:
        def chave(lin: dict[str, Any]) -> tuple[bool, float, float, str]:
            return (not lin["fronteira"], -lin["s"], 0.0, lin["servico"])
    else:
        def chave(lin: dict[str, Any]) -> tuple[bool, float, float, str]:
            return (lin["r"] <= 0, -lin["r"], -lin["s"], lin["servico"])
    return sorted(linhas.values(), key=chave)


def decidir_de_medida(entrada: EntradaIncidente, medida: dict[str, Any], inc: dict[str, Any],
                      ref_curto: dict[str, Any], ref_longo: dict[str, Any],
                      cfg: dict[str, Any]) -> Decisao:
    """O portão da d5; se abrir, o ranking por dois horizontes (mesma função no avaliador sequencial)."""
    cfg = _cfg(cfg)
    portao = d5.decidir_de_medida(medida, cfg)
    parametros = {**(portao.parametros or {}), "ref_seg_curto": cfg["ref_seg_curto"],
                  "ref_seg_longo": cfg["ref_seg_longo"], "localizacao": cfg["localizacao"]}
    if portao.status != "decidiu":
        return Decisao(status=portao.status, motivo_abstencao=portao.motivo_abstencao,
                       evidencias=portao.evidencias, parametros=parametros, versao=VERSAO)
    linhas = ranquear(entrada, inc, ref_curto, ref_longo, cfg)
    if not linhas:
        return Decisao(status="absteve", motivo_abstencao="sem_servico_significativo",
                       evidencias=portao.evidencias, parametros=parametros, versao=VERSAO)
    ranking = [ItemRanking(
        servico=lin["servico"],
        escore=-float(lin["r"] if cfg["localizacao"] != "profundo" else lin["s"]),
        evidencias={k: v for k, v in lin.items() if k != "servico"}) for lin in linhas]
    return Decisao(status="decidiu", ranking=ranking, evidencias=portao.evidencias,
                   parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    servicos_raiz = d5._entradas(entrada, cfg)
    ref_curto_ev = referencia.eventos_referencia(entrada, {**cfg, "ref_seg": cfg["ref_seg_curto"]})
    ref_longo_ev = referencia.eventos_referencia(entrada, {**cfg, "ref_seg": cfg["ref_seg_longo"]})
    inc = referencia.estatisticas(entrada.traces, servicos_raiz=servicos_raiz)
    ref_curto = referencia.estatisticas(ref_curto_ev, servicos_raiz=servicos_raiz)
    ref_longo = referencia.estatisticas(ref_longo_ev, servicos_raiz=servicos_raiz)
    medida = {"n_traces": len({getattr(e, "case_id", None) for e in entrada.traces}),
              "n_eventos_ref": len(ref_curto_ev), **d5.medir(inc, ref_curto, cfg)}
    return decidir_de_medida(entrada, medida, inc, ref_curto, ref_longo, cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "limiares_por_validacao_cruzada"},
            "n_eventos_normais": len(traces_normais),
            "cfg": {k: cfg[k] for k in ("limiar", "limiar_erro", "ref_seg_curto", "ref_seg_longo")}}


class _ModoHorizontes:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoHorizontes()
