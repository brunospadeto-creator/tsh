"""d4 — modelo estocástico de processo.

Pergunta: *quais serviços passaram a produzir eventos **improváveis** sob o comportamento estocástico
normal?*

Modelo, aprendido só no normal:

- por atividade-pai `a`, a distribuição do **padrão de filhas** de cada span de `a` (multiconjunto
  ordenado das atividades chamadas; folha = padrão vazio) — a linguagem estocástica de cada nó;
- por atividade `x`, a distribuição da **faixa de duração própria**;
- suavização de Laplace (valor nunca visto recebe probabilidade mínima, não zero).

Escore BINet de um valor observado: `σ(p, p_v) = Σ_{p_i > p_v} p_i`. Evento de padrão pertence ao
serviço do pai (quem decidiu chamar); evento de duração, ao serviço da atividade.

Duas decisões de 2026-10-03, as duas medidas sem caso de falha:

- **Faixas com cauda.** Com 10 faixas por decis, toda faixa tem p ≈ 0,1 e `σ` vale 0 para qualquer
  duração, inclusive a extrema — o escore de tempo não dispara nunca. As faixas passam a ser cortadas
  nos quantis 1/5/25/50/75/95/99%: as caudas ficam com p ≈ 0,01 e `σ` ≈ 0,98.
- **p por intervalo de predição**, não p empírico: com ~9 janelas normais o p empírico mínimo é
  1/10, que nunca passa num BH entre serviços. O p vem de `est.predicao` da média de `σ` do serviço
  contra as médias das janelas normais (validação cruzada: cada janela pontuada por um modelo que
  não a contém).

Gate de endpoint (entropic relevance, Polyvyanyy et al.): bits médios por trace
`−Σ log₂ P(padrão) − Σ log₂ P(faixa)` — o modelo é padrões + faixas, e os dois entram.
Se nenhum endpoint do incidente passar do quantil `1 − fp_alvo` das janelas normais, abstém
(`comportamento_estocastico_normal`).
"""
from __future__ import annotations

import bisect
import datetime
import math
from collections import Counter, defaultdict
from collections.abc import Sequence
from typing import Any

import numpy as np

from src.application.stage3.abordagens import calibracao as _calibracao
from src.application.stage3.abordagens import estatistica as est
from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d4"
VERSAO = "d4-v1"

DEFAULT_CFG: dict[str, Any] = {
    "min_traces": 30,
    "tamanho_janela_seg": 300,
    "laplace": 1.0,
    "min_eventos_servico": 20,
}
CORTES_FAIXA = (0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99)
MIN_AMOSTRAS_FAIXA = 20


def _cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


# --- features por trace (calculadas uma vez) ---


def _padrao(filhos: Sequence[Any]) -> str:
    return " | ".join(f"{a}×{n}" for a, n in est.assinatura_multiconjunto([str(f.activity) for f in filhos]))


def features(sequencia: Sequence[Any]) -> dict[str, Any]:
    """Início, endpoint, `[(pai, padrão, serviço_pai)]` e `[(atividade, duração_própria, serviço)]`."""
    ordenados = proc.ordenar(sequencia)
    filhos: dict[str, list[Any]] = defaultdict(list)
    for evento in ordenados:
        pai = proc.pai_de(evento, ordenados)
        if pai is not None:
            filhos[str(pai.span_id)].append(evento)
    raiz = min(ordenados, key=lambda e: (int(e.depth), int(e.start_us)))
    padroes = []
    duracoes = []
    for evento in ordenados:
        meus = filhos.get(str(evento.span_id), [])
        padroes.append((str(evento.activity), _padrao(meus), str(evento.service)))
        propria = max(0, int(evento.duration_us) - sum(int(f.duration_us) for f in meus))
        duracoes.append((str(evento.activity), propria, str(evento.service)))
    return {"inicio": min(int(e.start_us) for e in ordenados), "endpoint": str(raiz.activity),
            "padroes": padroes, "duracoes": duracoes}


def features_de(eventos: Sequence[Any]) -> list[dict[str, Any]]:
    return [features(s) for s in proc.sequencias_por_trace(list(eventos)).values() if s]


# --- modelo ---


def modelo(feats: Sequence[dict[str, Any]], laplace: float) -> dict[str, Any]:
    padroes: dict[str, Counter[str]] = defaultdict(Counter)
    duracoes: dict[str, list[int]] = defaultdict(list)
    for f in feats:
        for pai, padrao, _ in f["padroes"]:
            padroes[pai][padrao] += 1
        for atividade, valor, _ in f["duracoes"]:
            duracoes[atividade].append(valor)
    faixas: dict[str, dict[str, Any]] = {}
    for atividade, valores in duracoes.items():
        if len(valores) < MIN_AMOSTRAS_FAIXA:
            continue
        limites = [float(np.percentile(valores, 100 * c)) for c in CORTES_FAIXA]
        contagem = Counter(bisect.bisect_right(limites, v) for v in valores)
        faixas[atividade] = {"limites": limites, "contagem": [contagem.get(i, 0) for i in range(len(limites) + 1)]}
    return {"padroes": {a: dict(c) for a, c in padroes.items()}, "faixas": faixas, "laplace": laplace}


def _sigma(contagens: Sequence[float], indice: int | None, laplace: float) -> tuple[float, float]:
    """`(σ, p_v)` com Laplace. `indice=None` = valor nunca visto (um balde extra com só o Laplace)."""
    total = sum(contagens) + laplace * (len(contagens) + 1)
    probs = [(c + laplace) / total for c in contagens]
    p_v = laplace / total if indice is None else probs[indice]
    return sum(p for p in probs if p > p_v), p_v


def pontuar(feats: Sequence[dict[str, Any]], mod: dict[str, Any]) -> dict[str, Any]:
    """Por serviço: lista de σ; por endpoint: bits por trace (entropic relevance)."""
    laplace = float(mod["laplace"])
    por_servico: dict[str, list[float]] = defaultdict(list)
    piores: dict[str, list[tuple[float, str, str]]] = defaultdict(list)
    bits: dict[str, list[float]] = defaultdict(list)
    for f in feats:
        b = 0.0
        for pai, padrao, servico in f["padroes"]:
            conhecidos = mod["padroes"].get(pai)
            if not conhecidos:
                continue  # pai sem modelo: nada a dizer sobre ele
            nomes = sorted(conhecidos)
            indice = nomes.index(padrao) if padrao in conhecidos else None
            s, p_v = _sigma([conhecidos[n] for n in nomes], indice, laplace)
            por_servico[servico].append(s)
            b -= math.log2(p_v)
            if s > 0.9:
                piores[servico].append((s, pai, padrao or "(folha)"))
        for atividade, valor, servico in f["duracoes"]:
            faixa = mod["faixas"].get(atividade)
            if not faixa:
                continue
            s, p_v = _sigma(faixa["contagem"], bisect.bisect_right(faixa["limites"], valor), laplace)
            por_servico[servico].append(s)
            b -= math.log2(p_v)  # o modelo estocástico é padrões + faixas: os dois entram nos bits
        bits[f["endpoint"]].append(b)
    return {"servicos": dict(por_servico), "bits": dict(bits),
            "piores": {s: sorted(v, reverse=True)[:5] for s, v in piores.items()}}


def _media(valores: Sequence[float]) -> float:
    return sum(valores) / len(valores) if valores else 0.0


# --- artefato ---


def construir_artefato(traces_normais: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Modelo do normal + nulos por janela (cada janela pontuada por um modelo que não a contém)."""
    cfg = _cfg(cfg)
    feats = features_de(traces_normais)
    mod = modelo(feats, float(cfg["laplace"]))
    nulo_servico: dict[str, list[float]] = defaultdict(list)
    nulo_bits: dict[str, list[float]] = defaultdict(list)
    if feats:
        tamanho = int(float(cfg["tamanho_janela_seg"]) * 1e6)
        primeiro = min(f["inicio"] for f in feats)
        ultimo = max(f["inicio"] for f in feats)
        inicio = primeiro
        while inicio + tamanho <= ultimo + 1:
            dentro = [f for f in feats if inicio <= f["inicio"] < inicio + tamanho]
            fora = [f for f in feats if not inicio <= f["inicio"] < inicio + tamanho]
            if len(dentro) >= int(cfg["min_traces"]) and fora:
                r = pontuar(dentro, modelo(fora, float(cfg["laplace"])))
                for servico, valores in r["servicos"].items():
                    if len(valores) >= int(cfg["min_eventos_servico"]):
                        nulo_servico[servico].append(_media(valores))
                for endpoint, valores in r["bits"].items():
                    nulo_bits[endpoint].append(_media(valores))
            inicio += tamanho // 2
    return {"modo": NOME, "versao": VERSAO, "modelo": mod,
            "nulo_servico": dict(nulo_servico), "nulo_bits": dict(nulo_bits)}


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    cfg = _cfg(cfg)
    artefato = construir_artefato(traces_normais, cfg)
    if not janelas:
        janelas = _calibracao.janelas_de_normal(
            traces_normais, datetime.timedelta(seconds=float(cfg["tamanho_janela_seg"])))
    artefato["calibracao"] = _calibracao.calibrar_cruzado(
        lambda fora: construir_artefato(fora, cfg), decidir, traces_normais, list(janelas), cfg,
        fp_alvo=float(cfg.get("fp_alvo") or 0.05),
    )
    return artefato


# --- decisão ---


def _limite_gate(nulos: Sequence[float], fp_alvo: float) -> float | None:
    if len(nulos) < 3:
        return None
    ordenados = sorted(nulos)
    pos = min(len(ordenados) - 1, max(0, math.ceil((1.0 - fp_alvo) * len(ordenados)) - 1))
    return ordenados[pos]


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    cfg = _cfg(cfg)
    artefato = artefato or {}
    q = _calibracao.q_do_artefato(artefato, cfg)
    fp_alvo = float((artefato.get("calibracao") or {}).get("fp_alvo") or cfg.get("fp_alvo") or 0.05)
    parametros = {"q": q, "fp_alvo": fp_alvo, "cortes_faixa": list(CORTES_FAIXA)}
    mod = artefato.get("modelo")
    feats = features_de(entrada.traces)
    if not mod or len(feats) < int(cfg["min_traces"]):
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_traces": len(feats)}, parametros=parametros)

    r = pontuar(feats, mod)
    # gate de endpoint: entropic relevance acima do quantil 1 − fp_alvo das janelas normais
    gate: dict[str, Any] = {}
    for endpoint, valores in r["bits"].items():
        limite = _limite_gate((artefato.get("nulo_bits") or {}).get(endpoint) or [], fp_alvo)
        if limite is not None and valores:
            gate[endpoint] = {"bits": _media(valores), "limite": limite, "fora": _media(valores) > limite}
    evidencias: dict[str, Any] = {"n_traces": len(feats), "gate": gate}
    if not any(g["fora"] for g in gate.values()):
        return Decisao(status="absteve", motivo_abstencao="comportamento_estocastico_normal",
                       versao=VERSAO, evidencias=evidencias, parametros=parametros)

    testes: list[dict[str, Any]] = []
    for servico, valores in sorted(r["servicos"].items()):
        if len(valores) < int(cfg["min_eventos_servico"]):
            continue
        nulos = (artefato.get("nulo_servico") or {}).get(servico) or []
        t = est.predicao(_media(valores), nulos, alternative="greater")
        if t is not None:
            testes.append({"servico": servico, "media": _media(valores), "media_normal": _media(nulos),
                           "n_eventos": len(valores), "n_janelas_nor": t.n, "p": t.p})
    if not testes:
        return Decisao(status="absteve", motivo_abstencao="sem_servico_significativo", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)
    ajustados, significativos = est.benjamini_hochberg([t["p"] for t in testes], q)
    evidencias["p_min_ajustado"] = min(ajustados)
    for teste, p_adj, sig in zip(testes, ajustados, significativos):
        teste["p_ajustado"], teste["significante"] = p_adj, sig
    evidencias["testes"] = testes
    vencedores = [t for t in testes if t["significante"]]
    if not vencedores:
        return Decisao(status="absteve", motivo_abstencao="sem_servico_significativo", versao=VERSAO,
                       evidencias=evidencias, parametros=parametros)
    vencedores.sort(key=lambda t: (t["p_ajustado"], -t["media"], t["servico"]))
    return Decisao(
        status="decidiu",
        ranking=[ItemRanking(servico=t["servico"], escore=t["p_ajustado"], p_valor=t["p_ajustado"],
                             evidencias={"media_sigma": t["media"], "media_normal": t["media_normal"],
                                         "piores": r["piores"].get(t["servico"], [])})
                 for t in vencedores],
        evidencias=evidencias, parametros=parametros, versao=VERSAO,
    )


class _ModoD4:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD4()
