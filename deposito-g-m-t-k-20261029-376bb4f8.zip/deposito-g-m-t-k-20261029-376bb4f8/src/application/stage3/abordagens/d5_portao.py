"""d5 — portão de detecção por referência da mesma sessão.

Ideias 7 + 1 + 2 do dossiê. A pergunta é *"há algo agora que se afasta do normal recente desta sessão, com
tamanho que importa (e dano ao usuário, se ligado)?"* — não *"difere da baseline de outro dia?"*: contra
outro dia, a deriva normal entre sessões é de 3–4× e tudo parece anômalo.

- **Referência** (`referencia.eventos_referencia`): `ref_modo = "lookback"` (produto e avaliação oficial)
  usa os `ref_seg` segundos imediatamente antes da janela; `"janela_inicial"` só para diagnóstico.
  `referencia_fixa` (opcional, na cfg) força uma janela de referência: é como o avaliador sequencial
  congela a referência durante um alarme — o `decidir()` continua sem estado.
- **Portão** (ideia 1, limiar relativo à Weber): abre se alguma atividade tem mediana de duração ≥
  `limiar`× a da referência **ou** taxa de erro ≥ `limiar_erro` acima.
- **Segundo sinal** (ideia 2, opcional): com `limiar_dano_lat` ligado, só decide se a entrada (raízes do
  serviço de entrada) também piorou — sem dano, o alarme é suprimido.
- **Ranking**: serviços pelo maior efeito relativo (`referencia.ranking_por_efeito`), só os que passaram
  do portão. É localização de primeira ordem; a localização fina é da d6/d7.

Sem artefato de baseline: a referência é sempre da própria sessão. Os limiares são escolhidos por
validação cruzada em desenvolvimento, não calibrados por `q`.
"""
from __future__ import annotations

import datetime
from typing import Any

from src.application.stage3.abordagens import processo as proc
from src.application.stage3.abordagens import referencia
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente, ItemRanking

NOME = "d5"
VERSAO = "d5-v1"

DEFAULT_CFG: dict[str, Any] = {
    **referencia.DEFAULT_CFG,
    "ref_modo": "lookback",
    "limiar": 1.5,              # razão de mediana por atividade
    "limiar_erro": 0.05,        # aumento absoluto da taxa de erro
    "limiar_dano_lat": None,    # None = segundo sinal desligado; senão razão na entrada
    "limiar_dano_err": 0.02,
    "min_traces": 30,
    "referencia_fixa": None,    # (inicio, fim) ISO ou datetime: referência travada pelo avaliador
}

MOTIVOS = {
    "sem_referencia_recente": "a janela não tem referência da própria sessão utilizável",
    "portao_fechado": "nenhum efeito passou do limiar relativo",
    "sem_dano_na_entrada": "efeito presente, mas sem dano ao usuário na entrada",
}


def _cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return {**DEFAULT_CFG, **{k: v for k, v in (cfg or {}).items() if v is not None}}


def _dt(valor: Any) -> datetime.datetime:
    if isinstance(valor, datetime.datetime):
        return valor
    dt = datetime.datetime.fromisoformat(str(valor).replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=datetime.UTC)


def _entradas(entrada: EntradaIncidente, cfg: dict[str, Any]) -> list[str]:
    return list(cfg.get("entry_services") or (entrada.config_sistema or {}).get("entry_services") or [])


def _eventos_ref(entrada: EntradaIncidente, cfg: dict[str, Any]) -> list[Any]:
    fixa = cfg.get("referencia_fixa")
    if fixa:
        janela = (_dt(fixa[0]), _dt(fixa[1]))
        return proc.cortar_janela(list(entrada.traces_lookback) + list(entrada.traces), janela)
    return referencia.eventos_referencia(entrada, cfg)


def medir(inc: dict[str, Any], ref: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Efeitos e dano a partir das estatísticas já calculadas (`referencia.estatisticas`).

    Separado de `avaliar` para o avaliador sequencial reaproveitar as estatísticas entre instantes e
    combinações de parâmetro sem duplicar a regra.
    """
    efeitos = referencia.efeitos_por_atividade(inc, ref, cfg=cfg)
    passou = [e for e in efeitos
              if e["ratio_mediana"] >= float(cfg["limiar"]) or e["delta_erro"] >= float(cfg["limiar_erro"])]
    dano = referencia.dano_na_entrada(inc, ref, cfg) if cfg.get("limiar_dano_lat") is not None else None
    return {"efeitos": efeitos, "passou": passou, "dano": dano}


def avaliar(entrada: EntradaIncidente, cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """Medidas do portão, sem decidir."""
    cfg = _cfg(cfg)
    servicos_raiz = _entradas(entrada, cfg)
    ref_eventos = _eventos_ref(entrada, cfg)
    inc = referencia.estatisticas(entrada.traces, servicos_raiz=servicos_raiz)
    ref = referencia.estatisticas(ref_eventos, servicos_raiz=servicos_raiz)
    return {"n_traces": len({getattr(e, "case_id", None) for e in entrada.traces}),
            "n_eventos_ref": len(ref_eventos), **medir(inc, ref, cfg)}


def decidir_de_medida(medida: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    """A regra de decisão sobre uma medida pronta (a mesma em `decidir` e no avaliador sequencial)."""
    cfg = _cfg(cfg)
    parametros = {k: cfg[k] for k in ("limiar", "limiar_erro", "limiar_dano_lat", "limiar_dano_err",
                                      "ref_seg", "ref_modo")}
    if medida["n_traces"] < int(cfg["min_traces"]):
        return Decisao(status="absteve", motivo_abstencao="poucos_traces", versao=VERSAO,
                       evidencias={"n_traces": medida["n_traces"]}, parametros=parametros)
    evid: dict[str, Any] = {"n_traces": medida["n_traces"], "n_eventos_ref": medida["n_eventos_ref"],
                            "efeitos_no_portao": medida["passou"][:20], "dano": medida["dano"]}
    if not medida["efeitos"]:
        return Decisao(status="absteve", motivo_abstencao="sem_referencia_recente", versao=VERSAO,
                       evidencias=evid, parametros=parametros)
    if not medida["passou"]:
        return Decisao(status="absteve", motivo_abstencao="portao_fechado", versao=VERSAO,
                       evidencias=evid, parametros=parametros)
    if medida["dano"] is not None and not medida["dano"]["abre"]:
        return Decisao(status="absteve", motivo_abstencao="sem_dano_na_entrada", versao=VERSAO,
                       evidencias=evid, parametros=parametros)
    linhas = referencia.ranking_por_efeito(medida["passou"])
    ranking = []
    for i, linha in enumerate(linhas):
        seguinte = linhas[i + 1] if i + 1 < len(linhas) else None
        ranking.append(ItemRanking(
            servico=linha["servico"], escore=-float(linha["escore"]),
            evidencias={**linha, "empate_com_seguinte": bool(seguinte and seguinte["escore"] == linha["escore"])},
        ))
    return Decisao(status="decidiu", ranking=ranking, evidencias=evid, parametros=parametros, versao=VERSAO)


def decidir(entrada: EntradaIncidente, artefato: dict[str, Any], cfg: dict[str, Any]) -> Decisao:
    return decidir_de_medida(avaliar(entrada, cfg), cfg)


def preparar_baseline(traces_normais: list[Any], janelas: list[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Sem artefato de baseline: a referência é da própria sessão. Guarda só a identidade e a cfg."""
    cfg = _cfg(cfg)
    return {"modo": NOME, "versao": VERSAO, "calibracao": {"metodo": "limiares_por_validacao_cruzada"},
            "n_eventos_normais": len(traces_normais), "cfg": {k: cfg[k] for k in ("limiar", "limiar_erro")}}


class _ModoD5:
    nome = NOME
    versao = VERSAO
    janela_traces = staticmethod(lambda entrada, cfg: entrada.janela)
    preparar_baseline = staticmethod(preparar_baseline)
    decidir = staticmethod(decidir)


MODO = _ModoD5()
