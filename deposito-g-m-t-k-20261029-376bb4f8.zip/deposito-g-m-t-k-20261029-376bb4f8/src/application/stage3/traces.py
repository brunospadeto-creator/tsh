"""Recuperação retroativa de traces no Jaeger.

O Jaeger 1.62 exige `service` em `GET /api/traces` e devolve o trace inteiro de qualquer trace que
tenha um span do serviço consultado iniciando no intervalo. Por isso a busca cobre todos os serviços
instrumentados e une por `traceID`; o filtro de completude monta a árvore de cada requisição.
"""

import datetime
import logging
import re
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

import httpx

from src.application.stage3.entities import normalize_entity, short_service
from src.application.stage3.votes import summarize_raw_traces

logger = logging.getLogger(__name__)

MIN_SPLIT_US = 1_000_000  # não divide intervalos menores que 1 s
DEFAULT_EXCLUDED_SERVICES = ("jaeger-all-in-one", "teastore-registry")


@dataclass
class TraceEvent:
    """Um span no formato de event log de Process Mining."""

    case_id: str
    activity: str
    start_us: int
    duration_us: int
    pod: str
    service: str
    span_id: str
    attributes: dict[str, Any] = field(default_factory=dict)

    @property
    def entity(self) -> str:
        return normalize_entity(self.pod or self.service)

    @property
    def depth(self) -> int:
        return int(self.attributes.get("depth", 0))

    @property
    def is_error(self) -> bool:
        return bool(self.attributes.get("error"))


@dataclass
class TraceEventLog:
    events: list[TraceEvent] = field(default_factory=list)
    n_recovered: int = 0          # traces distintos achados no Jaeger (antes do filtro)
    n_complete_traces: int = 0
    n_orphans_attached: int = 0
    # Traces que `build_trace_events` recusou, por motivo. Não é sóCuriosidade: na F13 o pod do auth fica
    # NotReady, o span `server` do auth não chega, e o span `client` correspondente fica órfão — 302 traces
    # (10,4%) recusados. Antes essa contagem não existia, então a rejeição parecia perda de dado em vez do
    # que é: evidência de que o span do chamador chegou e o do chamado não.
    n_rejected: int = 0
    rejection_reasons: dict[str, int] = field(default_factory=dict)
    query: dict[str, Any] = field(default_factory=dict)
    # resumo de TODOS os traces brutos (inclui parciais) para os votos de localização (votes.py)
    signals: dict[str, Any] = field(default_factory=dict)
    # M8: mesmas grandezas por intervalo da baseline (`service_stats.summarize_extract`) na janela do
    # incidente, para a localização por anomalias (localizacao.py)
    window_stats: dict[str, Any] = field(default_factory=dict)

    # agrupamento por trace, recalculado só quando `events` cresce (só recebe `extend`). Sem o cache,
    # `endpoint_of` reagrupava e reordenava TODOS os eventos a cada chamada -- O(n²) em traces: com 5 min
    # de coleta (~4000 traces) eram ~35 min por incidente, 99% do Stage 3
    _grouped: tuple[int, dict[str, list[TraceEvent]]] | None = field(default=None, repr=False, compare=False)

    def traces(self) -> dict[str, list[TraceEvent]]:
        """Eventos por trace, cada trace em ordem de início (raiz primeiro). Não alterar as listas."""
        if self._grouped is not None and self._grouped[0] == len(self.events):
            return self._grouped[1]
        out: dict[str, list[TraceEvent]] = {}
        for event in self.events:
            out.setdefault(event.case_id, []).append(event)
        for events in out.values():
            events.sort(key=lambda e: (e.start_us, e.depth))
        self._grouped = (len(self.events), out)
        return out

    @staticmethod
    def _endpoint(events: list[TraceEvent]) -> str | None:
        for event in events:
            if event.depth == 0:
                return str(event.attributes.get("operation") or event.activity.split(": ", 1)[-1])
        return None

    def endpoint_of(self, case_id: str) -> str | None:
        """Endpoint = operação do span raiz (depth 0)."""
        return self._endpoint(self.traces().get(case_id, []))

    def traces_by_endpoint(self) -> dict[str, dict[str, list[TraceEvent]]]:
        grouped: dict[str, dict[str, list[TraceEvent]]] = {}
        for case_id, events in self.traces().items():
            endpoint = self._endpoint(events)
            if endpoint is not None:
                grouped.setdefault(endpoint, {})[case_id] = events
        return grouped


class JaegerClient:
    """Cliente mínimo da query API do Jaeger (`/api/services`, `/api/traces`).

    O Jaeger all-in-one com Badger fica lento (ou derruba a conexão) durante as compactações, então cada
    requisição é retentada com espera crescente em erro de transporte (timeout, conexão resetada) e em 5xx.
    Erros 4xx não são retentados. Esgotadas as tentativas, a exceção propaga (retentativa do job).
    """

    RETRY_STATUS = frozenset({500, 502, 503, 504})

    def __init__(
        self,
        base_url: str,
        *,
        client: httpx.Client | None = None,
        timeout: float = 120.0,
        retries: int = 4,
        backoff: float = 3.0,
    ):
        self._base = base_url.rstrip("/")
        self._client = client or httpx.Client(timeout=timeout)
        self._retries = max(1, retries)
        self._backoff = backoff

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        last: Exception | None = None
        for attempt in range(self._retries):
            try:
                resp = self._client.get(f"{self._base}{path}", params=params)
                if resp.status_code in self.RETRY_STATUS and attempt < self._retries - 1:
                    last = httpx.HTTPStatusError(
                        f"HTTP {resp.status_code} em {path}", request=resp.request, response=resp
                    )
                else:
                    resp.raise_for_status()
                    return resp.json()
            except httpx.TransportError as exc:
                if attempt == self._retries - 1:
                    raise
                last = exc
            logger.warning("jaeger %s falhou (%s); tentativa %d/%d", path, last, attempt + 1, self._retries)
            time.sleep(self._backoff * (attempt + 1))
        raise RuntimeError("inalcancavel")  # pragma: no cover

    def services(self) -> list[str]:
        return [str(s) for s in (self._get("/api/services").get("data") or [])]

    def traces(self, service: str, start_us: int, end_us: int, limit: int) -> list[dict[str, Any]]:
        params = {"service": service, "start": start_us, "end": end_us, "limit": limit}
        return list(self._get("/api/traces", params).get("data") or [])


def to_epoch_us(value: datetime.datetime) -> int:
    """Datetime naive (UTC, como o store grava) ou aware → epoch em microssegundos UTC."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=datetime.UTC)
    return int(value.timestamp() * 1_000_000)


def search_traces(
    client: JaegerClient,
    services: list[str],
    start_us: int,
    end_us: int,
    limit: int,
    *,
    min_split_us: int = MIN_SPLIT_US,
) -> tuple[dict[str, dict[str, Any]], int]:
    """Une por `traceID` a busca de cada serviço; divide o intervalo ao meio se bater no `limit`.

    Devolve `(traces, n_splits)`.
    """
    found: dict[str, dict[str, Any]] = {}
    splits = 0

    def _search(service: str, lo: int, hi: int) -> None:
        nonlocal splits
        data = client.traces(service, lo, hi, limit)
        if len(data) >= limit and (hi - lo) > min_split_us:
            splits += 1
            mid = (lo + hi) // 2
            _search(service, lo, mid)
            _search(service, mid, hi)
            return
        for trace in data:
            found.setdefault(str(trace["traceID"]), trace)

    for service in services:
        _search(service, start_us, end_us)
    return found, splits


def _tags(items: list[dict[str, Any]] | None) -> dict[str, Any]:
    return {str(t.get("key")): t.get("value") for t in (items or [])}


def _truthy(value: Any) -> bool:
    return value is True or str(value).lower() == "true"


def _parent_id(span: dict[str, Any]) -> str | None:
    for ref in span.get("references") or []:
        if ref.get("refType") == "CHILD_OF":
            return str(ref.get("spanID"))
    return None


def _exception_message(span: dict[str, Any]) -> str | None:
    for log in span.get("logs") or []:
        fields = _tags(log.get("fields"))
        if fields.get("event") == "exception" or "exception.message" in fields:
            return str(fields.get("exception.message") or fields.get("message") or fields.get("event"))
    return None


def classify_rejection(
    trace: Mapping[str, Any],
    entry_services: Sequence[str],
    entry_operation_regex: str = r"^[A-Z]+ /",
) -> str | None:
    """Por que este trace não serve para modelo de processo, ou `None` se serve.

    Fonte única da regra de aceitação: `build_trace_events` consulta aqui, então a decisão e o motivo não
    divergem. Devolve o motivo em vez de `None` porque a contagem de recusados é evidência, não ruído:

    - `sem_span_de_entrada` — o span `server` do serviço de entrada não chegou.
    - `multiplos_spans_de_entrada` — mais de uma raiz, então não dá para dizer onde o caso começa.
    - `orfao_nao_server:<servicos>` — sobrou span sem pai que não é `server` (típico: o `client` do
      chamador chegou, o `server` do chamado não). É o formato da F13: o auth fica NotReady, o pod não
      atende, e o span `server` do auth nunca é emitido.

    A distinção importa porque as três têm leituras opostas: as duas primeiras são perda de dado ou
    ambiguidade de rastreamento; a terceira é o próprio sintoma da falha, com o.called serviço nomeado.
    """
    processes = trace.get("processes") or {}
    spans = trace.get("spans") or []
    by_id = {str(s["spanID"]): s for s in spans}
    entry_re = re.compile(entry_operation_regex)

    def service_of(span: dict[str, Any]) -> str:
        return str((processes.get(span.get("processID")) or {}).get("serviceName") or "")

    def kind_of(span: dict[str, Any]) -> str:
        return str(_tags(span.get("tags")).get("span.kind") or "")

    parentless = [s for s in spans if (_parent_id(s) is None or _parent_id(s) not in by_id)]
    roots = [
        s for s in parentless
        if kind_of(s) == "server" and service_of(s) in entry_services
        and entry_re.search(str(s.get("operationName")))
    ]
    if not roots:
        return "sem_span_de_entrada"
    if len(roots) > 1:
        return "multiplos_spans_de_entrada"
    root = roots[0]
    orphans = [s for s in parentless if s is not root]
    nao_server = [s for s in orphans if kind_of(s) != "server"]
    if nao_server:
        # serviço do span órfão pelo `processID`; a lista deduplicada e ordenada mantém a chave estável
        # para agregar no `rejection_reasons`.
        alvos = ",".join(sorted({service_of(s) or "?" for s in nao_server}))
        return f"orfao_nao_server:{alvos}"
    return None


def build_trace_events(
    trace: dict[str, Any],
    entry_services: list[str],
    entry_operation_regex: str,
) -> tuple[list[TraceEvent], int] | None:
    """Filtro de completude + árvore de um trace; None se o trace é parcial.

    Devolve `(eventos, n_orfaos_anexados)`.
    """
    trace_id = str(trace["traceID"])
    processes = trace.get("processes") or {}
    spans = trace.get("spans") or []
    by_id = {str(s["spanID"]): s for s in spans}
    entry_re = re.compile(entry_operation_regex)

    def service_of(span: dict[str, Any]) -> str:
        return str((processes.get(span.get("processID")) or {}).get("serviceName") or "")

    def kind_of(span: dict[str, Any]) -> str:
        return str(_tags(span.get("tags")).get("span.kind") or "")

    parentless = [s for s in spans if (_parent_id(s) is None or _parent_id(s) not in by_id)]
    roots = [
        s for s in parentless
        if kind_of(s) == "server" and service_of(s) in entry_services and entry_re.search(str(s.get("operationName")))
    ]
    if classify_rejection(trace, entry_services, entry_operation_regex) is not None:
        return None
    root = roots[0]
    orphans = [s for s in parentless if s is not root]
    if any(kind_of(s) != "server" for s in orphans):
        return None  # órfão que não é `server` (ex.: JDBC sem pai) → trace parcial

    orphan_ids = {str(s["spanID"]) for s in orphans}
    depth: dict[str, int] = {str(root["spanID"]): 0}
    for oid in orphan_ids:
        depth[oid] = 1

    def depth_of(span_id: str, seen: frozenset[str] = frozenset()) -> int | None:
        if span_id in depth:
            return depth[span_id]
        if span_id in seen:
            return None
        parent = _parent_id(by_id[span_id])
        parent_depth = depth_of(parent, seen | {span_id}) if parent else None
        if parent_depth is None:
            return None
        depth[span_id] = parent_depth + 1
        return depth[span_id]

    events: list[TraceEvent] = []
    for span in spans:
        span_id = str(span["spanID"])
        span_depth = depth_of(span_id)
        if span_depth is None:
            return None
        proc = processes.get(span.get("processID")) or {}
        proc_tags = _tags(proc.get("tags"))
        service = service_of(span)
        tags = _tags(span.get("tags"))
        operation = str(span.get("operationName"))
        pod = str(proc_tags.get("k8s.pod.name") or proc_tags.get("host.name") or "")
        events.append(TraceEvent(
            case_id=trace_id,
            activity=f"{short_service(service)}: {operation}",
            start_us=int(span.get("startTime") or 0),
            duration_us=int(span.get("duration") or 0),
            pod=pod or normalize_entity(service),
            service=service,
            span_id=span_id,
            attributes={
                "operation": operation,
                "span.kind": kind_of(span),
                "parent_span_id": _parent_id(span) or (str(root["spanID"]) if span_id in orphan_ids else None),
                "orphan": span_id in orphan_ids,
                "depth": span_depth,
                "error": _truthy(tags.get("error")) or str(tags.get("otel.status_code")) == "ERROR",
                "exception": _exception_message(span),
                "db.system": tags.get("db.system"),
                "db.name": tags.get("db.name"),
            },
        ))
    return events, len(orphan_ids)


def build_event_log(
    raw_traces: dict[str, dict[str, Any]],
    entry_services: list[str],
    entry_operation_regex: str = r"^[A-Z]+ /",
    query: dict[str, Any] | None = None,
) -> TraceEventLog:
    log = TraceEventLog(n_recovered=len(raw_traces), query=query or {})
    for trace in raw_traces.values():
        built = build_trace_events(trace, entry_services, entry_operation_regex)
        if built is None:
            motivo = classify_rejection(trace, entry_services, entry_operation_regex) or "desconhecido"
            log.n_rejected += 1
            log.rejection_reasons[motivo] = log.rejection_reasons.get(motivo, 0) + 1
            continue
        events, n_orphans = built
        log.events.extend(events)
        log.n_complete_traces += 1
        log.n_orphans_attached += n_orphans
    return log


def recover_incident_trace(
    incident_id: str,
    incident_window: tuple[datetime.datetime, datetime.datetime],
    jaeger_endpoint: str,
    entry_services: list[str],
    excluded_services: list[str] | tuple[str, ...] = DEFAULT_EXCLUDED_SERVICES,
    entry_operation_regex: str = r"^[A-Z]+ /",
    trace_limit: int = 200,
    *,
    client: JaegerClient | None = None,
    discovery_service: str | None = None,
    discovery_route_regex: str = r"/services/([^/?]+)",
    discovery_bucket_sec: float = 30.0,
    known_services: list[str] | tuple[str, ...] = (),
) -> TraceEventLog | None:
    """Reconstrói os traces de requisição de usuário com spans na janela do incidente.

    None: o Jaeger respondeu, mas não há nenhum trace na janela. Erro de rede/HTTP propaga
    (retentativa do job).
    """
    jaeger = client or JaegerClient(jaeger_endpoint)
    start_us, end_us = to_epoch_us(incident_window[0]), to_epoch_us(incident_window[1])
    services = [s for s in jaeger.services() if s not in set(excluded_services)]
    raw, n_splits = search_traces(jaeger, services, start_us, end_us, trace_limit)
    logger.info("stage3 %s: %d traces em %d serviços (%d divisões)", incident_id, len(raw), len(services), n_splits)
    if not raw:
        return None
    log = build_event_log(
        raw, entry_services, entry_operation_regex,
        query={
            "window_start": incident_window[0].isoformat(), "window_end": incident_window[1].isoformat(),
            "services": services, "limit": trace_limit, "n_splits": n_splits,
        },
    )
    log.signals = summarize_raw_traces(
        raw, window=incident_window, entry_services=entry_services, entry_operation_regex=entry_operation_regex,
        discovery_service=discovery_service, discovery_route_regex=discovery_route_regex,
        known_services=known_services, bucket_seconds=discovery_bucket_sec,
    ).to_dict()
    from src.application.stage3.service_stats import extract, summarize_extract

    log.window_stats = summarize_extract(extract(
        raw, [incident_window], entry_services=entry_services, entry_operation_regex=entry_operation_regex,
        discovery_service=discovery_service, discovery_route_regex=discovery_route_regex,
        known_services=known_services, bucket_seconds=discovery_bucket_sec,
    ))
    return log
