"""Nome de entidade do Stage 3: a chave é o pod normalizado (sem hash de ReplicaSet/ordinal)."""

from src.pipeline.s4_representation import _strip_pod_suffix


def normalize_entity(name: str) -> str:
    return _strip_pod_suffix(name)


def short_service(service: str) -> str:
    """Serviço sem o prefixo `teastore-` (usado no nome das atividades)."""
    return service.removeprefix("teastore-")


def sanitize_evidence_id(text: str) -> str:
    """Remove `[`/`]` de um id de evidência do Stage 3.

    Alguns nomes de atividade do TeaStore trazem o padrão JAX-RS bruto (ex.
    `"persistence: GET .../categories/{id:[0-9][0-9]*}"`). Como o id de uma evidência é citado
    entre colchetes no prompt (`[tmp:<id>]`), um `]` dentro do próprio id trunca a extração antes
    da hora — achado real ao rodar o lote F1-F14 (3 dos 14 cenários abstiveram por
    `invalid_llm_output` com esse padrão exato de id truncado). `problem_map.py::_edge_evidence`
    reconstrói o mesmo id a partir do mesmo texto bruto — sanitizar aqui, usado nos dois lugares,
    mantém os dois lados em sincronia.
    """
    return text.replace("[", "(").replace("]", ")")
