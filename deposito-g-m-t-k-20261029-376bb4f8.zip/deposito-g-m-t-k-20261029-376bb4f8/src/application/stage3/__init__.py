"""Stage 3 — investigação detalhada de incidentes."""
