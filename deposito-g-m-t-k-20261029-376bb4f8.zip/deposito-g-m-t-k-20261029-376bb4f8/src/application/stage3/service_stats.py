"""Estatísticas por serviço em intervalos de tempo, para a baseline e para a janela do incidente.

A mesma extração (`extract`) roda sobre os traces brutos do Jaeger nos dois lados; o que muda é o resumo:

- baseline (`baseline_service_stats`): a distribuição de cada grandeza entre os intervalos normais
  (mediana, quartis) — é a referência "deste sistema, sob esta carga";
- incidente (`window_service_stats`): a mediana da grandeza entre os intervalos da janela — sustentada por
  construção (um pico isolado não move a mediana).

Grandezas por intervalo de `bucket_seconds`: spans `server` por serviço, respostas HTTP (total, >= 500,
>= 400), spans marcados com erro, raízes de requisição na entrada, presença de cada serviço nos traces de
cada endpoint, consultas de descoberta por alvo e durações por operação.

O grafo de chamadas (`infer_call_edges`) sai dos mesmos traces: a aresta é explícita quando o span tem pai
no trace (o ancestral mais próximo de outro serviço) e inferida por contenção no tempo quando o pai não foi
exportado — o caso do TeaStore, cujos spans `client` HTTP não chegam ao Jaeger.
"""

from __future__ import annotations

import datetime
import math
import re
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from src.application.stage3.entities import normalize_entity, short_service

# Tolerância de relógio para a contenção no tempo: spans de pods em nós diferentes carregam o relógio de
# cada nó. 2 ms cobre o desvio visto entre os nós do minikube e fica abaixo da duração típica de uma chamada.
CONTAINMENT_TOLERANCE_US = 2_000
# Atributos do span client que nomeiam o serviço chamado quando ele não é instrumentado (banco).
_PEER_KEYS = ("peer.service", "server.address", "net.peer.name", "db.name")


def _tags(items: Iterable[Mapping[str, Any]] | None) -> dict[str, Any]:
    return {str(t.get("key")): t.get("value") for t in (items or [])}


def _http_status(tags: Mapping[str, Any]) -> int | None:
    value = tags.get("http.response.status_code", tags.get("http.status_code"))
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _is_error(tags: Mapping[str, Any]) -> bool:
    value = tags.get("error")
    return value is True or str(value).lower() == "true" or str(tags.get("otel.status_code")) == "ERROR"


def _to_us(value: datetime.datetime) -> int:
    if value.tzinfo is None:
        value = value.replace(tzinfo=datetime.UTC)
    return int(value.timestamp() * 1e6)


def _match_known(token: str, known: Iterable[str]) -> str | None:
    tail = str(token).rstrip("/").split(".")[-1].split("/")[-1].lower()
    for service in sorted(known):
        if tail in (service.lower(), short_service(service).lower()):
            return service
    return None


def infer_call_edges(
    trace: Mapping[str, Any], known_services: Iterable[str] = ()
) -> Counter[tuple[str, str, str]]:
    """Arestas `(chamador, chamado, origem)` de um trace; origem = "explicita" | "inferida" | "cliente".

    - explícita: o span `server` tem pai no trace; o chamador é o ancestral mais próximo de outro serviço;
    - inferida: sem pai no trace, o chamador é o span `server` de outro serviço, de menor duração, que o
      contém no tempo (com `CONTAINMENT_TOLERANCE_US`);
    - cliente: span `client` para um serviço sem spans próprios (banco), nomeado pelos atributos de peer.
    """
    processes = trace.get("processes") or {}
    spans = list(trace.get("spans") or [])
    by_id = {str(s.get("spanID")): s for s in spans}
    service_of = {
        sid: normalize_entity(str((processes.get(s.get("processID")) or {}).get("serviceName") or ""))
        for sid, s in by_id.items()
    }
    kind_of = {sid: str(_tags(s.get("tags")).get("span.kind") or "") for sid, s in by_id.items()}
    parent_of: dict[str, str | None] = {}
    for sid, span in by_id.items():
        refs = [r for r in span.get("references") or [] if r.get("refType") == "CHILD_OF"]
        pid = str(refs[0].get("spanID")) if refs else None
        parent_of[sid] = pid if pid in by_id else None
    servers = [sid for sid in by_id if kind_of[sid] == "server" and service_of[sid]]
    known = set(known_services)
    edges: Counter[tuple[str, str, str]] = Counter()
    for sid in servers:
        callee = service_of[sid]
        caller: str | None = None
        origin = ""
        node = parent_of[sid]
        seen: set[str] = set()
        while node is not None and node not in seen:
            seen.add(node)
            if service_of.get(node) and service_of[node] != callee:
                caller, origin = service_of[node], "explicita"
                break
            node = parent_of.get(node)
        if caller is None and parent_of[sid] is None:
            span = by_id[sid]
            start = int(span.get("startTime") or 0)
            end = start + int(span.get("duration") or 0)
            best: tuple[int, str] | None = None
            for other in servers:
                if other == sid or service_of[other] == callee:
                    continue
                o = by_id[other]
                o_start = int(o.get("startTime") or 0)
                o_dur = int(o.get("duration") or 0)
                if (o_start <= start + CONTAINMENT_TOLERANCE_US
                        and o_start + o_dur >= end - CONTAINMENT_TOLERANCE_US and o_dur >= end - start):
                    if best is None or o_dur < best[0]:
                        best = (o_dur, service_of[other])
            if best is not None:
                caller, origin = best[1], "inferida"
        if caller is not None:
            edges[(caller, callee, origin)] += 1
    for sid, span in by_id.items():
        if kind_of[sid] != "client":
            continue
        tags = _tags(span.get("tags"))
        target = next((str(tags[k]) for k in _PEER_KEYS if tags.get(k)), "")
        callee = _match_known(target, known) if target else None
        caller = service_of[sid]
        if callee and caller and callee != caller and callee not in set(service_of.values()):
            edges[(caller, normalize_entity(callee), "cliente")] += 1
    return edges


@dataclass
class Extract:
    """Grandezas por intervalo; listas indexadas pelo intervalo."""

    bucket_seconds: float
    bucket_durations: list[float] = field(default_factory=list)
    server: dict[str, list[int]] = field(default_factory=dict)
    http: dict[str, list[int]] = field(default_factory=dict)
    http5: dict[str, list[int]] = field(default_factory=dict)
    http4: dict[str, list[int]] = field(default_factory=dict)
    erro: dict[str, list[int]] = field(default_factory=dict)
    entry_roots: list[int] = field(default_factory=list)
    # endpoint -> traces por intervalo; (endpoint, serviço) -> traces com o serviço por intervalo
    endpoint_traces: dict[str, list[int]] = field(default_factory=dict)
    endpoint_presence: dict[tuple[str, str], list[int]] = field(default_factory=dict)
    lookups: dict[str, list[int]] = field(default_factory=dict)
    # (serviço, operação) -> [(intervalo, duração em ms)]
    op_durations: dict[tuple[str, str], list[tuple[int, float]]] = field(default_factory=dict)
    # (serviço, operação) -> [(intervalo, duração própria em ms)] — duração do span menos a soma dos filhos
    # diretos, recortada ao próprio span. Sem isso a latência do chamador vem misturada com a do chamado
    # (pendência da Fase 1 do plano de generalização; Etapa E item 2 do plano de rastros).
    op_own_durations: dict[tuple[str, str], list[tuple[int, float]]] = field(default_factory=dict)
    edges: Counter[tuple[str, str, str]] = field(default_factory=Counter)
    services: set[str] = field(default_factory=set)

    @property
    def n_buckets(self) -> int:
        return len(self.bucket_durations)


def _grow(table: dict[Any, list[int]], key: Any, n: int) -> list[int]:
    row = table.get(key)
    if row is None:
        row = table[key] = [0] * n
    return row


def _direct_children_us(spans: Sequence[Mapping[str, Any]], ids: set[str]) -> dict[str, int]:
    """`{spanID pai: soma das durações dos filhos diretos, em µs}`.

    A soma é recortada à duração do próprio span: filhos concorrentes (o webui pede persistence e image ao
    mesmo tempo) se sobrepõem, e somar cru daria tempo negativo. Só conta filhos cujo pai está no trace.
    """
    out: Counter[str] = Counter()
    for span in spans:
        for ref in span.get("references") or []:
            if str(ref.get("refType")) != "CHILD_OF":
                continue
            parent = str(ref.get("spanID"))
            if parent in ids:
                out[parent] += int(span.get("duration") or 0)
    clipped: dict[str, int] = {}
    for span in spans:
        sid = str(span.get("spanID"))
        total = out.get(sid, 0)
        if total:
            clipped[sid] = min(total, int(span.get("duration") or 0))
    return clipped


def extract(
    raw_traces: Mapping[str, Mapping[str, Any]] | Iterable[Mapping[str, Any]],
    windows: Sequence[tuple[datetime.datetime, datetime.datetime]],
    *,
    entry_services: Sequence[str],
    entry_operation_regex: str,
    discovery_service: str | None,
    discovery_route_regex: str,
    known_services: Iterable[str] = (),
    bucket_seconds: float = 30.0,
) -> Extract:
    """Grandezas por intervalo sobre os traces cujos spans caem nas `windows` (intervalos concatenados)."""
    traces = list(raw_traces.values()) if isinstance(raw_traces, Mapping) else list(raw_traces)
    out = Extract(bucket_seconds=bucket_seconds)
    offsets: list[tuple[int, int, int]] = []  # (início_us, fim_us, índice do 1º intervalo)
    for w_start, w_end in windows:
        lo, hi = _to_us(w_start), _to_us(w_end)
        n = max(1, math.ceil((hi - lo) / 1e6 / bucket_seconds))
        offsets.append((lo, hi, out.n_buckets))
        for i in range(n):
            b_lo = lo + int(i * bucket_seconds * 1e6)
            out.bucket_durations.append(max(0.0, min(bucket_seconds, (hi - b_lo) / 1e6)))
    nb = out.n_buckets

    def bucket_of(t_us: int) -> int | None:
        for lo, hi, first in offsets:
            if lo <= t_us < hi:
                return min(first + int((t_us - lo) / 1e6 // bucket_seconds), nb - 1)
        return None

    entry = {normalize_entity(s) for s in entry_services}
    entry_re = re.compile(entry_operation_regex)
    route_re = re.compile(discovery_route_regex)
    discovery = normalize_entity(discovery_service) if discovery_service else None
    known = set(known_services)
    for trace in traces:
        processes = trace.get("processes") or {}
        spans = list(trace.get("spans") or [])
        ids = {str(s.get("spanID")) for s in spans}
        children_us = _direct_children_us(spans, ids)
        root_endpoint: str | None = None
        root_bucket: int | None = None
        present: set[str] = set()
        for span in spans:
            service = normalize_entity(str((processes.get(span.get("processID")) or {}).get("serviceName") or ""))
            if not service:
                continue
            start = int(span.get("startTime") or 0)
            b = bucket_of(start)
            if b is None:
                continue
            out.services.add(service)
            present.add(service)
            tags = _tags(span.get("tags"))
            if str(tags.get("span.kind") or "") != "server":
                continue
            _grow(out.server, service, nb)[b] += 1
            if _is_error(tags):
                _grow(out.erro, service, nb)[b] += 1
            status = _http_status(tags)
            if status is not None:
                _grow(out.http, service, nb)[b] += 1
                if status >= 500:
                    _grow(out.http5, service, nb)[b] += 1
                elif status >= 400:
                    _grow(out.http4, service, nb)[b] += 1
            op = str(span.get("operationName") or "")
            dur_ms = int(span.get("duration") or 0) / 1000.0
            out.op_durations.setdefault((service, op), []).append((b, dur_ms))
            # Duração própria: o span menos o que ele passou esperando pelos filhos diretos. Filhos que
            # apontam para um pai fora do trace (o "pai fantasma" do exp-v1.0.0) não entram na conta, então
            # nesse caso a própria cai para a duração total — degradação segura, sem número inventado.
            own_ms = max(0.0, dur_ms - children_us.get(str(span.get("spanID")), 0) / 1000.0)
            out.op_own_durations.setdefault((service, op), []).append((b, own_ms))
            refs = [r for r in span.get("references") or [] if r.get("refType") == "CHILD_OF"]
            parentless = not refs or all(str(r.get("spanID")) not in ids for r in refs)
            if parentless and service in entry and entry_re.search(op) and root_endpoint is None:
                root_endpoint, root_bucket = op, b
            if discovery and service == discovery:
                path = str(tags.get("url.path") or tags.get("http.target") or tags.get("http.url") or "")
                m = route_re.search(path)
                if m:
                    target = _match_known(m.group(1), known | out.services) or m.group(1)
                    _grow(out.lookups, normalize_entity(target), nb)[b] += 1
        if root_endpoint is not None and root_bucket is not None:
            if not out.entry_roots:
                out.entry_roots = [0] * nb
            out.entry_roots[root_bucket] += 1
            _grow(out.endpoint_traces, root_endpoint, nb)[root_bucket] += 1
            for service in present:
                _grow(out.endpoint_presence, (root_endpoint, service), nb)[root_bucket] += 1
        out.edges.update(infer_call_edges(trace, known | out.services))
    if not out.entry_roots:
        out.entry_roots = [0] * nb
    return out


# Chamadas paralelas do mesmo chamador (o webui pede persistence e image ao mesmo tempo) às vezes caem
# uma dentro da outra no tempo e geram arestas falsas -- que aparecem nas duas direções (na baseline de
# 25 min: persistence->image 566 × image->persistence 1516; auth->image 130 × image->auth 71). A aresta
# fica se for mais frequente que a reversa e se responder por >= 1% das chamadas que o chamado recebe.
# Calibrado na estrutura da baseline, não nas falhas; com spans `client` (M4) as arestas são explícitas.
MIN_EDGE_INBOUND_SHARE = 0.01


def call_graph(edges: Iterable[Sequence[Any]]) -> dict[str, set[str]]:
    """`{chamador: {chamados}}` a partir de `[chamador, chamado, origem, contagem]`, sem ruído de concorrência."""
    counts: Counter[tuple[str, str]] = Counter()
    explicit: set[tuple[str, str]] = set()
    for caller, callee, origin, count in edges:
        counts[(str(caller), str(callee))] += int(count)
        if origin in ("explicita", "cliente"):
            explicit.add((str(caller), str(callee)))
    inbound: Counter[str] = Counter()
    for (_, callee), count in counts.items():
        inbound[callee] += count
    graph: dict[str, set[str]] = defaultdict(set)
    for (caller, callee), count in counts.items():
        if (caller, callee) not in explicit:
            if count <= counts.get((callee, caller), 0):
                continue
            if count < MIN_EDGE_INBOUND_SHARE * inbound[callee]:
                continue
        graph[caller].add(callee)
    return dict(graph)


def reachable(graph: Mapping[str, set[str]], start: str) -> set[str]:
    """Serviços alcançáveis a partir de `start` (chamados diretos e indiretos)."""
    seen: set[str] = set()
    stack = list(graph.get(start, ()))
    while stack:
        node = stack.pop()
        if node in seen or node == start:
            continue
        seen.add(node)
        stack.extend(graph.get(node, ()))
    return seen


# --- resumo ---------------------------------------------------------------------------------------


def _quantile(ordered: Sequence[float], q: float) -> float:
    if not ordered:
        return 0.0
    pos = (len(ordered) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (pos - lo)


def dist(values: Iterable[float]) -> list[float]:
    """`[mediana, q1, q3, n]` de uma amostra."""
    ordered = sorted(float(v) for v in values)
    return [_quantile(ordered, 0.5), _quantile(ordered, 0.25), _quantile(ordered, 0.75), float(len(ordered))]


def _per_full_bucket(row: Sequence[int], durations: Sequence[float], bucket_seconds: float) -> list[float]:
    """Contagem por intervalo normalizada para um intervalo cheio; intervalos com < metade do tamanho saem."""
    return [c * bucket_seconds / d for c, d in zip(row, durations, strict=False) if d >= bucket_seconds / 2]


def _shares(num: Sequence[int], den: Sequence[int]) -> list[float]:
    return [n / d for n, d in zip(num, den, strict=False) if d > 0]


def _op_bucket_medians(samples: Sequence[tuple[int, float]]) -> list[float]:
    by_bucket: dict[int, list[float]] = defaultdict(list)
    for b, ms in samples:
        by_bucket[b].append(ms)
    return [dist(v)[0] for v in by_bucket.values()]


def summarize_extract(ex: Extract) -> dict[str, Any]:
    """Distribuições por intervalo (baseline) ou medianas da janela, no mesmo formato.

    Formato (todas as distribuições são `[mediana, q1, q3, n]`):
    `{"bucket_seconds", "n_buckets",
      "servicos": {serviço: {"spans_por_intervalo", "http_por_intervalo", "http5_fracao", "http4_fracao",
                             "erro_fracao", "consultas_por_intervalo"}},
      "entrada": {"raizes_por_intervalo"},
      "presenca": {serviço: {endpoint: fracao_dist}},
      "operacoes": {"serviço|operação": {"duracao_ms": [...], "duracao_propria_ms": [...],
                                          "mediana_por_intervalo": dist, "mediana_propria_por_intervalo": dist}},
      "arestas": [[chamador, chamado, origem, contagem], ...]}`
    """
    bs, durs = ex.bucket_seconds, ex.bucket_durations
    services: dict[str, dict[str, list[float]]] = {}
    for service in sorted(set(ex.server) | set(ex.lookups)):
        server = ex.server.get(service, [0] * ex.n_buckets)
        http = ex.http.get(service, [0] * ex.n_buckets)
        entry: dict[str, list[float]] = {
            "spans_por_intervalo": dist(_per_full_bucket(server, durs, bs)),
            "http_por_intervalo": dist(_per_full_bucket(http, durs, bs)),
            "http5_fracao": dist(_shares(ex.http5.get(service, [0] * ex.n_buckets), http)),
            "http4_fracao": dist(_shares(ex.http4.get(service, [0] * ex.n_buckets), http)),
            "erro_fracao": dist(_shares(ex.erro.get(service, [0] * ex.n_buckets), server)),
            "consultas_por_intervalo": dist(_per_full_bucket(ex.lookups.get(service, [0] * ex.n_buckets), durs, bs)),
        }
        services[service] = entry
    presence: dict[str, dict[str, list[float]]] = defaultdict(dict)
    for (endpoint, service), row in ex.endpoint_presence.items():
        presence[service][endpoint] = dist(_shares(row, ex.endpoint_traces.get(endpoint, [])))
    ops: dict[str, dict[str, list[float]]] = {}
    for (service, op), samples in ex.op_durations.items():
        own = ex.op_own_durations.get((service, op), [])
        ops[f"{service}|{op}"] = {
            "duracao_ms": dist(ms for _, ms in samples),
            "duracao_propria_ms": dist(ms for _, ms in own) if own else [],
            "mediana_por_intervalo": dist(_op_bucket_medians(samples)),
            "mediana_propria_por_intervalo": dist(_op_bucket_medians(own)) if own else [],
        }
    edges: Counter[tuple[str, str, str]] = ex.edges
    return {
        "bucket_seconds": bs, "n_buckets": ex.n_buckets,
        "servicos": services,
        "entrada": {"raizes_por_intervalo": dist(_per_full_bucket(ex.entry_roots, durs, bs))},
        "presenca": dict(presence),
        "endpoints": {ep: dist(_per_full_bucket(row, durs, bs)) for ep, row in ex.endpoint_traces.items()},
        "operacoes": ops,
        "arestas": [[a, b, o, c] for (a, b, o), c in sorted(edges.items())],
    }


def baseline_service_stats(
    raw_traces: Mapping[str, Mapping[str, Any]] | Iterable[Mapping[str, Any]],
    windows: Sequence[tuple[datetime.datetime, datetime.datetime]],
    cfg: Any,
    known_services: Iterable[str] = (),
) -> dict[str, Any]:
    """`service_stats` da baseline: distribuição de cada grandeza entre os intervalos normais."""
    ex = extract(
        raw_traces, windows, entry_services=list(cfg.entry_services),
        entry_operation_regex=cfg.entry_operation_regex, discovery_service=cfg.discovery_service,
        discovery_route_regex=cfg.discovery_route_regex, known_services=known_services,
        bucket_seconds=float(cfg.discovery_bucket_sec),
    )
    out = summarize_extract(ex)
    out["versao"] = 1
    return out
