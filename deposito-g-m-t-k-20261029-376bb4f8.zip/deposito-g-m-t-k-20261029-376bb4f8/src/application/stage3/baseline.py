"""Baseline do Stage 3: estatísticas de métricas (compute_baseline) e baseline de traces
(collect_trace_baseline): PetriNet, `span_stats` e `service_graph` por endpoint."""

import datetime
import json
import logging
import math
import time
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from src.application.stage3.config import Stage3Config, resolve_config
from src.application.stage3.edges import trace_edges
from src.application.stage3.entities import normalize_entity
from src.application.stage3.traces import (
    JaegerClient,
    TraceEvent,
    build_trace_events,
    search_traces,
    to_epoch_us,
)

logger = logging.getLogger(__name__)

TRACE_SLICE_SECONDS = 30          # fatia de tempo da consulta ao Jaeger (evita respostas gigantes)
QUERY_PAUSE_SECONDS = 0.2         # pausa entre consultas: o Jaeger all-in-one já foi OOMKilled sob rajadas
MAX_TRACES_PER_ENDPOINT = 2000    # teto de traces por endpoint usados no Inductive Miner


class BaselineInsufficientError(Exception):
    """Amostras normais insuficientes (ou sem `metrics_by_entity`) para um baseline válido."""


@dataclass
class CollectionBaseline:
    collection_id: str
    n_samples: int
    computed_at: datetime.datetime | None
    metric_stats: dict[str, dict[str, list[float]]]
    process_models: dict[str, str] = field(default_factory=dict)   # base64 do PNML por endpoint
    span_stats: dict[str, dict[str, list[float]]] = field(default_factory=dict)
    service_graph: dict[str, dict[str, list[float]]] = field(default_factory=dict)
    baseline_id: str = ""
    # M8: distribuição por intervalo de 30 s de cada grandeza por serviço + arestas do grafo de chamadas
    service_stats: dict[str, Any] = field(default_factory=dict)

    def petri_nets(self) -> dict[str, Any]:
        """PetriNets desserializados (PM4Py), por endpoint."""
        from src.application.stage3.process_models import deserialize_petri_net

        return {endpoint: deserialize_petri_net(encoded) for endpoint, encoded in self.process_models.items()}


def load_baseline(collection_id: str, repo: Any) -> CollectionBaseline | None:
    """Baseline pré-computado, só se `status == "completed"`."""
    row = repo.get_collection_baseline(collection_id)
    if row is None or row.status != "completed":
        return None
    return CollectionBaseline(
        collection_id=collection_id, n_samples=int(row.n_samples or 0), computed_at=row.computed_at,
        metric_stats=dict(row.metric_stats or {}), process_models=dict(row.process_models or {}),
        span_stats=dict(row.span_stats or {}), service_graph=dict(row.service_graph or {}),
        baseline_id=row.baseline_id, service_stats=dict(getattr(row, "service_stats", None) or {}),
    )


# --- estatísticas ---


def _percentile(sorted_values: Sequence[float], q: float) -> float:
    """Percentil com interpolação linear (mesmo método do numpy)."""
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    pos = (len(sorted_values) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return float(sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * (pos - lo))


def summarize(values: Sequence[float]) -> list[float]:
    """`[mean, std, min, max, p95, mediana, q1, q3]` (desvio padrão populacional).

    As posições 5-7 (M8) servem ao escore robusto de `localizacao.py`; quem lê só as 5 primeiras não muda.
    """
    ordered = sorted(float(v) for v in values)
    n = len(ordered)
    mean = sum(ordered) / n
    std = math.sqrt(sum((v - mean) ** 2 for v in ordered) / n)
    return [mean, std, ordered[0], ordered[-1], _percentile(ordered, 0.95),
            _percentile(ordered, 0.5), _percentile(ordered, 0.25), _percentile(ordered, 0.75)]


# --- compute_baseline (métricas) ---


def compute_metric_stats(
    samples: Sequence[dict[str, dict[str, float]]], min_baseline_samples: int = 5
) -> tuple[dict[str, dict[str, list[float]]], int]:
    """Estatísticas por entidade (normalizada) × métrica sobre as amostras normais."""
    usable = [s for s in samples if s]
    if len(usable) < min_baseline_samples:
        raise BaselineInsufficientError(
            f"{len(usable)} amostra(s) normal(is) com metrics_by_entity; mínimo {min_baseline_samples} "
            "(pacotes schema 1.0 não têm metrics_by_entity)"
        )
    values: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for sample in usable:
        merged: dict[str, dict[str, float]] = {}
        for entity, metrics in sample.items():
            bucket = merged.setdefault(normalize_entity(entity), {})
            for metric, value in metrics.items():
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    continue
                bucket[metric] = max(number, bucket[metric]) if metric in bucket else number
        for entity, metrics in merged.items():
            for metric, value in metrics.items():
                values[entity][metric].append(value)
    stats = {e: {m: summarize(v) for m, v in metrics.items()} for e, metrics in values.items()}
    return stats, len(usable)


def baseline_failures(collection_id: str, repo: Any) -> list[Any]:
    """Falhas da coleção marcadas como baseline (operação normal — `failures.is_baseline`)."""
    return [f for f in repo.list_failures_by_collection(collection_id) if f.is_baseline]


def _metrics_of(raw: str | None) -> dict[str, dict[str, float]] | None:
    try:
        data = json.loads(raw) if raw else None
    except (json.JSONDecodeError, TypeError):
        return None
    mbe = data.get("metrics_by_entity") if isinstance(data, dict) else None
    return mbe if isinstance(mbe, dict) and mbe else None


def compute_baseline(
    collection_id: str, repo: Any, min_baseline_samples: int = 5
) -> tuple[dict[str, dict[str, list[float]]], int]:
    """Lê os pacotes normais da coleção e calcula `metric_stats` (não persiste).

    Usa os pacotes de evidência (pós-drain); a falha que ainda não foi drenada cai nos pacotes
    **parciais**, que já trazem o mesmo `metrics_by_entity` (o drain só acrescenta templates de log).
    """
    collection = repo.get_collection(collection_id)
    if collection is None:
        raise ValueError(f"collection not found: {collection_id}")
    samples: list[dict[str, dict[str, float]]] = []
    for failure in baseline_failures(collection_id, repo):
        found = [
            m for pkg in repo.list_evidence_packages(collection.system_id, failure.failure_id)
            if (m := _metrics_of(pkg.package_json)) is not None
        ]
        if not found:
            found = [
                m for pkg in repo.list_partial_packages(failure.failure_id)
                if (m := _metrics_of(pkg.partial_package_json)) is not None
            ]
        samples.extend(found)
    return compute_metric_stats(samples, min_baseline_samples)


def _system_config(repo: Any, system_id: str) -> Stage3Config:
    system = repo.get_system(system_id)
    return resolve_config(dict(system.stage3_config or {}) if system else {})


def execute_compute_baseline(system_id: str, payload: dict[str, Any], *, repo: Any) -> dict[str, Any]:
    """Handler do job `compute_baseline`."""
    collection_id = str(payload["collection_id"])
    baseline = repo.get_collection_baseline(collection_id)
    stale = baseline is not None and payload.get("baseline_id") not in (None, baseline.baseline_id)
    if baseline is None or baseline.status != "pending" or stale:
        baseline = repo.create_or_replace_collection_baseline(collection_id, system_id)
    repo.mark_baseline_running(baseline.baseline_id)
    try:
        cfg = _system_config(repo, system_id)
        stats, n_samples = compute_baseline(collection_id, repo, cfg.min_baseline_samples)
    except Exception as exc:
        repo.mark_baseline_failed(baseline.baseline_id, str(exc))
        raise
    repo.mark_baseline_completed(baseline.baseline_id, stats, n_samples)
    return {"baseline_id": baseline.baseline_id, "n_samples": n_samples, "n_entities": len(stats)}


# --- collect_trace_baseline ---


@dataclass
class _EndpointAccumulator:
    n_traces: int = 0
    sequences: list[tuple[str, ...]] = field(default_factory=list)
    durations: dict[str, list[float]] = field(default_factory=lambda: defaultdict(list))
    edge_counts: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))   # por trace
    edge_durations: dict[str, list[float]] = field(default_factory=lambda: defaultdict(list))


def _ordered(events: list[TraceEvent]) -> list[TraceEvent]:
    return sorted(events, key=lambda e: (e.start_us, e.depth, e.span_id))


def _accumulate(acc: dict[str, _EndpointAccumulator], events: list[TraceEvent]) -> None:
    root = next((e for e in events if e.depth == 0), None)
    if root is None:
        return
    endpoint = str(root.attributes.get("operation"))
    bucket = acc.setdefault(endpoint, _EndpointAccumulator())
    bucket.n_traces += 1
    if len(bucket.sequences) < MAX_TRACES_PER_ENDPOINT:
        bucket.sequences.append(tuple(e.activity for e in _ordered(events)))
    for event in events:
        bucket.durations[event.activity].append(event.duration_us / 1000.0)
    per_trace: dict[str, int] = defaultdict(int)
    for edge in trace_edges(events):
        key = f"{edge.source}->{edge.target}"
        per_trace[key] += 1
        bucket.edge_durations[key].append(edge.span.duration_us / 1000.0)
    for key, count in per_trace.items():
        bucket.edge_counts[key].append(count)


def _slices(start: datetime.datetime, end: datetime.datetime) -> list[tuple[int, int]]:
    lo, hi = to_epoch_us(start), to_epoch_us(end)
    step = TRACE_SLICE_SECONDS * 1_000_000
    return [(t, min(t + step, hi)) for t in range(lo, hi, step)] or [(lo, hi)]


def collect_trace_baseline(
    windows: Sequence[tuple[datetime.datetime, datetime.datetime]],
    cfg: Stage3Config,
    *,
    client: JaegerClient | None = None,
    known_services: Sequence[str] = (),
) -> dict[str, Any]:
    """Recupera traces normais nas janelas, e por endpoint: PetriNet (IMf), `span_stats`, `service_graph`.

    Devolve `{"process_models", "span_stats", "service_graph", "n_traces", "skipped"}`.
    """
    from src.application.stage3.process_models import discover_petri_net, petri_net_to_graph_json, serialize_petri_net

    endpoint_url = cfg.resolved_jaeger_endpoint()
    if client is None and not endpoint_url:
        raise ValueError("Jaeger nao configurado: defina stage3_config.jaeger_endpoint ou JAEGER_QUERY_URL")
    if not cfg.entry_services:
        raise ValueError("stage3_config.entry_services e obrigatorio para coletar o baseline de traces")
    jaeger = client or JaegerClient(str(endpoint_url))
    # Os modelos de processo usam só traces com raiz num serviço de entrada. `service_stats` (M8) precisa dos
    # mesmos traces que o incidente vê -- a busca do incidente cobre todos os serviços não excluídos -- para
    # que as duas pontas meçam a mesma coisa (ex.: consultas ao registry fora das requisições de usuário).
    available = set(jaeger.services()) - set(cfg.excluded_services)
    services = [s for s in cfg.entry_services if s in available]
    if not services:
        raise ValueError(f"nenhum servico de entrada {list(cfg.entry_services)} encontrado no Jaeger")
    all_services = sorted(available)

    acc: dict[str, _EndpointAccumulator] = {}
    seen: set[str] = set()
    raw_all: list[dict[str, Any]] = []
    for window_start, window_end in windows:
        for lo, hi in _slices(window_start, window_end):
            raw, _ = search_traces(jaeger, all_services, lo, hi, cfg.trace_limit)
            time.sleep(QUERY_PAUSE_SECONDS)
            for trace_id, trace in raw.items():
                if trace_id in seen:
                    continue
                seen.add(trace_id)
                raw_all.append(trace)
                built = build_trace_events(trace, list(cfg.entry_services), cfg.entry_operation_regex)
                if built is not None:
                    _accumulate(acc, built[0])

    process_models: dict[str, str] = {}
    process_graphs: dict[str, dict] = {}
    span_stats: dict[str, dict[str, list[float]]] = {}
    service_graph: dict[str, dict[str, list[float]]] = {}
    skipped: dict[str, int] = {}
    for endpoint, bucket in acc.items():
        if bucket.n_traces < cfg.min_traces_per_endpoint:
            skipped[endpoint] = bucket.n_traces
            continue
        net, im, fm = discover_petri_net(bucket.sequences, cfg.noise_threshold)
        process_models[endpoint] = serialize_petri_net(net, im, fm)
        serialized = process_models[endpoint]
        process_graphs[endpoint] = petri_net_to_graph_json(serialized)
        span_stats[endpoint] = {a: summarize(d) for a, d in bucket.durations.items()}
        service_graph[endpoint] = {}
        for key, durations in bucket.edge_durations.items():
            counts = bucket.edge_counts[key]
            calls_per_trace = sum(counts) / bucket.n_traces  # traces sem a aresta contam 0
            mean, std, _, _, p95 = summarize(durations)[:5]
            service_graph[endpoint][key] = [calls_per_trace, mean, std, p95]
    from src.application.stage3.service_stats import baseline_service_stats

    service_stats = baseline_service_stats(raw_all, list(windows), cfg, known_services)
    return {
        "process_models": process_models, "process_graphs": process_graphs,
        "span_stats": span_stats, "service_graph": service_graph, "service_stats": service_stats,
        "n_traces": {ep: b.n_traces for ep, b in acc.items()}, "skipped": skipped,
    }


def execute_collect_trace_baseline(
    system_id: str, payload: dict[str, Any], *, repo: Any, client: JaegerClient | None = None
) -> dict[str, Any]:
    """Handler do job `collect_trace_baseline`: grava PetriNets e estatísticas de span no baseline."""
    collection_id = str(payload["collection_id"])
    baseline = repo.get_collection_baseline(collection_id)
    if baseline is None or baseline.status != "completed":
        raise ValueError("calcule o baseline de metricas da colecao antes de coletar os traces de baseline")
    repo.mark_trace_baseline(baseline.baseline_id, "running")
    try:
        windows = [(f.window_start, f.window_end) for f in baseline_failures(collection_id, repo)]
        if not windows:
            raise BaselineInsufficientError("a colecao nao tem falhas marcadas como baseline")
        cfg = _system_config(repo, system_id)
        result = collect_trace_baseline(windows, cfg, client=client, known_services=list(baseline.metric_stats or {}))
        if not result["process_models"]:
            raise BaselineInsufficientError(
                f"nenhum endpoint com >= {cfg.min_traces_per_endpoint} traces normais "
                f"(traces por endpoint: {result['n_traces'] or 'nenhum trace encontrado'}); "
                "os traces expiram do Jaeger em 48 h"
            )
    except Exception as exc:
        repo.mark_trace_baseline(baseline.baseline_id, "failed", str(exc))
        raise
    repo.update_baseline_trace_artifacts(
        baseline.baseline_id, result["process_models"], result["span_stats"], result["service_graph"],
        process_graphs=result.get("process_graphs"), service_stats=result.get("service_stats"),
    )
    return {
        "baseline_id": baseline.baseline_id, "endpoints": sorted(result["process_models"]),
        "n_traces": result["n_traces"], "skipped": result["skipped"],
    }
