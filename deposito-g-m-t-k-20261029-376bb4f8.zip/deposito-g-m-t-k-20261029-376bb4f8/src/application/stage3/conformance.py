"""Localização de entidade por Conformance Checking.

Alinha cada trace de requisição ao PetriNet do seu endpoint (PM4Py alignments), escolhe o trace
representativo (menor fitness) e deriva os desvios e os suspeitos de entidade.
"""

import datetime
from collections.abc import Mapping, Sequence
from typing import Any

from src.application.stage3 import egads
from src.application.stage3.attribution import attribute_entity
from src.application.stage3.entities import normalize_entity, short_service
from src.application.stage3.process_models import PetriNet
from src.application.stage3.traces import TraceEvent
from src.application.stage3.types import (
    ConformanceResult,
    Deviation,
    EntityCandidate,
    ErrorSpan,
    TemporalDeviation,
)

_MOVE_NONE = ">>"
# Prioridade do tipo de desvio quando um span cai em mais de uma categoria
_TYPE_PRIORITY = {"error": 0, "unexpected": 1, "wrong_order": 1, "temporal": 2}


def ordered_events(events: list[TraceEvent]) -> list[TraceEvent]:
    """Ordem de início do span (a mesma usada ao minerar o modelo baseline)."""
    return sorted(events, key=lambda e: (e.start_us, e.depth, e.span_id))


def _align(activities: list[str], model: PetriNet) -> tuple[float, list[tuple[str, str | None]]]:
    from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments
    from pm4py.objects.log.obj import Event, Trace

    net, im, fm = model
    result = alignments.apply_trace(Trace([Event({"concept:name": a}) for a in activities]), net, im, fm)
    return float(result["fitness"]), [(str(log), model_label) for log, model_label in result["alignment"]]


def conformance_check(events: list[TraceEvent], model: PetriNet) -> tuple[float, list[Deviation]]:
    """Alinha UM trace ao modelo; devolve `(fitness, desvios)`."""
    ordered = ordered_events(events)
    fitness, alignment = _align([e.activity for e in ordered], model)
    return fitness, deviations_from_alignment(ordered, alignment)


def deviations_from_alignment(
    ordered: list[TraceEvent], alignment: list[tuple[str, str | None]]
) -> list[Deviation]:
    """Traduz um alinhamento em desvios missing/unexpected/wrong_order.

    - movimento só de log (atividade observada que o modelo não esperava ali): `unexpected`, ou
      `wrong_order` se a mesma atividade também aparece como movimento só de modelo (foi
      esperada em outro ponto);
    - movimento só de modelo visível sem par no log: `missing`.
    """
    log_moves: list[tuple[int, TraceEvent]] = []
    model_moves: list[str] = []
    cursor = 0
    for log_label, model_label in alignment:
        if log_label != _MOVE_NONE:
            event = ordered[cursor]
            if model_label == _MOVE_NONE:
                log_moves.append((cursor, event))
            cursor += 1
        elif model_label is not None and model_label != _MOVE_NONE:
            model_moves.append(model_label)  # transições invisíveis chegam como None e são ignoradas

    deviations: list[Deviation] = []
    pending_model = list(model_moves)
    for position, event in log_moves:
        kind = "unexpected"
        if event.activity in pending_model:
            pending_model.remove(event.activity)
            kind = "wrong_order"
        deviations.append(Deviation(kind, event.activity, event.pod, position, event.depth, event.span_id))
    for activity in pending_model:
        pod = activity.split(": ", 1)[0]
        deviations.append(Deviation("missing", activity, pod, -1, None, None))
    return deviations


def select_representative(
    traces_by_endpoint: Mapping[str, Mapping[str, list[TraceEvent]]],
    models: Mapping[str, PetriNet],
) -> ConformanceResult | None:
    """Alinha todo trace dos endpoints com modelo; o de menor fitness é o representativo.

    Desempate: raiz de maior duração. None se nenhum endpoint dos traces tem modelo.
    Traces com a mesma sequência de atividades são alinhados uma só vez (variantes).
    """
    best: tuple[tuple[float, int], ConformanceResult] | None = None
    n_aligned = 0
    fitness_by_trace: dict[str, float] = {}
    for endpoint, traces in traces_by_endpoint.items():
        model = models.get(endpoint)
        if model is None:
            continue
        variants: dict[tuple[str, ...], tuple[float, list[tuple[str, str | None]]]] = {}
        for case_id, events in traces.items():
            ordered = ordered_events(events)
            key = tuple(e.activity for e in ordered)
            if key not in variants:
                variants[key] = _align(list(key), model)
            fitness, alignment = variants[key]
            n_aligned += 1
            fitness_by_trace[case_id] = fitness
            root_duration = max((e.duration_us for e in ordered if e.depth == 0), default=0)
            rank = (fitness, -root_duration)
            if best is None or rank < best[0]:
                best = (rank, ConformanceResult(
                    fitness=fitness,
                    deviations=deviations_from_alignment(ordered, alignment),
                    trace_id=case_id, endpoint=endpoint, n_traces_aligned=0,
                ))
    if best is None:
        return None
    best[1].n_traces_aligned = n_aligned
    best[1].fitness_by_trace = fitness_by_trace
    return best[1]


def find_error_spans(events: list[TraceEvent]) -> list[ErrorSpan]:
    out = []
    for position, event in enumerate(ordered_events(events)):
        if event.is_error:
            out.append(ErrorSpan(
                activity=event.activity, pod=event.pod, depth=event.depth,
                t_start=datetime.datetime.fromtimestamp(event.start_us / 1_000_000, datetime.UTC).replace(tzinfo=None),
                exception=event.attributes.get("exception"), span_id=event.span_id, position=position,
            ))
    return out


def find_temporal_deviations(
    representative: list[TraceEvent],
    endpoint_traces: Mapping[str, list[TraceEvent]],
    span_stats: Mapping[str, list[float]] | None,
    *,
    z_outlier: float = 3.0,
    p95_factor: float = 1.5,
    cusum_window: int = 5,
) -> list[TemporalDeviation]:
    """Duração anormal por atividade. `span_stats[atividade] = [mean, std, min, max, p95]` em ms.

    A série de uma atividade = suas durações (ms) em todos os traces completos do endpoint,
    ordenadas por início. Sem `span_stats` a checagem não roda. Além do z-score do span
    representativo, testa também `observado > p95 * p95_factor`: baseline
    assimétrica/bimodal (ex. atividade que mistura operação rápida e lenta) infla o desvio-padrão
    e deixa um desvio real abaixo de `z_outlier`; o percentil é robusto a esse caso.
    """
    if not span_stats:
        return []
    series: dict[str, list[tuple[int, float]]] = {}
    for events in endpoint_traces.values():
        for event in events:
            series.setdefault(event.activity, []).append((event.start_us, event.duration_us / 1000.0))
    out: list[TemporalDeviation] = []
    for position, event in enumerate(ordered_events(representative)):
        stats = span_stats.get(event.activity)
        if not stats:
            continue
        mean, std = float(stats[0]), float(stats[1])
        p95 = float(stats[4]) if len(stats) > 4 else 0.0
        duration_ms = event.duration_us / 1000.0
        z = egads.z_score(duration_ms, mean, std)
        values = [v for _, v in sorted(series.get(event.activity, []))]
        outliers = egads.detect_outlier(values, mean, std, z_outlier)
        changes = egads.detect_change_point(values, std, cusum_window)
        anomalous_ts = egads.detect_anomalous_ts(values, mean, std, z_outlier)
        percentile_hit = bool(egads.detect_percentile_outlier([duration_ms], p95, p95_factor))
        if abs(z) >= z_outlier or changes or anomalous_ts or percentile_hit:
            out.append(TemporalDeviation(
                metric_name=event.activity, pod_name=event.pod, outlier_indices=outliers,
                change_point_indices=changes, is_anomalous_ts=anomalous_ts,
                t_start=datetime.datetime.fromtimestamp(event.start_us / 1_000_000, datetime.UTC).replace(tzinfo=None),
                magnitude=abs(z), span_id=event.span_id, depth=event.depth, position=position,
                via_percentile=percentile_hit and abs(z) < z_outlier and not changes and not anomalous_ts,
            ))
    return out


def build_entity_candidates(
    representative: list[TraceEvent],
    deviations: list[Deviation],
    error_spans: list[ErrorSpan],
    temporal: list[TemporalDeviation],
    top_k: int = 3,
    *,
    observed_metrics_by_entity: Mapping[str, Mapping[str, float]] | None = None,
    metric_stats: Mapping[str, Mapping[str, Sequence[float]]] | None = None,
    delta_threshold: float = 2.0,
) -> list[EntityCandidate]:
    """Suspeitos de entidade do trace representativo.

    Desempate entre entidades: o número de categorias de sinal do grupo
    inteiro da entidade (erro, fluxo — unexpected/wrong_order —, duração — temporal —, métrica
    própria anômala corroborada via `observed_metrics_by_entity`/`metric_stats`; mesmas 4
    categorias de `attribution.assign_certainty`) decide antes de profundidade. Profundidade
    sozinha (usada isolada antes desta correção) deixava um span mais fundo com UM sinal fraco
    isolado (ex. `registry` com só "fluxo", uma chamada de descoberta de serviço que o PetriNet
    da baseline não reconhece) vencer um span mais raso com vários sinais reais combinados (ex.
    `webui` com erro+duração+fluxo) — achado ao rodar o lote F1-F14 completo.
    """
    by_span = {e.span_id: e for e in representative}
    positions = {e.span_id: i for i, e in enumerate(ordered_events(representative))}

    # 1. desvio observado por span, com o tipo de maior prioridade
    observed: dict[str, str] = {}

    def _mark(span_id: str | None, kind: str) -> None:
        if span_id is None or span_id not in by_span:
            return
        if span_id not in observed or _TYPE_PRIORITY[kind] < _TYPE_PRIORITY[observed[span_id]]:
            observed[span_id] = kind

    for dev in deviations:
        if dev.type in ("unexpected", "wrong_order"):
            _mark(dev.span_id, dev.type)
    for err in error_spans:
        _mark(err.span_id, "error")
    for tdev in temporal:
        _mark(tdev.span_id, "temporal")

    if not observed:
        return _missing_candidate(representative, deviations)

    # 2. agrupa por entidade; melhor span = mais profundo, desempate início mais cedo
    groups: dict[str, list[str]] = {}
    for span_id in observed:
        groups.setdefault(by_span[span_id].entity, []).append(span_id)

    def _best(span_ids: list[str]) -> str:
        return min(span_ids, key=lambda s: (-by_span[s].depth, by_span[s].start_us, s))

    def _corroborated(entity: str) -> bool:
        if not observed_metrics_by_entity or not metric_stats:
            return False
        result = attribute_entity(
            entity, observed_metrics_by_entity.get(entity, {}), metric_stats, delta_threshold
        )
        return bool(result and result.anomalous_metrics)

    entity_kinds = {entity: {observed[s] for s in spans} for entity, spans in groups.items()}

    def _signal_count(entity: str, kinds: set[str]) -> int:
        count = 0
        if "error" in kinds:
            count += 1
        if kinds & {"unexpected", "wrong_order"}:
            count += 1
        if "temporal" in kinds:
            count += 1
        if _corroborated(entity):
            count += 1
        return count

    ranked = sorted(
        ((entity, _best(spans), spans) for entity, spans in groups.items()),
        key=lambda item: (
            -_signal_count(item[0], entity_kinds[item[0]]),
            -by_span[item[1]].depth, by_span[item[1]].start_us, item[0],
        ),
    )[:top_k]
    candidates = []
    for rank, (entity, best_id, span_ids) in enumerate(ranked, start=1):
        event = by_span[best_id]
        candidates.append(EntityCandidate(
            rank=rank, pod_name=entity, service=event.service, activity=event.activity,
            deviation_type=observed[best_id],
            deviation_types=sorted(entity_kinds[entity], key=lambda k: _TYPE_PRIORITY[k]),
            depth=event.depth, position=positions[best_id], n_spans=len(span_ids),
            t_start=datetime.datetime.fromtimestamp(event.start_us / 1_000_000, datetime.UTC).replace(tzinfo=None),
        ))
    return candidates


def _missing_candidate(representative: list[TraceEvent], deviations: list[Deviation]) -> list[EntityCandidate]:
    """Sem desvio observado: o suspeito é o chamador do trecho ausente (certeza baixa)."""
    missing = [d for d in deviations if d.type == "missing"]
    if not missing:
        return []
    ordered = ordered_events(representative)
    gap = missing[0]
    gap_service = gap.activity.split(": ", 1)[0]
    # chamador esperado: o span `server` do mesmo serviço presente no trace (a atividade ausente
    # seria filha dele, ex.: JDBC do persistence); senão a raiz da requisição, que no TeaStore é
    # quem chama os demais serviços
    same_service = [e for e in ordered if short_service(e.service) == gap_service and e.depth <= 1]
    caller = same_service[0] if same_service else ordered[0]
    return [EntityCandidate(
        rank=1, pod_name=normalize_entity(caller.pod or caller.service), service=caller.service,
        activity=gap.activity, deviation_type="missing", deviation_types=["missing"],
        depth=caller.depth, position=-1, n_spans=0,
        t_start=datetime.datetime.fromtimestamp(caller.start_us / 1_000_000, datetime.UTC).replace(tzinfo=None),
        confidence="baixa",
    )]


def deviation_dict(dev: Deviation) -> dict[str, Any]:
    return {
        "type": dev.type, "activity": dev.activity, "pod": dev.pod,
        "position": dev.position, "depth": dev.depth, "span_id": dev.span_id,
    }
