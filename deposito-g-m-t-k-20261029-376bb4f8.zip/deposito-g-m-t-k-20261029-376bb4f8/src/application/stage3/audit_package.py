"""Pacote de auditoria do incidente: montagem, congelamento (hash + governança) e verificação.

O pacote é JSON autocontido: congela o que é perecível (traces do Jaeger, subconjunto do baseline) e o que
o dossiê atual não guarda (janela, suspeitos, E', prompt/resposta, θ). Reaproveita
`src/contract/governance.py` e não muta nenhum contrato ou log.
"""

import dataclasses
import datetime
import json
import socket
from collections.abc import Mapping, Sequence
from typing import Any

from src.application.stage3.entities import normalize_entity
from src.application.stage3.traces import TraceEvent
from src.contract.governance import compute_package_sha256, make_governance, verify_governance

AUDIT_PACKAGE_VERSION = "1.0"
# v3 (lote F1-F14): desempate por contagem de categorias de sinal do grupo
# inteiro da entidade (erro, fluxo, duração, métrica própria corroborada — mesmas 4 categorias
# de assign_certainty), decrescente; profundidade e início só decidem dentro do mesmo total de
# sinais. v2 (só "estrutural sempre antes de duração pura") deixava um span mais fundo com 1
# sinal fraco isolado vencer um mais raso com vários sinais reais combinados.
SELECTION_RULE = "votes(estrutural+descoberta+inanicao+fronteira+taxa_erro+chamada_ausente+k8s)/v5+abstain_estrutural"
HASHED_SECTIONS = ("incident", "detection", "stage3", "execution", "known_limitations")
_OUTSIDE_HASH = ("review", "integrity", "governance")


def jsonable(value: Any) -> Any:
    """Normaliza para tipos JSON (datetimes → ISO, tuplas → listas): garante hash estável após ir e voltar do banco."""
    normalized: Any = json.loads(json.dumps(value, default=_default, ensure_ascii=False))
    return normalized


def _default(obj: Any) -> Any:
    if isinstance(obj, datetime.datetime):
        return obj.isoformat()
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if isinstance(obj, set | frozenset):
        return sorted(obj)
    return str(obj)


def _iso(value: datetime.datetime | None) -> str | None:
    return value.isoformat() if value else None


# --- seções -----------------------------------------------------------------


def describe_incident(incident: Any) -> dict[str, Any]:
    return {
        "incident_id": incident.incident_id, "system_id": incident.system_id, "status": incident.status,
        "hypothesis": incident.hypothesis, "opened_at": _iso(incident.created_at),
        "window_start": _iso(incident.window_start), "window_end": _iso(incident.window_end),
        "log_ids": json.loads(incident.log_ids_json or "[]"),
        "evidence_ids": json.loads(incident.evidence_ids_json or "[]"),
    }


def describe_log(log: Any) -> dict[str, Any]:
    """Um log do incidente com o contrato embutido inteiro e `contract_sha256`."""
    try:
        contract = json.loads(log.contract_json) if log.contract_json else {}
    except (json.JSONDecodeError, TypeError):
        contract = {}
    steps: list[dict[str, Any]] = []
    try:
        steps = json.loads(log.steps_json) if log.steps_json else []
    except (json.JSONDecodeError, TypeError):
        pass
    return {
        "log_id": log.log_id, "window_start": _iso(log.window_start), "window_end": _iso(log.window_end),
        "collected_at": _iso(log.collected_at), "stage1_result": log.stage1_result,
        "primary_hypothesis": log.primary_hypothesis, "confidence": log.confidence,
        "contract_id": log.contract_id, "contract_sha256": compute_package_sha256(jsonable(contract)),
        "contract": jsonable(contract),
        "decision_audits": [
            {"step": s.get("name"), "status": s.get("status"), "data": s.get("data")}
            for s in steps if str(s.get("name", "")).startswith("Decisão")
        ],
        "steps_digest": [
            {"name": s.get("name"), "status": s.get("status"), "detail": s.get("detail")} for s in steps
        ],
    }


def struct_sha256(value: Any) -> str:
    return compute_package_sha256(jsonable(value))


def baseline_section(
    baseline: Any | None, *, entities: Sequence[str] = (), endpoint: str | None = None
) -> dict[str, Any] | None:
    """Só o que foi consultado + hashes das estruturas inteiras (`baseline.used`)."""
    if baseline is None:
        return None
    used_metrics = {
        normalize_entity(e): baseline.metric_stats[normalize_entity(e)]
        for e in entities if normalize_entity(e) in baseline.metric_stats
    }
    return {
        "baseline_id": baseline.baseline_id, "collection_id": baseline.collection_id,
        "computed_at": _iso(baseline.computed_at), "n_samples": baseline.n_samples,
        "sha256": {
            "metric_stats": struct_sha256(baseline.metric_stats),
            "process_models": struct_sha256(baseline.process_models),
            "span_stats": struct_sha256(baseline.span_stats),
        },
        "used": {
            "metric_stats": {e: {m: list(v[:2]) for m, v in stats.items()} for e, stats in used_metrics.items()},
            "span_stats": dict(baseline.span_stats.get(endpoint or "", {})),
            "process_model_sha256": struct_sha256(baseline.process_models.get(endpoint or "")),
        },
    }


def _span_json(e: TraceEvent) -> dict[str, Any]:
    return {
        "span_id": e.span_id, "parent_span_id": e.attributes.get("parent_span_id"),
        "orphan": bool(e.attributes.get("orphan")), "service": e.service, "pod": e.pod,
        "operation": e.attributes.get("operation"), "kind": e.attributes.get("span.kind"),
        "start_us": e.start_us, "duration_us": e.duration_us, "error": bool(e.attributes.get("error")),
        "exception": e.attributes.get("exception"), "depth": e.depth,
    }


def traces_section(
    *, jaeger_endpoint: str | None, log: Any | None, fitness_by_trace: Mapping[str, float],
    endpoint_by_trace: Mapping[str, str], traces: Mapping[str, list[TraceEvent]], representative_id: str | None,
    n_snapshots: int = 3,
) -> dict[str, Any]:
    """Traces usados: congela até `n_snapshots` (o representativo primeiro, depois os de menor fitness)."""
    ranked = sorted(fitness_by_trace, key=lambda t: (t != representative_id, fitness_by_trace[t], t))
    snapshots = [
        {"trace_id": tid, "endpoint": endpoint_by_trace.get(tid), "fitness": fitness_by_trace[tid],
         "spans": [_span_json(e) for e in sorted(traces.get(tid, []), key=lambda e: (e.start_us, e.depth))]}
        for tid in ranked[:n_snapshots] if tid in traces
    ]
    return {
        "jaeger_endpoint": jaeger_endpoint,
        "query": dict(log.query) if log else None,
        "n_recovered": log.n_recovered if log else 0,
        "n_complete": log.n_complete_traces if log else 0,
        "n_orphans_attached": log.n_orphans_attached if log else 0,
        "trace_ids": sorted(traces),
        "per_trace": [{"trace_id": t, "endpoint": endpoint_by_trace.get(t), "fitness": fitness_by_trace.get(t)}
                      for t in sorted(traces)],
        "snapshots": snapshots,
    }


def validation_report(errors: Sequence[str]) -> dict[str, Any]:
    """As 5 regras de validação da síntese com passou/falhou (a partir dos erros de `validate_llm_output`)."""
    markers = {
        1: ("não é um JSON", "campo ausente"), 2: ("confidence inválida",), 3: ("fora de E'",),
        4: ("supporting_evidence vazia", "id inexistente"), 5: ("confiança 'alta'", "missing_evidence deve"),
    }
    rules = []
    for rule_id, needles in markers.items():
        failed = [e for e in errors if any(n in e for n in needles)]
        rules.append({"id": rule_id, "passed": not failed, "detail": "; ".join(failed)})
    return {"passed": not errors, "rules": rules, "errors": list(errors)}


def contract_levels(
    *, candidates: Sequence[Mapping[str, Any]], attribution: Mapping[str, Any] | None,
    synthesis: Mapping[str, Any] | None, window: Sequence[str | None], theta: Mapping[str, Any],
    conformance: Mapping[str, Any] | None,
) -> list[dict[str, Any]]:
    """Contrato de Evidências por nível: (l, h, s, A, X, P, a)."""
    provenance = {"window": list(window), "theta": dict(theta)}
    top = candidates[0] if candidates else None
    localization = {
        "level": "localização", "h": top["pod_name"] if top else None, "s": top["confidence"] if top else None,
        "A": [f"cand:{c['rank']}" for c in candidates],
        "X": [f"dev:{i}" for i, d in enumerate((conformance or {}).get("deviations", [])) if d["type"] == "missing"],
        "P": {**provenance, "trace_id": (conformance or {}).get("trace_id")},
        "a": top is None,
    }
    attr = attribution or {}
    attribute = {
        "level": "atributo", "h": attr.get("dominant_metric"), "s": attr.get("anomaly_type"),
        "A": [f"met:{m}" for m in attr.get("anomalous_metrics", [])], "X": [], "P": provenance,
        "a": not attr,
    }
    syn = synthesis or {}
    synthesis_level = {
        "level": "síntese", "h": syn.get("hypothesis") or None, "s": syn.get("confidence") or None,
        "A": syn.get("supporting_evidence", []), "X": syn.get("missing_evidence", []), "P": provenance,
        "a": bool(syn.get("abstain", True)),
    }
    return [localization, attribute, synthesis_level]


def known_limitations(
    *, rules_engine_used: bool, profile_source: str | None, n_orphans_attached: int, has_inferred_map: bool,
    n_traces_recovered: int, n_snapshots: int,
) -> list[dict[str, str]]:
    """Limitações conhecidas embutidas."""
    out = [{"code": "evidence_package_nao_persistido",
            "detail": "o EvidencePackage do ciclo não é persistido; valem contract_json e metrics_by_entity_json"}]
    if rules_engine_used:
        out.append({"code": "thresholds_regras_nao_persistidos",
                    "detail": "min_val/max_val das regras não ficam no log do ciclo"})
    if profile_source == "stage3_start":
        out.append({"code": "perfil_tardio",
                    "detail": "o perfil foi capturado no início do Stage 3, não na abertura do incidente"})
    if n_orphans_attached:
        out.append({"code": "spans_client_ausentes",
                    "detail": "o Jaeger não tem os spans client do webui; spans server órfãos foram anexados à raiz"})
    if has_inferred_map:
        out.append({"code": "topologia_inferida",
                    "detail": "o mapa tem arestas/nós inferidos (órfãos anexados à raiz; "
                              "banco deduzido dos spans JDBC)"})
    if n_traces_recovered > n_snapshots:
        out.append({"code": "traces_pereciveis",
                    "detail": "traces além dos snapshots não são reconstituíveis após o TTL do Jaeger (48 h)"})
    out.append({"code": "baseline_recalculavel",
                "detail": "o baseline pode ser recalculado; só o subconjunto usado e os hashes ficam no pacote"})
    return out


# --- montagem / congelamento / verificação ------------------------------------


def build_audit_package(
    *, incident: Mapping[str, Any], logs: Sequence[Mapping[str, Any]], profile_snapshot: Mapping[str, Any],
    stage3: Mapping[str, Any], execution: Mapping[str, Any], limitations: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    return jsonable({
        "audit_package_version": AUDIT_PACKAGE_VERSION,
        "incident": incident,
        "detection": {"logs": list(logs), "profile_snapshot": profile_snapshot},
        "stage3": stage3,
        "execution": execution,
        "known_limitations": list(limitations),
        "review": {"status": "pending_human_review", "reason": None, "actual_entity": None, "reviewed_at": None},
    })


def _hashable(package: Mapping[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in package.items() if k not in _OUTSIDE_HASH}


def freeze_audit_package(package: dict[str, Any], *, system_id: str, hostname: str | None = None) -> dict[str, Any]:
    """Calcula `integrity` (SHA-256 canônico por seção e do pacote) e `governance` (escopo `system:<sid>:stage3`)."""
    frozen: dict[str, Any] = jsonable(package)
    base = _hashable(frozen)
    frozen["integrity"] = {
        "algorithm": "sha256(canonical_json)",
        "sections": {name: compute_package_sha256(base[name]) for name in HASHED_SECTIONS if name in base},
        "package_sha256": compute_package_sha256(base),
    }
    frozen["governance"] = jsonable(make_governance(
        collecting_agent=f"job-runner:{hostname or socket.gethostname()}",
        authorization_scope=f"system:{system_id}:stage3",
        package_dict=base,
    ))
    return frozen


def verify_audit_package(
    package: Mapping[str, Any], *, known_agents: set[str] | None = None, diagnosis: Any | None = None
) -> dict[str, Any]:
    """Verifica hashes por seção e do pacote, governança, `contract_sha256` dos logs e coerência com as colunas."""
    base = _hashable(package)
    integrity = package.get("integrity") or {}
    stored_sections = integrity.get("sections") or {}
    sections = {
        name: stored_sections.get(name) == compute_package_sha256(base[name])
        for name in HASHED_SECTIONS if name in base
    }
    package_ok = integrity.get("package_sha256") == compute_package_sha256(base)
    system_id = (package.get("incident") or {}).get("system_id")
    gov_ok, gov_reason = verify_governance(
        package.get("governance"), base, known_agents=known_agents, target_system_id=system_id,
    )
    if gov_ok and not str((package.get("governance") or {}).get("authorization_scope", "")).endswith(":stage3"):
        gov_ok, gov_reason = False, "escopo de governança não é de Stage 3"
    consistency: list[str] = []
    for log in (package.get("detection") or {}).get("logs", []):
        if log.get("contract_sha256") != compute_package_sha256(jsonable(log.get("contract") or {})):
            consistency.append(f"contract_sha256 divergente no log {log.get('log_id')}")
    if diagnosis is not None:
        consistency += _check_columns(package, diagnosis)
    return {
        "ok": package_ok and all(sections.values()) and gov_ok and not consistency,
        "package_sha256": package_ok, "sections": sections,
        "governance": {"ok": gov_ok, "reason": gov_reason}, "consistency": consistency,
    }


def _col(diagnosis: Any, name: str) -> Any:
    return diagnosis.get(name) if isinstance(diagnosis, Mapping) else getattr(diagnosis, name, None)


def _check_columns(package: Mapping[str, Any], diagnosis: Any) -> list[str]:
    """Coerência do pacote com as colunas de `stage3_diagnoses` (modelo ou dict)."""
    stage3 = package.get("stage3") or {}
    issues = []
    suspects = (stage3.get("localization") or {}).get("suspects")
    if _col(diagnosis, "entity_candidates") is not None and jsonable(_col(diagnosis, "entity_candidates")) != suspects:
        issues.append("suspeitos do pacote diferem de stage3_diagnoses.entity_candidates")
    synthesis = stage3.get("synthesis") or {}
    if _col(diagnosis, "llm_prompt") is not None and _col(diagnosis, "llm_prompt") != synthesis.get("prompt"):
        issues.append("prompt do pacote difere de stage3_diagnoses.llm_prompt")
    raw = _col(diagnosis, "llm_raw_response")
    if raw is not None and raw != synthesis.get("raw_response"):
        issues.append("resposta do LLM do pacote difere de stage3_diagnoses.llm_raw_response")
    theta = _col(diagnosis, "theta_snapshot")
    if theta is not None and jsonable(theta) != stage3.get("parameters"):
        issues.append("θ do pacote difere de stage3_diagnoses.theta_snapshot")
    if _col(diagnosis, "status") != stage3.get("status"):
        issues.append("status do pacote difere de stage3_diagnoses.status")
    return issues
