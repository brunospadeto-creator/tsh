"""Localização por votos independentes.

O Conformance Checking (`conformance.build_entity_candidates`) vira UM voto entre vários. Os demais
olham sinais que o alinhamento do trace representativo não enxerga -- achados ao analisar o lote
F1-F14 completo (3 lotes, 42 casos):

- ``descoberta``: consultas repetidas ao serviço de descoberta (registry) nomeiam o serviço que o
  chamador não consegue alcançar (``/services/<nome>``); consultas uniformes a vários alvos apontam
  o próprio serviço de descoberta.
- ``inanicao``: pouquíssimas requisições na janela -- o serviço de entrada está travado/fora do ar
  (é justamente quando o Conformance se abstém por falta de traces).
- ``fronteira``: com a entrada travada, o serviço (não-entrada) que ainda aparece nos traces
  parciais é onde as requisições estão presas.
- ``taxa_erro``: serviço com a maior taxa de spans ``server`` com erro.
- ``chamada_ausente``: serviço chamado cujas atividades esperadas sumiram do trace representativo.
- ``k8s``: eventos de saúde do pod (probe falhando, OOM, BackOff) na janela do incidente.
- ``metrica``: entidade com o maior |δ| de métrica própria contra a baseline (antes só usada quando
  o Conformance não tinha candidato).
- ``estrutural``: o ranking do Conformance, com peso decrescente por posição.

Cada voto é pura função dos insumos (traces brutos resumidos, desvios, eventos), o que permite
reavaliar as regras offline sobre rodadas salvas (``experimento-falhas/.../replay``).
"""

import datetime
import math
import re
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass, field
from typing import Any

from src.application.stage3.entities import normalize_entity, short_service
from src.application.stage3.types import AttributionResult, Deviation, EntityCandidate

STRUCTURAL_DECAY = (1.0, 0.6, 0.3)


@dataclass
class TraceSignals:
    """Resumo por serviço de TODOS os traces brutos da janela (completos ou não)."""

    window_seconds: float = 0.0
    n_traces: int = 0
    n_entry_roots: int = 0
    server_spans: dict[str, int] = field(default_factory=dict)
    error_server_spans: dict[str, int] = field(default_factory=dict)
    spans: dict[str, int] = field(default_factory=dict)
    discovery_lookups: dict[str, int] = field(default_factory=dict)
    # em quantos intervalos de `bucket_seconds` da janela cada alvo foi consultado (persistência)
    discovery_buckets: dict[str, int] = field(default_factory=dict)
    discovery_any_buckets: int = 0
    n_buckets: int = 0
    # respostas HTTP dos spans server (código >= 400) e profundidade média na árvore de chamadas
    http_server_spans: dict[str, int] = field(default_factory=dict)
    http_error_server_spans: dict[str, int] = field(default_factory=dict)
    mean_depth: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> "TraceSignals":
        return cls(**dict(data or {}))


@dataclass
class Vote:
    name: str
    entity: str
    weight: float
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class EntityVotes:
    entity: str
    score: float
    votes: list[Vote]

    def to_dict(self) -> dict[str, Any]:
        return {"entity": self.entity, "score": round(self.score, 4), "votes": [v.to_dict() for v in self.votes]}


def _tags(items: Iterable[Mapping[str, Any]] | None) -> dict[str, Any]:
    return {str(t.get("key")): t.get("value") for t in (items or [])}


def _http_status(tags: Mapping[str, Any]) -> int | None:
    value = tags.get("http.response.status_code", tags.get("http.status_code"))
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _depths(span_list: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    """Profundidade de cada span no trace (raiz ou pai ausente = 0)."""
    parent: dict[str, str | None] = {}
    for span in span_list:
        refs = [r for r in span.get("references") or [] if r.get("refType") == "CHILD_OF"]
        parent[str(span.get("spanID"))] = str(refs[0].get("spanID")) if refs else None
    depth: dict[str, int] = {}
    for sid in parent:
        chain = []
        node: str | None = sid
        while node is not None and node in parent and node not in depth and node not in chain:
            chain.append(node)
            node = parent[node]
        base = depth.get(node, -1) if node is not None else -1
        for i, n in enumerate(reversed(chain)):
            depth[n] = base + 1 + i
    return depth


def _is_error(tags: Mapping[str, Any]) -> bool:
    value = tags.get("error")
    return value is True or str(value).lower() == "true" or str(tags.get("otel.status_code")) == "ERROR"


def match_service(token: str, known: Iterable[str]) -> str | None:
    """Serviço conhecido nomeado por `token` (ex.: ``tools.descartes.teastore.persistence``)."""
    tail = token.rstrip("/").split(".")[-1].split("/")[-1].lower()
    for service in sorted(known):
        if tail in (service.lower(), short_service(service).lower()):
            return service
    return None


def summarize_raw_traces(
    raw_traces: Mapping[str, Mapping[str, Any]],
    *,
    window: tuple[datetime.datetime, datetime.datetime] | None,
    entry_services: Sequence[str],
    entry_operation_regex: str,
    discovery_service: str | None,
    discovery_route_regex: str,
    known_services: Iterable[str] = (),
    bucket_seconds: float = 30.0,
) -> TraceSignals:
    """Contagens por serviço sobre os traces brutos do Jaeger (inclui os parciais)."""
    entry_re = re.compile(entry_operation_regex)
    route_re = re.compile(discovery_route_regex)
    sig = TraceSignals(n_traces=len(raw_traces))
    t0_us: int | None = None
    if window is not None:
        sig.window_seconds = max(0.0, (window[1] - window[0]).total_seconds())
        t0_us = int(window[0].replace(tzinfo=datetime.UTC).timestamp() * 1e6) if window[0].tzinfo is None \
            else int(window[0].timestamp() * 1e6)
        sig.n_buckets = max(1, math.ceil(sig.window_seconds / bucket_seconds)) if bucket_seconds > 0 else 0
    server: Counter[str] = Counter()
    errors: Counter[str] = Counter()
    spans_by_service: Counter[str] = Counter()
    lookup_tokens: Counter[str] = Counter()
    token_buckets: dict[str, set[int]] = {}
    http_total: Counter[str] = Counter()
    http_errors: Counter[str] = Counter()
    depth_sum: Counter[str] = Counter()
    services: set[str] = set(known_services)
    for trace in raw_traces.values():
        processes = trace.get("processes") or {}
        span_list = trace.get("spans") or []
        ids = {str(s.get("spanID")) for s in span_list}
        depths = _depths(span_list)
        has_root = False
        for span in span_list:
            service = str((processes.get(span.get("processID")) or {}).get("serviceName") or "")
            if not service:
                continue
            services.add(service)
            tags = _tags(span.get("tags"))
            kind = str(tags.get("span.kind") or "")
            spans_by_service[service] += 1
            parents = [r for r in span.get("references") or [] if r.get("refType") == "CHILD_OF"]
            parentless = not parents or all(str(r.get("spanID")) not in ids for r in parents)
            if (parentless and kind == "server" and service in entry_services
                    and entry_re.search(str(span.get("operationName")))):
                has_root = True
            if kind == "server":
                server[service] += 1
                depth_sum[service] += depths.get(str(span.get("spanID")), 0)
                if _is_error(tags):
                    errors[service] += 1
                status = _http_status(tags)
                if status is not None:
                    http_total[service] += 1
                    if status >= 400:
                        http_errors[service] += 1
                if discovery_service and service == discovery_service:
                    path = str(tags.get("url.path") or tags.get("http.target") or tags.get("http.url") or "")
                    m = route_re.search(path)
                    if m:
                        lookup_tokens[m.group(1)] += 1
                        if t0_us is not None and sig.n_buckets:
                            idx = int((int(span.get("startTime") or 0) - t0_us) / 1e6 // bucket_seconds)
                            token_buckets.setdefault(m.group(1), set()).add(min(max(idx, 0), sig.n_buckets - 1))
        sig.n_entry_roots += int(has_root)
    lookups: Counter[str] = Counter()
    buckets: dict[str, set[int]] = {}
    for token, count in lookup_tokens.items():
        target = match_service(token, services) or token
        lookups[target] += count
        buckets.setdefault(target, set()).update(token_buckets.get(token, set()))
    sig.http_server_spans = dict(http_total)
    sig.http_error_server_spans = dict(http_errors)
    sig.mean_depth = {s: round(depth_sum[s] / n, 3) for s, n in server.items() if n}
    sig.discovery_buckets = {t: len(b) for t, b in buckets.items()}
    sig.discovery_any_buckets = len(set().union(*buckets.values())) if buckets else 0
    sig.server_spans = dict(server)
    sig.error_server_spans = dict(errors)
    sig.spans = dict(spans_by_service)
    sig.discovery_lookups = dict(lookups)
    return sig


def _service_for_short(short: str, known: Iterable[str]) -> str:
    for service in sorted(known):
        if short_service(service) == short:
            return service
    return short


def _absent_share(service: str, endpoint_traces: Mapping[str, Sequence[Any]]) -> float:
    """Fração dos traces do endpoint sem nenhum span de `service`."""
    if not endpoint_traces:
        return 0.0
    short = short_service(service)
    absent = sum(
        1 for events in endpoint_traces.values()
        if not any(short_service(str(getattr(e, "service", ""))) == short for e in events)
    )
    return absent / len(endpoint_traces)


@dataclass
class LatencyOutlier:
    activity: str
    service: str
    depth: int
    n: int
    p95_ms: float
    baseline_p95_ms: float

    @property
    def ratio(self) -> float:
        return self.p95_ms / self.baseline_p95_ms if self.baseline_p95_ms > 0 else float("inf")


def latency_outliers(
    endpoint_traces: Mapping[str, Sequence[Any]] | None,
    span_stats: Mapping[str, Sequence[float]] | None,
    *,
    factor: float,
    min_samples: int,
) -> list[LatencyOutlier]:
    """Atividades cujo p95 na janela passa de `factor` x o p95 da baseline (span_stats em ms:
    [média, desvio, mín, máx, p95]). Usa TODOS os traces do endpoint, não só o representativo."""
    if not endpoint_traces or not span_stats:
        return []
    durations: dict[str, list[float]] = {}
    meta: dict[str, tuple[str, int]] = {}
    for events in endpoint_traces.values():
        for e in events:
            activity = str(getattr(e, "activity", ""))
            if activity in span_stats:
                durations.setdefault(activity, []).append(float(getattr(e, "duration_us", 0)) / 1000.0)
                depth = int(getattr(e, "depth", 0))
                prev = meta.get(activity)
                meta[activity] = (str(getattr(e, "service", "")), max(depth, prev[1]) if prev else depth)
    out = []
    for activity, values in durations.items():
        stats = span_stats[activity]
        if len(values) < min_samples or len(stats) < 5:
            continue
        values.sort()
        p95 = values[min(len(values) - 1, int(0.95 * len(values)))]
        base = float(stats[4])
        if base > 0 and p95 >= factor * base:
            service, depth = meta[activity]
            out.append(LatencyOutlier(activity, service, depth, len(values), p95, base))
    return out


def vote_entities(
    *,
    signals: TraceSignals,
    candidates: Sequence[EntityCandidate],
    deviations: Sequence[Deviation],
    k8s_events: Sequence[Mapping[str, Any]],
    cfg: Any,
    known_services: Iterable[str] = (),
    metric_leader: AttributionResult | None = None,
    endpoint_traces: Mapping[str, Sequence[Any]] | None = None,
    latency: Sequence[LatencyOutlier] = (),
) -> list[EntityVotes]:
    """Soma dos votos por entidade, maior pontuação primeiro (desempate: ranking estrutural, nome)."""
    weights = dict(cfg.vote_weights)
    entry = cfg.entry_services[0] if cfg.entry_services else None
    known = set(signals.spans) | {c.pod_name for c in candidates} | set(known_services)
    votes: list[Vote] = []

    def add(name: str, entity: str | None, factor: float, detail: str) -> None:
        weight = float(weights.get(name, 0.0)) * factor
        if entity and weight > 0:
            votes.append(Vote(name, normalize_entity(entity), weight, detail))

    # estrutural: ranking do Conformance
    for i, cand in enumerate(candidates[: len(STRUCTURAL_DECAY)]):
        add("estrutural", cand.pod_name, STRUCTURAL_DECAY[i], f"conformance #{i + 1} ({cand.deviation_type})")

    # descoberta
    lookups = signals.discovery_lookups
    total = sum(lookups.values())
    rate_ok = (not cfg.discovery_min_rate or not signals.n_entry_roots
               or total / signals.n_entry_roots >= cfg.discovery_min_rate)
    n_buckets = signals.n_buckets

    def sustained(n: int) -> bool:
        # Consultas persistentes ao longo da janela = alvo continua inalcançável. Uma rajada só é a
        # redescoberta de um pod recém-recriado (o deploy da própria injeção cai no lookback) e rajadas
        # periódicas pequenas são ruído.
        return not cfg.discovery_min_bucket_share or not n_buckets or n / n_buckets >= cfg.discovery_min_bucket_share

    if cfg.discovery_service and total >= cfg.discovery_min_lookups and rate_ok:
        shares = {t: c / total for t, c in lookups.items()}
        top, top_count = max(lookups.items(), key=lambda kv: (kv[1], kv[0]))
        uniform = [t for t, s in shares.items() if s >= cfg.discovery_uniform_min_share]
        span = f" em {{}}/{n_buckets} intervalos de {cfg.discovery_bucket_sec}s" if n_buckets else "{}"
        if len(uniform) >= cfg.discovery_uniform_min_targets:
            if sustained(signals.discovery_any_buckets):
                add("descoberta", cfg.discovery_service, 1.0,
                    f"{total} consultas espalhadas por {len(uniform)} alvos ({', '.join(sorted(uniform))})"
                    + span.format(signals.discovery_any_buckets if n_buckets else ""))
        elif shares[top] >= cfg.discovery_dominant_share:
            n_top = signals.discovery_buckets.get(top, 0)
            if sustained(n_top):
                add("descoberta", top, 1.0, f"{top_count}/{total} consultas a {cfg.discovery_service} procuram {top}"
                    + span.format(n_top if n_buckets else ""))

    # inanição da entrada + fronteira
    minutes = signals.window_seconds / 60.0 if signals.window_seconds else 0.0
    rate = signals.n_entry_roots / minutes if minutes else float(signals.n_entry_roots)
    starving = rate < cfg.starve_min_roots_per_min
    if entry and starving:
        add("inanicao", entry, 1.0, f"{signals.n_entry_roots} requisições em {signals.window_seconds:.0f}s "
                                    f"({rate:.1f}/min < {cfg.starve_min_roots_per_min}/min)")
        others = [(n, s) for s, n in signals.spans.items() if s not in (entry, cfg.discovery_service)]
        if others:
            n, service = max(others)
            add("fronteira", service, 1.0, f"{n} spans de {service} nos traces presos")

    # taxa de erro
    rates = [
        (signals.error_server_spans.get(s, 0) / n, s)
        for s, n in signals.server_spans.items() if n >= cfg.error_rate_min_spans
    ]
    if rates:
        r, service = max(rates)
        if r >= cfg.error_rate_low:
            factor = 2.0 if r >= cfg.error_rate_high else 1.0
            add("taxa_erro", service, factor, f"{r:.0%} dos spans server de {service} com erro")

    # erro HTTP: o erro sobe pela cadeia (F8: 404 no persistence vira erro no auth e no webui), então o
    # culpado é o serviço mais PROFUNDO com taxa de respostas >= 400 acima do limiar. A entrada fica de
    # fora: erro nela já conta em `taxa_erro`, e votar de novo só repete o chamador (F9: webui 100%, o
    # registry quebrado não responde com erro)
    http = [
        (signals.mean_depth.get(s, 0.0), signals.http_error_server_spans.get(s, 0) / n, s)
        for s, n in signals.http_server_spans.items()
        if n >= cfg.http_error_min_spans and s not in cfg.entry_services
    ]
    flagged = [h for h in http if h[1] >= cfg.http_error_min_share]
    if flagged:
        depth, share, service = max(flagged)
        add("erro_http", service, 1.0, f"{share:.0%} das respostas de {service} com código >= 400 "
                                       f"(profundidade média {depth:.1f})")

    # chamada ausente
    missing: Counter[str] = Counter()
    for dev in deviations:
        if dev.type == "missing":
            missing[_service_for_short(dev.pod, known)] += 1
    # O trace representativo sozinho engana: às vezes é um trace degenerado (só a raiz com erro, F2) e
    # "perde" todos os filhos. Com `missing_min_trace_share`, o serviço precisa faltar também em boa parte
    # dos traces do mesmo endpoint (F7: persistence ausente em 99% dos traces de /product).
    eligible = [(c, s) for s, c in missing.items() if c >= cfg.missing_min_activities]
    use_share = bool(cfg.missing_min_trace_share and endpoint_traces)
    best: tuple[float, int, str] | None = None
    for count, service in eligible:
        share = _absent_share(service, endpoint_traces) if use_share and endpoint_traces else 1.0
        if use_share and share < cfg.missing_min_trace_share:
            continue
        if best is None or (share, count, service) > best:
            best = (share, count, service)
    if best is not None:
        share, count, service = best
        detail = f"{count} atividades de {service} ausentes no trace representativo"
        if use_share and endpoint_traces:
            detail += f"; {service} ausente em {share:.0%} dos {len(endpoint_traces)} traces do endpoint"
        add("chamada_ausente", service, 1.0, detail)

    # latência: a lentidão sobe pela cadeia de chamadas, então o culpado é o serviço mais PROFUNDO com p95
    # acima da baseline (desempate: maior razão). Peso 0 até recoletar a baseline -- a atual registrou o
    # TeaStore saturado (páginas de ~50 s), então nada parece lento contra ela
    if latency:
        slow = max(latency, key=lambda o: (o.depth, o.ratio))
        add("latencia", slow.service, 1.0, f"{slow.activity}: p95 {slow.p95_ms:.0f} ms = {slow.ratio:.1f}x "
                                            f"a baseline ({slow.baseline_p95_ms:.0f} ms, n={slow.n})")

    # eventos de saúde do K8s
    health: Counter[str] = Counter()
    for ev in k8s_events:
        if str(ev.get("reason")) in cfg.k8s_health_reasons and ev.get("res"):
            health[normalize_entity(str(ev["res"]))] += int(ev.get("count") or 1)
    if health:
        entity, count = max(health.items(), key=lambda kv: (kv[1], kv[0]))
        add("k8s", entity, 1.0, f"{count} eventos de saúde ({', '.join(sorted(cfg.k8s_health_reasons))})")

    # métrica: entidade de maior |δ| dominante
    if metric_leader is not None and abs(metric_leader.dominant_delta) > cfg.delta_threshold:
        add("metrica", metric_leader.pod_name, 1.0,
            f"{metric_leader.dominant_metric} com δ={metric_leader.dominant_delta:.1f}")

    structural_rank = {c.pod_name: i for i, c in enumerate(candidates)}
    totals: dict[str, EntityVotes] = {}
    for vote in votes:
        acc = totals.setdefault(vote.entity, EntityVotes(vote.entity, 0.0, []))
        acc.score += vote.weight
        acc.votes.append(vote)
    return sorted(
        totals.values(),
        key=lambda ev: (-ev.score, structural_rank.get(ev.entity, len(structural_rank)), ev.entity),
    )


# Sinais por suspeito (attribution.SIGNAL_ORDER) que são sintoma observado no span. Ficam de fora:
# "fluxo", que é desvio de estrutura (o mesmo que o voto `estrutural` já diz), e "métrica", que é z-score
# contra desvio quase zero na baseline (B5) -- no lote `081432Z` o auth tinha "métrica" em F4, F8, F10 e
# F14, sempre igual, pelo mesmo motivo que zerou o voto `metrica`. Volta quando a M5 trocar o z-score.
CANDIDATE_EVIDENCE_SIGNALS = ("erro", "duração")


def lider_so_estrutural(
    voted: Sequence[EntityVotes], cfg: Any, candidates: Sequence[Any] = ()
) -> EntityVotes | None:
    """Líder cujo voto se sustenta só em evidência estrutural, ou None se houver sinal de sintoma (M3).

    Não é a mesma coisa que "ninguém votou". Com o trace partido e os traces do chamador ausentes (M4),
    os votos de sintoma desaparecem e sobra o ranking do Conformance -- que é uma *hipótese* de
    estrutura, não uma observação de que o serviço está ruim. Publicar o primeiro colocado nessa
    situação nomeia um serviço sem nenhuma evidência contra ele.

    Olha só o líder: um sintoma em outro serviço não é evidência contra ele. Conta como evidência um voto
    de `structural_evidence_votes` ou um sinal do próprio span suspeito (`CANDIDATE_EVIDENCE_SIGNALS`):
    um span com erro ou duração anormal é sintoma observado mesmo quando não chega a virar voto
    (poucos traces para `taxa_erro`, por exemplo).

    Devolve `None` quando: não há líder, ou o líder tem evidência.
    """
    if not voted:
        return None
    lider = voted[0]
    evidencia = set(getattr(cfg, "structural_evidence_votes", ()) or ())
    if any(vote.name in evidencia for vote in lider.votes):
        return None
    for cand in candidates:
        if normalize_entity(cand.pod_name) == lider.entity and set(cand.signals) & set(CANDIDATE_EVIDENCE_SIGNALS):
            return None
    return lider


def rank_candidates(
    voted: Sequence[EntityVotes], candidates: Sequence[EntityCandidate], top_k: int
) -> list[EntityCandidate]:
    """Candidatos na ordem dos votos; reaproveita o candidato estrutural quando a entidade já era um."""
    by_entity = {c.pod_name: c for c in candidates}
    out: list[EntityCandidate] = []
    for rank, ev in enumerate(voted[:top_k], start=1):
        cand = by_entity.get(ev.entity)
        if cand is None:
            best = max(ev.votes, key=lambda v: v.weight)
            cand = EntityCandidate(
                rank=rank, pod_name=ev.entity, service=ev.entity, activity=f"{best.name}: {best.detail}",
                deviation_type="vote", deviation_types=["vote"], depth=None, position=-1, n_spans=0,
            )
        cand.rank = rank
        cand.vote_score = round(ev.score, 4)
        cand.votes = [v.name for v in ev.votes]
        out.append(cand)
    return out


def health_events_window(
    window_start: datetime.datetime, window_end: datetime.datetime, lookback_sec: int, settle_sec: int
) -> tuple[datetime.datetime, datetime.datetime]:
    """Janela dos eventos de saúde: curta, em volta do incidente (não o lookback dos traces).

    Probes que falham só durante o boot de um pod recém-implantado ficam de fora -- senão o próprio
    deploy da injeção vazaria como sinal.
    """
    return (window_start - datetime.timedelta(seconds=lookback_sec),
            window_end + datetime.timedelta(seconds=settle_sec))
