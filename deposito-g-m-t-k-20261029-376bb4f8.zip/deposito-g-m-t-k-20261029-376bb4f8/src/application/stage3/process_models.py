"""Modelos de processo por endpoint (PM4Py): descoberta, serialização PNML e leitura.

O PM4Py é importado sob demanda: só o job-runner precisa dele (extra `stage3`).
"""
import base64
from collections.abc import Sequence
from typing import Any, cast

PetriNet = tuple[Any, Any, Any]  # (net, initial_marking, final_marking)


def discover_petri_net(activity_sequences: Sequence[Sequence[str]], noise_threshold: float = 0.2) -> PetriNet:
    """Inductive Miner infrequent (IMf) sobre as sequências de atividades dos traces normais."""
    from pm4py.algo.discovery.inductive import algorithm as inductive
    from pm4py.objects.conversion.process_tree import converter as tree_converter
    from pm4py.objects.log.obj import Event, EventLog, Trace

    log = EventLog([Trace([Event({"concept:name": a}) for a in seq]) for seq in activity_sequences])
    tree = inductive.apply(
        log, variant=inductive.Variants.IMf, parameters={"noise_threshold": noise_threshold},
    )
    return cast(PetriNet, tree_converter.apply(tree))


def serialize_petri_net(net: Any, im: Any, fm: Any) -> str:
    """PNML em base64 (texto seguro para JSON). PNML, não pickle: formato aberto e sem execução."""
    from pm4py.objects.petri_net.exporter import exporter

    return base64.b64encode(exporter.serialize(net, im, fm)).decode("ascii")


def deserialize_petri_net(encoded: str) -> PetriNet:
    from pm4py.objects.petri_net.importer import importer

    return cast(PetriNet, importer.deserialize(base64.b64decode(encoded)))


def petri_net_to_graph_json(encoded: str) -> dict[str, list[dict[str, Any]]]:
    """Serializa o PNML da baseline num grafo JSON (nós/arestas) para o Cytoscape.

    Devido ao import sob demanda do pm4py, aqui sempre deserializa para preservar um
    único caminho de leitura (lidar com o objeto da rede sem importar os tipos do pm4py
    no módulo de aplicação). Nós: places (p) e transitions (t); arestas: arcs PNML.
    Atributos `petri:type`/`petri:name`/`activity` ficam no `data` para o front.
    """
    net, im, fm = deserialize_petri_net(encoded)
    places: list[tuple[int, Any]] = _indexed_places(net)
    transitions: list[tuple[int, Any]] = _indexed_transitions(net)
    nodes: list[dict[str, Any]] = [
        {"data": {"id": f"p{n}", "name": getattr(p, "label", None) or p.name or f"place{n}", "type": "place"}}
        for n, p in places
    ]
    nodes += [
        {"data": {"id": f"t{n}", "name": t.label or t.name or f"transition{n}", "type": "transition",
                  "activity": getattr(t, "label", None)}}
        for n, t in transitions
    ]
    edges = _edges_json(net, places, transitions, nodes)
    return {"nodes": nodes, "edges": edges}


def _indexed_places(net: Any) -> list[tuple[int, Any]]:
    return list(enumerate(net.places))


def _indexed_transitions(net: Any) -> list[tuple[int, Any]]:
    return list(enumerate(net.transitions))


def _edges_json(
    net: Any, places: list[tuple[int, Any]], transitions: list[tuple[int, Any]], nodes: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    by_obj: dict[int, str] = {}
    for n, p in places:
        by_obj[id(p)] = f"p{n}"
    for n, t in transitions:
        by_obj[id(t)] = f"t{n}"
    edges: list[dict[str, Any]] = []
    for arc in net.arcs:
        source = by_obj.get(id(arc.source), "")
        target = by_obj.get(id(arc.target), "")
        if not (source and target):
            continue
        edges.append({"data": {"id": f"{source}-{target}", "source": source, "target": target}})
    return edges
