"""Mapa do problema: rede de serviços dos traces da janela, anotada com suspeitos e desvios.
Determinístico — nenhum LLM; o resultado é um JSON congelado no pacote de auditoria."""

import datetime
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from src.application.stage3 import egads
from src.application.stage3.baseline import summarize
from src.application.stage3.edges import Edge, trace_edges
from src.application.stage3.entities import normalize_entity, sanitize_evidence_id, short_service
from src.application.stage3.traces import TraceEvent
from src.application.stage3.types import (
    AttributionResult,
    ConformanceResult,
    Deviation,
    EntityCandidate,
    ErrorSpan,
)

MAP_VERSION = "1.0"
MAX_ANOMALOUS_EDGES = 10
ABSENT_MIN_CALLS_PER_TRACE = 0.5   # fase 2: aresta "ausente" se o baseline tinha >= 0,5 chamada/trace


@dataclass
class _EdgeAcc:
    source: str
    target: str
    kind: str
    dest_inferred: bool = False
    n_calls: int = 0
    traces: set[str] = field(default_factory=set)
    durations: list[float] = field(default_factory=list)
    n_errors: int = 0
    z: float = 0.0
    n_missing: int = 0
    missing_activities: list[str] = field(default_factory=list)
    activities: set[str] = field(default_factory=set)
    edge_span_ids: set[str] = field(default_factory=set)


def _endpoint_of(events: list[TraceEvent]) -> str | None:
    root = next((e for e in events if e.depth == 0), None)
    return str(root.attributes.get("operation")) if root else None


def build_problem_map(
    traces: Mapping[str, list[TraceEvent]],
    *,
    window: tuple[datetime.datetime, datetime.datetime] | None = None,
    conformance: ConformanceResult | None = None,
    candidates: Sequence[EntityCandidate] = (),
    error_spans: Sequence[ErrorSpan] = (),
    attributions: Mapping[str, AttributionResult | None] | None = None,
    span_stats: Mapping[str, Mapping[str, Sequence[float]]] | None = None,
    service_graph: Mapping[str, Mapping[str, Sequence[float]]] | None = None,
    z_outlier: float = 3.0,
    max_nodes: int = 50,
    max_edges: int = 200,
) -> dict[str, Any]:
    """Rede de serviços observada + desvios (fases 1 e 2 — a 3 é `petri_net_graph`)."""
    attributions = attributions or {}
    span_stats = span_stats or {}
    edges: dict[tuple[str, str, str], _EdgeAcc] = {}
    node_spans: dict[str, int] = defaultdict(int)
    node_errors: dict[str, int] = defaultdict(int)
    node_z: dict[str, float] = defaultdict(float)
    node_meta: dict[str, dict[str, Any]] = {}

    def edge_acc(edge: Edge) -> _EdgeAcc:
        key = (edge.source, edge.target, edge.kind)
        if key not in edges:
            edges[key] = _EdgeAcc(edge.source, edge.target, edge.kind, edge.dest_inferred)
        return edges[key]

    for case_id, events in traces.items():
        endpoint = _endpoint_of(events)
        stats = span_stats.get(endpoint or "", {})
        for event in events:
            if event.attributes.get("db.system"):
                continue  # o span de banco pertence ao nó do banco, contado abaixo
            node_spans[event.entity] += 1
            node_errors[event.entity] += int(event.is_error)
            node_meta.setdefault(event.entity, {"kind": "service", "instrumented": True, "inferred": False})
        for link in trace_edges(events):
            acc = edge_acc(link)
            acc.n_calls += 1
            acc.traces.add(case_id)
            acc.durations.append(link.span.duration_us / 1000.0)
            acc.n_errors += int(link.span.is_error)
            acc.activities.add(link.span.activity)
            acc.edge_span_ids.add(link.span.span_id)
            entry = stats.get(link.span.activity)
            if entry:
                z = abs(egads.z_score(link.span.duration_us / 1000.0, float(entry[0]), float(entry[1])))
                acc.z = max(acc.z, z)
                node_z[link.target] = max(node_z[link.target], z)
            if link.dest_inferred:
                node_spans[link.target] += 1
                node_errors[link.target] += int(link.span.is_error)
                node_meta.setdefault(link.target, {"kind": "db", "instrumented": False, "inferred": True})
        for event in events:  # z dos nós de serviço
            entry = stats.get(event.activity)
            if entry and not event.attributes.get("db.system"):
                z = abs(egads.z_score(event.duration_us / 1000.0, float(entry[0]), float(entry[1])))
                node_z[event.entity] = max(node_z[event.entity], z)

    rep_events = traces.get(conformance.trace_id, []) if conformance else []
    rep_edges = trace_edges(rep_events) if rep_events else []
    rep_by_id = {e.span_id: e for e in rep_events}

    # 4. arestas ausentes e inesperadas (do trace representativo)
    if conformance is not None and rep_events:
        root = next((e for e in rep_events if e.depth == 0), rep_events[0])
        for dev in conformance.deviations:
            if dev.type == "missing":
                _add_missing(edges, node_meta, dev, root.entity)
            elif dev.type == "unexpected" and dev.span_id in rep_by_id:
                event = rep_by_id[dev.span_id]
                parent = rep_by_id.get(str(event.attributes.get("parent_span_id")))
                if parent is not None and parent.entity != event.entity:
                    key = (parent.entity, event.entity, "unexpected")
                    acc = edges.setdefault(key, _EdgeAcc(parent.entity, event.entity, "unexpected"))
                    acc.n_calls += 1
                    acc.traces.add(conformance.trace_id)
                    acc.durations.append(event.duration_us / 1000.0)
                    acc.activities.add(event.activity)
                    acc.edge_span_ids.add(event.span_id)

    edge_list = [_edge_json(acc) for acc in edges.values()]
    _apply_baseline_diff(edge_list, traces, service_graph)

    # entidades que só aparecem em arestas ausentes (não têm span no trace) também viram nó
    for edge in edge_list:
        for entity in (edge["source"], edge["target"]):
            node_meta.setdefault(entity, {"kind": "service", "instrumented": True, "inferred": False, "absent": True})

    suspect_by_entity = {c.pod_name: c for c in candidates}
    nodes = []
    for entity, meta in node_meta.items():
        cand = suspect_by_entity.get(entity)
        attribution = attributions.get(entity)
        top_metric = attribution.dominant_metric if attribution else None
        node = {
            "id": entity, "label": entity, **meta,
            "role": "suspect" if cand else "context",
            "rank": cand.rank if cand else None,
            "confidence": cand.confidence if cand else None,
            "score": cand.score if cand else None,
            "n_spans": node_spans.get(entity, 0), "n_error_spans": node_errors.get(entity, 0),
            "max_z": round(node_z.get(entity, 0.0), 3),
            "max_abs_delta": round(max((abs(d) for d in attribution.metric_deltas.values()), default=0.0), 3)
            if attribution else 0.0,
            "top_metric": top_metric,
        }
        nodes.append(node)

    highlight_nodes = sorted({n for e in rep_edges for n in (e.source, e.target)} | {e.entity for e in rep_events})
    highlight_edge_keys = {(e.source, e.target, e.kind) for e in rep_edges}

    # 7. tetos
    truncated = False
    if len(nodes) > max_nodes:
        truncated = True
        nodes.sort(key=lambda n: (n["role"] != "suspect", -n["n_error_spans"], -n["max_z"], -n["n_spans"], n["id"]))
        nodes = nodes[:max_nodes]
    kept = {n["id"] for n in nodes}
    edge_list = [e for e in edge_list if e["source"] in kept and e["target"] in kept]
    if len(edge_list) > max_edges:
        truncated = True
        edge_list.sort(key=lambda e: (not _has_signal(e, z_outlier), -e["n_calls"], e["source"], e["target"]))
        edge_list = edge_list[:max_edges]
    edge_list.sort(key=lambda e: (e["source"], e["target"], e["kind"]))
    for i, edge in enumerate(edge_list):
        edge["id"] = f"e{i}"
        edge["evidence_ids"] = _edge_evidence(edge, edges, error_spans, conformance)
        edge["highlight"] = (edge["source"], edge["target"], edge["kind"]) in highlight_edge_keys
    nodes.sort(key=lambda n: (n["rank"] is None, n["rank"] or 0, n["id"]))

    # 8. arestas anômalas → ids de evidência do E'
    for i, edge in enumerate(anomalous_edges({"edges": edge_list}, z_outlier)):
        edge["edge_evidence_id"] = f"edge:{i}"

    return {
        "version": MAP_VERSION,
        "phase": 2 if service_graph else 1,
        "generated_from": {
            "n_traces": len(traces),
            "window_start": window[0].isoformat() if window else None,
            "window_end": window[1].isoformat() if window else None,
        },
        "nodes": nodes,
        "edges": edge_list,
        "highlight": {
            "trace_id": conformance.trace_id if conformance else None,
            "node_ids": [n for n in highlight_nodes if n in kept],
            "edge_ids": [e["id"] for e in edge_list if e["highlight"]],
        },
        "truncated": truncated,
    }


def _add_missing(
    edges: dict[tuple[str, str, str], _EdgeAcc], node_meta: dict[str, dict[str, Any]], dev: Deviation, caller: str
) -> None:
    service = dev.activity.split(": ", 1)[0]
    target = next((n for n in node_meta if short_service(n) == service), None) or normalize_entity(
        f"teastore-{service}"
    )
    if target == caller:
        return
    for kind in ("call", "inferred_call"):
        acc = edges.get((caller, target, kind))
        if acc is not None:
            acc.n_missing += 1
            acc.missing_activities.append(dev.activity)
            return
    key = (caller, target, "missing")
    acc = edges.setdefault(key, _EdgeAcc(caller, target, "missing"))
    acc.n_missing += 1
    acc.missing_activities.append(dev.activity)
    acc.activities.add(dev.activity)


def _edge_json(acc: _EdgeAcc) -> dict[str, Any]:
    durations = acc.durations
    stats = summarize(durations) if durations else None
    return {
        "id": "", "source": acc.source, "target": acc.target, "kind": acc.kind, "dest_inferred": acc.dest_inferred,
        "n_calls": acc.n_calls, "n_traces": len(acc.traces),
        "mean_ms": round(stats[0], 3) if stats else 0.0, "p95_ms": round(stats[4], 3) if stats else 0.0,
        "n_errors": acc.n_errors, "z": round(acc.z, 3), "n_missing": acc.n_missing,
        "missing_activities": list(acc.missing_activities), "baseline": None, "diff": None,
        "activities": sorted(acc.activities), "evidence_ids": [], "highlight": False,
    }


def _apply_baseline_diff(
    edge_list: list[dict[str, Any]],
    traces: Mapping[str, list[TraceEvent]],
    service_graph: Mapping[str, Mapping[str, Sequence[float]]] | None,
) -> None:
    """Fase 2: compara a frequência e a duração das arestas com as do baseline."""
    if not service_graph:
        return
    by_endpoint: dict[str, int] = defaultdict(int)
    for events in traces.values():
        endpoint = _endpoint_of(events)
        if endpoint:
            by_endpoint[endpoint] += 1
    total = sum(by_endpoint.values()) or 1
    baseline: dict[str, list[float]] = {}
    for endpoint, count in by_endpoint.items():
        for key, values in (service_graph.get(endpoint) or {}).items():
            merged = baseline.setdefault(key, [0.0, 0.0, 0.0, 0.0])
            weight = count / total
            for i in range(4):
                merged[i] += float(values[i]) * weight
    seen = set()
    for edge in edge_list:
        key = f"{edge['source']}->{edge['target']}"
        seen.add(key)
        base = baseline.get(key)
        if base is None:
            edge["diff"] = "new" if edge["kind"] in ("call", "inferred_call") else None
            continue
        edge["baseline"] = [round(v, 3) for v in base]
        if edge["kind"] in ("call", "inferred_call") and base[2] >= 0:
            z = abs(egads.z_score(edge["mean_ms"], base[1], base[2]))
            if z >= 3.0:
                edge["diff"] = "slower"
                edge["z"] = max(edge["z"], round(z, 3))
    for key, base in baseline.items():
        if key in seen or base[0] < ABSENT_MIN_CALLS_PER_TRACE:
            continue
        source, _, target = key.partition("->")
        edge_list.append({
            "id": "", "source": source, "target": target, "kind": "missing", "dest_inferred": False,
            "n_calls": 0, "n_traces": 0, "mean_ms": 0.0, "p95_ms": 0.0, "n_errors": 0, "z": 0.0, "n_missing": 1,
            "missing_activities": [], "baseline": [round(v, 3) for v in base], "diff": "absent",
            "activities": [], "evidence_ids": [], "highlight": False,
        })


def _has_signal(edge: dict[str, Any], z_outlier: float) -> bool:
    return edge["kind"] in ("missing", "unexpected") or edge["n_errors"] > 0 or abs(edge["z"]) >= z_outlier \
        or edge.get("diff") in ("absent", "new", "slower")


def _edge_evidence(
    edge: dict[str, Any],
    accs: Mapping[tuple[str, str, str], _EdgeAcc],
    error_spans: Sequence[ErrorSpan],
    conformance: ConformanceResult | None,
) -> list[str]:
    ids: list[str] = []
    acc = accs.get((edge["source"], edge["target"], edge["kind"]))
    span_ids = acc.edge_span_ids if acc else set()
    ids += [f"err:{i}" for i, err in enumerate(error_spans) if err.span_id in span_ids]
    if conformance is not None:
        for i, dev in enumerate(conformance.deviations):
            if dev.span_id in span_ids or (dev.type == "missing" and dev.activity in edge["missing_activities"]):
                ids.append(f"dev:{i}")
    ids += [f"tmp:{sanitize_evidence_id(a)}" for a in edge["activities"] if edge["z"] >= 3.0][:3]
    return ids


def anomalous_edges(
    problem_map: Mapping[str, Any], z_outlier: float = 3.0, limit: int = MAX_ANOMALOUS_EDGES
) -> list[dict[str, Any]]:
    """Arestas com sinal, por |z| decrescente: ausentes/inesperadas, com erro, lentas ou diferentes do baseline.

    Divergência da regra original ("kind ≠ call"): `inferred_call` NÃO é anômala — todo órfão do
    Jaeger gera uma, e marcá-las inundaria o E' em todo incidente.
    """
    signal = [e for e in problem_map.get("edges", []) if _has_signal(e, z_outlier)]
    signal.sort(key=lambda e: (-abs(e["z"]), -e["n_errors"], e["source"], e["target"]))
    return signal[:limit]


def petri_net_graph(model: tuple[Any, Any, Any], conformance: ConformanceResult | None = None) -> dict[str, Any]:
    """Fase 3: PetriNet do endpoint convertido em grafo JSON (lugares, transições, arcos)."""
    net, im, fm = model
    missing = {d.activity for d in (conformance.deviations if conformance else []) if d.type == "missing"}
    unexpected = {d.activity for d in (conformance.deviations if conformance else []) if d.type == "unexpected"}
    nodes = []
    for place in net.places:
        nodes.append({"id": f"p:{place.name}", "label": "", "kind": "place",
                      "marking": "initial" if place in im else "final" if place in fm else None})
    for tr in net.transitions:
        label = tr.label
        nodes.append({"id": f"t:{tr.name}", "label": label or "τ", "kind": "transition" if label else "silent",
                      "deviation": "missing" if label in missing else "unexpected" if label in unexpected else None})
    arcs = []
    for arc in net.arcs:
        src = f"p:{arc.source.name}" if arc.source in net.places else f"t:{arc.source.name}"
        dst = f"p:{arc.target.name}" if arc.target in net.places else f"t:{arc.target.name}"
        arcs.append({"source": src, "target": dst})
    return {"version": MAP_VERSION, "phase": 3, "nodes": nodes, "edges": arcs}

