"""Síntese causal por LLM: evidências restritas E', prompt Avizienis e validação."""

import json
import os
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from src.application.stage3.entities import normalize_entity, sanitize_evidence_id
from src.application.stage3.problem_map import anomalous_edges
from src.application.stage3.types import (
    AttributionResult,
    ConformanceResult,
    EntityCandidate,
    ErrorSpan,
    TemporalDeviation,
)

REQUIRED_FIELDS = (
    "fault", "error", "failure", "hypothesis", "confidence", "confidence_reason",
    "supporting_evidence", "alternative_hypotheses", "missing_evidence", "abstain",
)
CONFIDENCE_LEVELS = {"alta", "média", "baixa"}
_CONFIDENCE_ORDER = {"baixa": 0, "média": 1, "alta": 2}
NO_SIGNAL_NOTE = "suspeito 1 sem sinais de métrica, de Conformance ou de votos (acrescentado pela validação P4)"

STAGE3_PROMPT_TEMPLATE = """\
Você é um analisador de falhas em sistemas cloud-native. Use APENAS as evidências
abaixo. Não invente eventos, serviços ou métricas não listados. Cada evidência abaixo traz seu id
entre colchetes (ex.: [dev:0]); cite em "supporting_evidence" os ids que sustentam a hipótese.
Ancore a hipótese no suspeito 1; em "alternative_hypotheses" cite os demais suspeitos (pela
entidade) e por que são menos prováveis; não altere a ordem nem a certeza dos suspeitos.

Sistema: {system_name}
Incidente: {incident_hypothesis} (detectado em {incident_created_at})
Serviço candidato: {candidate_service} (pod: {candidate_pod})
Suspeitos (ordem determinística; a certeza é da localização, não da causa):
{suspects_block}
Arestas anômalas do mapa (chamadas ausentes, inesperadas, com erro ou lentas):
{edges_block}
{fitness_line}{structural_block}
--- EVIDÊNCIAS DE ATRIBUTO ---
Tipo de anomalia: {anomaly_type}
Métrica principal: {dominant_metric}
Início estimado: {t_start}
Métricas anômalas: {metrics_summary}
Spans com erro: {errors_summary}
Desvios temporais: {temporal_summary}

--- TOPOLOGIA ---
Dependências upstream: {upstream_services}
Dependências downstream: {downstream_services}

--- TAREFA ---
Responda EXATAMENTE neste formato JSON:
{{
  "fault": "causa (fault) no nível de recurso ou configuração",
  "error": "manifestação interna observada",
  "failure": "sintoma observável pelo usuário ou SLO violado",
  "hypothesis": "hipótese causal principal em 1–2 frases",
  "confidence": "alta|média|baixa",
  "confidence_reason": "justificativa com número de evidências convergentes",
  "supporting_evidence": ["ids de evidências que sustentam a hipótese"],
  "alternative_hypotheses": ["da mais para a menos plausível"],
  "missing_evidence": ["..."],
  "abstain": false
}}
Se evidências insuficientes: abstain=true, demais campos vazios ("" ou []).
"""

_STRUCTURAL_BLOCK = """
--- EVIDÊNCIAS ESTRUTURAIS (Process Mining) ---
Desvios de controle de fluxo:
  Atividades ausentes:     {missing}
  Atividades inesperadas:  {unexpected}
  Atividades fora de ordem: {wrong_order}
"""
_PARTIAL_LOCALIZATION_NOTE = (
    "\nAtenção: a localização por Conformance Checking não foi possível (traces insuficientes na janela); "
    "não há evidência estrutural. Registre o Conformance em \"missing_evidence\" e não declare confiança \"alta\".\n"
)


@dataclass
class RestrictedEvidence:
    """E': evidências que o LLM pode citar, cada uma com id estável."""

    items: dict[str, dict[str, Any]] = field(default_factory=dict)   # id → {id, kind, text}
    entities: list[str] = field(default_factory=list)                # entidades citáveis
    partial_localization: bool = False
    context: dict[str, Any] = field(default_factory=dict)            # campos do prompt
    # P4: teto da confiança da síntese
    localization_confidence: str | None = None
    top_without_signals: bool = False

    def add(self, item_id: str, kind: str, text: str, **extra: Any) -> None:
        self.items[item_id] = {"id": item_id, "kind": kind, "text": text, **extra}

    def ids(self) -> set[str]:
        return set(self.items)

    def line(self, item_id: str) -> str:
        return f"[{item_id}] {self.items[item_id]['text']}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "items": list(self.items.values()), "entities": list(self.entities),
            "partial_localization": self.partial_localization, "context": self.context,
            "localization_confidence": self.localization_confidence, "top_without_signals": self.top_without_signals,
        }


def build_restricted_evidence(
    *,
    system_name: str,
    incident_hypothesis: str,
    incident_created_at: str,
    conformance: ConformanceResult | None,
    candidates: Sequence[EntityCandidate],
    attribution: AttributionResult | None,
    attributions: Mapping[str, AttributionResult | None] | None = None,
    error_spans: Sequence[ErrorSpan] = (),
    span_temporal: Sequence[TemporalDeviation] = (),
    metric_temporal: Sequence[TemporalDeviation] = (),
    problem_map: Mapping[str, Any] | None = None,
    z_outlier: float = 3.0,
    fitness_threshold: float = 0.8,
) -> RestrictedEvidence:
    ev = RestrictedEvidence(partial_localization=conformance is None)
    top = candidates[0] if candidates else None
    if top is not None:
        ev.localization_confidence = top.confidence or None
        ev.top_without_signals = not top.signals and not getattr(top, "votes", None)
    top_entity = top.pod_name if top else (attribution.pod_name if attribution else "")
    entities: list[str] = [c.pod_name for c in candidates]
    if attribution and attribution.pod_name not in entities:
        entities.append(normalize_entity(attribution.pod_name))

    if conformance is not None:
        ev.add("fit", "fitness",
               f"fitness {conformance.fitness:.2f} no endpoint {conformance.endpoint} "
               f"(trace {conformance.trace_id}; {conformance.n_traces_aligned} traces alinhados)")
        for i, dev in enumerate(conformance.deviations):
            ev.add(f"dev:{i}", "deviation", f"{dev.type}: {dev.activity} (pod {dev.pod})")
            entities.append(normalize_entity(dev.pod))

    for cand in candidates:
        sinais = ", ".join(cand.signals) or "nenhum"
        if cand.rank == 1:
            ev.add(f"cand:{cand.rank}", "candidate",
                   f"suspeito 1 {cand.pod_name}: {cand.deviation_type} em {cand.activity} (profundidade {cand.depth}); "
                   f"sinais: {sinais}; certeza da localização {cand.confidence}")
        else:
            ev.add(f"cand:{cand.rank}", "candidate",
                   f"suspeito {cand.rank} {cand.pod_name}: melhor span {cand.activity}; sinais: {sinais}; "
                   f"certeza {cand.confidence}")

    for i, err in enumerate(error_spans):
        detail = f" — {err.exception}" if err.exception else ""
        ev.add(f"err:{i}", "error_span", f"erro em {err.activity} (pod {err.pod}, profundidade {err.depth}){detail}")
        entities.append(normalize_entity(err.pod))

    if problem_map:
        for edge in anomalous_edges(problem_map, z_outlier):
            eid = edge.get("edge_evidence_id")
            if not eid:
                continue
            bits = [f"{edge['source']} → {edge['target']} ({edge['kind']})"]
            if edge["n_errors"]:
                bits.append(f"{edge['n_errors']} erro(s)")
            if edge["n_missing"]:
                bits.append(f"{edge['n_missing']} chamada(s) ausente(s)")
            if edge["z"]:
                bits.append(f"|z|={edge['z']:.1f}")
            if edge.get("diff"):
                bits.append(f"vs normal: {edge['diff']}")
            ev.add(eid, "edge", ", ".join(bits))
        for node in problem_map.get("nodes", []):
            entities.append(str(node["id"]))

    if attribution is not None:
        for metric in attribution.anomalous_metrics:
            ev.add(f"met:{metric}", "metric",
                   f"{metric} = {attribution.metric_deltas[metric]:+.1f}σ em relação ao normal "
                   f"({attribution.pod_name})")
    for tdev in [*span_temporal, *metric_temporal]:
        when = tdev.t_start.isoformat() if tdev.t_start else "n/d"
        ev.add(f"tmp:{sanitize_evidence_id(tdev.metric_name)}", "temporal",
               f"{tdev.metric_name} ({tdev.pod_name}): |δ|={tdev.magnitude:.1f} desde {when}"
               + (", série inteira anômala" if tdev.is_anomalous_ts else "")
               + (", acima do p95 da baseline (percentil, não por z-score)" if tdev.via_percentile else ""))

    upstream: list[str] = []
    downstream: list[str] = []
    for edge in (problem_map or {}).get("edges", []):
        if edge["kind"] not in ("call", "inferred_call"):
            continue
        if edge["target"] == top_entity and edge["source"] not in upstream:
            upstream.append(edge["source"])
        if edge["source"] == top_entity and edge["target"] not in downstream:
            downstream.append(edge["target"])
    for service in [*upstream, *downstream]:
        ev.add(f"dep:{service}", "dependency", f"{service} está ligado a {top_entity} nos traces da janela")
        entities.append(service)

    ev.entities = list(dict.fromkeys(e for e in entities if e))
    ev.context = {
        "system_name": system_name, "incident_hypothesis": incident_hypothesis,
        "incident_created_at": incident_created_at,
        "candidate_service": top.service if top else top_entity, "candidate_pod": top_entity,
        "fitness_threshold": fitness_threshold,
        "anomaly_type": attribution.anomaly_type if attribution else "n/d",
        "dominant_metric": (f"{attribution.dominant_metric} = {attribution.dominant_delta:+.1f}σ em relação ao normal"
                            if attribution else "n/d"),
        "t_start": (top.t_start.isoformat() if top and top.t_start else "n/d"),
        "upstream": upstream, "downstream": downstream,
    }
    return ev


def _ids_of(ev: RestrictedEvidence, kind: str) -> str:
    lines = [ev.line(i) for i, item in ev.items.items() if item["kind"] == kind]
    return "; ".join(lines) if lines else "nenhum"


def render_prompt(ev: RestrictedEvidence) -> str:
    ctx = ev.context
    if ev.partial_localization:
        fitness_line, structural = _PARTIAL_LOCALIZATION_NOTE, ""
    else:
        by_type: dict[str, list[str]] = {"missing": [], "unexpected": [], "wrong_order": []}
        for item_id, item in ev.items.items():
            if item["kind"] == "deviation":
                by_type[item["text"].split(":", 1)[0]].append(ev.line(item_id))
        fitness_line = (
            f"Fitness de conformance: {ev.line('fit')} (< {ctx['fitness_threshold']} = desvio significativo)\n"
            if "fit" in ev.items else ""
        )
        structural = _STRUCTURAL_BLOCK.format(**{k: "; ".join(v) or "nenhuma" for k, v in by_type.items()})
    suspects = "\n".join(f"  {ev.line(i)}" for i, item in ev.items.items() if item["kind"] == "candidate") \
        or "  (nenhum suspeito por Conformance)"
    edges = "\n".join(f"  {ev.line(i)}" for i, item in ev.items.items() if item["kind"] == "edge") or "  nenhuma"
    return STAGE3_PROMPT_TEMPLATE.format(
        system_name=ctx["system_name"], incident_hypothesis=ctx["incident_hypothesis"],
        incident_created_at=ctx["incident_created_at"], candidate_service=ctx["candidate_service"],
        candidate_pod=ctx["candidate_pod"], suspects_block=suspects, edges_block=edges,
        fitness_line=fitness_line, structural_block=structural, anomaly_type=ctx["anomaly_type"],
        dominant_metric=ctx["dominant_metric"], t_start=ctx["t_start"], metrics_summary=_ids_of(ev, "metric"),
        errors_summary=_ids_of(ev, "error_span"), temporal_summary=_ids_of(ev, "temporal"),
        upstream_services=", ".join(f"[dep:{s}] {s}" for s in ctx["upstream"]) or "nenhuma",
        downstream_services=", ".join(f"[dep:{s}] {s}" for s in ctx["downstream"]) or "nenhuma",
    )


# --- chamada e validação ---


@dataclass
class LLMSynthesisResult:
    fault: str = ""
    error: str = ""
    failure: str = ""
    hypothesis: str = ""
    confidence: str = ""
    confidence_reason: str = ""
    supporting_evidence: list[str] = field(default_factory=list)
    alternative_hypotheses: list[str] = field(default_factory=list)
    missing_evidence: list[str] = field(default_factory=list)
    abstain: bool = False
    abstain_reason: str | None = None
    raw_response: str = ""
    prompt_used: str = ""
    llm_provider: str = ""
    llm_model: str = ""
    validation_errors: list[str] = field(default_factory=list)


def parse_llm_json(raw: str) -> dict[str, Any] | None:
    text = raw.strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if fenced:
        text = fenced.group(1)
    else:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            return None
        text = text[start:end + 1]
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _entity_mentions(text: str, universe: Sequence[str]) -> set[str]:
    """Tokens com cara de entidade: nomes com hífen cujo prefixo é o de alguma entidade conhecida."""
    prefixes = {e.split("-", 1)[0] for e in universe if "-" in e}
    if not prefixes:
        return set()
    tokens = re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)+", text.lower())
    return {normalize_entity(t) for t in tokens if t.split("-", 1)[0] in prefixes}


def validate_llm_output(data: dict[str, Any] | None, ev: RestrictedEvidence) -> list[str]:
    """Regras 1–5 de validação da saída; lista vazia = válido."""
    if data is None:
        return ["resposta não é um JSON válido"]
    errors = [f"campo ausente: {f}" for f in REQUIRED_FIELDS if f not in data]
    if errors:
        return errors
    if data["abstain"] is True:
        return []
    if data["confidence"] not in CONFIDENCE_LEVELS:
        errors.append(f"confidence inválida: {data['confidence']!r}")
    known = {normalize_entity(e).lower() for e in ev.entities}
    for name in ("fault", "error", "failure"):
        for mention in sorted(_entity_mentions(str(data[name]), ev.entities)):
            if mention not in known:
                errors.append(f"entidade citada em {name} fora de E': {mention}")
    cited = data["supporting_evidence"]
    if not isinstance(cited, list) or not cited:
        errors.append("supporting_evidence vazia")
    else:
        errors += [f"id inexistente em E': {i}" for i in cited if i not in ev.ids()]
    if ev.partial_localization:
        if data["confidence"] == "alta":
            errors.append("confiança 'alta' não permitida sem localização por Conformance")
        if not any("conformance" in str(m).lower() for m in data["missing_evidence"]):
            errors.append("missing_evidence deve citar o Conformance Checking")
    return errors


def build_llm_client(config: Mapping[str, Any]) -> Any:
    """Cliente a partir de `repo.get_llm_config()` (mesma escolha de provedor dos motores de diagnóstico)."""
    from src.rag.providers import CohereClient, GeminiClient, MockJudge, normalize_llm_model

    provider = str(config.get("provider") or "mock")
    model = normalize_llm_model(provider, config.get("model"))
    if provider == "gemini":
        return GeminiClient(api_key=str(config.get("api_key") or os.environ.get("GEMINI_API_KEY", "")), model=model)
    if provider == "cohere":
        return CohereClient(
            api_key=str(config.get("cohere_api_key") or os.environ.get("COHERE_API_KEY", "")), model=model
        )
    return MockJudge()


def synthesize(
    ev: RestrictedEvidence, client: Any, *, provider: str = "", model: str = ""
) -> LLMSynthesisResult:
    """Chama o LLM com o prompt de E' e valida a saída."""
    prompt = render_prompt(ev)
    raw = client.generate(prompt, "", 0.0)
    result = LLMSynthesisResult(raw_response=raw, prompt_used=prompt, llm_provider=provider, llm_model=model)
    data = parse_llm_json(raw)
    result.validation_errors = validate_llm_output(data, ev)
    if result.validation_errors or data is None:
        result.abstain, result.abstain_reason = True, "invalid_llm_output"
        return result
    result.abstain = data["abstain"] is True
    if result.abstain:
        result.abstain_reason = "llm_abstained"
        return result
    for name in ("fault", "error", "failure", "hypothesis", "confidence", "confidence_reason"):
        setattr(result, name, str(data[name]))
    for name in ("supporting_evidence", "alternative_hypotheses", "missing_evidence"):
        setattr(result, name, [str(x) for x in data[name]])
    enforce_confidence_coherence(result, ev)
    return result


def enforce_confidence_coherence(result: LLMSynthesisResult, ev: RestrictedEvidence) -> None:
    """P4: a conclusão causal não pode ser mais confiante que a localização em que se apoia.

    Rebaixa (não rejeita) a confiança da síntese ao nível do suspeito 1 e, se ele não tem sinal
    nenhum, força `baixa` e registra a ausência em `missing_evidence`. Determinístico: não depende
    de o LLM seguir a instrução do prompt.
    """
    ceiling = "baixa" if ev.top_without_signals else ev.localization_confidence
    if ceiling in _CONFIDENCE_ORDER and result.confidence in _CONFIDENCE_ORDER \
            and _CONFIDENCE_ORDER[result.confidence] > _CONFIDENCE_ORDER[ceiling]:
        why = "suspeito 1 sem sinais" if ev.top_without_signals else f"certeza da localização {ceiling}"
        result.confidence_reason = (f"{result.confidence_reason} [rebaixada de {result.confidence} para "
                                    f"{ceiling}: {why} (P4)]").strip()
        result.confidence = ceiling
    if ev.top_without_signals and not any("sina" in m.lower() for m in result.missing_evidence):
        result.missing_evidence.append(NO_SIGNAL_NOTE)
