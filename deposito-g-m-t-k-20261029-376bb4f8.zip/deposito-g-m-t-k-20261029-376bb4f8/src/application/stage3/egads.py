"""Detectores temporais no estilo EGADS (Laptev et al., 2015)."""

from collections.abc import Sequence

EPSILON = 1e-6


def z_score(value: float, mean: float, std: float) -> float:
    return (value - mean) / (std + EPSILON)


def detect_outlier(
    series: Sequence[float], baseline_mean: float, baseline_std: float, z_threshold: float = 3.0
) -> list[int]:
    """Índices com |z-score| > z_threshold em relação ao baseline."""
    return [i for i, x in enumerate(series) if abs(z_score(x, baseline_mean, baseline_std)) > z_threshold]


def detect_change_point(series: Sequence[float], baseline_std: float, window: int = 5) -> list[int]:
    """Mudança de nível: |média(janela seguinte) − média(janela anterior)| > 2σ_baseline.

    Índice = primeiro ponto da janela seguinte. Sequências consecutivas de índices (o mesmo
    degrau visto por janelas deslocadas) colapsam no de maior diferença.
    """
    if window < 1 or len(series) < 2 * window:
        return []
    limit = 2 * (baseline_std + EPSILON)
    hits: list[tuple[int, float]] = []
    for i in range(window, len(series) - window + 1):
        before = sum(series[i - window:i]) / window
        after = sum(series[i:i + window]) / window
        if abs(after - before) > limit:
            hits.append((i, abs(after - before)))
    points: list[int] = []
    run: list[tuple[int, float]] = []
    for hit in hits:
        if run and hit[0] != run[-1][0] + 1:
            points.append(max(run, key=lambda h: h[1])[0])
            run = []
        run.append(hit)
    if run:
        points.append(max(run, key=lambda h: h[1])[0])
    return points


def detect_percentile_outlier(series: Sequence[float], p95: float, factor: float = 1.0) -> list[int]:
    """Índices com valor > `p95 * factor` (refinamento).

    Alternativa ao z-score fixo: robusta a baseline assimétrica/bimodal, onde a mistura de
    comportamentos (ex. "adicionar item" rápido + "finalizar pedido" lento na mesma atividade)
    infla o desvio-padrão e mascara um desvio real que fica abaixo de `z_outlier`.
    """
    if p95 <= 0:
        return []
    threshold = p95 * factor
    return [i for i, x in enumerate(series) if x > threshold]


def detect_anomalous_ts(
    series: Sequence[float], baseline_mean: float, baseline_std: float, z_threshold: float = 3.0
) -> bool:
    """Série inteira anômala quando mais de 50% dos pontos são outliers."""
    if not series:
        return False
    return len(detect_outlier(series, baseline_mean, baseline_std, z_threshold)) / len(series) > 0.5
