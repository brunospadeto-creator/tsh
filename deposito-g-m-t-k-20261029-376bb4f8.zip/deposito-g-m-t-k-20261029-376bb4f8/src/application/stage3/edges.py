"""Arestas de chamada entre entidades de um trace (base do mapa do problema e do `service_graph`)."""

from dataclasses import dataclass

from src.application.stage3.traces import TraceEvent


@dataclass(frozen=True)
class Edge:
    source: str
    target: str
    kind: str                 # "call" | "inferred_call"
    span: TraceEvent          # span de destino (duração e erro da aresta)
    dest_inferred: bool = False


def db_node(event: TraceEvent) -> str | None:
    """Nó do banco inferido de um span JDBC (`<db.system>:<db.name>`); None se não é span de banco."""
    system = event.attributes.get("db.system")
    if not system:
        return None
    name = event.attributes.get("db.name")
    return f"{system}:{name}" if name else str(system)


def trace_edges(events: list[TraceEvent]) -> list[Edge]:
    """Arestas de UM trace, a partir dos pais dos spans (não da ordem temporal).

    - span cujo pai está no trace e cujo serviço difere: `pai → span` (`call`);
    - `server` órfão anexado à raiz: `raiz → órfão` (`inferred_call`);
    - span de banco (`db.system`): `entidade → nó do banco` (`call`, destino inferido).
    """
    by_id = {e.span_id: e for e in events}
    edges: list[Edge] = []
    for event in events:
        node = db_node(event)
        if node is not None:
            edges.append(Edge(event.entity, node, "call", event, dest_inferred=True))
            continue
        parent = by_id.get(str(event.attributes.get("parent_span_id")))
        if parent is None or parent.entity == event.entity:
            continue
        kind = "inferred_call" if event.attributes.get("orphan") else "call"
        edges.append(Edge(parent.entity, event.entity, kind, event))
    return edges
