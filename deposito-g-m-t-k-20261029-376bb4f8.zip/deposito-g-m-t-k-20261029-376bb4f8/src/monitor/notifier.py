import logging
import smtplib
import ssl
from abc import ABC, abstractmethod
from email.message import EmailMessage
from typing import Any

import httpx

from src.infra.settings import get_settings

logger = logging.getLogger("monitor")


def _extract_log_fields(log: Any) -> dict[str, Any]:
    if isinstance(log, dict):
        return {
            "system_id": log.get("system_id", ""),
            "evidence_id": log.get("evidence_id", ""),
            "primary_hypothesis": log.get("primary_hypothesis", ""),
            "confidence": log.get("confidence", 0.0),
        }
    return {
        "system_id": getattr(log, "system_id", ""),
        "evidence_id": getattr(log, "evidence_id", ""),
        "primary_hypothesis": getattr(log, "primary_hypothesis", ""),
        "confidence": getattr(log, "confidence", 0.0),
    }


class Notifier(ABC):
    @abstractmethod
    def notify(self, contract: Any, log: Any) -> None:
        ...


class LogNotifier(Notifier):
    def notify(self, contract: Any, log: Any) -> None:
        fields = _extract_log_fields(log)
        logger.warning(
            f"[ANOMALY] system={fields['system_id']} evidence={fields['evidence_id']} "
            f"hypothesis={fields['primary_hypothesis']} confidence={fields['confidence']}"
        )


class EmailNotifier(Notifier):
    def __init__(self) -> None:
        self.logger = logging.getLogger("monitor.email")

    def notify(self, contract: Any, log: Any) -> None:
        settings = get_settings()
        fields = _extract_log_fields(log)
        msg = EmailMessage()
        msg["Subject"] = f"[VERITAS] Anomalia detectada em {fields['system_id']}"
        msg["From"] = settings.smtp_from
        msg["To"] = settings.smtp_to
        body = (
            f"Sistema: {fields['system_id']}\n"
            f"Evidência: {fields['evidence_id']}\n"
            f"Hipótese: {fields['primary_hypothesis']}\n"
            f"Confiança: {fields['confidence']}\n"
        )
        msg.set_content(body)
        try:
            ctx = ssl.create_default_context() if settings.smtp_use_tls else None
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as server:
                if settings.smtp_use_tls:
                    server.starttls(context=ctx)
                if settings.smtp_user:
                    server.login(settings.smtp_user, settings.smtp_password)
                server.send_message(msg)
            self.logger.info("Email sent to %s", settings.smtp_to)
        except Exception as exc:
            self.logger.error("Failed to send email: %s", exc)


class WebhookNotifier(Notifier):
    def __init__(self) -> None:
        self.logger = logging.getLogger("monitor.webhook")

    def notify(self, contract: Any, log: Any) -> None:
        settings = get_settings()
        fields = _extract_log_fields(log)
        payload = {
            "system_id": fields["system_id"],
            "evidence_id": fields["evidence_id"],
            "primary_hypothesis": fields["primary_hypothesis"],
            "confidence": fields["confidence"],
        }
        try:
            resp = httpx.post(settings.webhook_url, json=payload, timeout=10)
            resp.raise_for_status()
            self.logger.info("Webhook sent to %s (status=%d)", settings.webhook_url, resp.status_code)
        except Exception as exc:
            self.logger.error("Failed to send webhook: %s", exc)


def create_notifier() -> Notifier:
    settings = get_settings()
    backend = settings.notifier_backend.lower()
    if backend == "email":
        return EmailNotifier()
    if backend == "webhook":
        return WebhookNotifier()
    return LogNotifier()
