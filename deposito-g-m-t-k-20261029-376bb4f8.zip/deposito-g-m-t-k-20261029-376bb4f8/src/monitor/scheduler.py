from typing import Any

from src.infra.settings import get_settings
from src.store.repository import Repository


def poll_active_systems(repo: Repository | None = None) -> int:
    if repo is None:
        settings = get_settings()
        repo = Repository(settings.db_url)
        repo.create_all()
    scheduled = repo.schedule_due_monitoring()
    scheduled += repo.schedule_due_gate_recalibrations()
    return scheduled


def refresh_schedule(active_systems: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    if active_systems is None:
        return []
    return [
        {
            "system_id": system["system_id"],
            "job_kind": "monitoring",
            "schedule": system.get("polling_interval_sec", 300),
        }
        for system in active_systems
    ]
