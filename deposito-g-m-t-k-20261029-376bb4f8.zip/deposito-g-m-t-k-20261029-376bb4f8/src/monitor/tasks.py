import json
import logging
import threading
from datetime import UTC, datetime, timedelta
from typing import Any

import httpx

from src.diagnosis.labels import canonical_label, is_baseline_label
from src.monitor.notifier import LogNotifier, create_notifier  # noqa: F401  (parcheado em testes)

logger = logging.getLogger(__name__)

_ML_RUNTIME_URL: str | None = None

_ENGINE_CACHE_MAX = 32
_DRAIN_ENGINE_CACHE_MAX = 16

# Process-level LRU caches keyed by (system_id, run_id, stage) / (system_id, collection_id).
# Bounded to avoid unbounded memory growth when many systems/runs are active.
# Só o job-runner (single-threaded, sequencial) toca esses caches hoje, então
# não há corrida real em produção — os locks são blindagem barata contra
# mudanças futuras (ex: se o monitoramento passar a ser disparado direto de
# uma rota síncrona), não a correção de um bug ativo.
_ENGINE_CACHE: dict[str, Any] = {}
_DRAIN_ENGINE_CACHE: dict[str, Any] = {}
_ENGINE_CACHE_LOCK = threading.Lock()
_DRAIN_CACHE_LOCK = threading.Lock()


def _pycaret_model_mtime(system_id: str, stage: int = 2) -> float | None:
    """Returns mtime of pycaret_stage{N}/model.skops, or None if absent."""
    import re
    from pathlib import Path

    from src.infra.settings import get_settings
    def _safe(s: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]", "_", s)
    path = Path(get_settings().models_dir) / _safe(system_id) / f"pycaret_stage{stage}" / "model.skops"
    try:
        return path.stat().st_mtime
    except FileNotFoundError:
        return None


def _cache_set(
    cache: dict[str, Any],
    key: str,
    value: Any,
    maxsize: int,
    lock: "threading.Lock | None" = None,
) -> None:
    """Insert into a dict-based LRU cache, evicting the oldest entry when full."""
    if lock is not None:
        with lock:
            _cache_set_unsafe(cache, key, value, maxsize)
    else:
        _cache_set_unsafe(cache, key, value, maxsize)


def _cache_set_unsafe(cache: dict[str, Any], key: str, value: Any, maxsize: int) -> None:
    if key in cache:
        cache.pop(key)
    elif len(cache) >= maxsize:
        cache.pop(next(iter(cache)))
    cache[key] = value


def _cache_get(
    cache: dict[str, Any],
    key: str,
    lock: "threading.Lock | None" = None,
    default: Any = None,
) -> Any:
    """Lê de um cache LRU baseado em dict, promovendo a chave a mais recente.

    `dict` normal preserva ordem de inserção mas não tem `move_to_end`
    (isso é só de `OrderedDict`) -- uma leitura sem popar+reinserir não move
    a chave, então `_cache_set_unsafe`'s `next(iter(cache))` (o mais antigo
    por INSERÇÃO) evictava entradas usadas com frequência só porque foram
    inseridas primeiro -- o cache se comportava como FIFO, não LRU (achado
    real de code review, 2026-09-15).
    """
    def _get_unsafe() -> Any:
        if key not in cache:
            return default
        value = cache.pop(key)
        cache[key] = value
        return value

    if lock is not None:
        with lock:
            return _get_unsafe()
    return _get_unsafe()


def _get_ml_runtime_url() -> str:
    global _ML_RUNTIME_URL
    if _ML_RUNTIME_URL is None:
        from src.infra.settings import get_settings

        _ML_RUNTIME_URL = get_settings().ml_runtime_url
    return _ML_RUNTIME_URL


def _diagnose_via_http(
    system_id: str,
    evidence_dict: dict[str, Any],
    run_id: str | None = None,
) -> dict[str, Any] | None:
    url = f"{_get_ml_runtime_url()}/diagnose"
    try:
        resp = httpx.post(
            url,
            json={
                "system_id": system_id,
                "evidence": evidence_dict,
                "run_id": run_id,
            },
            timeout=30.0,
        )
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError as exc:
        logger.warning("ML Runtime returned %s for %s: %s", exc.response.status_code, system_id, exc.response.text)
        return None
    except httpx.RequestError as exc:
        logger.warning("ML Runtime request failed for %s: %s", system_id, exc)
        return None


def _get_active_system(system_id: str, *, repo: Any | None = None) -> dict[str, Any] | None:
    try:
        from src.infra.settings import get_settings
        from src.store.repository import Repository

        if repo is None:
            settings = get_settings()
            repo = Repository(settings.db_url)
            repo.create_all()
        system = repo.get_system(system_id)
        if system is None:
            return None
        run_id = system.active_run_id or None
        run = None
        if run_id:
            run = repo.get_training_run(run_id)
        collection_id = run.collection_id if run is not None else None
        engine_config = json.loads(str(system.engine_config)) if system.engine_config else {}
        if not collection_id:
            collection_id = engine_config.get("collection_id")

        # Campos de estágios independentes
        stage1_engine = getattr(system, "stage1_engine", None)
        stage2_engine = getattr(system, "stage2_engine", None)
        stage1_run_id = getattr(system, "stage1_run_id", None)
        stage2_run_id = getattr(system, "stage2_run_id", None)

        # Perfil ativo pode ter informações mais atualizadas
        active_profile = None
        try:
            profiles = repo.list_profiles(system_id) if hasattr(repo, "list_profiles") else []
            for p in profiles:
                if getattr(p, "active", False):
                    active_profile = p
                    break
        except Exception:
            pass

        if active_profile is not None:
            stage1_engine = getattr(active_profile, "stage1_engine", None) or stage1_engine
            stage2_engine = getattr(active_profile, "stage2_engine", None) or stage2_engine
            stage1_run_id = getattr(active_profile, "stage1_run_id", None) or stage1_run_id
            stage2_run_id = getattr(active_profile, "stage2_run_id", None) or stage2_run_id

            s1cfg_raw = getattr(active_profile, "stage1_config", None)
            if s1cfg_raw:
                try:
                    stage1_config = json.loads(str(s1cfg_raw)) if isinstance(s1cfg_raw, str) else dict(s1cfg_raw)
                except Exception:
                    stage1_config = {}
            else:
                stage1_config = {}

            s2cfg_raw = getattr(active_profile, "stage2_config", None)
            if s2cfg_raw:
                try:
                    stage2_config = json.loads(str(s2cfg_raw)) if isinstance(s2cfg_raw, str) else dict(s2cfg_raw)
                except Exception:
                    stage2_config = {}
            else:
                stage2_config = {}
        else:
            stage1_config = {}
            stage2_config = {}

        # Verifica se runs de stage estão treinados
        stage1_run = repo.get_training_run(stage1_run_id) if stage1_run_id else None
        stage2_run = repo.get_training_run(stage2_run_id) if stage2_run_id else None

        # Se collection_id ainda não foi resolvido, herda do run de stage
        if not collection_id and stage1_run is not None:
            collection_id = stage1_run.collection_id
        if not collection_id and stage2_run is not None:
            collection_id = stage2_run.collection_id

        return {
            "monitoring_active": system.monitoring_active,
            "has_trained_model": run is not None and run.status == "completed",
            "run_id": run.run_id if run else None,
            "collection_id": collection_id,
            "engine_type": system.engine_type,
            "engine_config": engine_config,
            "llm_prompt": system.llm_prompt,
            # estágios independentes
            "stage1_engine": stage1_engine,
            "stage2_engine": stage2_engine,
            "stage1_run_id": stage1_run_id,
            "stage2_run_id": stage2_run_id,
            "has_stage1_model": (
                stage1_run is not None and stage1_run.status == "completed"
            ) or (
                stage1_engine in ("pycaret", "pycaret_stage1")
                and _pycaret_model_mtime(system_id, stage=1) is not None
            ),
            "has_stage2_model": (
                stage2_run is not None and stage2_run.status == "completed"
            ) or (
                stage2_engine == "pycaret" and _pycaret_model_mtime(system_id, stage=2) is not None
            ),
            "stage1_config": stage1_config,
            "stage2_config": stage2_config,
        }
    except Exception:
        return None


def _collect_signals(
    system: Any,
    window_start: str,
    window_end: str,
) -> dict[str, Any] | None:
    # Logs e métricas são coletados de fontes independentes (Loki, Prometheus);
    # uma falha isolada numa delas não deve descartar o que a outra já
    # entregou com sucesso — o monitoramento é visibilidade operacional
    # contínua, não um dataset de treino que precisa ser tudo-ou-nada
    # (ver PrometheusClient, que continua propagando erro de propósito para
    # a coleta de dados de treino; a resiliência aqui é decidida neste
    # caller específico, não no client compartilhado).
    system_id = getattr(system, "system_id", "?")
    logs = None
    metrics = None
    metrics_by_entity: dict[str, dict[str, list[float]]] = {}

    try:
        from src.collector.loki_client import LokiClient
        from src.infra.settings import get_settings

        settings = get_settings()
        loki = LokiClient(settings.loki_url)
        query = str(system.loki_label_selector)
        logs = loki.query_range(query, window_start, window_end)
    except Exception as exc:
        logger.warning("loki collection failed for %s: %s", system_id, exc)

    try:
        from src.collector.prometheus_client import (
            CANONICAL_METRIC_QUERIES,
            PrometheusClient,
            flatten_labeled_metrics,
            group_by_entity,
        )
        from src.infra.settings import get_settings

        settings = get_settings()
        prom = PrometheusClient(settings.prometheus_url)
        prometheus_selector = str(system.prometheus_label_selector)
        raw_queries = str(system.metric_queries) if system.metric_queries else None
        metric_queries = json.loads(raw_queries) if raw_queries else CANONICAL_METRIC_QUERIES
        labeled = prom.get_labeled_metrics(prometheus_selector, metric_queries, window_start, window_end)
        metrics = flatten_labeled_metrics(labeled)
        metrics_by_entity = group_by_entity(labeled)
    except Exception as exc:
        logger.warning("prometheus collection failed for %s: %s", system_id, exc)

    # Eventos do orquestrador (probes, OOM, restarts): antes só a coleta offline os buscava e todo
    # pacote online saía com `k8s_infrastructure_events` vazio.
    k8s_events: list[dict[str, Any]] = []
    try:
        from src.collector.tasks import _fetch_orchestration_events
        from src.infra.settings import get_settings

        k8s_events = list(_fetch_orchestration_events(get_settings(), system, window_start, window_end) or [])
    except Exception as exc:
        logger.warning("k8s events collection failed for %s: %s", system_id, exc)

    if logs is None and metrics is None:
        return None
    return {
        "logs": logs or [], "metrics": metrics or {}, "metrics_by_entity": metrics_by_entity,
        "k8s_events": k8s_events,
    }


def _json_safe(value: Any) -> Any:
    return json.loads(json.dumps(value, ensure_ascii=False, default=str))


def _step(name: str, status: str = "pending", detail: str = "", data: Any | None = None) -> dict[str, Any]:
    return {
        "name": name,
        "status": status,
        "detail": detail,
        "data": _json_safe(data) if data is not None else None,
        "at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
    }


def _set_step(
    steps: list[dict[str, Any]],
    name: str,
    status: str,
    detail: str = "",
    data: Any | None = None,
) -> None:
    for step in steps:
        if step["name"] == name:
            step["status"] = status
            step["detail"] = detail
            if data is not None:
                step["data"] = _json_safe(data)
            step["at"] = datetime.now(UTC).isoformat().replace("+00:00", "Z")
            return
    steps.append(_step(name, status, detail, data=data))


def _load_baseline_drain_engine(repo: Any, system_id: str, collection_id: str | None) -> tuple[Any | None, str | None]:
    if not collection_id:
        return None, None
    drain_cache_key = f"{system_id}:{collection_id}"
    if drain_cache_key in _DRAIN_ENGINE_CACHE:
        return _cache_get(_DRAIN_ENGINE_CACHE, drain_cache_key, lock=_DRAIN_CACHE_LOCK)
    from src.pipeline.drain import MiniDrain

    baselines = repo.list_failures(system_id, status="completed", is_baseline=True, collection_id=collection_id)
    if not baselines:
        baselines = repo.list_failures(system_id, is_baseline=True, collection_id=collection_id)
    for baseline in baselines:
        fallback_engine = MiniDrain()
        fallback_templates = 0
        evidence_count = 0
        state_invalid = False
        try:
            for evidence in repo.list_evidence_packages(system_id, failure_id=baseline.failure_id):
                evidence_count += 1
                pkg_json = json.loads(str(evidence.package_json)) if evidence.package_json else {}
                drain_state = pkg_json.get("metadata", {}).get("drain_state")
                if not drain_state:
                    top_templates = (
                        pkg_json.get("log_details", {}).get("top_templates")
                        or pkg_json.get("logs", {}).get("top_templates")
                        or {}
                    )
                    if isinstance(top_templates, dict):
                        for template, count in top_templates.items():
                            if template:
                                # Alimenta `count` vezes para aproximar o `size`
                                # real do cluster (capado para evitar loop
                                # excessivo em templates com contagem muito alta).
                                try:
                                    repeats = min(int(count), 100)
                                except (TypeError, ValueError):
                                    repeats = 1
                                for _ in range(max(1, repeats)):
                                    fallback_engine.add_log_message(str(template))
                                fallback_templates += 1
                    continue
                state = json.loads(drain_state) if isinstance(drain_state, str) else drain_state
                restored = MiniDrain.from_state(state)
                # Valida o engine restaurado antes de cachear: from_state não
                # lança exceção para um state mal-formado mas semanticamente
                # vazio/quebrado — sem isso, um engine inútil ficaria
                # cacheado indefinidamente (o cache nunca invalida sozinho).
                # A prova é feita num clone descartável (reconstruído do mesmo
                # `state`), não em `restored` — add_log_message muta o
                # clustering real, e o engine que vai pro cache precisa ficar
                # intacto (achado real de code review, 2026-09-15: a mensagem
                # de teste ficava permanentemente nos top_templates cacheados).
                probe = MiniDrain.from_state(state)
                test_result = probe.add_log_message("test connection timeout")
                if test_result["cluster_id"] == -1:
                    logger.warning(
                        "restored drain engine for failure=%s returned -1 for test message, skipping",
                        baseline.failure_id,
                    )
                    state_invalid = True
                    break
                result = restored, baseline.failure_id
                _cache_set(_DRAIN_ENGINE_CACHE, drain_cache_key, result, _DRAIN_ENGINE_CACHE_MAX, lock=_DRAIN_CACHE_LOCK)
                return result
            if state_invalid:
                continue
            if fallback_templates > 0:
                logger.info(
                    "rebuilt baseline drain engine from %d templates for failure=%s",
                    fallback_templates, baseline.failure_id,
                )
                result = fallback_engine, baseline.failure_id
                _cache_set(_DRAIN_ENGINE_CACHE, drain_cache_key, result, _DRAIN_ENGINE_CACHE_MAX, lock=_DRAIN_CACHE_LOCK)
                return result
            if evidence_count > 0:
                logger.info(
                    "using empty baseline drain engine for failure=%s because no drain state/templates were stored",
                    baseline.failure_id,
                )
                result = fallback_engine, baseline.failure_id
                _cache_set(_DRAIN_ENGINE_CACHE, drain_cache_key, result, _DRAIN_ENGINE_CACHE_MAX, lock=_DRAIN_CACHE_LOCK)
                return result
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            logger.warning(
                "baseline drain state malformed for failure=%s: %s", baseline.failure_id, exc,
            )
            continue
        except Exception as exc:
            logger.error(
                "unexpected error loading drain state for failure=%s: %s", baseline.failure_id, exc,
            )
            continue
    return None, None


def metrics_by_entity_json(metrics_by_entity: dict[str, dict[str, float]]) -> str:
    """Resumo entidade × métrica do ciclo para o Stage 3.

    Entidades com nome normalizado (`_strip_pod_suffix`, a mesma chave de `metric_stats`); se dois
    pods colapsam na mesma entidade, vale o maior valor (mesma redução por máximo do S3).
    """
    from src.pipeline.s4_representation import _strip_pod_suffix

    merged: dict[str, dict[str, float]] = {}
    for entity, metrics in metrics_by_entity.items():
        bucket = merged.setdefault(_strip_pod_suffix(entity), {})
        for name, value in metrics.items():
            # série crua (lista por amostra, formato de `_collect_signals`) reduz pelo pico, como o S3;
            # antes a lista era descartada em silêncio e o Stage 3 ficava sem métrica
            if isinstance(value, list | tuple):
                numbers = [v for v in value if isinstance(v, int | float)]
                if not numbers:
                    continue
                value = max(numbers)
            try:
                number = float(value)
            except (TypeError, ValueError):
                continue
            bucket[name] = max(number, bucket[name]) if name in bucket else number
    return json.dumps(merged, ensure_ascii=False)


def _monitor_log(
    system_id: str,
    *,
    run_id: str | None,
    collection_id: str | None,
    window_start: str,
    window_end: str,
    package_window_seconds: int,
    steps: list[dict[str, Any]],
    evidence_id: str = "",
    contract_id: str = "",
    stage1_result: str = "normal",
    primary_hypothesis: str | None = None,
    confidence: float | None = None,
    contract_json: dict[str, Any] | None = None,
    error: str | None = None,
    block_contributions: list[dict[str, Any]] | None = None,
    metrics_by_entity: dict[str, dict[str, float]] | None = None,
) -> dict[str, Any]:
    log_entry = {
        "system_id": system_id,
        "run_id": run_id,
        "collection_id": collection_id,
        "evidence_id": evidence_id,
        "contract_id": contract_id,
        "collected_at": window_end,
        "window_start": window_start,
        "window_end": window_end,
        "package_window_seconds": package_window_seconds,
        "steps_json": json.dumps(steps, ensure_ascii=False, default=str),
        "stage1_result": stage1_result,
        "primary_hypothesis": primary_hypothesis,
        "confidence": confidence,
        "contract_json": contract_json or {},
        "error": error,
    }
    if block_contributions:
        log_entry["block_contributions"] = json.dumps(
            block_contributions, ensure_ascii=False, default=str
        )
    if metrics_by_entity:
        log_entry["metrics_by_entity_json"] = metrics_by_entity_json(metrics_by_entity)
    return log_entry


def _load_engine_from_bundle(engine_type: str, run_id: str, system_id: str, stage: int) -> Any | None:
    """Carrega e retorna uma engine com bundle do stage especificado."""
    try:
        import os

        from src.diagnosis.engines import ENGINE_REGISTRY
        from src.infra.settings import get_settings
        from src.trainer.model_store import ModelStore

        settings = get_settings()
        model_store = ModelStore(base_dir=settings.models_dir)
        # Inclui o mtime do arquivo do bundle na chave: se o bundle for
        # substituído no disco sob o mesmo run_id, o cache não serve mais o
        # engine antigo indefinidamente.
        try:
            bundle_mtime = os.path.getmtime(model_store.bundle_path(system_id, run_id))
        except OSError:
            bundle_mtime = 0
        cache_key = f"{system_id}:{run_id}:{stage}:{bundle_mtime}"
        if cache_key in _ENGINE_CACHE:
            return _cache_get(_ENGINE_CACHE, cache_key, lock=_ENGINE_CACHE_LOCK)

        bundle_bytes = model_store.load(system_id, run_id)
        if bundle_bytes is None:
            return None
        bundle = json.loads(bundle_bytes.decode("utf-8"))
        engine_cls = ENGINE_REGISTRY[engine_type]
        engine = engine_cls()
        if stage == 1:
            engine.load_stage1(bundle)
        else:
            engine.load_stage2(bundle)
        _cache_set(_ENGINE_CACHE, cache_key, engine, _ENGINE_CACHE_MAX, lock=_ENGINE_CACHE_LOCK)
        logger.info("engine cached: %s stage%d run=%s", engine_type, stage, run_id[:8])
        return engine
    except Exception as exc:
        logger.warning("failed to load %s engine stage%d for run %s: %s", engine_type, stage, run_id, exc)
        return None


def _load_gate_calibration(repo: Any, system_id: str, run_id: str | None) -> Any | None:
    """Carrega a GateCalibration ativa (banco prevalece sobre bundle)."""
    try:
        row = repo.get_active_gate_calibration(system_id, run_id=run_id)
    except Exception as exc:
        logger.warning("failed to load gate calibration for %s: %s", system_id, exc)
        return None
    if row is None:
        return None
    try:
        from src.diagnosis.calibration import GateCalibration

        payload = row.payload if isinstance(row.payload, dict) else json.loads(row.payload)
        return GateCalibration.from_dict(payload)
    except Exception as exc:
        logger.warning("invalid gate calibration payload for %s: %s", system_id, exc)
        return None


def _load_bundle_tau_config(system_id: str, run_id: str | None) -> dict[str, Any] | None:
    """Extrai ``pipeline_config`` do bundle do run (tier bundle do gate).

    Retorna ``None`` quando não há run/bundle ou em caso de erro de leitura.
    """
    if not run_id:
        return None
    try:
        from src.infra.settings import get_settings
        from src.trainer.model_store import ModelStore

        model_store = ModelStore(base_dir=get_settings().models_dir)
        bundle_bytes = model_store.load(system_id, run_id)
        if bundle_bytes is None:
            return None
        bundle = json.loads(bundle_bytes.decode("utf-8"))
        cfg = (bundle.get("manifest") or {}).get("pipeline_config") or {}
        return cfg if isinstance(cfg, dict) else None
    except Exception as exc:
        logger.warning(
            "failed to load bundle tau config for %s/%s: %s", system_id, run_id, exc
        )
        return None


def _effective_gate(
    repo: Any,
    system_id: str,
    stage2_run_id: str | None,
    predicted_class: str | None,
    default_tau: float,
) -> tuple[float, str, str | None]:
    """Resolve o limiar efetivo do gate para o ciclo de monitoramento.

    Retorna ``(tau, fonte, fitted_at)`` com fonte ∈ {"banco", "bundle", "fixed"},
    nessa ordem de precedência. O tier bundle só participa quando o bundle foi
    treinado com ``tau_mode="adaptive"`` e tabela por classe não vazia —
    bundles legados (fixed) mantêm o comportamento atual (tau fixo do perfil).
    """
    calib = _load_gate_calibration(repo, system_id, stage2_run_id)
    if calib is not None and calib.thresholds:
        from src.diagnosis.calibration import effective_threshold

        return effective_threshold(calib, predicted_class or ""), "banco", calib.fitted_at

    from src.diagnosis.pipeline import PipelineConfig, resolve_tau

    bcfg = _load_bundle_tau_config(system_id, stage2_run_id) or {}
    if bcfg.get("tau_mode") == "adaptive" and bcfg.get("tau_by_class"):
        try:
            pc = PipelineConfig(
                tau_mode="adaptive",
                tau_by_class=dict(bcfg["tau_by_class"]),
                tau=float(bcfg.get("tau", default_tau)),
            )
            tau = resolve_tau(pc, predicted_class)
            return tau, "bundle", None
        except (TypeError, ValueError) as exc:
            logger.warning("invalid bundle tau config for %s: %s", system_id, exc)
    return default_tau, "fixed", None


def _run_staged_diagnosis(
    info: dict[str, Any],
    pkg: Any,
    system_id: str,
    repo: Any,
    steps: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Executa diagnóstico usando motores de stage1 e stage2 independentes."""
    stage1_engine_type = info.get("stage1_engine")
    stage2_engine_type = info.get("stage2_engine")
    stage1_run_id = info.get("stage1_run_id")
    stage2_run_id = info.get("stage2_run_id")
    tau = float((info.get("stage2_config") or {}).get("tau", 0.80))

    # --- Stage 1 ---
    _set_step(steps, "Avaliação do modelo", "running", f"stage1 engine={stage1_engine_type}")

    if stage1_engine_type in ("rules", "llm") and not stage1_run_id:
        from src.diagnosis.engines.llm import LLMEngine
        from src.diagnosis.engines.rules import RulesEngine
        if stage1_engine_type == "rules":
            thresholds = (info.get("stage1_config") or {}).get("thresholds")
            engine_s1 = RulesEngine(thresholds=thresholds)
        else:
            engine_s1 = LLMEngine()
            _global_llm = repo.get_llm_config()
            _llm_cfg = dict(_global_llm)
            _llm_cfg.update({k: v for k, v in (info.get("engine_config") or {}).items() if v})
            _llm_cfg["prompt_stage1"] = _global_llm.get("prompt_stage1", "")
            engine_s1.train([], [], config=_llm_cfg)
    elif stage1_engine_type == "pycaret":
        engine_s1 = None
        if stage1_run_id:
            # stage1_run_id guarda o exploration_id escolhido no perfil — carrega
            # direto da tabela `explorations`, sem depender do arquivo do /promote.
            pycaret_cache_key = f"{system_id}:{stage1_run_id}:1"
            engine_s1 = _cache_get(_ENGINE_CACHE, pycaret_cache_key, lock=_ENGINE_CACHE_LOCK)
            if engine_s1 is None:
                from src.diagnosis.engines.pycaret_stage1 import PyCaretStage1Engine
                _e = PyCaretStage1Engine()
                if _e.load_from_exploration(stage1_run_id):
                    _cache_set(_ENGINE_CACHE, pycaret_cache_key, _e, _ENGINE_CACHE_MAX, lock=_ENGINE_CACHE_LOCK)
                    engine_s1 = _e
                else:
                    logger.warning(
                        "pycaret exploration %s not found/without model for system %s",
                        stage1_run_id, system_id,
                    )
        else:
            # Compatibilidade: perfis antigos sem stage1_run_id usam o arquivo
            # global gravado pelo /promote.
            pycaret_cache_key = f"{system_id}:pycaret_stage1:1"
            cached = _cache_get(_ENGINE_CACHE, pycaret_cache_key, lock=_ENGINE_CACHE_LOCK)
            if cached is not None:
                cached_engine, cached_mtime = cached
                if _pycaret_model_mtime(system_id, stage=1) == cached_mtime:
                    engine_s1 = cached_engine
            if engine_s1 is None:
                from src.diagnosis.engines.pycaret_stage1 import PyCaretStage1Engine
                _e = PyCaretStage1Engine()
                if _e.load_from_store(system_id):
                    _cache_set(_ENGINE_CACHE, pycaret_cache_key, (_e, _pycaret_model_mtime(system_id, stage=1)), _ENGINE_CACHE_MAX, lock=_ENGINE_CACHE_LOCK)
                    engine_s1 = _e
                else:
                    logger.warning("pycaret_stage1 model not found for system %s", system_id)
                    engine_s1 = None
    elif stage1_run_id:
        engine_s1 = _load_engine_from_bundle(stage1_engine_type, stage1_run_id, system_id, stage=1)
    else:
        engine_s1 = None

    if engine_s1 is None:
        _set_step(steps, "Avaliação do modelo", "failed", "engine stage1 não disponível")
        return None

    try:
        import uuid
        s1_result = engine_s1.diagnose_stage1(pkg)
    except Exception as exc:
        _set_step(steps, "Avaliação do modelo", "failed", f"stage1 falhou: {exc}")
        return None

    stage1_text_mode = (
        getattr(engine_s1, "_text_mode_s1", None)
        or getattr(engine_s1, "_text_mode", None)
        or ((s1_result.detail or {}).get("text_mode") if s1_result.detail else None)
    )
    _set_step(steps, "Avaliação do modelo", "completed", f"stage1={s1_result.label} conf={s1_result.confidence:.2f}", {
        "stage1_result": s1_result.label,
        "confidence": s1_result.confidence,
        "detail": s1_result.detail,
        "stage1_engine": stage1_engine_type,
        "stage1_text_mode": stage1_text_mode,
    })
    _set_step(steps, "Decisão 1", "completed", f"stage1={s1_result.label} conf={s1_result.confidence:.2f}", {
        "stage1_result": s1_result.label,
        "confidence": s1_result.confidence,
        "detail": s1_result.detail,
        "stage1_text_mode": stage1_text_mode,
    })

    if s1_result.label != "anomalous":
        return {
            "status": "ok",
            "incident_id": str(uuid.uuid4()),
            "evidence_id": getattr(pkg, "evidence_id", ""),
            "system_id": system_id,
            "stage1_result": "normal",
            "primary_hypothesis": "normal",
            "confidence": s1_result.confidence,
            "_avaliacao_step_handled": True,
            "_stage2_step_handled": True,
        }

    # --- Stage 2 ---
    if not stage2_engine_type:
        return {
            "status": "ok",
            "incident_id": str(uuid.uuid4()),
            "evidence_id": getattr(pkg, "evidence_id", ""),
            "system_id": system_id,
            "stage1_result": "anomalous",
            "primary_hypothesis": "anomalous",
            "confidence": s1_result.confidence,
            "_avaliacao_step_handled": True,
            "_stage2_step_handled": True,
        }

    _set_step(steps, "Avaliação do modelo", "running", f"stage2 engine={stage2_engine_type}")
    _set_step(steps, "Decisão 2", "running", f"stage2 engine={stage2_engine_type}")

    if stage2_engine_type in ("rules",) and not stage2_run_id:
        from src.diagnosis.engines.rules import RulesEngine
        engine_s2 = RulesEngine()
        stage2_config = info.get("stage2_config") or {}
        engine_s2.load_stage2(stage2_config)
        class_map = stage2_config.get("class_map") or {}
        if class_map:
            engine_s2.set_class_map(class_map)
    elif stage2_engine_type == "llm":
        from src.diagnosis.engines.llm import LLMEngine
        engine_s2 = LLMEngine()
        _global_llm2 = repo.get_llm_config()
        _llm_cfg2 = dict(_global_llm2)
        _llm_cfg2.update({k: v for k, v in (info.get("engine_config") or {}).items() if v})
        _llm_cfg2["prompt_stage2"] = _global_llm2.get("prompt_stage2", "")
        engine_s2.train([], [], config=_llm_cfg2)
        # injeta classes de falha
        try:
            collection_id = info.get("collection_id")
            failure_classes = []
            if collection_id:
                failures = repo.list_failures(system_id, status="completed", collection_id=collection_id)
            else:
                failures = repo.list_failures(system_id, status="completed")
            ref_class = None
            try:
                system_model = repo.get_system(system_id)
                ref_class = system_model.ref_class if system_model else None
            except Exception:
                pass
            for f in failures:
                if not getattr(f, "is_baseline", False) and f.name != ref_class:
                    failure_classes.append(f.name)
            engine_s2.set_failure_classes(sorted(set(failure_classes)))
        except Exception:
            pass
    elif stage2_engine_type == "pycaret":
        engine_s2 = None
        if stage2_run_id:
            # stage2_run_id guarda o exploration_id escolhido no perfil — carrega
            # direto da tabela `explorations`, sem depender do arquivo do /promote.
            pycaret_cache_key = f"{system_id}:{stage2_run_id}:2"
            engine_s2 = _cache_get(_ENGINE_CACHE, pycaret_cache_key, lock=_ENGINE_CACHE_LOCK)
            if engine_s2 is None:
                from src.diagnosis.engines.pycaret_stage2 import PyCaretStage2Engine
                _e = PyCaretStage2Engine()
                if _e.load_from_exploration(stage2_run_id):
                    _cache_set(_ENGINE_CACHE, pycaret_cache_key, _e, _ENGINE_CACHE_MAX, lock=_ENGINE_CACHE_LOCK)
                    engine_s2 = _e
                else:
                    logger.warning(
                        "pycaret exploration %s not found/without model for system %s",
                        stage2_run_id, system_id,
                    )
        else:
            # Compatibilidade: perfis antigos sem stage2_run_id usam o arquivo
            # global gravado pelo /promote.
            pycaret_cache_key = f"{system_id}:pycaret_stage2:2"
            cached = _cache_get(_ENGINE_CACHE, pycaret_cache_key, lock=_ENGINE_CACHE_LOCK)
            if cached is not None:
                cached_engine, cached_mtime = cached
                if _pycaret_model_mtime(system_id) == cached_mtime:
                    engine_s2 = cached_engine
            if engine_s2 is None:
                from src.diagnosis.engines.pycaret_stage2 import PyCaretStage2Engine
                _e = PyCaretStage2Engine()
                if _e.load_from_store(system_id):
                    _cache_set(_ENGINE_CACHE, pycaret_cache_key, (_e, _pycaret_model_mtime(system_id)), _ENGINE_CACHE_MAX, lock=_ENGINE_CACHE_LOCK)
                    engine_s2 = _e
                else:
                    logger.warning("pycaret_stage2 model not found for system %s", system_id)
                    engine_s2 = None
    elif stage2_run_id:
        engine_s2 = _load_engine_from_bundle(stage2_engine_type, stage2_run_id, system_id, stage=2)
    else:
        engine_s2 = None

    if engine_s2 is None:
        logger.error(
            "stage2 engine unavailable for system %s — stage2 classification lost, falling back to stage1",
            system_id,
        )
        _set_step(steps, "Avaliação do modelo", "warning", "stage2 indisponível — usando stage1",
                  {"stage1_result": "anomalous", "reason": "stage2 engine unavailable", "stage2_degraded": True})
        _set_step(steps, "Decisão 2", "warning", "stage2 indisponível — usando stage1",
                  {"final_result": "anomalous", "reason": "stage2 engine unavailable", "stage2_degraded": True})
        return {
            "status": "ok",
            "incident_id": str(uuid.uuid4()),
            "evidence_id": getattr(pkg, "evidence_id", ""),
            "system_id": system_id,
            "stage1_result": "anomalous",
            "primary_hypothesis": "anomalous",
            "confidence": s1_result.confidence,
            "stage2_degraded": True,
            "_avaliacao_step_handled": True,
            "_stage2_step_handled": True,
        }

    try:
        s2_result = engine_s2.diagnose_stage2(pkg)
    except Exception as exc:
        logger.warning("stage2 diagnose failed for %s: %s", system_id, exc)
        _set_step(steps, "Avaliação do modelo", "completed", f"stage2 falhou: {exc}",
                  {"stage1_result": "anomalous", "stage2_error": str(exc)})
        _set_step(steps, "Decisão 2", "failed", f"stage2 falhou: {exc}",
                  {"final_result": "anomalous", "reason": str(exc)})
        s2_result = None

    if s2_result is None:
        return {
            "status": "ok",
            "incident_id": str(uuid.uuid4()),
            "evidence_id": getattr(pkg, "evidence_id", ""),
            "system_id": system_id,
            "stage1_result": "anomalous",
            "primary_hypothesis": "anomalous",
            "confidence": s1_result.confidence,
            "_avaliacao_step_handled": True,
            "_stage2_step_handled": True,
        }

    ref_class = None
    try:
        system_model = repo.get_system(system_id)
        ref_class = system_model.ref_class if system_model else None
    except Exception:
        pass
    normalized_s2_hypothesis = canonical_label(s2_result.hypothesis, ref_class=ref_class)
    if is_baseline_label(normalized_s2_hypothesis, ref_class=ref_class):
        _set_step(steps, "Avaliação do modelo", "completed", f"stage2=baseline conf={s2_result.confidence:.2f}", {
            "stage1_result": "normal",
            "stage2_result": "baseline",
            "confidence": s2_result.confidence,
            "probabilities": s2_result.probabilities,
            "stage1_engine": stage1_engine_type,
            "stage2_engine": stage2_engine_type,
            "stage1_text_mode": stage1_text_mode,
            "stage2_text_mode": (
                getattr(engine_s2, "_text_mode_s2", None)
                or getattr(engine_s2, "_text_mode", None)
                or ((s2_result.detail or {}).get("text_mode") if s2_result.detail else None)
            ),
        })
        _set_step(steps, "Decisão 2", "completed", "baseline — sem incidente", {
            "final_result": "normal",
            "primary_hypothesis": "baseline",
            "confidence": s2_result.confidence,
            "notify": False,
        })
        return {
            "status": "ok",
            "incident_id": str(uuid.uuid4()),
            "evidence_id": getattr(pkg, "evidence_id", ""),
            "system_id": system_id,
            "stage1_result": "normal",
            "primary_hypothesis": "baseline",
            "confidence": s2_result.confidence,
            "_avaliacao_step_handled": True,
            "_stage2_step_handled": True,
        }
    if normalized_s2_hypothesis is not None:
        s2_result.hypothesis = normalized_s2_hypothesis

    tau, gate_fonte, gate_fitted_at = _effective_gate(
        repo, system_id, stage2_run_id, normalized_s2_hypothesis, default_tau=tau
    )

    if s2_result.confidence < tau:
        _set_step(steps, "Avaliação do modelo", "completed",
                  f"stage2 conf={s2_result.confidence:.2f} < tau={tau}",
                  {"stage1_result": "anomalous", "stage2_confidence": s2_result.confidence,
                   "tau": tau, "tau_fonte": gate_fonte, "gate_calibration_fitted_at": gate_fitted_at,
                   "reason": "low_confidence"})
        _set_step(steps, "Decisão 2", "completed",
                  "baixa confiança — descartando anomalia",
                  {"final_result": "normal", "reason": "stage2 confidence below tau"})
        return {
            "status": "ok",
            "incident_id": str(uuid.uuid4()),
            "evidence_id": getattr(pkg, "evidence_id", ""),
            "system_id": system_id,
            "stage1_result": "normal",
            "primary_hypothesis": "normal",
            "confidence": s2_result.confidence,
            "_avaliacao_step_handled": True,
            "_stage2_step_handled": True,
        }

    secondary = None
    if s2_result.secondary_confidence is not None and s2_result.secondary_confidence >= tau:
        secondary = s2_result.secondary_hypothesis
    stage2_text_mode = (
        getattr(engine_s2, "_text_mode_s2", None)
        or getattr(engine_s2, "_text_mode", None)
        or ((s2_result.detail or {}).get("text_mode") if s2_result.detail else None)
    )

    _set_step(steps, "Avaliação do modelo", "completed", f"stage2={s2_result.hypothesis} conf={s2_result.confidence:.2f}", {
        "stage1_result": "anomalous",
        "stage2_result": s2_result.hypothesis,
        "confidence": s2_result.confidence,
        "probabilities": s2_result.probabilities,
        "secondary_hypothesis": secondary,
        "tau": tau,
        "tau_fonte": gate_fonte,
        "gate_calibration_fitted_at": gate_fitted_at,
        "stage1_engine": stage1_engine_type,
        "stage2_engine": stage2_engine_type,
        "stage1_text_mode": stage1_text_mode,
        "stage2_text_mode": stage2_text_mode,
    })
    _set_step(steps, "Decisão 2", "completed", f"stage2={s2_result.hypothesis} conf={s2_result.confidence:.2f}",
              {"final_result": "anomalous", "primary_hypothesis": s2_result.hypothesis,
               "secondary_hypothesis": secondary, "confidence": s2_result.confidence,
               "probabilities": s2_result.probabilities,
               "stage2_text_mode": stage2_text_mode})

    # BL-3105: engines de stage2 que declaram explain() (hoje só
    # "blockwise") produzem a explicação post-hoc por bloco — sem isso,
    # result["block_contributions"] nunca tinha produtor em produção, mesmo
    # com o consumidor (log_entry/ContractProvenance.decision_explanation)
    # já pronto desde BL-3104.
    block_contributions = None
    if hasattr(engine_s2, "explain"):
        try:
            block_contributions = [
                {"block": c.name, "delta": c.delta, "share": c.share}
                for c in engine_s2.explain(pkg)
            ]
        except Exception as exc:
            logger.warning("block explanation failed for %s: %s", system_id, exc)
            block_contributions = None

    return {
        "status": "ok",
        "incident_id": str(uuid.uuid4()),
        "evidence_id": getattr(pkg, "evidence_id", ""),
        "system_id": system_id,
        "stage1_result": "anomalous",
        "primary_hypothesis": s2_result.hypothesis,
        "confidence": s2_result.confidence,
        "secondary_hypothesis": secondary,
        "probabilities": s2_result.probabilities,
        "stage1_detail": s1_result.detail,
        "stage2_detail": s2_result.detail,
        "block_contributions": block_contributions,
        "_avaliacao_step_handled": True,
        "_stage2_step_handled": True,
    }


def _governance_step(system_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Gera o passo de auditoria de governança do ciclo.

    O hash cobre o ``contract_json`` do ciclo; agente é o próprio worker e
    escopo ``system:<sid>:diagnose``.
    """
    import socket
    from dataclasses import asdict

    from src.contract.governance import make_governance

    gov = make_governance(
        collecting_agent=f"job-runner:{socket.gethostname()}",
        authorization_scope=f"system:{system_id}:diagnose",
        package_dict=payload,
    )
    d = asdict(gov)
    return {
        "name": "Governança",
        "data": {
            "collecting_agent": d["collecting_agent"],
            "authorization_scope": d["authorization_scope"],
            "source_package_sha256": d["source_package_sha256"],
            "collected_at": d["collected_at"],
            "verificado": True,
        },
    }


def execute_monitoring(system_id: str, notify_func: Any | None = None, *, repo: Any | None = None) -> dict[str, Any]:
    info = _get_active_system(system_id, repo=repo)

    if info is None:
        if notify_func is not None:
            notify_func(system_id)
        return {"system_id": system_id, "status": "completed"}

    if not info["monitoring_active"]:
        return {"system_id": system_id, "status": "skipped", "reason": "monitoring not active"}

    engine_type = info.get("engine_type")
    stage1_engine = info.get("stage1_engine")
    has_staged_engine = bool(stage1_engine) and (
        stage1_engine in ("rules", "llm") or info.get("has_stage1_model")
    )
    if engine_type not in ("rules", "llm") and not info["has_trained_model"] and not has_staged_engine:
        return {"system_id": system_id, "status": "skipped", "reason": "no trained model"}

    notifier = create_notifier()

    try:
        from src.infra.settings import get_settings
        from src.pipeline.pipeline import build_collect_config, collect_evidence
        from src.schemas.contract import (
            ContractProvenance,
            DiagnosisInfo,
            EvidenceContract,
            IncidentInfo,
            MobilizedEvidence,
            ReviewStatus,
        )
        from src.schemas.intermediate import RawSignalCollection
        from src.store.repository import Repository

        if repo is None:
            settings = get_settings()
            repo = Repository(settings.db_url)
            repo.create_all()
        system = repo.get_system(system_id)
        if system is None:
            if notify_func is not None:
                notify_func(system_id)
            return {"system_id": system_id, "status": "completed"}

        collection_id = info.get("collection_id")
        collection = repo.get_collection(collection_id) if collection_id else None
        package_window_seconds = int(
            collection.package_window_seconds
            if collection is not None and collection.package_window_seconds
            else int(system.polling_interval_sec or 300)
        )
        steps = [
            _step("Coleta online", "pending", f"janela de {package_window_seconds}s"),
            _step("Drain baseline", "pending", "carregar modelo Drain da baseline"),
            _step("Avaliação do modelo", "pending", "enviar pacote ao motor de diagnóstico"),
            _step("Decisão 1", "pending", "classificar estágio 1"),
            _step("Decisão 2", "pending", "registrar decisão final"),
        ]

        now = datetime.now(UTC)
        window_end = now.isoformat().replace("+00:00", "Z")
        window_start = (now - timedelta(seconds=package_window_seconds)).isoformat().replace("+00:00", "Z")

        raw = _collect_signals(system, window_start, window_end)
        if raw is None:
            raw_collection = RawSignalCollection(logs=[], metrics={})
            _set_step(
                steps,
                "Coleta online",
                "failed",
                "falha ao consultar fontes; pacote vazio",
                {
                    "window_start": window_start,
                    "window_end": window_end,
                    "package_window_seconds": package_window_seconds,
                    "logs": [],
                    "metrics": {},
                    "error": "failed to query monitoring sources",
                },
            )
        else:
            raw_collection = RawSignalCollection(
                logs=raw["logs"] or [],
                metrics=raw["metrics"] or {},
                metrics_by_entity=raw.get("metrics_by_entity") or {},
                k8s_events=raw.get("k8s_events") or None,
            )
            _set_step(
                steps,
                "Coleta online",
                "completed",
                f"{len(raw_collection.logs or [])} logs; {len(raw_collection.metrics or {})} métricas",
                {
                    "window_start": window_start,
                    "window_end": window_end,
                    "package_window_seconds": package_window_seconds,
                    "log_count": len(raw_collection.logs or []),
                    "metric_count": len(raw_collection.metrics or {}),
                    "metrics": raw_collection.metrics or {},
                    "log_samples": (raw_collection.logs or [])[:20],
                },
            )

        pipeline_cfg = getattr(system, "pipeline_config", None)
        collect_config = build_collect_config(pipeline_cfg, window_start, window_end)
        collect_config.window_seconds = package_window_seconds

        drain_engine, baseline_failure_id = _load_baseline_drain_engine(repo, system_id, collection_id)
        if drain_engine is not None:
            _set_step(
                steps,
                "Drain baseline",
                "running",
                f"baseline {baseline_failure_id}",
                {"baseline_failure_id": baseline_failure_id, "collection_id": collection_id},
            )
        else:
            _set_step(
                steps,
                "Drain baseline",
                "warning",
                "baseline sem estado Drain; usando Drain novo",
                {"baseline_failure_id": None, "collection_id": collection_id},
            )

        from src.collector.providers.db_provider import DBVersionProvider

        active_cenario = getattr(system, "active_version_cenario", None) or "baseline"
        version_provider = DBVersionProvider(repo)
        version_context = version_provider.get(system_id, active_cenario)

        from src.schemas.validation import get_package_schema_validator
        pkgs = collect_evidence(
            raw_collection,
            system_id,
            collect_config,
            source_run_id=info.get("run_id") or system_id,
            drain_engine=drain_engine,
            version_context=version_context,
            cenario=active_cenario,
        )
        validator = get_package_schema_validator()
        for pkg in pkgs:
            validator.validate_and_warn(pkg, context=f"monitoring system={system_id}")
        if drain_engine is not None:
            _set_step(
                steps,
                "Drain baseline",
                "completed",
                f"{len(pkgs)} pacote(s) processado(s)",
                {
                    "baseline_failure_id": baseline_failure_id,
                    "collection_id": collection_id,
                    "evidence_packages": [pkg.to_old_dict() for pkg in pkgs],
                },
            )
        else:
            _set_step(
                steps,
                "Drain baseline",
                "warning",
                "baseline sem estado Drain; pacote gerado com Drain novo",
                {
                    "baseline_failure_id": None,
                    "collection_id": collection_id,
                    "evidence_packages": [pkg.to_old_dict() for pkg in pkgs],
                },
            )
        if not pkgs:
            _set_step(steps, "Avaliação do modelo", "skipped", "nenhum pacote gerado")
            _set_step(
                steps,
                "Decisão 1",
                "completed",
                "normal por ausência de evidência",
                {"stage1_result": "normal", "reason": "no evidence package generated"},
            )
            _set_step(
                steps,
                "Decisão 2",
                "completed",
                "normal por ausência de evidência",
                {"final_result": "normal", "notify": False, "reason": "no evidence package generated"},
            )
            log_entry = _monitor_log(
                system_id,
                run_id=info.get("run_id"),
                collection_id=collection_id,
                window_start=window_start,
                window_end=window_end,
                package_window_seconds=package_window_seconds,
                steps=steps,
                # Sem pacote de evidência não há diagnóstico possível — não é
                # o mesmo que "diagnosticado como normal".
                stage1_result="error",
                error="no evidence package generated",
            )
            try:
                repo.save_monitoring_log(log_entry)
            except Exception as exc:
                logger.warning("failed to save monitoring log for %s: %s", system_id, exc)
            if notify_func is not None:
                notify_func(system_id)
            return {"system_id": system_id, "status": "completed", "run_id": info.get("run_id")}

        pkg = pkgs[0]
        llm_audit_data: dict[str, Any] = {}

        # Nova rota: estágios independentes
        if info.get("stage1_engine"):
            result = _run_staged_diagnosis(info, pkg, system_id, repo, steps)
            if result is None:
                # falha no diagnóstico — "Avaliação do modelo" já foi marcado pela função interna
                _set_step(steps, "Decisão 1", "completed", "normal por fallback", {"stage1_result": "normal", "reason": "staged diagnose failed"})
                _set_step(steps, "Decisão 2", "completed", "normal por fallback", {"final_result": "normal", "notify": False, "reason": "staged diagnose failed"})
                log_entry = _monitor_log(
                    system_id, run_id=info.get("run_id"), collection_id=collection_id,
                    window_start=window_start, window_end=window_end,
                    package_window_seconds=package_window_seconds, steps=steps,
                    stage1_result="error", error="staged diagnose failed",
                )
                try:
                    repo.save_monitoring_log(log_entry)
                except Exception as exc:
                    logger.warning("failed to save monitoring log for %s: %s", system_id, exc)
                if notify_func is not None:
                    notify_func(system_id)
                return {"system_id": system_id, "status": "completed", "run_id": info.get("run_id")}
            # result OK — continua o fluxo de contrato/log abaixo
        elif engine_type == "rules":
            _set_step(steps, "Avaliação do modelo", "running", "avaliando thresholds de regras")
            from src.diagnosis.engines.rules import RulesEngine
            thresholds = (info.get("engine_config") or {}).get("thresholds")
            engine = RulesEngine(thresholds=thresholds)
            report = engine.diagnose(pkg)
            result = {
                "status": "ok",
                "incident_id": report.incident_id,
                "evidence_id": report.evidence_id,
                "system_id": report.system_id,
                "stage1_result": report.stage1_result,
                "primary_hypothesis": report.primary_hypothesis,
                "confidence": report.confidence,
            }
            _set_step(steps, "Avaliação do modelo", "running", "rules gerou resposta", result)
        elif engine_type == "llm":
            _set_step(steps, "Avaliação do modelo", "running", "chamando LLM")
            try:
                from src.diagnosis.engines.llm import LLMEngine
                engine_config = info.get("engine_config") or {}
                engine = LLMEngine(
                    provider=engine_config.get("provider", "mock"),
                    model=engine_config.get("model", "gemini-2.5-flash"),
                    prompt_template=info.get("llm_prompt"),
                )
                engine.train([], [], config=engine_config)
                report = engine.diagnose(pkg)
                result = {
                    "status": "ok",
                    "incident_id": report.incident_id,
                    "evidence_id": report.evidence_id,
                    "system_id": report.system_id,
                    "stage1_result": report.stage1_result,
                    "primary_hypothesis": report.primary_hypothesis,
                    "confidence": report.confidence,
                    "llm_prompt": report.llm_prompt,
                    "llm_response": report.llm_response,
                }
                llm_audit_data = {
                    "llm_prompt": report.llm_prompt,
                    "llm_response": report.llm_response,
                }
                _set_step(steps, "Avaliação do modelo", "running", "LLM gerou resposta", result)
            except Exception as exc:
                logger.warning("LLM diagnose failed for %s: %s", system_id, exc)
                audit_payload = {"error": str(exc), "engine_type": engine_type}
                if "engine" in locals():
                    audit_payload["llm_prompt"] = getattr(engine, "last_prompt", None)
                    audit_payload["llm_response"] = getattr(engine, "last_response", None)
                llm_audit_data = {
                    "llm_prompt": audit_payload.get("llm_prompt"),
                    "llm_response": audit_payload.get("llm_response"),
                }
                _set_step(
                    steps,
                    "Avaliação do modelo",
                    "failed",
                    "LLM falhou",
                    audit_payload,
                )
                result = None
        else:
            _set_step(steps, "Avaliação do modelo", "running", f"run {info['run_id']}")
            result = _diagnose_via_http(system_id, pkg.to_old_dict(), info["run_id"])
            if result is not None:
                _set_step(steps, "Avaliação do modelo", "running", "runtime ML gerou resposta", result)

        if result is None or result.get("status") != "ok":
            logger.warning("diagnose failed for %s, logging as normal", system_id)
            diagnose_failed_data = {"result": result, "engine_type": engine_type}
            if llm_audit_data:
                diagnose_failed_data.update(llm_audit_data)
            _set_step(
                steps,
                "Avaliação do modelo",
                "failed",
                "diagnóstico indisponível",
                diagnose_failed_data,
            )
            decision1_data = {"stage1_result": "normal", "reason": "diagnose failed"}
            decision2_data = {"final_result": "normal", "notify": False, "reason": "diagnose failed"}
            if llm_audit_data:
                decision1_data.update(llm_audit_data)
                decision2_data.update(llm_audit_data)
            _set_step(
                steps,
                "Decisão 1",
                "completed",
                "normal por fallback",
                decision1_data,
            )
            _set_step(
                steps,
                "Decisão 2",
                "completed",
                "normal por fallback",
                decision2_data,
            )
            log_entry = _monitor_log(
                system_id,
                run_id=info.get("run_id"),
                collection_id=collection_id,
                window_start=window_start,
                window_end=window_end,
                package_window_seconds=package_window_seconds,
                steps=steps,
                # stage1_result="error" (não o default "normal") — sem isso, um
                # ciclo em que o diagnóstico falhou aparecia com o mesmo rótulo
                # de "tudo certo" pra qualquer consumidor que olhe só esse
                # campo (dashboard, contagem de anomalias) sem checar `error`.
                stage1_result="error",
                error="diagnose failed",
            )
            try:
                repo.save_monitoring_log(log_entry)
            except Exception as exc:
                logger.warning("failed to save monitoring log for %s: %s", system_id, exc)
            if notify_func is not None:
                notify_func(system_id)
            return {"system_id": system_id, "status": "completed", "run_id": info.get("run_id")}

        contract = EvidenceContract(
            incident=IncidentInfo(
                incident_id=result["incident_id"],
                evidence_id=result["evidence_id"],
                system_id=result["system_id"],
            ),
            diagnosis=DiagnosisInfo(
                stage_1=result["stage1_result"],
                primary_hypothesis=result["primary_hypothesis"],
                confidence=result["confidence"],
            ),
            mobilized_evidence=MobilizedEvidence(
                log_templates=list(pkg.log_details.top_templates.keys())[:5],
                metric_features=list(pkg.metrics.keys()),
                events=[str(e) for e in pkg.k8s_infrastructure_events],
            ),
            provenance=ContractProvenance(
                processing_stages=["collection", "representation", "embedding", "diagnosis"],
                model_params={"run_id": info["run_id"] or ""},
            ),
            review=ReviewStatus(),
        )
        block_contribs = result.get("block_contributions")
        if block_contribs:
            contract.provenance.decision_explanation = {
                "method": "block_ablation",
                "contributions": block_contribs,
            }
        system_ref_class = getattr(system, "ref_class", None)
        normalized_hypothesis = canonical_label(result.get("primary_hypothesis"), ref_class=system_ref_class)
        if is_baseline_label(normalized_hypothesis, ref_class=system_ref_class):
            normalized_hypothesis = "baseline"
            result["primary_hypothesis"] = normalized_hypothesis
            result["stage1_result"] = "normal"
            contract.diagnosis.stage_1 = "normal"
            contract.diagnosis.primary_hypothesis = normalized_hypothesis
        elif normalized_hypothesis is not None:
            result["primary_hypothesis"] = normalized_hypothesis
        if not result.pop("_avaliacao_step_handled", False):
            _set_step(
                steps,
                "Avaliação do modelo",
                "completed",
                f"stage1={result.get('stage1_result', 'normal')}",
                result,
            )
        _set_step(
            steps,
            "Decisão 1",
            "completed",
            f"stage1={result.get('stage1_result', 'normal')}",
            {
                "stage1_result": result.get("stage1_result", "normal"),
                "primary_hypothesis": result.get("primary_hypothesis"),
                "confidence": result.get("confidence"),
                "evidence_id": result.get("evidence_id", ""),
                "llm_prompt": result.get("llm_prompt"),
                "llm_response": result.get("llm_response"),
            },
        )
        contract_json = {
                "incident": {
                    "incident_id": contract.incident.incident_id,
                    "evidence_id": contract.incident.evidence_id,
                    "system_id": contract.incident.system_id,
                },
                "diagnosis": {
                    "stage_1": contract.diagnosis.stage_1,
                    "primary_hypothesis": contract.diagnosis.primary_hypothesis,
                    "confidence": contract.diagnosis.confidence,
                },
            }
        if not result.pop("_stage2_step_handled", False):
            _set_step(
                steps,
                "Decisão 2",
                "completed",
                f"{result.get('stage1_result', 'normal')} | {result.get('primary_hypothesis') or 'sem hipótese'}",
                {
                    "final_result": result.get("stage1_result", "normal"),
                    "notify": result.get("stage1_result") == "anomalous",
                    "contract": contract_json,
                    "llm_prompt": result.get("llm_prompt"),
                    "llm_response": result.get("llm_response"),
                },
            )
        try:
            steps.append(_governance_step(system_id, contract_json))
        except Exception as exc:  # governança é auditoria — nunca derruba o ciclo
            logger.warning("failed to stamp governance step for %s: %s", system_id, exc)

        log_entry = _monitor_log(
            system_id,
            run_id=info.get("run_id"),
            collection_id=collection_id,
            window_start=window_start,
            window_end=window_end,
            package_window_seconds=package_window_seconds,
            steps=steps,
            evidence_id=result.get("evidence_id", ""),
            contract_id=result.get("incident_id", ""),
            stage1_result=result.get("stage1_result", "normal"),
            primary_hypothesis=result.get("primary_hypothesis"),
            confidence=result.get("confidence"),
            contract_json=contract_json,
            block_contributions=result.get("block_contributions"),
            metrics_by_entity=pkg.metrics_by_entity,
        )
        try:
            repo.save_monitoring_log(log_entry)
            opened_incident = repo.maybe_open_incident_for_recent_anomalies(system_id)
            if opened_incident is not None:
                logger.info(
                    "opened incident %s for %s after consecutive anomalies",
                    opened_incident.incident_id,
                    system_id,
                )
                try:
                    from src.application.stage3.tasks import enqueue_stage3_job

                    enqueue_stage3_job(repo, opened_incident)
                except Exception as exc:  # Stage 3 é análise diferida: nunca derruba o ciclo
                    logger.warning("failed to enqueue stage3 for %s: %s", system_id, exc)
                try:
                    # Modos d1–d4 escolhidos: despacho novo, `enqueue_stage3_job` intocado
                    from src.application.stage3.abordagens.despacho import despachar_modos

                    despachar_modos(repo, opened_incident)
                except Exception as exc:
                    logger.warning("failed to enqueue stage3 modes for %s: %s", system_id, exc)
        except Exception as exc:
            logger.warning("failed to save monitoring log for %s: %s", system_id, exc)

        if result.get("stage1_result") == "anomalous":
            notifier.notify(contract, log_entry)

        if notify_func is not None:
            notify_func(system_id)

        return {
            "system_id": system_id,
            "status": "completed",
            "run_id": info.get("run_id"),
            "evidence_id": result.get("evidence_id", ""),
            "stage1_result": result.get("stage1_result", "normal"),
        }

    except Exception as exc:
        logger.error("monitoring failed for %s: %s", system_id, exc, exc_info=True)
        if notify_func is not None:
            notify_func(system_id)
        return {"system_id": system_id, "status": "completed", "run_id": info.get("run_id")}
