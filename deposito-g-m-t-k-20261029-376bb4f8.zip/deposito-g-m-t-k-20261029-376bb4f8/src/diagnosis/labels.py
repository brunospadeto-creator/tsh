from __future__ import annotations

from typing import Any

BASELINE_LABEL = "baseline"
BASELINE_DESCRIPTION = "Operação normal / baseline"
LEGACY_BASELINE_LABELS = {"MODELO", "normal", "baseline"}


def canonical_label(value: Any, ref_class: str | None = None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    ref = str(ref_class).strip() if ref_class else ""
    if text in LEGACY_BASELINE_LABELS or (ref and text == ref):
        return BASELINE_LABEL
    return text


def display_label(value: Any, ref_class: str | None = None) -> str:
    label = canonical_label(value, ref_class=ref_class)
    if label is None:
        return "sem hipótese"
    if label == BASELINE_LABEL:
        return BASELINE_DESCRIPTION
    return label


def is_baseline_label(value: Any, ref_class: str | None = None) -> bool:
    return canonical_label(value, ref_class=ref_class) == BASELINE_LABEL


def is_failure_label(value: Any, ref_class: str | None = None) -> bool:
    label = canonical_label(value, ref_class=ref_class)
    return label is not None and label != BASELINE_LABEL
