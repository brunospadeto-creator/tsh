from src.schemas.evidence_package import METRIC_NAMES, EvidencePackage

_CAT_ORD = {"LOW": 0, "NORMAL": 1, "ELEVATED": 2, "HIGH": 3, "CRITICAL": 4}

# memoria_working_set_mb correlaciona com uptime do container, não com a
# falha (mesmo motivo que levou à criação do TFE *_no_memory_wss). Excluída
# de todo treinamento para evitar data leakage. A ablação já mantém sua
# própria cópia (EXCLUDED_FEATURES em ablation.py) -- este é o guard central
# pro treino normal (PyCaret, ML-RF, Feature-Fusion). entity_worst_cat_
# variant acrescentada junto:
# mesmo vazamento, só que por pod em vez de agregado.
TRAINING_EXCLUDED_FEATURES = frozenset({
    "memoria_working_set_mb", "cat_memoria_working_set_mb",
    "entity_worst_cat_memoria_working_set_mb",
})

# Congelado -- NÃO referenciar ALL_FEATURE_NAMES aqui. É o fallback de
# `feature_names` pra bundles de modelo salvos antes do campo
# `feature_names_snapshot` existir (ver ml_rf.py/feature_fusion_rf.py). Se
# ALL_FEATURE_NAMES crescer no futuro, esses 16 nomes continuam sendo o
# vetor que os modelos antigos foram treinados com.
_LEGACY_16_FEATURE_NAMES = (
    METRIC_NAMES
    + [f"cat_{c}" for c in METRIC_NAMES]
    + ["log_total", "log_unknown"]
)

# LOLS_VOLUME_ORD bate com get_logs_volume() (src/pipeline/s4_representation.py)
# -- que só retorna "LOW"/"MEDIUM"/"HIGH", nunca "NORMAL". Usar "NORMAL" aqui
# (erro da v1 do plano de atributos) faria logs_volume_cat ficar sempre -1
# pra pacotes de volume médio de log, o caso mais comum.
LOGS_VOLUME_ORD = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}

ENVIRONMENT_NAMES = [
    "logs_volume_cat", "k8s_events_n", "pod_count",
]

# `config_status_changed`/`app_commit_changed` removidas de ENVIRONMENT_NAMES em
# 20/09/2026: são metadado do PROCESSO de injeção da falha (o script registrou uma
# mudança de config/commit), não sintoma observável de um incidente real -- mesma
# categoria de risco de memoria_working_set_mb acima. Achado real: numa exploração
# PyCaret com metricas por pod (entity_features=true), essas duas apareceram nas
# posições #2/#6 de importância entre 82 features
# -- mais influentes do que quando isoladas
# (onde já eram "quase inertes"). Removidas da CATÁLOGO (não só filtradas por
# treino) para não serem sequer selecionáveis via `features=[...]`. As funções
# `_config_status_changed`/`_app_commit_changed` abaixo continuam existindo -- ainda
# usadas por `s4_representation.py::_version_summary_safe_text` pra gerar a cauda de
# versão binarizada (sim/não) dos modos TFE seguros, um uso legítimo diferente deste.

# Acréscimo -- resumo cross-pod
# de largura fixa: por métrica canônica, o ordinal da PIOR categoria entre
# as entidades de metrics_by_entity (mesmo _CAT_ORD já usado nas features
# "cat_<metrica>" agregadas). Sempre ACRESCENTADO ao final de
# ALL_FEATURE_NAMES, nunca inserido entre as 21 features já existentes --
# bundles antigos continuam reproduzíveis via feature_names_snapshot
# (ver selected_features_vector). Pacote sem metrics_by_entity vira -1.0 em
# todas (mesmo "sem dado" de logs_volume_cat/k8s_events_n quando não há
# categorized_features), nunca 0.0 (que seria uma categoria real, LOW).
ENTITY_SUMMARY_NAMES = [f"entity_worst_cat_{m}" for m in METRIC_NAMES]

# Fallback só usado quando não há como inferir o commit de referência do
# próprio treino (nenhum pacote rotulado como baseline disponível) -- era o
# commit do cenário baseline original (jpetstore-compose), hoje incorreto
# pra qualquer outro sistema (ex. teastore usa 34b37f7, jpetstore-k8s usa
# 5feb194). Achado real em 2026-09-11: como constante global fixa, deixava
# app_commit_changed sempre 1 (nunca bate com o commit de referência
# errado) pra qualquer sistema != jpetstore-compose -- feature virava dead
# weight (nem ajuda nem atrapalha, mas não faz o que promete). Ver
# infer_reference_app_commit(): o jeito certo é derivar do próprio dataset
# de treino (commit majoritário entre os pacotes rotulados como baseline),
# nunca precisa de configuração manual e nunca fica desatualizado.
REFERENCE_APP_COMMIT = "af0313a"


def infer_reference_app_commit(
    packages: list[EvidencePackage],
    labels: list[str],
    ref_class: str,
    default: str = REFERENCE_APP_COMMIT,
) -> str:
    """Deriva o commit de referência do próprio treino: o app_commit_version
    majoritário entre os pacotes rotulados como baseline (`ref_class`).
    Autocorretivo por coleção/sistema -- nunca precisa de configuração
    manual e nunca fica desatualizado como uma constante global fixa
    ficaria. Cai no `default` só se não houver nenhum pacote de baseline
    com app_commit_version utilizável (dataset degenerado)."""
    from collections import Counter

    counts: Counter[str] = Counter()
    for pkg, label in zip(packages, labels):
        if label != ref_class:
            continue
        commit = ((pkg.versao or {}).get("aplicacao") or {}).get("app_commit_version", "")
        if commit and commit != "N/A":
            counts[commit] += 1
    if not counts:
        return default
    return counts.most_common(1)[0][0]

ALL_FEATURE_NAMES = tuple(
    name for name in (
        METRIC_NAMES
        + [f"cat_{c}" for c in METRIC_NAMES]
        + ["log_total", "log_unknown"]
        + ENVIRONMENT_NAMES
        + ENTITY_SUMMARY_NAMES
    )
    if name not in TRAINING_EXCLUDED_FEATURES
)


def _config_status_changed(versao: dict) -> float:
    """versao.configuracao.status é setado direto pelo script de injeção de
    falha (CONFIGURACOES_ALTERADAS/SEM_ALTERACAO) -- verdade-terreno, ao
    contrário de config_change_type (que tenta adivinhar a categoria por
    palavra-chave no texto do diff e pode errar)."""
    status = (versao.get("configuracao") or {}).get("status", "SEM_ALTERACAO")
    return 1.0 if status == "CONFIGURACOES_ALTERADAS" else 0.0


def _app_commit_changed(versao: dict, reference_commit: str = REFERENCE_APP_COMMIT) -> float:
    """1 se o commit do pacote difere do commit de referência (baseline).
    Binário, não um hash por commit: um valor quase-único por cenário
    vazaria a própria classe-alvo pro classificador (testado empiricamente
    -- F1=0.998 com só 4 features usando o hash, sinal de memorização, não
    de diagnóstico real). app_commit_version ausente/"N/A" conta como
    "igual à referência" (0), não como "diferente". `reference_commit`
    deve vir de `infer_reference_app_commit()` no treino (nunca do
    REFERENCE_APP_COMMIT fixo, que só existe como fallback de último
    recurso)."""
    commit = (versao.get("aplicacao") or {}).get("app_commit_version", "")
    if not commit or commit == "N/A":
        return 0.0
    return 1.0 if commit != reference_commit else 0.0


def extract_all_features(
    package: EvidencePackage,
    reference_commit: str = REFERENCE_APP_COMMIT,
) -> dict[str, float]:
    """Monta as features possíveis num dict nome→valor (16 tabulares + 3 de
    ambiente K8s/topologia + 7 de resumo por pod) -- inclui mesmo as excluídas
    de ALL_FEATURE_NAMES (ver TRAINING_EXCLUDED_FEATURES), pra bundles antigos
    que ainda referenciam esses nomes no próprio `feature_names_snapshot`."""
    metrics = package.metrics or {}
    row: dict[str, float] = {col: float(metrics.get(col) or 0) for col in METRIC_NAMES}
    cf = package.categorized_features
    cat_m = cf.categorized_metrics if cf else {}
    for col in METRIC_NAMES:
        row[f"cat_{col}"] = float(_CAT_ORD.get(str(cat_m.get(col, "")).upper(), -1))
    log = package.log_details
    row["log_total"] = float(log.total_count)
    row["log_unknown"] = float(log.unknown_count)
    if cf:
        row["logs_volume_cat"] = float(LOGS_VOLUME_ORD.get(str(cf.logs_volume).upper(), -1))
        row["k8s_events_n"] = float(len(cf.k8s_event_reasons))
        row["pod_count"] = float(len(cf.normalized_pods))
    else:
        row["logs_volume_cat"] = -1.0
        row["k8s_events_n"] = 0.0
        row["pod_count"] = 0.0
    versao = package.versao or {}
    row["config_status_changed"] = _config_status_changed(versao)
    row["app_commit_changed"] = _app_commit_changed(versao, reference_commit)
    # Import local (não no topo do módulo) pra evitar ciclo -- s4_representation.py
    # já importa deste módulo (_app_commit_changed/_config_status_changed, ver
    # _version_summary_safe_text). Seguro em runtime: por aqui só é chamada
    # depois que os dois módulos já terminaram de carregar.
    from src.pipeline.s4_representation import entity_metrics_summary
    entity_summary = entity_metrics_summary(package)
    for col in METRIC_NAMES:
        entry = entity_summary.get(col)
        row[f"entity_worst_cat_{col}"] = float(_CAT_ORD.get(entry[0].upper(), -1)) if entry else -1.0
    return row


def selected_features_vector(
    package: EvidencePackage,
    enabled: list[str],
    feature_names: list[str] | None = None,
    reference_commit: str = REFERENCE_APP_COMMIT,
) -> list[float]:
    """Vetor de N posições (ordem `feature_names`), zerando as features que
    não estão em `enabled` — mantém o vetor sempre do mesmo tamanho dentro de
    uma seleção, pra não quebrar modelos treinados com seleções diferentes.

    `feature_names` deve ser o snapshot salvo no bundle do modelo no momento
    do treino (`feature_names_snapshot`) -- nunca ALL_FEATURE_NAMES *atual*
    na hora da inferência. Se ALL_FEATURE_NAMES crescer depois que um modelo
    foi treinado, usar o valor atual aqui mudaria o tamanho do vetor e
    quebraria a inferência desse modelo (scikit-learn rejeita shape
    diferente do treino). Default pra ALL_FEATURE_NAMES só serve pra
    treinar um modelo novo, nunca pra carregar um existente.
    """
    names = feature_names or ALL_FEATURE_NAMES
    all_features = extract_all_features(package, reference_commit)
    enabled_set = set(enabled)
    return [all_features[name] if name in enabled_set else 0.0 for name in names]
