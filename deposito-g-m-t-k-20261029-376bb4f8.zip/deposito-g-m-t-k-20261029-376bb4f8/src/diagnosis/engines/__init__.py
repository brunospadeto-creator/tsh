from collections.abc import Iterator, MutableMapping
from importlib import import_module
from typing import Any


_ENGINE_PATHS: dict[str, tuple[str, str]] = {
    "faiss": ("src.diagnosis.engines.faiss", "FAISSEngine"),
    "ml-rf": ("src.diagnosis.engines.ml_rf", "MLRFEngine"),
    "feature-fusion-rf": ("src.diagnosis.engines.feature_fusion_rf", "FeatureFusionRFEngine"),
    "rules": ("src.diagnosis.engines.rules", "RulesEngine"),
    "llm": ("src.diagnosis.engines.llm", "LLMEngine"),
    # "pycaret" não segue o padrão dos demais (uma classe só, treinada via
    # ENGINE_REGISTRY/train_stage): Stage1 e Stage2 são modelos distintos,
    # promovidos separadamente do Explorador (não treináveis via ENGINE_REGISTRY,
    # requires_training=False em catalog.py). Mapeado aqui pro Stage2 só por
    # retrocompatibilidade de quem já indexava ENGINE_REGISTRY["pycaret"];
    # o dispatch real (monitor/tasks.py, pages_explorador.py) importa
    # PyCaretStage1Engine/PyCaretStage2Engine diretamente por estágio.
    "pycaret": ("src.diagnosis.engines.pycaret_stage2", "PyCaretStage2Engine"),
    "blockwise": ("src.diagnosis.engines.blockwise", "BlockwiseRFEngine"),
}


def _load_engine(name: str) -> type:
    module_name, class_name = _ENGINE_PATHS[name]
    return getattr(import_module(module_name), class_name)


class _EngineRegistry(MutableMapping[str, type]):
    def __getitem__(self, key: str) -> type:
        if key not in _ENGINE_PATHS:
            raise KeyError(key)
        return _load_engine(key)

    def __setitem__(self, key: str, value: type) -> None:
        raise TypeError("ENGINE_REGISTRY is read-only")

    def __delitem__(self, key: str) -> None:
        raise TypeError("ENGINE_REGISTRY is read-only")

    def __iter__(self) -> Iterator[str]:
        return iter(_ENGINE_PATHS)

    def __len__(self) -> int:
        return len(_ENGINE_PATHS)


ENGINE_REGISTRY: MutableMapping[str, type] = _EngineRegistry()


def __getattr__(name: str) -> Any:
    exports = {
        "FAISSEngine": "faiss",
        "MLRFEngine": "ml-rf",
        "FeatureFusionRFEngine": "feature-fusion-rf",
        "RulesEngine": "rules",
        "LLMEngine": "llm",
        "PyCaretStage2Engine": "pycaret",
        "BlockwiseRFEngine": "blockwise",
    }
    if name in exports:
        return _load_engine(exports[name])
    if name == "PyCaretStage1Engine":
        from src.diagnosis.engines.pycaret_stage1 import PyCaretStage1Engine
        return PyCaretStage1Engine
    raise AttributeError(name)


__all__ = [
    "FAISSEngine", "FeatureFusionRFEngine", "LLMEngine", "MLRFEngine",
    "PyCaretStage1Engine", "PyCaretStage2Engine", "RulesEngine",
    "BlockwiseRFEngine", "ENGINE_REGISTRY",
]
