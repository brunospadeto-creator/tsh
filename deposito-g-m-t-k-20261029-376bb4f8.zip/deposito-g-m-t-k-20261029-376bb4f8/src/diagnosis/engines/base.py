from dataclasses import dataclass, field
from typing import Any


@dataclass
class EngineMetadata:
    engine_type: str
    name: str
    description: str
    requires_training: bool
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class DiagnosisReport:
    incident_id: str
    evidence_id: str
    system_id: str
    failure_id: str | None
    stage1_result: str
    primary_hypothesis: str | None
    confidence: float | None
    secondary_hypothesis: str | None = None
    secondary_competition: float | None = None
    probabilities: dict[str, float] | None = None
    engine_type: str = "unknown"
    engine_params: dict[str, Any] = field(default_factory=dict)
    reasoning: str | None = None
    llm_prompt: str | None = None
    llm_response: str | None = None


# ---------------------------------------------------------------------------
# Novos dataclasses para estágios independentes
# ---------------------------------------------------------------------------

@dataclass
class Stage1Result:
    """Resultado do Estágio 1 (classificação binária: normal vs anomalous)."""
    label: str                      # "normal" | "anomalous"
    confidence: float
    detail: dict[str, Any] | None = None   # vizinhos FAISS, probs RF, threshold violado, etc.


@dataclass
class Stage2Result:
    """Resultado do Estágio 2 (classificação multi-classe: qual falha)."""
    hypothesis: str                         # nome da classe de falha
    confidence: float
    probabilities: dict[str, float] = field(default_factory=dict)
    secondary_hypothesis: str | None = None
    secondary_confidence: float | None = None
    detail: dict[str, Any] | None = None


def binary_prob_anomalous(classes: list[int], proba_row: Any) -> tuple[float, float]:
    """Extrai (prob_normal, prob_anomalous) de uma linha de predict_proba binário
    (rótulos 0=normal/1=anomalous), respeitando `classifier.classes_`.

    predict_proba só devolve 1 coluna quando o treino viu uma única classe
    (dataset sem baseline, ou só baseline) -- nesse caso a coluna não é
    necessariamente "prob_normal": é a probabilidade da única classe que o
    classificador conhece. Ler a coluna por posição fixa (assumindo sempre
    "prob_normal") fazia todo pacote anômalo virar "normal" com confiança
    alta quando o treino só tinha a classe 1 (achado real, ver code review
    2026-09-15).
    """
    if len(classes) > 1:
        idx_anomalous = classes.index(1)
        prob_anomalous = float(proba_row[idx_anomalous])
        return 1.0 - prob_anomalous, prob_anomalous
    prob_anomalous = 1.0 if classes[0] == 1 else 0.0
    return 1.0 - prob_anomalous, prob_anomalous
