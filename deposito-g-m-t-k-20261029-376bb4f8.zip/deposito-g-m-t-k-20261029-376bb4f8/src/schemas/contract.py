from dataclasses import dataclass, field
from typing import Any


@dataclass
class IncidentInfo:
    incident_id: str
    evidence_id: str
    system_id: str
    failure_id: str | None = None


@dataclass
class DiagnosisInfo:
    stage_1: str
    primary_hypothesis: str | None
    confidence: float | None
    secondary_hypothesis: str | None = None


@dataclass
class MobilizedEvidence:
    log_templates: list[str]
    metric_features: list[str]
    events: list[str] = field(default_factory=list)


@dataclass
class ContractProvenance:
    processing_stages: list[str]
    model_params: dict[str, Any]
    stage_errors: list[str] | None = None
    # explicação post-hoc da decisão: {"method": ..., "contributions": [...]}
    decision_explanation: dict[str, Any] | None = None


@dataclass
class ReviewStatus:
    status: str = "pending_human_review"
    reason: str | None = None

    def confirm(self, reason: str | None = None) -> None:
        if self.status in ("confirmed", "rejected"):
            raise ValueError("contrato já foi revisado (already reviewed)")
        self.status = "confirmed"
        self.reason = reason

    def reject(self, reason: str | None = None) -> None:
        if self.status in ("confirmed", "rejected"):
            raise ValueError("contrato já foi revisado (already reviewed)")
        self.status = "rejected"
        self.reason = reason


@dataclass
class GovernanceInfo:
    """Proveniência + autorização da coleta (Extensão III.b)."""

    collecting_agent: str        # identidade do coletor (ex.: "job-runner:<worker_id>")
    authorization_scope: str     # escopo declarado (ex.: "system:{id}:collect")
    source_package_sha256: str   # hash SHA-256 do EvidencePackage serializado
    collected_at: str            # ISO UTC


@dataclass
class EvidenceContract:
    incident: IncidentInfo
    diagnosis: DiagnosisInfo
    mobilized_evidence: MobilizedEvidence
    provenance: ContractProvenance
    review: ReviewStatus
    status: str = "completa"
    governance: GovernanceInfo | None = None

    def __post_init__(self) -> None:
        if self.provenance.stage_errors and len(self.provenance.stage_errors) > 0:
            self.status = "coleta_incompleta"
