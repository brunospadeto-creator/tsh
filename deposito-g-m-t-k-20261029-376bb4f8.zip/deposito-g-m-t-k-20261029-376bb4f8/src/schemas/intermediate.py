from dataclasses import dataclass, field
from typing import Any


@dataclass
class TemplateFreq:
    template: str
    count: int


@dataclass
class RawSignalCollection:
    logs: list[dict[str, Any]] | None
    metrics: dict[str, list[float]]
    k8s_events: list[dict[str, Any]] | None = None
    # Métricas rotuladas por pod/entidade: entidade -> métrica -> lista de amostras brutas na janela.
    # Vazio quando o coletor não agrupa por entidade (compat total legada).
    metrics_by_entity: dict[str, dict[str, list[float]]] = field(default_factory=dict)


@dataclass
class SelectedSignals:
    logs: list[dict[str, Any]]
    metrics: dict[str, list[float]]
    time_range: tuple[str | None, str | None]
    k8s_events: list[dict[str, Any]] | None = None
    pod_names: list[str] = field(default_factory=list)
    metrics_by_entity: dict[str, dict[str, list[float]]] = field(default_factory=dict)


@dataclass
class CleanedSignals:
    templates: list[TemplateFreq]
    metric_values: dict[str, list[float]]
    k8s_events: list[dict[str, Any]] | None = None
    pod_counts: dict[str, int] = field(default_factory=dict)
    unknown_count: int = 0
    unknown_samples: list[str] = field(default_factory=list)
    template_params: dict[str, list[str]] = field(default_factory=dict)
    total_log_count: int = 0
    template_count: int = 0
    metrics_by_entity: dict[str, dict[str, list[float]]] = field(default_factory=dict)


@dataclass
class NormalizedAggregated:
    templates: list[TemplateFreq]
    metrics_raw: dict[str, float] = field(default_factory=dict)
    k8s_events: list[dict[str, Any]] | None = None
    pod_counts: dict[str, int] = field(default_factory=dict)
    unknown_count: int = 0
    unknown_samples: list[str] = field(default_factory=list)
    total_log_count: int = 0
    # Pico por entidade por métrica — mesma redução (arr.max())
    # de metrics_raw, mas agrupada por pod. Vazio quando a coleta não é
    # rotulada por entidade.
    metrics_by_entity: dict[str, dict[str, float]] = field(default_factory=dict)


@dataclass
class CollectConfig:
    window_start: str
    window_end: str
    window_seconds: int = 60
    severity_filter: list[str] | None = None
    top_k_templates: int = 10
    norm_method: str = "none"
    max_lines_per_chunk: int = 5000
    semantic_mask_classes: list[str] | None = None  # (default vazio = legado)
