from dataclasses import dataclass, field
from typing import Any


@dataclass
class LogDetails:
    total_count: int = 0
    unknown_count: int = 0
    unknown_samples: list[str] = field(default_factory=list)
    top_templates: dict[str, int] = field(default_factory=dict)

    @property
    def unknown_ratio(self) -> float:
        if self.total_count == 0:
            return 0.0
        return self.unknown_count / self.total_count


@dataclass
class Topology:
    active_pods: dict[str, int] = field(default_factory=dict)


@dataclass
class BaselineInfo:
    historical_mean_unknown: float = 0.0
    baseline_mocked: bool = False


@dataclass
class MetadataEvidencia:
    cenario: str = ""
    minute: str = ""
    anomaly_detected: bool = False
    anomaly_type: str = "modelo"
    severity_score: float = 0.0
    timestamp_exec: str = ""
    drain_state: str = ""


@dataclass
class CollectionPolicy:
    window_seconds: int = 60
    max_raw_logs: int = 5000
    parser: str = "drain"
    sampling_applied: bool = False
    profile_hash: str = ""


@dataclass
class CategorizedFeatures:
    logs_volume: str = "LOW"
    template_patterns: list[str] = field(default_factory=list)
    categorized_metrics: dict[str, str] = field(default_factory=dict)
    normalized_pods: list[str] = field(default_factory=list)
    k8s_event_reasons: list[str] = field(default_factory=list)
    app_commit: str = "N/A"
    config_change_type: str = "NONE"


@dataclass
class EvidencePackage:
    schema_version: str = "1.0"
    pipeline_version: str = "baseline"
    drain_template_version: str = "manual"
    source_run_id: str = ""
    metadata: MetadataEvidencia = field(default_factory=MetadataEvidencia)
    k8s_infrastructure_events: list[dict[str, Any]] = field(default_factory=list)
    log_details: LogDetails = field(default_factory=LogDetails)
    topology: Topology = field(default_factory=Topology)
    metrics: dict[str, float] = field(default_factory=dict)
    # desdobramento por serviço/pod — vazio no modo monolítico
    metrics_by_entity: dict[str, dict[str, float]] = field(default_factory=dict)
    baseline: BaselineInfo = field(default_factory=BaselineInfo)
    versao: dict[str, Any] = field(default_factory=dict)
    categorized_features: CategorizedFeatures | None = None

    evidence_id: str = ""
    system_id: str = ""
    failure_id: str | None = None
    window_start: str | None = None
    window_end: str | None = None
    collection_policy: CollectionPolicy = field(default_factory=CollectionPolicy)

    def to_old_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "schema_version": self.schema_version,
            "pipeline_version": self.pipeline_version,
            "drain_template_version": self.drain_template_version,
            "source_run_id": self.source_run_id,
            "metadata": {
                "cenario": self.metadata.cenario,
                "minute": self.metadata.minute,
                "anomaly_detected": self.metadata.anomaly_detected,
                "anomaly_type": self.metadata.anomaly_type,
                "severity_score": self.metadata.severity_score,
                "timestamp_exec": self.metadata.timestamp_exec,
                "drain_state": self.metadata.drain_state,
            },
            "k8s_infrastructure_events": list(self.k8s_infrastructure_events),
            "log_details": {
                "total_count": self.log_details.total_count,
                "unknown_count": self.log_details.unknown_count,
                "unknown_samples": list(self.log_details.unknown_samples),
                "top_templates": dict(self.log_details.top_templates),
            },
            "topology": {
                "active_pods": dict(self.topology.active_pods),
            },
            "metrics": dict(self.metrics),
            "baseline": {
                "historical_mean_unknown": self.baseline.historical_mean_unknown,
                "baseline_mocked": self.baseline.baseline_mocked,
            },
            "versao": dict(self.versao),
            "evidence_id": self.evidence_id,
            "system_id": self.system_id,
            "failure_id": self.failure_id,
            "window_start": self.window_start,
            "window_end": self.window_end,
            "collection_policy": {
                "window_seconds": self.collection_policy.window_seconds,
                "max_raw_logs": self.collection_policy.max_raw_logs,
                "parser": self.collection_policy.parser,
                "sampling_applied": self.collection_policy.sampling_applied,
                "profile_hash": self.collection_policy.profile_hash,
            },
        }
        if self.categorized_features is not None:
            result["categorized_features"] = {
                "logs_volume": self.categorized_features.logs_volume,
                "template_patterns": list(self.categorized_features.template_patterns),
                "categorized_metrics": dict(self.categorized_features.categorized_metrics),
                "normalized_pods": list(self.categorized_features.normalized_pods),
                "k8s_event_reasons": list(self.categorized_features.k8s_event_reasons),
                "app_commit": self.categorized_features.app_commit,
                "config_change_type": self.categorized_features.config_change_type,
            }
        if self.metrics_by_entity:
            result["metrics_by_entity"] = {
                entity: dict(m) for entity, m in self.metrics_by_entity.items()
            }
        return result


METRIC_NAMES = [
    "cpu_usage", "cpu_throttled", "memoria_usage_mb", "memoria_working_set_mb",
    "fs_writes_bytes", "fs_reads_bytes", "latencia_pura_ms",
]


def metrics_to_vector(metrics: dict[str, float]) -> list[float]:
    return [metrics.get(name, 0.0) for name in METRIC_NAMES]
