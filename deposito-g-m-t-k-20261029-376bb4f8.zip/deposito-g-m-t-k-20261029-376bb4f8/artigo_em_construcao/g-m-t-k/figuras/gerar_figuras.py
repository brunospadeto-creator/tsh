#!/usr/bin/env python3
"""Figuras do artigo (`main.tex`): diagrama do método, linha do tempo de um instante e reamostragem da baseline.

Paleta: os três primeiros tons da paleta categórica validada (azul, laranja, verde-água; todos os pares passam
no validador de daltonismo), com rótulo direto em todas as marcas, porque o verde-água tem contraste < 3:1.
A figura 3 lê o checkpoint do R1 (`DADOS_SAIDA/metricas-rz/robustez/resultados.pkl`), sem recalcular nada.

A figura do caso real lê o RCAEval RE1-OB em `$BASES_EXTERNAS_ORIGEM/RCAEval` (padrão: o disco da máquina dos
experimentos) e escolhe o caso por critério fixo, impresso na saída.

Uso (venv do experimento): python gerar_figuras.py → fig-metodo.pdf, fig-tempo.pdf, fig-r1.pdf, fig-caso.pdf (+ .png).
Com `--en`, as mesmas figuras em inglês, com ponto decimal, em `en/` e com os nomes da submissão à SOCA:
`Fig1` (método), `Fig2` (caso real), `Fig3` (reamostragem da baseline) e `FigS1` (linha do tempo, do Online
Resource 1).
"""
from __future__ import annotations

import os
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

AQUI = os.path.dirname(os.path.abspath(__file__))
EN = "--en" in sys.argv
NOMES_EN = {"fig-metodo": "Fig1", "fig-caso": "Fig2", "fig-r1": "Fig3", "fig-tempo": "FigS1"}


def T(pt: str, en: str) -> str:
    return en if EN else pt


def dec(s: str) -> str:
    """Vírgula decimal em português; ponto em inglês."""
    return s if EN else s.replace(".", ",")
AZUL, LARANJA, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
TINTA, TINTA2, GRADE, FUNDO = "#0b0b0b", "#52514e", "#d9d8d4", "#fcfcfb"

SANS = ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"]  # Liberation Sans: mesmas métricas do Arial
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": SANS, "font.size": 9.5,
                     "mathtext.fontset": "custom", "mathtext.rm": "sans", "mathtext.it": "sans:italic",
                     "mathtext.bf": "sans:bold",  # fórmulas na mesma fonte do texto, e não em DejaVu
                     "pdf.fonttype": 42, "ps.fonttype": 42, "axes.edgecolor": TINTA2,
                     "axes.labelcolor": TINTA, "xtick.color": TINTA2, "ytick.color": TINTA2,
                     "axes.spines.top": False, "axes.spines.right": False, "figure.facecolor": "white"})


def salvar(fig: plt.Figure, nome: str) -> None:
    pasta, nome = (os.path.join(AQUI, "en"), NOMES_EN[nome]) if EN else (AQUI, nome)
    os.makedirs(pasta, exist_ok=True)
    for ext in ("pdf", "eps", "png"):  # EPS: formato pedido pela SOCA para figuras vetoriais
        fig.savefig(os.path.join(pasta, f"{nome}.{ext}"), bbox_inches="tight", dpi=200)
    plt.close(fig)


def caixa(ax, x, y, w, h, texto, cor=None, peso="normal"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.04",
                                fc=FUNDO, ec=cor or TINTA2, lw=1.6 if cor else 1.0))
    ax.text(x + w / 2, y + h / 2, texto, ha="center", va="center", color=TINTA, fontsize=8.5, weight=peso,
            linespacing=1.3)


def seta(ax, a, b, cor=TINTA2):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=10, lw=1.0, color=cor,
                                 shrinkA=2, shrinkB=2))


def fig_metodo() -> None:
    # Caixas da altura do texto e espaços menores: a figura ocupa cerca de 3/4 da altura anterior.
    fig, ax = plt.subplots(figsize=(7.2, 2.7))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 3.75)
    ax.axis("off")
    caixa(ax, 0.1, 3.0, 2.6, 0.65, T("Baseline do sistema\n(trecho normal)", "System baseline\n(normal stretch)"))
    caixa(ax, 0.1, 1.6, 2.6, 0.65, T("Janela (t−120, t]\n× referência da sessão", "Window (t−120, t]\n× session reference"))
    caixa(ax, 3.2, 3.05, 3.4, 0.6, T("limiares: $N_f$, τ, λ, q\n(taxa-alvo de falso positivo)", "thresholds: $N_f$, τ, λ, q\n(false-positive target)"))
    caixa(ax, 3.2, 2.25, 3.4, 0.6, T("Escore de Desvio\npor Família $s(v)$", "Family-wise\nDeviation Score $s(v)$"), AZUL, "bold")
    caixa(ax, 3.2, 1.45, 3.4, 0.6, T("Portão de Rastros (contraste da\nsessão ou testes da composição)", "Traces Gate (session contrast\nor call-composition tests)"), LARANJA)
    caixa(ax, 3.2, 0.65, 3.4, 0.6, T("Portão de Sintoma\n(evento do orquestrador)", "Symptom Gate\n(orchestrator event)"), AQUA)
    caixa(ax, 7.0, 2.25, 2.8, 0.6, T("Portão de Métricas\nmax $s(v)$ ≥ τ", "Metrics Gate\nmax $s(v)$ ≥ τ"), AZUL)
    caixa(ax, 7.0, 1.2, 2.8, 0.8, T("Algum portão aberto?\nsim → ranking por $s(v)$\nnão → abstenção", "Any gate open?\nyes → rank by $s(v)$\nno → abstain"))
    caixa(ax, 7.0, 0.1, 2.8, 0.8, T("Serviço com sintoma\npromovido ao 1º lugar\n(se houver)", "Service with symptom\npromoted to first place\n(if any)"))
    seta(ax, (2.7, 3.35), (3.2, 3.35))
    seta(ax, (2.7, 2.0), (3.2, 2.55))
    seta(ax, (2.7, 1.93), (3.2, 1.75))
    seta(ax, (2.7, 1.85), (3.2, 0.95))
    seta(ax, (4.9, 3.05), (4.9, 2.85))
    seta(ax, (6.6, 2.55), (7.0, 2.55), AZUL)
    seta(ax, (8.4, 2.25), (8.4, 2.0), AZUL)
    seta(ax, (6.6, 1.75), (7.0, 1.7), LARANJA)
    seta(ax, (6.6, 0.95), (7.0, 1.45), AQUA)
    seta(ax, (8.4, 1.2), (8.4, 0.9))
    salvar(fig, "fig-metodo")


def fig_tempo() -> None:
    fig, ax = plt.subplots(figsize=(6.6, 2.0))
    inj = 0
    ax.axvspan(inj - 600, inj, ymin=0.55, ymax=0.85, color=AZUL, alpha=0.18, lw=0)
    ax.text(inj - 300, 0.70, T("referência das métricas (600 s)\ncongelada no início da injeção", "metrics reference (600 s)\nfrozen at the injection start"), ha="center", va="center",
            fontsize=8.5, color=TINTA, transform=ax.get_xaxis_transform())
    for k, t in enumerate(range(120, 601, 60)):
        alto = k == 0
        ax.axvspan(t - 120, t, ymin=0.15 + 0.0, ymax=0.40, color=LARANJA, alpha=0.30 if alto else 0.07, lw=0)
        ax.plot([t, t], [0.12, 0.43], color=LARANJA, lw=1.4 if alto else 0.8, transform=ax.get_xaxis_transform())
    ax.text(-15, 0.27, T("1ª janela (t = inj + 120 s) →", "1st window (t = inj + 120 s) →"), ha="right", va="center", fontsize=8.5, color=TINTA,
            transform=ax.get_xaxis_transform())
    ax.text(130, 0.50, T("instantes com causa: inj + 120 s … inj + 600 s, a cada 60 s", "fault-active instants: inj + 120 s … inj + 600 s, every 60 s"), ha="left", fontsize=8.5,
            color=TINTA2, transform=ax.get_xaxis_transform())
    ax.axvline(inj, color=TINTA, lw=1.2)
    ax.text(inj + 8, 0.93, T("injeção", "injection"), ha="left", va="top", fontsize=8.5, color=TINTA, transform=ax.get_xaxis_transform())
    ax.set_xlim(-720, 660)
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    ax.set_xlabel(T("tempo em relação à injeção (s), bases públicas", "time relative to the injection (s), public datasets"), labelpad=16)
    salvar(fig, "fig-tempo")


def fig_r1() -> None:
    sys.path.insert(0, os.path.join(AQUI, "..", "..", "..", "bases-externas", "metricas-rz"))
    import robustez as R  # noqa: PLC0415
    r1 = R.ler("resultados")["R1"]
    a = [x["g-m∨t|mf"] for x in r1["A"]]
    t = [x["g-m∨t∨k|mfk@B"] for x in r1["TeaStore"]]
    paineis = [(T("RCAEval inédito: F1@1", "Unseen RCAEval: F1@1"), [x[0] for x in a], 0.6, T("critério ≥ 0,6 ", "criterion ≥ 0.6 "), 0.614, a, ("right", "left")),
               (T("TeaStore inédito com orquestrador: alarme", "Unseen TeaStore with orchestrator: alarm"), [x[2] * 100 for x in t], 20.0, T(" limite ≤ 20%", " limit ≤ 20%"), 15.3, t,
                ("left", "right"))]
    fig, axs = plt.subplots(1, 2, figsize=(6.3, 2.6))
    for ax, (titulo, v, lim, rot_lim, obs, tri, (al_lim, al_obs)) in zip(axs, paineis, strict=True):
        ok = sum(1 for f1, f2, al in tri if f1 >= 0.6 and f2 >= 0.7 and al <= 0.20) / len(tri)
        ax.hist(v, bins=24, color=AZUL, edgecolor="white", linewidth=0.8)
        ax.axvline(lim, color=TINTA, lw=1.0, ls="--")
        ax.axvline(obs, color=LARANJA, lw=1.6)
        topo = ax.get_ylim()[1]
        ax.set_ylim(0, topo * 1.25)
        ax.text(lim, topo * 1.13, rot_lim, ha=al_lim, va="center", fontsize=8.5, color=TINTA)
        reg = T("registrado", "recorded")
        rot_obs = dec(f" {reg} {obs:g}") if al_obs == "left" else dec(f"{reg} {obs:g} ")
        ax.text(obs, topo * 1.03, rot_obs, ha=al_obs, va="center", fontsize=8.5, color=TINTA)
        sub = dec(T(f"(critério vale em {ok:.1%} dos sorteios)", f"(criterion holds in {ok:.1%} of the draws)"))
        ax.set_title(f"{titulo}\n{sub}", fontsize=8.5, color=TINTA)
        ax.set_xlabel(T("valor nos 500 sorteios de baseline", "value over the 500 baseline draws") if lim < 1
                      else T("alarme (%) nos 500 sorteios de baseline", "alarm (%) over the 500 baseline draws"))
        ax.grid(axis="y", color=GRADE, lw=0.6)
        ax.set_axisbelow(True)
    axs[0].set_ylabel(T("sorteios", "draws"))
    fig.tight_layout()
    salvar(fig, "fig-r1")


def _servico(col: str) -> str:
    """Serviço de uma coluna do RCAEval, como em `emenda2.servico_col`."""
    return col.split("__")[0] if "__" in col else col.rsplit("_", 1)[0]


def _caso_re1ob(pasta: str):
    """Série normalizada pela referência e os escores E1 (maior amostra) e E2 (mediana) por serviço, no 1º instante
    com causa: janela (inj, inj + 120], referência (inj − 600, inj], como no `extras_revisao.py`."""
    import numpy as np  # noqa: PLC0415
    import pandas as pd  # noqa: PLC0415
    arq = os.path.join(pasta, "data.csv")
    if not os.path.exists(arq):
        arq = os.path.join(pasta, "simple_metrics.csv")
    df = pd.read_csv(arq).set_index("time").sort_index()
    df = df[[c for c in df.columns if "_" in str(c)]].apply(pd.to_numeric, errors="coerce")
    with open(os.path.join(pasta, "inject_time.txt")) as f:
        inj = float(f.read().strip())
    tempo = df.index.to_numpy(dtype=float)
    ref = df[(tempo >= max(tempo[0], inj - 600)) & (tempo < inj)]
    jan = df[(tempo > inj) & (tempo <= inj + 120)]
    med = ref.median()
    iqr = (ref.quantile(0.75) - ref.quantile(0.25)).where(lambda x: x > 0, 1.0)
    z = (df - med) / iqr  # série em unidades de IQR da referência
    e1 = ((jan - med).abs() / iqr).max()
    e2 = ((jan.median() - med).abs() / iqr)
    por = {}
    for nome, sc in (("E1", e1), ("E2", e2)):
        d = {}
        for c, v in sc.items():
            if np.isfinite(v):
                s = _servico(c)
                if v > d.get(s, (-1, ""))[0]:
                    d[s] = (float(v), c)
        por[nome] = d
    return z, inj, por


def fig_caso() -> None:
    """Caso real do RCAEval RE1-OB, escolhido por critério fixo: o primeiro caso, em ordem alfabética, em que a
    maior amostra da janela (degrau E1 da Tabela 4) e a mediana da janela (E2) põem serviços diferentes em 1º."""
    origem = os.path.join(os.environ.get("BASES_EXTERNAS_ORIGEM", "/mnt/gpu-disk/veritas/novo-artigo/datasets"),
                          "RCAEval", "RE1-OB", "RE1-OB")
    casos = sorted(os.path.relpath(p, origem).replace(os.sep, "/")
                   for p in (os.path.join(origem, a, b) for a in os.listdir(origem)
                             for b in os.listdir(os.path.join(origem, a))) if os.path.isdir(p))
    for caso in casos:
        z, inj, por = _caso_re1ob(os.path.join(origem, caso))
        top = {k: max(v, key=lambda s: v[s][0]) for k, v in por.items()}
        if top["E1"] != top["E2"]:
            break
    else:
        raise SystemExit("nenhum caso do RE1-OB com E1 e E2 discordantes")
    import numpy as np  # noqa: PLC0415
    causa = caso.split("/")[0].rsplit("_", 1)[0]
    print(f"caso escolhido: RE1-OB/{caso}; causa {causa}; 1º por E1: {top['E1']}; 1º por E2: {top['E2']}")

    fig, (ax, bx) = plt.subplots(2, 1, figsize=(3.4, 3.9), gridspec_kw={"height_ratios": [1.15, 1]})
    t = z.index.to_numpy(dtype=float) - inj
    vis = (t >= -600) & (t <= 120)
    ax.axvspan(-600, 0, color="#e6eefa", lw=0)  # cores sólidas: o EPS não tem transparência
    ax.axvspan(0, 120, color="#fce5da", lw=0)
    for chave, cor in (("E1", TINTA2), ("E2", AZUL)):
        col = por[chave][top[chave]][1]  # a coluna que pôs o 1º de cada escore em primeiro lugar
        y = z[col].to_numpy(dtype=float)
        ax.plot(t[vis], y[vis], color=cor, lw=0.9, label=col)
        ax.plot([0, 120], [float(np.nanmedian(y[(t > 0) & (t <= 120)]))] * 2, color=cor, lw=2.2)
    ax.axvline(0, color=TINTA, lw=0.8)
    ax.set_xlim(-600, 120)
    ax.set_ylim(top=ax.get_ylim()[1] * 1.55)  # folga acima das séries para a legenda e os rótulos das faixas
    ax.set_xlabel(T("tempo em relação à injeção (s)", "time relative to the injection (s)"), fontsize=8)
    ax.set_ylabel(T("desvio (em IQR da ref.)", "deviation (ref. IQRs)"), fontsize=8)
    ax.tick_params(labelsize=7.5)
    ax.legend(fontsize=7, frameon=False, loc="upper left", bbox_to_anchor=(0.0, 0.90))
    ax.text(-590, 0.97, T("referência", "reference"), transform=ax.get_xaxis_transform(), ha="left", va="top",
            fontsize=7, color=TINTA2)
    ax.text(60, 0.97, T("janela", "window"), transform=ax.get_xaxis_transform(), ha="center", va="top",
            fontsize=6.3, color=TINTA2)

    servs = sorted(set(por["E1"]) | set(por["E2"]), key=lambda s: -max(por["E1"].get(s, (0,))[0],
                                                                         por["E2"].get(s, (0,))[0]))[:5]
    yy = np.arange(len(servs))
    bx.barh(yy - 0.2, [por["E1"].get(s, (0,))[0] for s in servs], height=0.38, color=TINTA2,
            label=T("maior amostra (E1)", "largest sample (E1)"))
    bx.barh(yy + 0.2, [por["E2"].get(s, (0,))[0] for s in servs], height=0.38, color=AZUL,
            label=T("mediana da janela (E2)", "window median (E2)"))
    bx.set_yticks(yy, [s + T(" (causa)", " (cause)") if s == causa else s for s in servs], fontsize=7.5)
    bx.invert_yaxis()
    bx.set_xscale("symlog", linthresh=1)
    bx.set_xlabel(T("escore do serviço (escala log)", "service score (log scale)"), fontsize=8)
    bx.tick_params(axis="x", labelsize=7.5)
    bx.legend(fontsize=7, frameon=False, loc="upper center", bbox_to_anchor=(0.35, -0.28), ncol=2)
    fig.tight_layout(h_pad=0.6)
    salvar(fig, "fig-caso")


if __name__ == "__main__":
    fig_metodo()
    fig_tempo()
    fig_r1()
    fig_caso()
