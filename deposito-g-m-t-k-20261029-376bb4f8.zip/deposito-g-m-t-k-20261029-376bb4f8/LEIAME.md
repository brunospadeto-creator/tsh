# Material do artigo "Detecção de erros e localização de causas em microsserviços com métricas por serviço e limiares calibrados na baseline"

Autores: Bruno Spadeto (Programa de Pós-Graduação em Governança e Transformação Digital, Universidade Federal do
Tocantins) e Diego de Castro Rodrigues (Universidade Federal do Tocantins e Instituto Federal do Tocantins).

Este pacote reúne o protocolo registrado, as três emendas, o código do método, os scripts de avaliação e de
robustez, os comparadores, os relatórios de resultado, a coleta do TeaStore e a cronologia dos commits. O código é
o que produziu os números do artigo; o pacote traz só os arquivos de que esses scripts dependem.

## O que há aqui

| caminho | conteúdo |
|---|---|
| `CRONOLOGIA.md` | commits do protocolo, das emendas e das análises, com hashes e datas; sha256 do código congelado no registro e neste pacote |
| `registro/` | o `PROTOCOLO-COMPLETO.md` como estava no commit do registro (`6ca30930`) e o código congelado nesse commit |
| `bases-externas/metricas-rz/PROTOCOLO-COMPLETO.md` | protocolo com as emendas 1 a 3 e os resultados |
| `bases-externas/metricas-rz/PROTOCOLO.md` | ciclo de desenvolvimento do escore (iterações 1 a 5), anterior ao registro |
| `bases-externas/metricas-rz/resultado-*.md`, `RESULTADO-ARTIGO.md` | resultados de cada etapa e das análises adicionais |
| `bases-externas/` | método, adaptadores do RCAEval, do OpenRCA Market e do Eadro, calibração pela baseline, robustez e comparadores, com o protocolo e o resultado de cada rodada |
| `experimento-falhas/teastore/stage3-online/replay/` | avaliação do TeaStore: métodos de rastros, método proposto, extensão com eventos e cache da robustez |
| `experimento-falhas/teastore/` | protocolos do TeaStore, implantação (`teastore-base.yaml`, `TEASTORE_COMMIT`), injeção de falhas (`falha-cli/`, `lib.sh`, `falhas-config-f11-f14.md`, `imagens/`) e drivers dos lotes (`coleta-lote-stage3.sh`, `run-*-lotes.sh`, `stage3-online/`) |
| `src/` | módulos da biblioteca de monitoramento do autor que os scripts importam (portões, referência da sessão, métodos de rastros e o que eles carregam) |
| `bases-externas/reproducao/` | ambiente travado (`requirements.txt`, `Dockerfile`), script de reprodução do confirmatório RCAEval e versão do pacote dos comparadores |
| `NOMES.md` | correspondência entre os nomes do artigo e os códigos usados no código e nos documentos |
| `SHA256SUMS` | sha256 de cada arquivo do pacote |

O código e os documentos usam códigos internos (por exemplo, `g-m∨t|mf` para o Híbrido de Métricas e Rastros); o
`NOMES.md` traduz cada um.

## Dados

- **RCAEval** e **OpenRCA Market**: públicos, baixados dos repositórios dos autores (ver o artigo).
- **TeaStore**: a telemetria bruta das oito rodadas usadas no artigo (rastros, métricas e eventos do Kubernetes), as
  baselines de rastros normais das duas coleções e os arquivos de controle estão na parte 3 deste registro do Zenodo.
  Os registros por instante e por caso que as tabelas leem estão na parte 2.

## Onde está cada parte

| parte | arquivo | Zenodo | GitHub |
|---|---|---|---|
| 1. Código e protocolo | este pacote (`deposito-g-m-t-k-<data>-<commit>.zip`) | sim | sim |
| 2. Evidências derivadas | `2-evidencias.tar.gz` | sim | sim |
| 3. Telemetria do TeaStore | `teastore-*.tar.gz` (10 arquivos) | sim | não |

O registro do Zenodo é a versão de referência do artigo e tem as três partes. As partes 1 e 2 também estão no
GitHub, em <https://github.com/brunospadeto-creator/tsh>; a parte 3 fica só no Zenodo, porque os arquivos passam do
limite de tamanho por arquivo do GitHub. Nos dois lugares, o `SHA256SUMS` ao lado dos arquivos confere cada um.

## Como reproduzir o confirmatório RCAEval

O confirmatório RCAEval (F1@1 = 0,614 no artigo) roda a partir dos dados públicos, em cerca de 4 minutos com 24
processos. Num teste do autor (20/10/2026), num contêiner limpo e sem acesso à rede, o resultado foi idêntico, linha
por linha, ao `resultado-confirmatorio-A.md` do pacote. Os arquivos do RCAEval (suítes RE1, RE2 e RE3) ficam numa
pasta `<dados>/RCAEval/<suíte>/<suíte>/`, como saem da descompactação. Só as suítes RE1-OB, RE1-SS, RE1-TT, RE2-SS e
RE3-SS são usadas.

Com Docker, na raiz do pacote:

```
docker build -t g-m-t-k-repro -f bases-externas/reproducao/Dockerfile .
docker run --rm -v <dados>:/dados:ro -v <saida>:/saida g-m-t-k-repro /dados /saida
```

Sem Docker, com Python 3.12: `pip install -r bases-externas/reproducao/requirements.txt` e
`bash bases-externas/reproducao/reproduzir.sh <dados> <saida>`.

O script compara o resultado com o `resultado-confirmatorio-A.md` do pacote e com os números do artigo, e termina com
código 0 se tudo bate. As demais etapas nas bases públicas usam os mesmos módulos e as variáveis
`BASES_EXTERNAS_ORIGEM` (pasta dos dados) e `BASES_EXTERNAS_SAIDA` (pasta dos artefatos). Os comparadores publicados
precisam também do pacote em `requirements-comparadores.txt`.

A comparação no protocolo operacional (BARO e N-Sigma na janela, com o mesmo portão) é feita por
`bases-externas/metricas-rz/operacional.py`: `--parte publicas` nas bases públicas (14 min), `--parte teastore --raiz
<raiz do pacote>` depois dos passos do TeaStore abaixo, e `--relatorio`, que grava o `resultado-operacional.md`. `bases-externas/metricas-rz/complementos.py`, depois do `operacional.py` e do `robustez.py`, grava o
`resultado-complementos.md` (instantes por conjunto, frações do R1 e o recorte de 23 casos do OpenRCA Market).
O TORAI roda com `bases-externas/metricas-rz/comparadores_torai.py --rodar` e `--relatorio` (cerca de 10 min com 24
processos), com o mesmo `causal-learn` modificado que o RCD usa; só o RE2 traz as séries de logs e de rastros que ele lê.

O PDiagnose e o passo de desvio de Fukuda et al. rodam com `bases-externas/metricas-rz/comparadores_novos.py --rodar` e `--relatorio` (`resultado-comparadores-novos.md`). O custo de execução por instante (`resultado-custo.md`) sai de `bases-externas/metricas-rz/custo.py --n 3 --n-rastros 2`, num núcleo, e os intervalos de confiança das tabelas de comparação e o δ de Cliff (`resultado-ic-efeito.md`) saem de `bases-externas/metricas-rz/ic_efeito.py`, que só lê os caches da parte 2. A ablação do N_f no Portão de Métricas (`resultado-ablacao-nf.md`) sai de `bases-externas/metricas-rz/ablacao_nf.py`, que também só lê esses caches. As figuras do artigo saem de `artigo_em_construcao/g-m-t-k/figuras/gerar_figuras.py`.

## Como reproduzir o TeaStore

As tabelas do TeaStore saem de oito rodadas: as quatro do conjunto inédito (`20261013T051436Z`, `20261013T061915Z`,
`20261013T143247Z`, `20261016T075241Z`) e as quatro da coleta definitiva (`20261016T002739Z`, `20261016T151716Z`,
`20261016T223053Z`, `20261017T050131Z`). Para reproduzir, a partir da parte 3:

1. extrair os oito `teastore-<run-id>.tar.gz` e o `teastore-controle.tar.gz` em
   `experimento-falhas/teastore/stage3-online/resultados/` (o controle traz os marcadores dos lotes da coleta
   definitiva e os artefatos da baseline das duas coleções);
2. extrair o `teastore-baselines.tar.gz` numa pasta qualquer e apontar `TEASTORE_BACKUPS` para ela;
3. instalar `requirements.txt` e, para o BARO e o N-Sigma no TeaStore, o pacote de `requirements-comparadores.txt`;
4. em `experimento-falhas/teastore/stage3-online/`, rodar nesta ordem (tempo com 24 processos, num teste do autor):

| passo | produz | tempo |
|---|---|---|
| `python replay/definitiva.py` | métodos de rastros na coleta definitiva | 2 min |
| `python replay/definitiva_unificado.py` | tabela única de todos os métodos de rastros | 7 min |
| `python replay/definitiva_sem_k8s.py` | ablação dos eventos do Kubernetes nos métodos de rastros | 2 min |
| `python replay/hibrido_d9a.py --conjuntos def` | Contraste com Reserva e com Orquestrador e Reserva | 2 min |
| `python replay/baseline_dinamica.py` | limiares calculados pela baseline (componente 6) | 7 min |
| `python replay/metricas_rz_teastore.py` | Híbrido de Métricas e Rastros na coleta definitiva | 10 s |
| `python replay/metricas_rz_ineditos.py` | os 17 cenários inéditos (B′) | 9 min |
| `python replay/metricas_rz_k8s.py` | Híbrido de Três Sinais nos 41 cenários | 1 min |
| `python replay/sintoma_normais.py` | alarme do canal de sintoma nos instantes normais (análise adicional) | 1 min |
| `python replay/sintoma_fases.py` | eventos de sintoma por fase da linha do tempo (análise adicional) | 6 s |
| `python replay/robustez_cache_teastore.py` | cache por instante que `bases-externas/metricas-rz/robustez.py` lê | 4 min |

Num teste do autor (21/10/2026), a partir deste pacote e só com os arquivos das partes 1 e 3, os relatórios, as
calibrações e o cache da robustez saíram idênticos, byte a byte, aos da parte 2, e 202 dos 205 registros por
instante também. Os outros três são da tabela única (`unificado/`) e diferem só nos modos `d1` e `d1c`
(conformance por alinhamento, fora do artigo), em p-valores da ordem de 1e-143 e na ordem de serviços empatados; a
diferença muda de uma execução para outra, nenhuma decisão nem primeiro lugar muda, e a tabela única sai idêntica. A coleta (implantação do TeaStore,
injeção das falhas e drivers dos lotes) está em `experimento-falhas/teastore/`, mas depende do cluster Kubernetes e
do sistema de monitoramento em operação; ela documenta como os dados foram obtidos e não é necessária para
reproduzir as tabelas.

## Sobre o código do sistema de monitoramento

Os scripts do TeaStore importam módulos da biblioteca de monitoramento do autor (`src/`), da qual os métodos de
rastros fazem parte. Entre eles está `src/application/stage3/llm_synthesis.py`, a síntese textual de incidentes por
modelo de linguagem do sistema de monitoramento. Ela é importada por `src/application/stage3/tasks.py`, mas nenhum
script deste pacote a chama: nenhum número do artigo depende de modelo de linguagem.

Os comentários e as docstrings passaram por uma limpeza que retirou as referências às notas internas do autor; a
lógica é a do commit indicado na `CRONOLOGIA.md` (ver a seção "Limpeza dos comentários").

## O que o registro prova e o que não prova

O protocolo foi registrado num repositório git privado do autor, e não num serviço público de pré-registro. Os
hashes permitem conferir que o protocolo e o código deste pacote são os registrados. As datas dos commits, porém, são
declaradas pelo autor. Este depósito é posterior à execução e não prova a data do registro.

## Licença (proposta)

Código sob licença MIT; documentos e resultados sob CC BY 4.0.

