#!/usr/bin/env python3
"""Ciclo de melhoria no RCAEval (`PROTOCOLO.md`): ranking por métricas (`m-rz`) sobre os portões de traces já
medidos, separado em dev e holdout.

Os portões vêm dos registros do `../d9a/` e das calibrações do `../baseline-dinamica/`. As métricas vêm de
`simple_metrics.csv` de cada caso. Uso: python ciclo.py
"""
from __future__ import annotations

import datetime
import warnings
import importlib.util
import os
import random
import sys
from collections import Counter, defaultdict
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
sys.path[:0] = [RAIZ, os.path.join(RAIZ, "baseline-dinamica")]

import rcaeval as BD  # noqa: E402  (baseline-dinamica: carregar, calibracoes, decisoes, exatos)

from comum import DADOS_ORIGEM, DADOS_SAIDA  # noqa: E402

ORIGEM = os.path.join(DADOS_ORIGEM, "RCAEval")
JANELA, REF = 120, 600
SEMENTE = "20261018-metricas"


def _d9a() -> Any:
    spec = importlib.util.spec_from_file_location("d9a_analisar", os.path.join(RAIZ, "d9a", "analisar.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def dividir(linhas: list[dict[str, Any]]) -> dict[str, str]:
    """`{caso: "dev" | "holdout"}`, estratificado por suíte × tipo de falha."""
    estratos: dict[tuple[str, str], list[str]] = defaultdict(list)
    for caso, grupo, tipo in sorted({(x["caso"], x["grupo"], x["tipo"]) for x in linhas}):
        estratos[(grupo, tipo)].append(caso)
    rnd, out = random.Random(SEMENTE), {}
    for chave in sorted(estratos):
        cs = estratos[chave]
        rnd.shuffle(cs)
        for i, c in enumerate(cs):
            out[c] = "dev" if i % 2 == 0 else "holdout"
    return out


def _serie(caso: str) -> tuple[pd.DataFrame, float]:
    suite, resto = caso.split("/", 1)
    pasta = os.path.join(ORIGEM, suite, suite, resto)
    arq = os.path.join(pasta, "simple_metrics.csv")
    if not os.path.exists(arq):   # `multi-source-data`: o `metrics.csv` dessa pasta já é o simples
        arq = os.path.join(pasta, "metrics.csv")
    df = pd.read_csv(arq)
    df = df.set_index("time").sort_index()
    with open(os.path.join(pasta, "inject_time.txt")) as f:
        inj = float(f.read().strip())
    return df.apply(pd.to_numeric, errors="coerce"), inj


def _escala(ref: np.ndarray) -> np.ndarray:
    q75, q25 = np.nanpercentile(ref, 75, axis=0), np.nanpercentile(ref, 25, axis=0)
    esc = q75 - q25
    dp = np.nanstd(ref, axis=0)
    med = np.abs(np.nanmedian(ref, axis=0))
    esc = np.where(esc > 0, esc, dp)
    return np.where(esc > 0, esc, 1e-9 * med + 1e-12)


def _escala_familia(ref: np.ndarray, cols: list[str]) -> np.ndarray:
    """Iteração 5: IQR → desvio → mediana dos IQR (senão desvios) positivos da mesma família; NaN = coluna fora."""
    q75, q25 = np.nanpercentile(ref, 75, axis=0), np.nanpercentile(ref, 25, axis=0)
    iqr, dp = q75 - q25, np.nanstd(ref, axis=0)
    esc = np.where(iqr > 0, iqr, np.where(dp > 0, dp, np.nan))
    fam = np.array([c.rsplit("_", 1)[1] for c in cols])
    for f in set(fam):
        idx = fam == f
        pos = iqr[idx][iqr[idx] > 0]
        if not len(pos):
            pos = dp[idx][dp[idx] > 0]
        if len(pos):
            esc[idx] = np.where(np.isnan(esc[idx]), float(np.median(pos)), esc[idx])
    return esc


def escores(tempo: np.ndarray, val: np.ndarray, cols: list[str], t: float,
            ref: tuple[float, float], familia: bool = False) -> dict[str, dict[str, float]]:
    """`{serviço: {família: z}}` com z = |mediana(janela) − mediana(ref)| / IQR(ref) (guardas no PROTOCOLO.md)."""
    a, b = np.searchsorted(tempo, t - JANELA, "right"), np.searchsorted(tempo, t, "right")
    r0, r1 = np.searchsorted(tempo, ref[0], "left"), np.searchsorted(tempo, ref[1], "left")
    jan, rf = val[a:b], val[r0:r1]
    if len(jan) == 0 or len(rf) == 0:
        return {}
    esc = _escala_familia(rf, cols) if familia else _escala(rf)
    z = np.abs(np.nanmedian(jan, axis=0) - np.nanmedian(rf, axis=0)) / esc
    out: dict[str, dict[str, float]] = defaultdict(dict)
    for col, v in zip(cols, z, strict=True):
        if np.isfinite(v):
            s, fam = col.rsplit("_", 1)
            out[s][fam] = max(out[s].get(fam, 0.0), float(v))
    return dict(out)


def ordenar(por: dict[str, float]) -> list[str]:
    return [s for s, _ in sorted(por.items(), key=lambda kv: (-kv[1], kv[0]))][:3]


def ranking_rz(es: dict[str, dict[str, float]]) -> list[str]:
    """Iteração 1: serviço = maior z entre todas as famílias."""
    return ordenar({s: max(f.values()) for s, f in es.items() if f})


def normalizadores(linhas: list[dict[str, Any]], es: dict[tuple[str, str], dict[str, dict[str, float]]],
                   q: float = 95.0) -> dict[str, dict[str, float]]:
    """Iteração 2: `{suíte: {família: percentil q do z}}` nas janelas normais da baseline (`na_baseline`)."""
    por: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for x in linhas:
        if x["periodo"] == "normal" and x["na_baseline"]:
            for fams in es.get((x["caso"], x["t"]), {}).values():
                for f, v in fams.items():
                    por[x["grupo"]][f].append(v)
    return {g: {f: float(np.percentile(v, q)) for f, v in fs.items()} for g, fs in por.items()}


def ranking_rzb(es: dict[str, dict[str, float]], n: dict[str, float]) -> list[str]:
    """Iteração 2: serviço = maior z normalizado pela baseline da suíte."""
    return ordenar({s: max((v / n[f] for f, v in fams.items() if n.get(f, 0) > 0), default=0.0)
                    for s, fams in es.items()})


def _u(es: dict[str, dict[str, float]], n: dict[str, float]) -> dict[str, float]:
    """Iteração 3: `s(v) = max_f log(1+z_f) / log(1+N_f)`."""
    return {s: max((float(np.log1p(v) / np.log1p(n[f])) for f, v in fams.items() if n.get(f, 0) > 0), default=0.0)
            for s, fams in es.items()}


def ranking_rzl(es: dict[str, dict[str, float]], n: dict[str, float]) -> list[str]:
    return ordenar(_u(es, n))


def ranking_rzg(es: dict[str, dict[str, float]], n: dict[str, float], ctx: dict[str, Any]) -> list[str]:
    """Iteração 3: o resíduo da d9 (`residuo_1`) sobre os escores log-normalizados das métricas."""
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    u = _u(es, n)
    efeitos = [{"servico": s, "atividade": s, "ratio_mediana": 1.0 + v, "delta_erro": 0.0} for s, v in u.items() if v > 0]
    return [lin["servico"] for lin in d9.ranquear(efeitos, ctx, "residuo_1")][:3] if efeitos else []


def tau_gate(linhas: list[dict[str, Any]], es: dict[tuple[str, str], dict[str, dict[str, float]]],
             norm: dict[str, dict[str, float]], fp: float = 0.05) -> dict[str, float]:
    """Iteração 5: limiar do portão `g-m` por suíte, nas janelas da baseline (como o λ da d9-b)."""
    import math  # noqa: PLC0415
    por: dict[str, list[float]] = defaultdict(list)
    for x in linhas:
        if x["periodo"] == "normal" and x["na_baseline"]:
            por[x["grupo"]].append(max(_u(es[(x["caso"], x["t"])], norm[x["grupo"]]).values(), default=0.0))
    out = {}
    for g, v in por.items():
        v = sorted(v, reverse=True)
        k = int(math.floor(fp * len(v) + 1e-12))
        out[g] = math.nextafter(v[k], math.inf) if k < len(v) else 0.0
    return out


def fusao_borda(m: list[str], t: list[str]) -> list[str]:
    """Iteração 4: Borda 3-2-1, pesos iguais; empate pela ordem das métricas."""
    pts: dict[str, int] = defaultdict(int)
    for lst in (m, t):
        for i, s in enumerate(lst[:3]):
            pts[s] += 3 - i
    pos = {s: i for i, s in enumerate(m)}
    return sorted(pts, key=lambda s: (-pts[s], pos.get(s, 99), s))[:3]


def fusao_conc(m: list[str], t: list[str]) -> list[str]:
    """Iteração 4: o 1º dos traces sobe ao topo se estiver no top-2 das métricas."""
    if t and t[0] in m[:2]:
        return [t[0]] + [s for s in m if s != t[0]][:2]
    return m[:3]


def escores_metricas(linhas: list[dict[str, Any]],
                     familia: bool = False) -> dict[tuple[str, str], dict[str, dict[str, float]]]:
    """Escores por instante, com cache em disco (`DADOS_SAIDA/metricas-rz/escores[-familia].pkl`)."""
    import pickle  # noqa: PLC0415
    cache = os.path.join(DADOS_SAIDA, "metricas-rz", "escores-familia.pkl" if familia else "escores.pkl")
    if os.path.exists(cache):
        with open(cache, "rb") as f:
            return pickle.load(f)
    out: dict[tuple[str, str], dict[str, dict[str, float]]] = {}
    por_caso: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for x in linhas:
        por_caso[x["caso"]].append(x)
    for caso, xs in por_caso.items():
        df, inj = _serie(caso)
        tempo, val, cols = df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns)
        for x in xs:
            t = datetime.datetime.fromisoformat(x["t"]).replace(tzinfo=datetime.UTC).timestamp()
            ref = (inj - REF, inj) if x["periodo"] == "falha" else (t - JANELA - REF, t - JANELA)
            out[(caso, x["t"])] = escores(tempo, val, cols, t, ref, familia)
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    with open(cache + ".tmp", "wb") as f:
        pickle.dump(out, f)
    os.replace(cache + ".tmp", cache)
    return out


PORTOES = ("d9", "d9+a", "d9-b+c", "d9-b+c@0.01", "g-m", "g-m∨t", "g-m∧t")
RANKINGS = {"m": "m-rz", "mb": "m-rzb", "ml": "m-rzl", "mg": "m-rzg", "fb": "f-borda", "fc": "f-conc", "mf": "m-rzf"}
MODOS = (*PORTOES, *RANKINGS.values(), *(f"{p}|{k}" for k in RANKINGS for p in PORTOES[1:]))


def portoes(linhas: list[dict[str, Any]]) -> dict[tuple[str, str], dict[str, dict[str, Any]]]:
    """Decisões dos portões de traces por instante (cache em disco; `BD.decisoes` é o lento)."""
    import pickle  # noqa: PLC0415
    cache = os.path.join(DADOS_SAIDA, "metricas-rz", "portoes.pkl")
    if os.path.exists(cache):
        with open(cache, "rb") as f:
            return pickle.load(f)
    cals = {fp: BD.calibracoes(linhas, fp) for fp in (0.05, 0.01)}
    ex = BD.exatos()
    out = {}
    for x in linhas:
        d5 = BD.decisoes(x, cals[0.05][x["grupo"]], ex.get(x["caso"]), Counter())
        d1 = BD.decisoes(x, cals[0.01][x["grupo"]], ex.get(x["caso"]), Counter())
        out[(x["caso"], x["t"])] = {"d9": d5["d9"], "d9+a": d5["d9+a"], "d9-b+c": d5["d9-b+c"],
                                    "d9-b+c@0.01": d1["d9-b+c"]}
    with open(cache + ".tmp", "wb") as f:
        pickle.dump(out, f)
    os.replace(cache + ".tmp", cache)
    return out


def decisoes(g: dict[str, dict[str, Any]], rks: dict[str, list[str]]) -> dict[str, dict[str, Any]]:
    out = dict(g)
    for k, nome in RANKINGS.items():
        rm = rks[k]
        out[nome] = {"dec": bool(rm), "rk": rm, "f": rm}
        for porta in PORTOES[1:]:
            out[f"{porta}|{k}"] = {"dec": g[porta]["dec"], "rk": rm if g[porta]["dec"] else [], "f": rm}
    return out


def por_caso(linhas: list[dict[str, Any]], gs: dict[tuple[str, str], dict[str, dict[str, Any]]],
             rks: dict[tuple[str, str], dict[str, list[str]]]) -> dict[str, dict[str, Counter]]:
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in MODOS}
    for x in linhas:
        if x["periodo"] == "normal" and x.get("na_baseline"):
            continue
        esp = x["gabarito"]
        for m, d in decisoes(gs[(x["caso"], x["t"])], rks[(x["caso"], x["t"])]).items():
            c = pc[m][x["caso"]]
            if x["periodo"] == "normal":
                c["nn"] += 1
                c["al"] += d["dec"]
            elif esp:
                c["ne"] += 1
                c["dec"] += d["dec"]
                for k in (1, 2):
                    c[f"tp{k}"] += d["dec"] and esp in d["rk"][:k]
                    c[f"o{k}"] += esp in d["f"][:k]
    return pc


def main() -> int:
    warnings.simplefilter("ignore", RuntimeWarning)   # colunas toda NaN numa janela: escore NaN, ignorado
    D = _d9a()  # noqa: N806
    D.METODOS = MODOS
    linhas = BD.carregar()
    parte = dividir(linhas)
    es = escores_metricas(linhas)
    norm = normalizadores(linhas, es)
    ctxs = {(x["caso"], x["t"]): BD.P._ctx(x["ctx"]) for x in linhas}
    rks = {}
    for k, v in es.items():
        n = norm.get(k[0].split("/")[0], {})
        rks[k] = {"m": ranking_rz(v), "mb": ranking_rzb(v, n), "ml": ranking_rzl(v, n), "mg": ranking_rzg(v, n, ctxs[k])}
    gs = portoes(linhas)
    esf = escores_metricas(linhas, familia=True)
    normf = normalizadores(linhas, esf)
    tau = tau_gate(linhas, esf, normf)
    for k, g in gs.items():
        suite = k[0].split("/")[0]
        rk = ranking_rzl(esf.get(k, {}), normf.get(suite, {}))
        rks[k]["mf"] = rk
        gm = max(_u(esf.get(k, {}), normf.get(suite, {})).values(), default=0.0) >= tau[suite]
        gt = g["d9-b+c@0.01"]["dec"]
        gs[k] = {**g, "g-m": {"dec": gm and bool(rk), "rk": rk if gm else [], "f": rk},
                 "g-m∨t": {"dec": gm or gt, "rk": rk if (gm or gt) else [], "f": rk},
                 "g-m∧t": {"dec": gm and gt, "rk": rk if (gm and gt) else [], "f": rk}}
    for k, r in rks.items():
        t9 = gs[k]["d9"]["f"]
        r["fb"], r["fc"] = fusao_borda(r["mb"], t9), fusao_conc(r["mb"], t9)
    pc = por_caso(linhas, gs, rks)
    out = ["# Iterações 1–3 — `m-rz` / `m-rzb` / `m-rzl` / `m-rzg` / fusões / `m-rzf` + portão `g-m` (ranking por métricas) no RCAEval", "",
           "`PROTOCOLO.md`. Exploratório. Meta: F1@1 ≥ 0,6 e F1@2 ≥ 0,7, no dev **e** no holdout.", ""]
    for nome in ("dev", "holdout"):
        casos = sorted(c for c, p in parte.items() if p == nome)
        out += [f"## {nome} ({len(casos)} casos)", "", *D.tabela(pc, casos), ""]
        for a, b in (("d9-b+c@0.01|mf", "d9-b+c@0.01|mb"), ("g-m|mf", "d9-b+c@0.01|mb"),
                     ("g-m∨t|mf", "d9-b+c@0.01|mb"), ("g-m∧t|mf", "d9-b+c@0.01|mb")):
            d, lo, hi = D.diferenca(pc, casos, a, b)
            out.append(f"- ΔF1@1 {a} − {b} = {d:+.3f} [IC 95% {lo:+.3f} a {hi:+.3f}]")
        out.append("")
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-it5.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
