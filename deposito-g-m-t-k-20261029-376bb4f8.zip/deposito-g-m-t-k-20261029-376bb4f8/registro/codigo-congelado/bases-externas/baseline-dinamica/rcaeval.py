#!/usr/bin/env python3
"""Pré-teste d9-b / d2c-b / d9-b+c no RCAEval (`PROTOCOLO.md`), sobre os registros do `../d9a/`.

1. `--refazer`: ranking **exato** da d2c-b (`d2cr.decidir(q)`) nos instantes em que ela decide, um arquivo por caso
   (ordem sorteada, semente fixa). Rodar com `timeout 600`: o que não couber usa o ranking de q = 1 (declarado).
2. análise → `resultado-rcaeval.md`.
Uso: python rcaeval.py [--refazer] [--jobs 24]
"""
from __future__ import annotations

import argparse
import glob
import gzip
import json
import os
import random
import sys
import time
from collections import Counter, defaultdict
from typing import Any

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
sys.path[:0] = [RAIZ, os.path.join(RAIZ, "pre-teste"), AQUI]

import analisar as P  # noqa: E402  (pre-teste: _ctx, _rank9, _passa)
import calib  # noqa: E402

from comum import DADOS_SAIDA, execucao, instantes as I, metodos as M, rapido  # noqa: E402

ENTRADA = os.path.join(DADOS_SAIDA, "d9a", "rcaeval")
SAIDA = os.path.join(DADOS_SAIDA, "baseline-dinamica", "rcaeval")
METODOS = ("d9", "d9-b", "d2c-r", "d2c-a", "d2c-b", "d9+a", "d9-b+c")
SEMENTE, N_BOOT = 20261018, 2000


def _pm(x: dict[str, Any]) -> float:
    d = x["d2cr"]
    return float(d["p_min"]) if d.get("p_min") is not None and d["status"] != "falhou" else 1.0


def carregar() -> list[dict[str, Any]]:
    out = []
    for arq in sorted(glob.glob(os.path.join(ENTRADA, "*.jsonl.gz"))):
        with gzip.open(arq, "rt") as f:
            out += [json.loads(x) for x in f if x.strip()]
    return [x for x in out if x["periodo"] != "sombra"]


def calibracoes(linhas: list[dict[str, Any]], fp: float) -> dict[str, dict[str, Any]]:
    out = {}
    for g in sorted({x["grupo"] for x in linhas}):
        base = [{"efeitos": x["efeitos"], "p_min": _pm(x)} for x in linhas
                if x["grupo"] == g and x["periodo"] == "normal" and x["na_baseline"]]
        out[g] = calib.calibrar(base, fp)
    return out


def _job(job: tuple[str, float, list[str]]) -> str:
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    caso_id, q, ts = job
    destino = os.path.join(SAIDA, f"{caso_id.replace('/', '__')}.json")
    if os.path.exists(destino):
        return f"{caso_id}: já feito"
    t0 = time.monotonic()
    caso = execucao._modulo(os.path.join(RAIZ, "rcaeval/adaptar.py")).carregar(caso_id)
    sis = M.cfg_sistema(caso.sistema)
    rapido.ativar()
    quer, out = set(ts), {}
    for _periodo, t, ent, _n in I.entradas(caso, I.REF):
        if t.isoformat() in quer:
            rapido.limpar()
            d = d2cr.decidir(ent, {}, {**sis, "q": q})
            out[t.isoformat()] = [i.servico for i in d.ranking][:3] if d.status == "decidiu" else []
    os.makedirs(SAIDA, exist_ok=True)
    with open(destino + ".tmp", "w") as f:
        json.dump({"q": q, "rankings": out}, f)
    os.replace(destino + ".tmp", destino)
    return f"{caso_id}: {len(out)} instantes, {time.monotonic() - t0:.0f}s"


def refazer(linhas: list[dict[str, Any]], jobs: int) -> None:
    cal = calibracoes(linhas, calib.FP_ALVO)
    por: dict[str, list[str]] = defaultdict(list)
    for x in linhas:
        if not (x["periodo"] == "normal" and x["na_baseline"]) and _pm(x) <= cal[x["grupo"]]["q_d2cb"]:
            por[x["caso"]].append(x["t"])
    casos = sorted(por)
    random.Random(f"{SEMENTE}-d2cb").shuffle(casos)
    grupo = {x["caso"]: x["grupo"] for x in linhas}
    print(f"{len(casos)} casos, {sum(map(len, por.values()))} instantes", flush=True)
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        for msg in ex.map(_job, [(c, cal[grupo[c]]["q_d2cb"], por[c]) for c in casos]):
            print(msg, flush=True)


def exatos() -> dict[str, dict[str, Any]]:
    out = {}
    for arq in glob.glob(os.path.join(SAIDA, "*.json")):
        with open(arq) as f:
            out[os.path.basename(arq)[:-5].replace("__", "/")] = json.load(f)
    return out


def decisoes(x: dict[str, Any], cal: dict[str, Any], ex: dict[str, Any] | None,
             cont: Counter) -> dict[str, dict[str, Any]]:
    ctx, efs = P._ctx(x["ctx"]), x["efeitos"]
    r9 = P._rank9([e for e in efs if P._passa(e, 1.5, 0.10)], ctx)
    f9 = P._rank9([e for e in efs if P._passa(e, 1.0, 0.0)], ctx)
    rb = P._rank9(calib.passou_d9b(efs, cal), ctx)
    d2 = x["d2cr"]
    rk2 = d2["ranking"] if d2["status"] != "falhou" else []
    pm = _pm(x)
    a = x["d2ca"]
    ra = a["ranking"] if a["status"] == "decidiu" else []
    rc: list[str] = []
    if pm <= cal["q_d2cb"]:
        if ex is not None and ex["q"] == cal["q_d2cb"] and x["t"] in ex["rankings"]:
            rc = ex["rankings"][x["t"]]
            cont["exato"] += 1
        else:
            rc = rk2
            cont["aprox"] += 1
    out = {"d9": {"dec": bool(r9), "rk": r9, "f": f9},
           "d9-b": {"dec": bool(rb), "rk": rb, "f": f9},
           "d2c-r": {"dec": bool(rk2) and pm <= 1e-50, "rk": rk2 if pm <= 1e-50 else [], "f": rk2},
           "d2c-a": {"dec": bool(ra), "rk": ra, "f": rk2},
           "d2c-b": {"dec": bool(rc), "rk": rc, "f": rk2}}
    out["d9+a"] = dict(out["d9"]) if r9 else {"dec": bool(ra), "rk": ra, "f": f9}
    out["d9-b+c"] = dict(out["d9-b"]) if rb else {"dec": bool(rc), "rk": rc, "f": f9}
    return out


def por_caso(linhas: list[dict[str, Any]], cals: dict[str, dict[str, Any]], ex: dict[str, Any],
             cont: Counter) -> dict[str, dict[str, Counter]]:
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in METODOS}
    for x in linhas:
        if x["periodo"] == "normal" and x.get("na_baseline"):
            continue
        esp = x["gabarito"]
        for m, d in decisoes(x, cals[x["grupo"]], ex.get(x["caso"]), cont).items():
            c = pc[m][x["caso"]]
            if x["periodo"] == "normal":
                c["nn"] += 1
                c["al"] += d["dec"]
            elif esp:
                c["ne"] += 1
                c["dec"] += d["dec"]
                for k in (1, 2):
                    c[f"tp{k}"] += d["dec"] and esp in d["rk"][:k]
                    c[f"o{k}"] += esp in d["f"][:k]
    return pc


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--refazer", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    linhas = carregar()
    if args.refazer:
        refazer(linhas, args.jobs)
        return 0
    import importlib.util  # noqa: PLC0415
    spec = importlib.util.spec_from_file_location("d9a_analisar", os.path.join(RAIZ, "d9a", "analisar.py"))
    D = importlib.util.module_from_spec(spec)  # noqa: N806
    spec.loader.exec_module(D)
    D.METODOS = METODOS
    ex = exatos()
    out = ["# Pré-teste d9-b / d2c-b / d9-b+c — RCAEval (limiares pela baseline de cada suíte)", "",
           "`PROTOCOLO.md`. Descritivo (casos já vistos por outros métodos). Todos os instantes; normais da baseline "
           "fora do alarme.", ""]
    for fp in (calib.FP_ALVO, 0.01):
        cals = calibracoes(linhas, fp)
        cont: Counter = Counter()
        pc = por_caso(linhas, cals, ex, cont)
        casos = sorted({x["caso"] for x in linhas})
        papel = "principal" if fp == calib.FP_ALVO else "sensibilidade (exploratória)"
        out += [f"## FP_ALVO = {fp} ({papel})", "",
                "| suíte | janelas | λ | q d2c-b |", "|---|---|---|---|"]
        out += [f"| {g} | {c['n_janelas']} | {c['lambda']:.3f} | {c['q_d2cb']:.2e} |" for g, c in cals.items()]
        out += ["", *D.tabela(pc, casos), ""]
        for a, b in (("d9-b", "d9"), ("d2c-b", "d2c-r"), ("d2c-b", "d2c-a"), ("d9-b+c", "d9"), ("d9-b+c", "d9+a")):
            d, lo, hi = D.diferenca(pc, casos, a, b)
            sa, sb, p = D.mcnemar(pc[a], pc[b])
            out.append(f"- ΔF1@1 {a} − {b} = {d:+.3f} [IC 95% {lo:+.3f} a {hi:+.3f}]; McNemar: só {a} {sa}, "
                       f"só {b} {sb}, p = {p:.3f}")
        tot = cont["exato"] + cont["aprox"]
        out += ["", f"Ranking da d2c-b: {cont['exato']} de {tot} "
                f"decisões exatas ({cont['exato'] / tot:.0%}); o resto com o ranking de q = 1." if tot else "", ""]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-rcaeval.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
