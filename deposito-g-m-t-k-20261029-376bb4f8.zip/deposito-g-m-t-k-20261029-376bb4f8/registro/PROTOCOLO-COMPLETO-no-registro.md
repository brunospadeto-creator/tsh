# Protocolo completo do `g-m∨t|mf` — TeaStore, RCAEval e OpenRCA Market (pré-registro, 18/10/2026)

Pedido do usuário: registrar e executar o protocolo completo, **todas as partes**. O Eadro SN fica fora
(`../RESULTADO.md` §13). Este documento é commitado **antes** de qualquer execução das partes confirmatórias A e B.
O que foi visto até aqui está no `PROTOCOLO.md`: as iterações 1–5 e a generalização. Nenhum número de A ou de B foi
visto.

## 1. Hipótese e método congelado

**Hipótese:** o `g-m∨t|mf` mantém, em dados que nunca viu, a meta do ciclo: **F1@1 ≥ 0,6 e F1@2 ≥ 0,7** com portão,
com **alarme ≤ 20%**.

**Método:** congelado no commit deste pré-registro. Os arquivos ficam como estão:

| arquivo | sha256 (12) | papel |
|---|---|---|
| `bases-externas/metricas-rz/ciclo.py` | `40d86a363ed2` | `escores(familia=True)`, `normalizadores`, `tau_gate`, `ranking_rzl`, `_u` |
| `bases-externas/metricas-rz/outras.py` | `35de2d920c9a` | adaptadores Eadro e Market e portão de traces nas bases abertas |
| `bases-externas/baseline-dinamica/calib.py` | `8703dc7a6b43` | λ e q pela baseline (`d9-b+c@0.01`) |
| `bases-externas/baseline-dinamica/rcaeval.py` | `0d05ed8ff492` | decisões do portão de traces no RCAEval |
| `experimento-falhas/teastore/stage3-online/replay/metricas_rz_teastore.py` | `4a1293f3a0ea` | adaptador TeaStore (métricas por serviço) |
| `experimento-falhas/teastore/stage3-online/replay/baseline_dinamica.py` | `d9edbf430618` | portão de traces no TeaStore (`d9-b+c@0.01`, `d9-k-b+c@0.01`) |

**Portões:**
- `g-m`: `max_v s(v) ≥ τ`, com τ da baseline e FP_ALVO 0,05;
- `t`: `d9-b+c@0.01`;
- decisão: `g-m` OU `t`.

**Ranking:** `m-rzf`.

**O que pode mudar depois deste commit:**
- **código novo, só de entrada:** o adaptador do RCAEval só com métricas (§3) e a troca de conjunto nos scripts de
  medida do TeaStore (§6). Eles leem dados e escolhem instantes e casos, sem nenhuma regra de decisão ou de ranking;
- **correções:** só de leitura de dado (formato, relógio, nome de serviço), achadas na rodada de teste (§5), e por
  emenda commitada antes da rodada oficial.

## 2. Material

| parte | base / conjunto | casos | já visto pelo método? | papel |
|---|---|---|---|---|
| **A** | RCAEval **RE1-OB, RE1-SS, RE1-TT** (`data.csv`, só métricas, 5 tipos × 25) | 375 | não | **confirmatório** |
| **A** | RCAEval **RE2-SS** (`simple_metrics.csv`, só métricas, 6 tipos × 15) | 90 | não | **confirmatório** |
| **A** | RCAEval **RE3-SS** (`simple_metrics.csv`; traces em 13, não usados) | 30 | não | **confirmatório** |
| **B** | TeaStore **lote novo**, 4 lotes × 6 cenários (h1–h6 × 2, g1–g6 × 2), sementes 20261041–44 | 24 | não | **confirmatório** |
| C | RCAEval RE2/RE3 OB e TT (com traces) | 240 | sim (ciclo) | descritivo |
| C | OpenRCA Market (2 cloudbeds, 2 dias) | 77 | sim | descritivo |
| C | TeaStore definitiva | 24 | sim | descritivo |

O Market não tem dias inéditos, e os casos do RCAEval com traces já foram usados no ciclo. Por isso as duas bases
só entram como descritivas.

Na parte A não há traces: o RE1 e o Sock Shop não têm. O canal `t` fica ausente e nunca abre, e o `g-m∨t|mf` se
reduz ao `g-m|mf`. A parte A testa a **metade de métricas** do método; a parte B testa o método inteiro.

## 3. Parte A — RCAEval inédito (regras fixas)

| item | regra |
|---|---|
| leitura | `data.csv` (RE1) ou `simple_metrics.csv` (RE2-SS, RE3-SS); colunas `<serviço>_<família>` (o `rsplit("_", 1)` do `ciclo.escores`); `time` em s; `inject_time.txt` |
| gabarito | o serviço do nome da pasta (`<serviço>_<tipo>`); o tipo é o sufixo |
| instantes de falha | de `injeção + 120 s` até `min(fim, injeção + 600 s)`, passo de 60 s |
| instantes normais | de `início + 270 s` até a injeção, passo de 60 s |
| referência | falha: `[injeção − 600, injeção)`; normal: `[t − 720, t − 120)`; as duas cortadas no início do caso (no RE1 o pré-falha tem ≥ 360 s) |
| baseline | por suíte, casos sorteados com a semente `20261019-<suíte>`, na ordem do sorteio, até somar **≥ 20 janelas normais**, com no mínimo 5 casos. Os instantes normais desses casos ficam fora do alarme, mas os de falha entram |
| τ e N | `ciclo.normalizadores` (percentil 95) e `ciclo.tau_gate` (FP 0,05) sobre as janelas da baseline de cada suíte |
| comparadores | `m-rz` (iteração 1: z bruto, guarda numérica antiga) e `cpu-max` (só a família `cpu`, maior z), os dois com o mesmo portão `g-m` |
| resultado primário | **um só**, juntando as 5 suítes (495 casos menos os 15 da rodada de teste) |
| secundários | por suíte, por sistema (OB, SS, TT) e por tipo de falha: descritivos |

## 4. Parte B — TeaStore, lote novo (regras fixas)

- **Coleta:** `experimento-falhas/teastore/run-metricas-rz-lotes.sh`, cópia do driver da coleta inédita com:
  - sementes 20261041–44 (nunca usadas);
  - baseline fixa 32c273a6, a mesma da definitiva;
  - durações do congelamento;
  - lote abortado recomeça inteiro com a mesma semente, até 3 tentativas.
- O harness, a imagem, o `congelamento.json` e o `stage3_config` não mudam.
- **O cluster é ligado pelo usuário.** O driver só começa depois disso.
- **Medida offline,** idêntica à da definitiva, com o conjunto trocado para os 4 runs novos:
  - portão de traces: `baseline_dinamica.py`, com λ e q da 32c273a6;
  - métricas: `metricas_rz_teastore.py`, com a baseline das métricas no trecho da sessão antes do normal medido,
    como na definitiva;
  - comparadores pelos mesmos scripts: d9-k, d9-k+a, v-cons-b e d9-k-b+c@0.01;
  - instantes, D0.4 e gabarito: os da definitiva.
- Cenário que não passa no verificador da falha não é coletado e fica registrado. Lote que não fecha em 3
  tentativas: o resultado sai com os lotes completos, e a ausência é declarada.

## 5. Rodada de teste (antes das oficiais)

- **A:** 15 casos sorteados (semente `20261019-teste`, 3 por suíte), com saída separada. Confere:
  - instantes por caso;
  - escores finitos;
  - serviço do gabarito presente nas colunas;
  - janelas de baseline ≥ 20 por suíte.

  **O F1 não é lido.** Os 15 casos saem da leitura oficial.
- **B:** o pré-voo do `coleta-lote-stage3.sh`, que confere o congelamento, e a checagem dos pacotes contínuos do
  1º cenário. Os resultados não são lidos.

## 6. Leitura fixada antes de rodar

| parte | confirma se | não confirma se |
|---|---|---|
| **A** (480 casos) | F1@1 ≥ 0,6 **e** F1@2 ≥ 0,7 **e** alarme ≤ 20%, nos valores pontuais | qualquer um dos três falha |
| **B** (24 cenários) | idem | idem |
| C | — (só reportado) | — |

- Comparação com os anteriores, só descritiva:
  - McNemar no top-1 com portão: `g-m∨t|mf` contra d9-k e d9-k+a (B), e contra `m-rz` e `cpu-max` (A);
  - ΔF1@1 com IC por bootstrap.
- O intervalo de confiança é reportado, mas não entra no critério.
- Uma hipótese primária por parte, sem correção por múltiplas comparações.
- Nada é recalibrado com A ou B. O resultado sai como estiver, inclusive se não confirmar.

## 7. Etapas

| # | etapa | onde roda | tempo |
|---|---|---|---|
| 1 | commit e push deste pré-registro e do driver | — | 5 min |
| 2 | adaptador A (`confirmatorio_a.py`) | offline | ~40 min |
| 3 | rodada de teste A (15 casos, sem F1) | offline | ≤ 10 min |
| 4 | **rodada oficial A** → `resultado-confirmatorio-A.md` | offline | ≤ 10 min |
| 5 | descritivos C com o código congelado → `resultado-descritivo-C.md` | offline | ~5 min |
| 6 | **coleta B** (usuário liga o cluster; driver em segundo plano) | cluster | ~29 h (4 × ~7,3 h) |
| 7 | **rodada oficial B** → `resultados/protocolo-metricas-rz/resultado-confirmatorio-B.md` | offline | ~20 min |
| 8 | `RESULTADO.md`, `session.md`, commit | — | 15 min |
