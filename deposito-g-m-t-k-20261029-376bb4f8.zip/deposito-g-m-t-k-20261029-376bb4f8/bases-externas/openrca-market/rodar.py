#!/usr/bin/env python3
"""OpenRCA Market: d9-k, v-cons-b, d2c-r e d9 nos casos de falha (pod/serviço) e nos trechos normais. Retomável.

Registros em `/mnt/gpu-disk/datasets/bases-externas/openrca-market/registros/`. Precisa do `adaptar.py --extrair`.
Uso: python rodar.py [--jobs 24] [--limite N]
"""
from __future__ import annotations

import argparse
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import execucao  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=24)
    ap.add_argument("--limite", type=int, help="só os N primeiros casos (fumaça)")
    args = ap.parse_args()
    ids = adaptar.listar()
    execucao.rodar(os.path.join(AQUI, "adaptar.py"), ids[: args.limite] if args.limite else ids, adaptar.SAIDA,
                   args.jobs)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
