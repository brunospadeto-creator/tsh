#!/usr/bin/env python3
"""Artefatos do v-cons-b no OpenRCA Market (`../PLANO.md` §4.2): por cloudbed, o trecho `baseline` do 1º dia
(`BASELINE_SEG` s a ≥ 30 min de qualquer falha, definido em `adaptar.plano_de_casos`). Precisa do `--extrair`.

Uso: python baseline.py
"""
from __future__ import annotations

import json
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import execucao, metodos  # noqa: E402


def main() -> int:
    for caso_id, v in sorted(adaptar.casos().items()):
        if not v.get("baseline"):
            continue
        eventos = adaptar.ler_eventos(caso_id)
        art = metodos.preparar_vconsb(eventos, adaptar.SISTEMA)
        art["_preparo"].update({"trecho": caso_id, "ini_s": v["ini_s"], "fim_s": v["fim_s"]})
        destino = execucao.caminho_artefato(adaptar.SAIDA, v["cb"])
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with open(destino, "w") as f:
            json.dump(art, f, default=str)
        cal = (art.get("d6") or {}).get("calibracao") or {}
        print(f"{v['cb']}: {len(eventos)} eventos; q(d6)={cal.get('q')} janelas={cal.get('n_janelas')} "
              f"a0-b={art['a0-b'].get('janelas')} ({art['_preparo']['segundos']}s)", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
