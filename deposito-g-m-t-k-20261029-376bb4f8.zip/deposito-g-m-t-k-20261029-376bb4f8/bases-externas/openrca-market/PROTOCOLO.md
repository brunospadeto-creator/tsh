# Protocolo — OpenRCA Market (cloudbed-1/2): d9-k, v-cons-b e d2c-r × d9

Escrito em 17/10/2026, **antes** de rodar qualquer método nesta base (só contagens e tráfego dos dados foram
vistos). Commitado antes da execução. Base do plano: `../PLANO.md` §0–§3, §4.2 e §7.

## 1. Casos

- Registros do `record.csv` que caem nos 2 dias de telemetria (`2022_03_20`, `2022_03_21`) de cada cloudbed: 118 de
  148. Desses, **41 em nó ficam fora** (sem serviço como gabarito). Entram **77 falhas** em pod/serviço.
- Gabarito = componente sem o sufixo de réplica (`shippingservice-1`, `recommendationservice2-0` → serviço).
- **Normais:** 16 trechos de 15 min planejados a ≥ 30 min de qualquer falha (até 4 por dia); 5 caem depois do fim
  da telemetria do 2º dia e ficam fora → **11 trechos normais**.
- Tráfego útil medido antes (amostra de 17 casos): 250–930 traces completos por janela de 120 s (≫ D0.4).

## 2. Períodos, instantes e configuração

- falha = `[t, t + 600 s)`, cortada na falha seguinte (a duração não é documentada pelo OpenRCA — declarado);
  pré-falha = os 600 s antes de `t` (pode incluir o fim de uma falha anterior — declarado);
- instantes, janela, referência e D0.4 como no `comum/instantes.py` (60 s, 120 s, 150 s, ≥ 30 traces);
- entrada `frontend`, operação `hipstershop.Frontend/Recv.`; erro = `status_code` fora de {0, Ok/OK, 2xx, 3xx};
- `timestamp` em ms, `duration` em µs; sem eventos K8s; `dependencias_sem_span` vazio.

## 3. Baseline do v-cons-b

Por cloudbed, o trecho `baseline` de 30 min do 1º dia (a ≥ 30 min de qualquer falha; não é caso normal).

## 4. Métodos e medidas

Os mesmos do RCAEval (`comum/metodos.py`, `comum/metricas.py`), por cloudbed e no total.

## 5. Leitura fixada antes

A mesma do RCAEval: d9-k e d2c-r generalizam se F1@1 ≥ d9 e alarme ≤ 2%; v-cons-b se top-3 sabendo ≥ 80% e
top-1 sabendo ≥ d9. Declarar as críticas publicadas aos rótulos do OpenRCA (arXiv 2607.13548). Nada recalibrado.
