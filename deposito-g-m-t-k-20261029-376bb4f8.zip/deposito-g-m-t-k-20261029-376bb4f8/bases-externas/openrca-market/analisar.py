#!/usr/bin/env python3
"""OpenRCA Market: `resultado.md` a partir dos registros (`../PLANO.md` §3).

Uso: python analisar.py
"""
from __future__ import annotations

import glob
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import metodos, metricas, nome_resultado  # noqa: E402


def main() -> int:
    plano = adaptar.casos()
    notas = [
        "OpenRCA Market (cloudbed-1 e cloudbed-2), parâmetros congelados do TeaStore, sem eventos K8s.",
        f"Falhas em pod/serviço com gabarito de serviço; {sum('fora' in v for v in plano.values())} falhas em nó "
        "fora. Duração da falha não documentada: teto de 600 s, cortado na falha seguinte.",
        "Normal = trechos de 15 min a ≥ 30 min de qualquer falha; baseline do v-cons-b = trecho separado do 1º dia.",
        "Rótulos do OpenRCA têm críticas publicadas (arXiv 2607.13548); AC@4 = AC@5 = AC@3 (top-3).",
    ]
    arqs = sorted(glob.glob(os.path.join(adaptar.SAIDA, "registros", "*.jsonl.gz")))
    texto = metricas.relatorio(f"OpenRCA Market — d9-k, v-cons-b, d2c-r × d9 ({len(arqs)} casos)",
                               metricas.ler(arqs), metodos.METODOS, notas)
    with open(os.path.join(AQUI, nome_resultado()), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
