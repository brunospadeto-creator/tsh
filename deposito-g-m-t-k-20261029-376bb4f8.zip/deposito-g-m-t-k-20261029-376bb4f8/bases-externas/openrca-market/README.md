# OpenRCA Market (cloudbed-1 e cloudbed-2; 148 falhas)

Código de análise independente desta base (ver `../PLANO.md` §4). Arquivos previstos: `PROTOCOLO.md` (commitado
antes de rodar), `adaptar.py`, `baseline.py`, `rodar.py`, `analisar.py` e `resultado.md`. Dados de origem em
`/mnt/gpu-disk/veritas/novo-artigo/datasets/` (só leitura); insumos e registros brutos em
`/mnt/gpu-disk/datasets/bases-externas/openrca-market/` (fora do git). Código escrito (ver `../PLANO.md` §7 para os achados e o passo a passo).
