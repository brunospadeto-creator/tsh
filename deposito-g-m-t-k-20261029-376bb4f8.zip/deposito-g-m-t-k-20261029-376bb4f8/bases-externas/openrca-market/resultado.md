# OpenRCA Market — d9-k, v-cons-b, d2c-r × d9 (88 casos)

OpenRCA Market (cloudbed-1 e cloudbed-2), parâmetros congelados do TeaStore, sem eventos K8s.
Falhas em pod/serviço com gabarito de serviço; 41 falhas em nó fora. Duração da falha não documentada: teto de 600 s, cortado na falha seguinte.
Normal = trechos de 15 min a ≥ 30 min de qualquer falha; baseline do v-cons-b = trecho separado do 1º dia.
Rótulos do OpenRCA têm críticas publicadas (arXiv 2607.13548); AC@4 = AC@5 = AC@3 (top-3).

## Todos

| método | casos | instantes normais | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| d9-k | 77 | 121 | 0.154 [0.084–0.228] | 0.164 | 0.164 | 0% | 81% | 22% [15%–29%] | 31% | 42% | 0.260 | 0.545 | 0.455 |
| v-cons-b | 77 | 121 | 0.152 [0.083–0.225] | 0.179 | 0.226 | 0% | 81% | 27% [20%–35%] | 41% | 53% | 0.338 | 0.623 | 0.530 |
| v-cons-b-1 | 77 | 121 | 0.154 [0.086–0.225] | 0.179 | 0.224 | 0% | 81% | 25% [19%–31%] | 36% | 49% | 0.338 | 0.623 | 0.530 |
| d2c-r | 77 | 121 | 0.015 [0.000–0.039] | 0.020 | 0.020 | 0% | 98% | 17% [11%–24%] | 29% | 38% | 0.156 | 0.338 | 0.294 |
| d9 | 77 | 121 | 0.154 [0.084–0.228] | 0.164 | 0.164 | 0% | 81% | 22% [15%–29%] | 31% | 42% | 0.260 | 0.545 | 0.455 |

## cloudbed-1

| método | casos | instantes normais | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| d9-k | 35 | 66 | 0.126 [0.030–0.241] | 0.137 | 0.137 | 0% | 82% | 17% [9%–27%] | 26% | 39% | 0.257 | 0.543 | 0.446 |
| v-cons-b | 35 | 66 | 0.104 [0.028–0.193] | 0.158 | 0.246 | 0% | 82% | 22% [14%–33%] | 38% | 54% | 0.314 | 0.629 | 0.520 |
| v-cons-b-1 | 35 | 66 | 0.115 [0.031–0.210] | 0.153 | 0.240 | 0% | 82% | 21% [13%–29%] | 33% | 49% | 0.314 | 0.629 | 0.520 |
| d2c-r | 35 | 66 | 0.006 [0.000–0.020] | 0.019 | 0.019 | 0% | 98% | 12% [5%–18%] | 24% | 31% | 0.086 | 0.229 | 0.200 |
| d9 | 35 | 66 | 0.126 [0.030–0.241] | 0.137 | 0.137 | 0% | 82% | 17% [9%–27%] | 26% | 39% | 0.257 | 0.543 | 0.446 |

## cloudbed-2

| método | casos | instantes normais | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| d9-k | 42 | 55 | 0.178 [0.081–0.283] | 0.187 | 0.187 | 0% | 81% | 25% [15%–36%] | 36% | 46% | 0.262 | 0.548 | 0.462 |
| v-cons-b | 42 | 55 | 0.192 [0.091–0.303] | 0.196 | 0.210 | 0% | 81% | 31% [20%–43%] | 43% | 51% | 0.357 | 0.619 | 0.538 |
| v-cons-b-1 | 42 | 55 | 0.187 [0.088–0.294] | 0.201 | 0.210 | 0% | 81% | 28% [18%–38%] | 38% | 48% | 0.357 | 0.619 | 0.538 |
| d2c-r | 42 | 55 | 0.021 [0.000–0.066] | 0.021 | 0.021 | 0% | 98% | 22% [12%–33%] | 33% | 43% | 0.214 | 0.429 | 0.371 |
| d9 | 42 | 55 | 0.178 [0.081–0.283] | 0.187 | 0.187 | 0% | 81% | 25% [15%–36%] | 36% | 46% | 0.262 | 0.548 | 0.462 |

## Sabendo top-1 por tipo de falha

| tipo | casos | d9-k | v-cons-b | v-cons-b-1 | d2c-r | d9 |
|---|---|---|---|---|---|---|
| container CPU load | 12 | 44% | 41% | 40% | 19% | 44% |
| container memory load | 13 | 16% | 23% | 21% | 21% | 16% |
| container network latency | 7 | 25% | 27% | 21% | 18% | 25% |
| container network packet corruption | 9 | 38% | 44% | 35% | 26% | 38% |
| container network packet retransmission | 8 | 8% | 29% | 26% | 8% | 8% |
| container packet loss | 7 | 24% | 32% | 27% | 43% | 24% |
| container process termination | 4 | 3% | 8% | 8% | 0% | 3% |
| container read I/O load | 13 | 13% | 16% | 19% | 9% | 13% |
| container write I/O load | 4 | 0% | 3% | 3% | 0% | 0% |

## McNemar exato pareado (acerto majoritário por caso)

- d9-k × d9 (tp1): só d9-k 0, só d9 0, p = 1.000
- d2c-r × d9 (tp1): só d2c-r 0, só d9 9, p = 0.004
- d2c-r × d9-k (tp1): só d2c-r 0, só d9-k 9, p = 0.004
- v-cons-b × d9-k (o3): só v-cons-b 14, só d9-k 3, p = 0.013

## Leitura (fixada no PROTOCOLO.md)

- d9-k: F1@1 0.154 × d9 0.154; alarme 0% → **generaliza**
- d2c-r: F1@1 0.015 × d9 0.154; alarme 0% → **não generaliza**
- v-cons-b: top-3 sabendo 53% (≥ 80%); top-1 27% × d9 22% → **não generaliza**
