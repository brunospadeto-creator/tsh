#!/usr/bin/env python3
"""OpenRCA Market (cloudbed-1 e cloudbed-2) → `comum.instantes.Caso` (`../PLANO.md` §4.2).

A telemetria é contínua por dia (`telemetry/<AAAA_MM_DD>/trace/trace_span.csv`, ~1,3 GB por dia, `timestamp` em
ms, `duration` em µs) e as falhas estão em `record.csv` (`timestamp` em s, `level` pod/service/node, `component`, `reason`).

- **Casos de falha:** só `level` pod ou service (têm serviço como gabarito); falhas em nó ficam fora e são contadas.
  Falha = `[t, t + DURACAO)`, cortada no início da falha seguinte; pré-falha = os 600 s antes de `t`.
- **Casos normais:** trechos de `NORMAL_SEG` s a ≥ `MARGEM_SEG` s de qualquer falha registrada (inclusive de nó),
  até `NORMAIS_POR_DIA` por dia, espaçados por igual; sem gabarito.
- **Baseline do v-cons-b:** por cloudbed, o 1º trecho de `BASELINE_SEG` s elegível do 1º dia (não é caso normal).
- Serviço = `cmdb_id` sem o sufixo de réplica (`adservice-1`, `adservice2-0` → `adservice`). Entrada = `frontend`,
  operação `hipstershop.Frontend/Recv.`; erro = `status_code` fora de {0, Ok/OK, 2xx, 3xx}.

`extrair` lê cada dia uma vez e grava um parquet pequeno por caso em `/mnt/gpu-disk/datasets/bases-externas/
openrca-market/fatias/`; `carregar` lê só a fatia. Uso: python adaptar.py --extrair | --listar
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import re
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

from comum import DADOS_ORIGEM, DADOS_SAIDA, instantes, jaeger  # noqa: E402

RAIZ = os.path.join(DADOS_ORIGEM, "OpenRCA", "dataset", "Market")
SAIDA = os.path.join(DADOS_SAIDA, "openrca-market")
FATIAS = os.path.join(SAIDA, "fatias")
CLOUDBEDS = ("cloudbed-1", "cloudbed-2")
DURACAO_SEG = 600          # duração não documentada: teto comum do plano (confirmar; declarado no PROTOCOLO.md)
MARGEM_SEG = 1800
NORMAL_SEG = 900
NORMAIS_POR_DIA = 4
BASELINE_SEG = 1800
SISTEMA = {"nome": "online-boutique-market", "entry_services": ["frontend"],
           "entry_operation_regex": r"^hipstershop\.Frontend/Recv\.$", "dependencias_sem_span": {}}
OK_STATUS = {"0", "ok", "unset", ""}


def servico(componente: str) -> str:
    return re.sub(r"2?-\d+$", "", componente)


def _erro(status: str) -> bool:
    s = str(status).strip().lower()
    if s in OK_STATUS or s == "nan":
        return False
    return not (s.isdigit() and 200 <= int(s) < 400)


def _dias(cb: str) -> list[str]:
    return sorted(os.path.basename(p) for p in glob.glob(os.path.join(RAIZ, cb, "telemetry", "*")))


def _registros(cb: str) -> list[dict[str, str]]:
    with open(os.path.join(RAIZ, cb, "record.csv")) as f:
        return sorted(csv.DictReader(f), key=lambda r: float(r["timestamp"]))


def plano_de_casos() -> dict[str, dict]:
    """`{caso_id: {cb, dia, ini_s, fim_s, tipo, gabarito, falha, pre, normais}}` — determinístico, sem ler traces."""
    import pandas as pd

    casos: dict[str, dict] = {}
    for cb in CLOUDBEDS:
        regs = _registros(cb)
        ts_todos = [float(r["timestamp"]) for r in regs]
        for k, dia in enumerate(_dias(cb)):
            caminho = os.path.join(RAIZ, cb, "telemetry", dia, "trace", "trace_span.csv")
            primeira = pd.read_csv(caminho, usecols=["timestamp"], nrows=1)["timestamp"].iloc[0] / 1000
            ini_dia, fim_dia = primeira, primeira + 86400
            do_dia = [r for r in regs if ini_dia <= float(r["timestamp"]) < fim_dia]
            for i, r in enumerate(do_dia):
                t = float(r["timestamp"])
                seguintes = [x for x in ts_todos if x > t]
                fim = min(t + DURACAO_SEG, seguintes[0] if seguintes else fim_dia)
                base = {"cb": cb, "dia": dia, "tipo": r["reason"], "nivel": r["level"]}
                if r["level"] == "node":
                    casos[f"{cb}/{dia}/no-{i:02d}"] = {**base, "fora": "falha em nó (sem serviço)"}
                    continue
                casos[f"{cb}/{dia}/f{i:02d}"] = {**base, "gabarito": servico(r["component"]),
                                                 "ini_s": t - instantes.LOOKBACK, "fim_s": fim,
                                                 "falha": [t, fim], "pre": [t - instantes.LOOKBACK, t]}
            # trechos normais elegíveis (a ≥ MARGEM de qualquer falha)
            livres, a = [], ini_dia
            for t in [x for x in ts_todos if ini_dia - MARGEM_SEG <= x < fim_dia + MARGEM_SEG] + [fim_dia + MARGEM_SEG]:
                b = t - MARGEM_SEG
                if b - a >= NORMAL_SEG:
                    livres.append((a, min(b, fim_dia)))
                a = max(a, t + DURACAO_SEG + MARGEM_SEG)
            if k == 0 and livres and livres[0][1] - livres[0][0] >= BASELINE_SEG:
                a0 = livres[0][0]
                casos[f"{cb}/{dia}/baseline"] = {"cb": cb, "dia": dia, "tipo": "", "baseline": True,
                                                 "ini_s": a0, "fim_s": a0 + BASELINE_SEG}
                livres[0] = (a0 + BASELINE_SEG, livres[0][1])
            trechos = [(x, x + NORMAL_SEG) for a_, b_ in livres
                       for x in range(int(a_), int(b_) - NORMAL_SEG + 1, NORMAL_SEG)]
            passo = max(1, len(trechos) // NORMAIS_POR_DIA)
            for j, (x, y) in enumerate(trechos[::passo][:NORMAIS_POR_DIA]):
                casos[f"{cb}/{dia}/n{j}"] = {"cb": cb, "dia": dia, "tipo": "", "gabarito": None,
                                             "ini_s": x, "fim_s": y, "normais": [[x, y]]}
    return casos


def _caminho_plano() -> str:
    return os.path.join(SAIDA, "plano_de_casos.json")


def casos() -> dict[str, dict]:
    if not os.path.exists(_caminho_plano()):
        os.makedirs(SAIDA, exist_ok=True)
        with open(_caminho_plano(), "w") as f:
            json.dump(plano_de_casos(), f, indent=1)
    with open(_caminho_plano()) as f:
        return json.load(f)


def listar() -> list[str]:
    return sorted(c for c, v in casos().items() if "fora" not in v and not v.get("baseline"))


def _fatia(caso_id: str) -> str:
    return os.path.join(FATIAS, caso_id.replace("/", "__") + ".parquet")


def extrair() -> None:
    """Uma passada por dia: cada linha vai para a fatia de todo caso cujo intervalo a contém."""
    import pandas as pd

    os.makedirs(FATIAS, exist_ok=True)
    plano = {c: v for c, v in casos().items() if "fora" not in v}
    for cb in CLOUDBEDS:
        for dia in _dias(cb):
            alvo = {c: v for c, v in plano.items() if v["cb"] == cb and v["dia"] == dia
                    and not os.path.exists(_fatia(c))}
            if not alvo:
                continue
            partes: dict[str, list] = {c: [] for c in alvo}
            caminho = os.path.join(RAIZ, cb, "telemetry", dia, "trace", "trace_span.csv")
            for ch in pd.read_csv(caminho, chunksize=2_000_000, dtype={"status_code": str, "parent_span": str,
                                                                       "span_id": str, "trace_id": str}):
                s = ch["timestamp"] / 1000
                for c, v in alvo.items():
                    m = (s >= v["ini_s"]) & (s < v["fim_s"])
                    if m.any():
                        partes[c].append(ch[m])
            for c, ps in partes.items():
                df = pd.concat(ps) if ps else pd.DataFrame()
                df.to_parquet(_fatia(c))
                print(f"{c}: {len(df)} spans", flush=True)


def ler_eventos(caso_id: str) -> list:
    import pandas as pd

    df = pd.read_parquet(_fatia(caso_id))
    if df.empty:
        return []
    linhas = zip(df["trace_id"].astype(str), df["span_id"].astype(str),
                 [p if isinstance(p, str) and p and p != "nan" else None for p in df["parent_span"]],
                 df["cmdb_id"].astype(str).map(servico), df["operation_name"].astype(str),
                 (df["timestamp"].astype("int64") * 1000), df["duration"].astype("int64"),   # ms → µs; duração já em µs
                 df["status_code"].astype(str).map(_erro), strict=True)
    return jaeger.eventos(jaeger.de_linhas(linhas), SISTEMA)


def carregar(caso_id: str) -> instantes.Caso | None:
    v = casos()[caso_id]
    eventos = ler_eventos(caso_id)
    if not eventos:
        return None
    us = 1_000_000
    caso = instantes.Caso(id=caso_id, base="openrca-market", grupo=v["cb"], tipo=v.get("tipo") or "",
                          gabarito=v.get("gabarito"), eventos=eventos, sistema=SISTEMA,
                          extra={"dia": v["dia"], "nivel": v.get("nivel", "")})
    if v.get("falha"):
        caso.falha = (int(v["falha"][0] * us), int(v["falha"][1] * us))
        caso.pre = (int(v["pre"][0] * us), int(v["pre"][1] * us))
    caso.normais = [(int(a * us), int(b * us)) for a, b in v.get("normais") or []]
    return caso


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--extrair", action="store_true")
    ap.add_argument("--listar", action="store_true")
    args = ap.parse_args()
    if args.extrair:
        extrair()
    plano = casos()
    print(f"{len(listar())} casos: {sum('falha' in v for v in plano.values())} falhas com serviço, "
          f"{sum('normais' in v for v in plano.values())} trechos normais, "
          f"{sum('fora' in v for v in plano.values())} falhas em nó fora, "
          f"{sum(bool(v.get('baseline')) for v in plano.values())} baselines")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
