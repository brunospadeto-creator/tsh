#!/usr/bin/env python3
"""Compara o resultado reproduzido com o do pacote e confere os números do artigo.

Uso: python3 comparar.py <referencia.md> <reproduzido.md>. Sai com 0 se tudo bate.
"""
import re
import sys

ARTIGO = {  # Tabela "Etapas confirmatórias" e Tabela "Onde o método falha" do artigo
    "F1@1": "0.614", "IC": "0.572–0.654", "F1@2": "0.704", "alarme": "6.6%",
    "Train Ticket": "0.283", "atraso": "0.403", "perda": "0.230",
}


def primario(txt: str) -> tuple[str, ...]:
    linha = next(x for x in txt.splitlines() if x.startswith("| g-m∨t|mf | 474 |"))
    return re.search(r"\| (\d\.\d{3}) \[([^\]]+)\] \| (\S+) \| (\S+) \|", linha).groups()


def grupo(txt: str, titulo: str) -> str:
    bloco = txt.split(f"### {titulo}", 1)[1]
    linha = next(x for x in bloco.splitlines() if x.startswith("| g-m∨t|mf |"))
    return re.search(r"\| (\d\.\d{3}) \[", linha).group(1)


def main() -> int:
    ref, rep = (open(p, encoding="utf-8").read() for p in sys.argv[1:3])
    p = primario(rep)
    obtido = {"F1@1": p[0], "IC": p[1], "F1@2": p[2], "alarme": p[3],
              "Train Ticket": grupo(rep, "sistema TT"), "atraso": grupo(rep, "tipo delay"),
              "perda": grupo(rep, "tipo loss")}
    ok = True
    print("| medida | artigo | reproduzido | |\n|---|---|---|---|")
    for k, v in ARTIGO.items():
        igual = obtido[k] == v
        ok &= igual
        print(f"| {k} | {v} | {obtido[k]} | {'ok' if igual else 'DIFERE'} |")
    identico = ref == rep
    print(f"\nArquivo inteiro idêntico ao do pacote: {'sim' if identico else 'não'}")
    if not identico:
        a, b = ref.splitlines(), rep.splitlines()
        dif = [i for i in range(max(len(a), len(b))) if (a[i:i + 1] or [""]) != (b[i:i + 1] or [""])]
        print(f"{len(dif)} linhas diferentes; primeiras: {dif[:10]}")
    return 0 if ok and identico else 1


if __name__ == "__main__":
    sys.exit(main())
