#!/usr/bin/env bash
# Reproduz o confirmatório RCAEval do artigo (Tabela "Etapas confirmatórias", F1@1 = 0,614) a partir dos dados
# públicos e compara o resultado com o que está no pacote.
#
# Uso: bash bases-externas/reproducao/reproduzir.sh <pasta-dos-dados> [<pasta-de-saida>] [<processos>]
#   <pasta-dos-dados> contém RCAEval/RE1-OB/RE1-OB/<caso>/<n>/{data.csv,inject_time.txt}, e o mesmo para RE1-SS,
#   RE1-TT, RE2-SS e RE3-SS (é o formato dos arquivos do RCAEval depois de descompactados).
# No contêiner: docker run --rm -v <dados>:/dados:ro -v <saida>:/saida g-m-t-k-repro /dados /saida
set -euo pipefail
DADOS=${1:?informe a pasta dos dados}
SAIDA=${2:-$PWD/saida-reproducao}
JOBS=${3:-$(nproc)}
RAIZ=$(cd "$(dirname "$0")/../.." && pwd)
MR="$RAIZ/bases-externas/metricas-rz"
for s in RE1-OB RE1-SS RE1-TT RE2-SS RE3-SS; do
  [ -d "$DADOS/RCAEval/$s/$s" ] || { echo "falta $DADOS/RCAEval/$s/$s" >&2; exit 2; }
done
mkdir -p "$SAIDA"
REF="$SAIDA/referencia-confirmatorio-A.md"
cp "$MR/resultado-confirmatorio-A.md" "$REF"
trap 'cp "$REF" "$MR/resultado-confirmatorio-A.md"' EXIT   # o arquivo do pacote volta ao original no fim
export BASES_EXTERNAS_ORIGEM="$DADOS" BASES_EXTERNAS_SAIDA="$SAIDA/artefatos" PYTHONHASHSEED=0
mkdir -p "$BASES_EXTERNAS_SAIDA"
echo "Python $(python3 --version 2>&1 | cut -d' ' -f2); $JOBS processos; dados em $DADOS"
inicio=$(date +%s)
(cd "$MR" && python3 confirmatorio_a.py --jobs "$JOBS")
cp "$MR/resultado-confirmatorio-A.md" "$SAIDA/resultado-confirmatorio-A.md"
echo "Tempo: $(( $(date +%s) - inicio )) s"
python3 "$RAIZ/bases-externas/reproducao/comparar.py" "$REF" "$SAIDA/resultado-confirmatorio-A.md"
