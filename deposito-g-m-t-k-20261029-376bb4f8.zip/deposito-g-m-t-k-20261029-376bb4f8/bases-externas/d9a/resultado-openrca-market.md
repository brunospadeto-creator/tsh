# d9+a e d2c-a — OpenRCA Market (descritivo (o pré-teste já usou todos os casos))

Pré-registro em `PROTOCOLO.md` (commitado antes da execução). Sem eventos K8s. d2c-a exata (d2c-r com q = 1e-3 × min p_min do histórico da sessão); d9+a = d9, ou d2c-a quando a d9 se abstém.

## todos os casos — instantes avaliáveis (principal)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 77 | 99 | 0.154 [0.080–0.229] | 0.164 | 0.0% | 81.4% | 21.2% | 34.1% |
| d2c-r | 77 | 99 | 0.017 [0.000–0.044] | 0.017 | 0.0% | 98.4% | 17.5% | 29.0% |
| d2c-a | 77 | 99 | 0.071 [0.016–0.135] | 0.084 | 0.0% | 91.4% | 17.5% | 29.0% |
| d9+a | 77 | 99 | 0.166 [0.090–0.241] | 0.176 | 0.0% | 79.5% | 21.2% | 34.1% |

- ΔF1@1 d9+a − d9 = +0.012 [IC 95% -0.002 a +0.038]; McNemar (top-1 com portão): só d9+a 1, só d9 0, p = 1.000
- ΔF1@1 d2c-a − d2c-r = +0.053 [IC 95% +0.006 a +0.112]; McNemar (top-1 com portão): só d2c-a 3, só d2c-r 0, p = 0.250

## todos os casos — todos os instantes (secundário)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 77 | 121 | 0.154 [0.080–0.229] | 0.164 | 0.0% | 81.4% | 21.2% | 34.1% |
| d2c-r | 77 | 121 | 0.017 [0.000–0.044] | 0.017 | 0.0% | 98.4% | 17.5% | 29.0% |
| d2c-a | 77 | 121 | 0.071 [0.016–0.135] | 0.084 | 0.0% | 91.4% | 17.5% | 29.0% |
| d9+a | 77 | 121 | 0.166 [0.090–0.241] | 0.176 | 0.0% | 79.5% | 21.2% | 34.1% |

- ΔF1@1 d9+a − d9 = +0.012 [IC 95% -0.002 a +0.038]; McNemar (top-1 com portão): só d9+a 1, só d9 0, p = 1.000
- ΔF1@1 d2c-a − d2c-r = +0.053 [IC 95% +0.006 a +0.112]; McNemar (top-1 com portão): só d2c-a 3, só d2c-r 0, p = 0.250

## Leitura fixada (PROTOCOLO.md §4)

- d9+a × d9: ΔF1@1 +0.012 (IC inf. -0.002); alarme 0.0% × 0.0% → não melhora (descritivo)
- d2c-a × d2c-r: ΔF1@1 +0.053 (IC inf. +0.006); alarme 0.0% → melhora (descritivo)
- critério original (F1@1 ≥ d9 e alarme ≤ 2%): d9+a 0.166 / 0.0% → passa; d2c-a 0.071 / 0.0% → não passa

Instantes com histórico (\|H\| ≥ 2): normais 99 de 121; falha 678 de 678.
