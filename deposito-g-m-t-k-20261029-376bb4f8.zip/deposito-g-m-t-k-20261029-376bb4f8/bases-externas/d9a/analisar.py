#!/usr/bin/env python3
"""Pré-registro d9+a / d2c-a (`PROTOCOLO.md`): um `resultado-<base>.md` por base.

Medidas e leitura fixadas no `PROTOCOLO.md` §3–§4 antes da execução. Uso: python analisar.py [--bases …]
"""
from __future__ import annotations

import argparse
import glob
import gzip
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict
from typing import Any

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), os.path.join(os.path.dirname(AQUI), "pre-teste")]

import analisar as P  # noqa: E402  (pre-teste: _ctx, _rank9, _passa)

from comum import DADOS_SAIDA, DUPLICADOS  # noqa: E402

ENTRADA = os.path.join(DADOS_SAIDA, "d9a")
METODOS = ("d9", "d2c-r", "d2c-a", "d9+a")
SEMENTE, N_BOOT = 20261018, 2000
NOMES = {"rcaeval": "RCAEval", "openrca-market": "OpenRCA Market", "eadro": "Eadro SN"}


def carregar(base: str) -> list[dict[str, Any]]:
    out = []
    for arq in sorted(glob.glob(os.path.join(ENTRADA, base, "*.jsonl.gz"))):
        with gzip.open(arq, "rt") as f:
            out += [json.loads(x) for x in f if x.strip()]
    return [x for x in out if x["periodo"] != "sombra" and x["caso"] not in DUPLICADOS]


def decisoes(x: dict[str, Any]) -> dict[str, dict[str, Any]]:
    ctx, efs = P._ctx(x["ctx"]), x["efeitos"]
    r9 = P._rank9([e for e in efs if P._passa(e, 1.5, 0.10)], ctx)
    f9 = P._rank9([e for e in efs if P._passa(e, 1.0, 0.0)], ctx)
    d2 = x["d2cr"]
    rk2 = d2["ranking"] if d2["status"] != "falhou" else []
    pm = float(d2["p_min"]) if d2.get("p_min") is not None and d2["status"] != "falhou" else 1.0
    a = x["d2ca"]
    ra = a["ranking"] if a["status"] == "decidiu" else []
    out = {"d9": {"dec": bool(r9), "rk": r9, "f": f9},
           "d2c-r": {"dec": bool(rk2) and pm <= 1e-50, "rk": rk2 if pm <= 1e-50 else [], "f": rk2},
           "d2c-a": {"dec": bool(ra), "rk": ra, "f": rk2}}
    out["d9+a"] = dict(out["d9"]) if r9 else {"dec": bool(ra), "rk": ra, "f": f9}
    return out


def por_caso(linhas: list[dict[str, Any]], so_avaliaveis: bool) -> dict[str, dict[str, Counter]]:
    """`{método: {caso: contagens}}`."""
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in METODOS}
    for x in linhas:
        if so_avaliaveis and x["d2ca"]["n_hist"] < 2:
            continue
        if x["periodo"] == "normal" and x.get("na_baseline"):
            continue
        esp = x["gabarito"]
        for m, d in decisoes(x).items():
            c = pc[m][x["caso"]]
            if x["periodo"] == "normal":
                c["nn"] += 1
                c["al"] += d["dec"]
            elif esp:
                c["ne"] += 1
                c["dec"] += d["dec"]
                for k in (1, 2):
                    c[f"tp{k}"] += d["dec"] and esp in d["rk"][:k]
                    c[f"o{k}"] += esp in d["f"][:k]
    return pc


def f1(cs: list[Counter], k: int = 1) -> float:
    tp = sum(c[f"tp{k}"] for c in cs)
    fp = sum(c["dec"] - c[f"tp{k}"] + c["al"] for c in cs)
    fn = sum(c["ne"] - c[f"tp{k}"] for c in cs)
    return 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else math.nan


def taxa(cs: list[Counter], num: str, den: str) -> float:
    d = sum(c[den] for c in cs)
    return sum(c[num] for c in cs) / d if d else math.nan


def media(cs: list[Counter], k: str) -> float:
    v = [c[k] / c["ne"] for c in cs if c["ne"]]
    return sum(v) / len(v) if v else math.nan


def boot(casos: list[str], fn: Any) -> tuple[float, float]:
    rnd = random.Random(SEMENTE)
    v = sorted(x for x in (fn([rnd.choice(casos) for _ in casos]) for _ in range(N_BOOT)) if not math.isnan(x))
    return (v[int(0.025 * len(v))], v[max(0, int(0.975 * len(v)) - 1)]) if v else (math.nan, math.nan)


def mcnemar(a: dict[str, Counter], b: dict[str, Counter]) -> tuple[int, int, float]:
    maj = lambda c: c["ne"] > 0 and c["tp1"] / c["ne"] > 0.5  # noqa: E731
    cs = [k for k in a if a[k]["ne"]]
    sa = sum(maj(a[k]) and not maj(b[k]) for k in cs)
    sb = sum(maj(b[k]) and not maj(a[k]) for k in cs)
    n = sa + sb
    return sa, sb, (min(1.0, 2 * sum(math.comb(n, i) for i in range(min(sa, sb) + 1)) / 2 ** n) if n else 1.0)


def _f(x: float) -> str:
    return "—" if math.isnan(x) else f"{x:.3f}"


def _p(x: float) -> str:
    return "—" if math.isnan(x) else f"{x:.1%}"


def tabela(pc: dict[str, dict[str, Counter]], casos: list[str]) -> list[str]:
    out = ["| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |",
           "|---|---|---|---|---|---|---|---|---|"]
    for m in METODOS:
        cs = [pc[m][c] for c in casos if c in pc[m]]
        ic = boot([c for c in casos if c in pc[m]], lambda s, m=m: f1([pc[m][c] for c in s]))
        out.append(f"| {m} | {sum(1 for c in cs if c['ne'])} | {sum(c['nn'] for c in cs)} | {_f(f1(cs))} "
                   f"[{_f(ic[0])}–{_f(ic[1])}] | {_f(f1(cs, 2))} | {_p(taxa(cs, 'al', 'nn'))} | "
                   f"{_p(1 - taxa(cs, 'dec', 'ne'))} | {_p(media(cs, 'o1'))} | {_p(media(cs, 'o2'))} |")
    return out


def diferenca(pc: dict[str, dict[str, Counter]], casos: list[str], a: str, b: str) -> tuple[float, float, float]:
    fn = lambda s: f1([pc[a][c] for c in s]) - f1([pc[b][c] for c in s])  # noqa: E731
    lo, hi = boot(casos, fn)
    return fn(casos), lo, hi


def relatorio(base: str, linhas: list[dict[str, Any]]) -> str:
    excl = set()
    if base == "rcaeval":
        with open(os.path.join(AQUI, "amostra-pre-teste-rcaeval.txt")) as f:
            excl = {x.strip() for x in f if x.strip()}
    todos = sorted({x["caso"] for x in linhas})
    conjuntos = [("todos os casos", todos)]
    if excl:
        conjuntos = [("**confirmatório: casos inéditos (fora do pré-teste)**", [c for c in todos if c not in excl]),
                     ("descritivo: todos os casos", todos)]
    papel = "confirmatório" if base == "rcaeval" else "descritivo (o pré-teste já usou todos os casos)"
    out = [f"# d9+a e d2c-a — {NOMES[base]} ({papel})", "",
           "Pré-registro em `PROTOCOLO.md` (commitado antes da execução). Sem eventos K8s. d2c-a exata "
           "(d2c-r com q = 1e-3 × min p_min do histórico da sessão); d9+a = d9, ou d2c-a quando a d9 se abstém.", ""]
    leitura: list[str] = []
    for rot, casos in conjuntos:
        for sub, so in (("instantes avaliáveis (principal)", True), ("todos os instantes (secundário)", False)):
            pc = por_caso(linhas, so)
            out += [f"## {rot} — {sub}", "", *tabela(pc, casos), ""]
            for a, b in (("d9+a", "d9"), ("d2c-a", "d2c-r")):
                d, lo, hi = diferenca(pc, casos, a, b)
                sa, sb, p = mcnemar(pc[a], pc[b])
                out.append(f"- ΔF1@1 {a} − {b} = {d:+.3f} [IC 95% {lo:+.3f} a {hi:+.3f}]; McNemar (top-1 com "
                           f"portão): só {a} {sa}, só {b} {sb}, p = {p:.3f}")
            out.append("")
            if rot == conjuntos[0][0] and so:
                cs = {m: [pc[m][c] for c in casos if c in pc[m]] for m in METODOS}
                al = {m: taxa(cs[m], "al", "nn") for m in METODOS}
                fs = {m: f1(cs[m]) for m in METODOS}
                d1, lo1, _ = diferenca(pc, casos, "d9+a", "d9")
                d2, lo2, _ = diferenca(pc, casos, "d2c-a", "d2c-r")
                ok1 = d1 > 0 and lo1 > 0 and al["d9+a"] - al["d9"] <= 0.01
                ok2 = d2 > 0 and lo2 > 0 and al["d2c-a"] <= 0.02
                verbo = ("**melhora**", "**não melhora**") if base == "rcaeval" else ("melhora (descritivo)",
                                                                                      "não melhora (descritivo)")
                leitura = [
                    f"- d9+a × d9: ΔF1@1 {d1:+.3f} (IC inf. {lo1:+.3f}); alarme {_p(al['d9+a'])} × {_p(al['d9'])} → "
                    + (verbo[0] if ok1 else verbo[1]),
                    f"- d2c-a × d2c-r: ΔF1@1 {d2:+.3f} (IC inf. {lo2:+.3f}); alarme {_p(al['d2c-a'])} → "
                    + (verbo[0] if ok2 else verbo[1]),
                    f"- critério original (F1@1 ≥ d9 e alarme ≤ 2%): d9+a {_f(fs['d9+a'])} / {_p(al['d9+a'])} → "
                    + ("passa" if fs["d9+a"] >= fs["d9"] and al["d9+a"] <= 0.02 else "não passa")
                    + f"; d2c-a {_f(fs['d2c-a'])} / {_p(al['d2c-a'])} → "
                    + ("passa" if fs["d2c-a"] >= fs["d9"] and al["d2c-a"] <= 0.02 else "não passa")]
    n_av = Counter((x["periodo"], x["d2ca"]["n_hist"] >= 2) for x in linhas)
    out += ["## Leitura fixada (PROTOCOLO.md §4)", "", *leitura, "",
            f"Instantes com histórico (\\|H\\| ≥ 2): normais {n_av[('normal', True)]} de "
            f"{n_av[('normal', True)] + n_av[('normal', False)]}; falha {n_av[('falha', True)]} de "
            f"{n_av[('falha', True)] + n_av[('falha', False)]}."]
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bases", default="rcaeval,openrca-market,eadro")
    args = ap.parse_args()
    for base in args.bases.split(","):
        linhas = carregar(base)
        if not linhas:
            print(f"{base}: sem registros")
            continue
        texto = relatorio(base, linhas)
        with open(os.path.join(AQUI, f"resultado-{base}.md"), "w") as f:
            f.write(texto)
        print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
