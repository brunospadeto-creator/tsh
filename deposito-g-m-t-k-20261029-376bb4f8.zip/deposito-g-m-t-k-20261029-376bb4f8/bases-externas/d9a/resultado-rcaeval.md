# d9+a e d2c-a — RCAEval (confirmatório)

Pré-registro em `PROTOCOLO.md` (commitado antes da execução). Sem eventos K8s. d2c-a exata (d2c-r com q = 1e-3 × min p_min do histórico da sessão); d9+a = d9, ou d2c-a quando a d9 se abstém.

## **confirmatório: casos inéditos (fora do pré-teste)** — instantes avaliáveis (principal)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 200 | 1166 | 0.322 [0.263–0.381] | 0.397 | 8.2% | 20.5% | 38.4% | 52.7% |
| d2c-r | 200 | 1166 | 0.006 [0.000–0.017] | 0.013 | 0.0% | 92.7% | 10.4% | 19.7% |
| d2c-a | 200 | 1166 | 0.134 [0.080–0.187] | 0.157 | 0.9% | 75.3% | 10.4% | 19.7% |
| d9+a | 200 | 1166 | 0.362 [0.301–0.422] | 0.434 | 9.1% | 14.4% | 38.4% | 52.7% |

- ΔF1@1 d9+a − d9 = +0.040 [IC 95% +0.019 a +0.063]; McNemar (top-1 com portão): só d9+a 11, só d9 0, p = 0.001
- ΔF1@1 d2c-a − d2c-r = +0.128 [IC 95% +0.074 a +0.187]; McNemar (top-1 com portão): só d2c-a 23, só d2c-r 0, p = 0.000

## **confirmatório: casos inéditos (fora do pré-teste)** — todos os instantes (secundário)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 201 | 1534 | 0.317 [0.258–0.377] | 0.391 | 9.0% | 20.8% | 38.2% | 52.5% |
| d2c-r | 201 | 1534 | 0.006 [0.000–0.017] | 0.013 | 0.0% | 92.7% | 10.4% | 19.6% |
| d2c-a | 201 | 1534 | 0.134 [0.082–0.191] | 0.156 | 0.7% | 75.4% | 10.4% | 19.6% |
| d9+a | 201 | 1534 | 0.356 [0.297–0.414] | 0.428 | 9.6% | 14.8% | 38.2% | 52.5% |

- ΔF1@1 d9+a − d9 = +0.039 [IC 95% +0.018 a +0.063]; McNemar (top-1 com portão): só d9+a 11, só d9 0, p = 0.001
- ΔF1@1 d2c-a − d2c-r = +0.128 [IC 95% +0.074 a +0.186]; McNemar (top-1 com portão): só d2c-a 23, só d2c-r 0, p = 0.000

## descritivo: todos os casos — instantes avaliáveis (principal)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 238 | 1388 | 0.312 [0.259–0.373] | 0.391 | 7.7% | 20.8% | 38.1% | 54.1% |
| d2c-r | 238 | 1388 | 0.005 [0.000–0.014] | 0.011 | 0.0% | 93.5% | 11.1% | 19.9% |
| d2c-a | 238 | 1388 | 0.143 [0.093–0.197] | 0.163 | 0.8% | 74.5% | 11.1% | 19.9% |
| d9+a | 238 | 1388 | 0.353 [0.300–0.410] | 0.429 | 8.4% | 13.8% | 38.1% | 54.1% |

- ΔF1@1 d9+a − d9 = +0.041 [IC 95% +0.022 a +0.063]; McNemar (top-1 com portão): só d9+a 11, só d9 0, p = 0.001
- ΔF1@1 d2c-a − d2c-r = +0.137 [IC 95% +0.088 a +0.192]; McNemar (top-1 com portão): só d2c-a 23, só d2c-r 0, p = 0.000

## descritivo: todos os casos — todos os instantes (secundário)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 239 | 1826 | 0.308 [0.256–0.364] | 0.385 | 8.4% | 21.1% | 37.9% | 53.9% |
| d2c-r | 239 | 1826 | 0.005 [0.000–0.014] | 0.011 | 0.0% | 93.5% | 11.0% | 19.8% |
| d2c-a | 239 | 1826 | 0.142 [0.094–0.197] | 0.163 | 0.6% | 74.6% | 11.0% | 19.8% |
| d9+a | 239 | 1826 | 0.349 [0.297–0.406] | 0.423 | 8.9% | 14.1% | 37.9% | 53.9% |

- ΔF1@1 d9+a − d9 = +0.041 [IC 95% +0.022 a +0.062]; McNemar (top-1 com portão): só d9+a 11, só d9 0, p = 0.001
- ΔF1@1 d2c-a − d2c-r = +0.137 [IC 95% +0.088 a +0.192]; McNemar (top-1 com portão): só d2c-a 23, só d2c-r 0, p = 0.000

## Leitura fixada (PROTOCOLO.md §4)

- d9+a × d9: ΔF1@1 +0.040 (IC inf. +0.019); alarme 9.1% × 8.2% → **melhora**
- d2c-a × d2c-r: ΔF1@1 +0.128 (IC inf. +0.074); alarme 0.9% → **melhora**
- critério original (F1@1 ≥ d9 e alarme ≤ 2%): d9+a 0.362 / 9.1% → não passa; d2c-a 0.134 / 0.9% → não passa

Instantes com histórico (\|H\| ≥ 2): normais 1523 de 2001; falha 2123 de 2130.
