# d9+a e d2c-a — Eadro SN (descritivo (o pré-teste já usou todos os casos))

Pré-registro em `PROTOCOLO.md` (commitado antes da execução). Sem eventos K8s. d2c-a exata (d2c-r com q = 1e-3 × min p_min do histórico da sessão); d9+a = d9, ou d2c-a quando a d9 se abstém.

## todos os casos — instantes avaliáveis (principal)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 24 | 18 | 0.047 [0.000–0.146] | 0.047 | 0.0% | 20.8% | 4.2% | 4.2% |
| d2c-r | 24 | 18 | 0.000 [0.000–0.000] | 0.000 | 0.0% | 100.0% | 12.5% | 29.2% |
| d2c-a | 24 | 18 | 0.000 [0.000–0.000] | 0.000 | 0.0% | 91.7% | 12.5% | 29.2% |
| d9+a | 24 | 18 | 0.045 [0.000–0.143] | 0.045 | 0.0% | 16.7% | 4.2% | 4.2% |

- ΔF1@1 d9+a − d9 = -0.001 [IC 95% -0.006 a +0.000]; McNemar (top-1 com portão): só d9+a 0, só d9 0, p = 1.000
- ΔF1@1 d2c-a − d2c-r = +0.000 [IC 95% +0.000 a +0.000]; McNemar (top-1 com portão): só d2c-a 0, só d2c-r 0, p = 1.000

## todos os casos — todos os instantes (secundário)

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 31 | 22 | 0.036 [0.000–0.111] | 0.036 | 4.5% | 22.6% | 3.2% | 3.2% |
| d2c-r | 31 | 22 | 0.000 [0.000–0.000] | 0.000 | 0.0% | 100.0% | 12.9% | 29.0% |
| d2c-a | 31 | 22 | 0.000 [0.000–0.000] | 0.000 | 0.0% | 93.5% | 12.9% | 29.0% |
| d9+a | 31 | 22 | 0.035 [0.000–0.109] | 0.035 | 4.5% | 19.4% | 3.2% | 3.2% |

- ΔF1@1 d9+a − d9 = -0.001 [IC 95% -0.004 a +0.000]; McNemar (top-1 com portão): só d9+a 0, só d9 0, p = 1.000
- ΔF1@1 d2c-a − d2c-r = +0.000 [IC 95% +0.000 a +0.000]; McNemar (top-1 com portão): só d2c-a 0, só d2c-r 0, p = 1.000

## Leitura fixada (PROTOCOLO.md §4)

- d9+a × d9: ΔF1@1 -0.001 (IC inf. -0.006); alarme 0.0% × 0.0% → não melhora (descritivo)
- d2c-a × d2c-r: ΔF1@1 +0.000 (IC inf. +0.000); alarme 0.0% → não melhora (descritivo)
- critério original (F1@1 ≥ d9 e alarme ≤ 2%): d9+a 0.045 / 0.0% → não passa; d2c-a 0.000 / 0.0% → não passa

Instantes com histórico (\|H\| ≥ 2): normais 18 de 22; falha 24 de 31.
