# Pré-registro — d9+a (d9 OU d2c-a) e d2c-a, sem K8s, em RCAEval, OpenRCA Market e Eadro SN

Escrito em 18/10/2026 (ARQ), **antes** de rodar a medida completa. Commitado antes da execução; mudança depois de
ver número = protocolo novo, declarado. Origem: pré-teste de ≤ 10 min por base (`session.md` §42.89,
`../pre-teste/`), onde a d9+a foi definida **depois** de ver os números (pós-hoc). Este protocolo existe para
medi-la em casos que o pré-teste não viu.

## 1. Métodos (sem eventos K8s; nada de `src/` muda)

| método | regra |
|---|---|
| **d2c-a** | d2c-r com o limiar calibrado na própria sessão: em cada instante, `q = 1e-3 × min p_min(H)`, onde `p_min` é o menor p ajustado (BH) da d2c-r e H é o histórico da sessão (§2). Decide e ranqueia com `d2cr.decidir(q)`, de forma **exata**. Sem histórico (\|H\| < 2) → abstém |
| **d9+a** | se a d9 decide → a decisão e o ranking da d9; senão → os da d2c-a. Ranking forçado ("sabendo") = o da d9 |
| d9 (referência) | portão razão ≥ 1,5 ou Δerro ≥ 0,10, ranking `residuo_1`, forçado permissivo (como na rodada oficial) |
| d2c-r (referência) | q = 1e-50 fixo (como na rodada oficial) |

Parâmetros fixos e iguais nas três bases: margem 1e-3; \|H\| entre 2 e 3; janela, passo, referência da sessão, D0.4
e teto de falha da rodada oficial (`../PLANO.md` §0).

## 2. Histórico da sessão (H)

- instante normal: até 3 instantes normais anteriores do mesmo caso;
- instante de falha: até 3 janelas `sombra` dentro do pré-falha, terminando na injeção, 60 s e 120 s antes (cada uma
  com os seus 150 s de referência dentro do pré-falha). As sombras não são medidas;
- instante sem histórico (\|H\| < 2): d2c-a abstém; d9+a = d9.

## 3. Medidas

F1@1 e F1@2 com portão; alarme; abstenção; sabendo top-1 e top-2. IC 95% por bootstrap de caso (2000, semente
20261018), também para a **diferença** de F1@1 entre dois métodos (reamostrando os mesmos casos). McNemar exato
pareado no acerto majoritário por caso (top-1 com portão).

- **Conjunto principal:** só os instantes avaliáveis (\|H\| ≥ 2), para todos os métodos.
- **Secundário:** todos os instantes (sem histórico, a d2c-a abstém).
- RCAEval: instantes normais `na_baseline` fora do alarme, como na rodada oficial.

## 4. Casos e leitura — separado por base

### 4.1 RCAEval — **confirmatório**

- **Casos:** os 241 menos os 39 do pré-teste (`amostra-pre-teste-rcaeval.txt`) = **202 casos inéditos** para a
  d9+a e a d2c-a. Os 240 com falha também são reportados, como descritivo.
- **Leitura fixada (só nos 202):**
  - **d9+a melhora a d9** se ΔF1@1 (d9+a − d9) > 0 com o limite inferior do IC 95% > 0 **e** alarme(d9+a) −
    alarme(d9) ≤ 1 pp;
  - **d2c-a melhora a d2c-r** se ΔF1@1 (d2c-a − d2c-r) > 0 com o limite inferior do IC 95% > 0 **e** alarme(d2c-a)
    ≤ 2%;
  - o critério de generalização original (F1@1 ≥ d9 e alarme ≤ 2%) também é reportado.

### 4.2 OpenRCA Market — **descritivo**

O pré-teste já usou todos os 88 casos (77 falhas + 11 trechos normais). Mesmas medidas, sem leitura confirmatória.

### 4.3 Eadro SN — **descritivo**

O pré-teste já usou todos os casos (31 falhas + 2 trechos normais). Mesmas medidas, sem leitura confirmatória.
Ressalvas da rodada oficial: referência contaminada pela falha anterior; poucas falhas com histórico de sombra.

## 5. Execução

`extrair.py <base>` → `/mnt/gpu-disk/datasets/bases-externas/d9a/<base>/` (por instante: efeitos e grafo da d9;
p_min e ranking da d2c-r; decisão e ranking exatos da d2c-a). `analisar.py` → `resultado-<base>.md`, uma por base.
Market e Eadro: todos os casos. RCAEval: todos os casos (a leitura usa os 202).

## 6. Emenda de 18/10 (antes de qualquer resultado do RCAEval; limite de 10 min por base, pedido do usuário)

O RCAEval completo (~1 h) passa do limite de **10 min por base** pedido pelo usuário. Uma rodada completa chegou a
começar por engano e foi interrompida às 09:56. Os 25 arquivos gravados foram **apagados sem leitura**.
Novo desenho do RCAEval:

- **Amostra:** `--n 36` sobre os 202 inéditos — a estratificação (RE2-TT a meio peso, arredondamento) dá **28 casos** (RE2-OB 13, RE2-TT 7, RE3-OB 4, RE3-TT 4) (fora de `amostra-pre-teste-rcaeval.txt`), estratificada por suíte com o
  RE2-TT a meio peso (como no pré-teste), semente `20261018-d9a-rcaeval` (`extrair.py rcaeval --n 36 --excluir
  amostra-pre-teste-rcaeval.txt --semente d9a-rcaeval`). Lista gravada em `amostra-d9a-rcaeval.txt` antes de rodar.
- **Limite:** 10 min. Caso que não terminar no limite fica fora e é declarado (viés para casos mais leves).
- **Leitura:** a mesma do §4.1, nesta amostra. Com menos casos o IC fica mais largo: "não melhora" pode ser falta
  de poder, e isso será dito.
- Market e Eadro: sem mudança (já rodados inteiros, descritivos).
