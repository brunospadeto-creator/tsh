#!/usr/bin/env python3
"""Pré-registro d9+a / d2c-a (`PROTOCOLO.md`): extrai, por instante, as medidas da d9 e da d2c-r e a decisão
**exata** da d2c-a (d2c-r com q = 1e-3 × min p_min do histórico da sessão), em todos os casos da base. Derivado de
`../pre-teste/extrair.py` (mesma medida, mais o campo `d2ca`).

Por instante grava:
- d9: os efeitos por atividade (razão de medianas, Δ erro…) da janela × referência da sessão (`d5.avaliar` com o
  portão da d9) e o contexto do grafo (`d9.contexto`) → qualquer portão/ranking da d9 é refeito offline com
  `d9.ranquear` (o ranking permissivo é exatamente o "forçado" da d9);
- d2c-r: `p_min_ajustado` (BH) e o ranking com q = 1 (permissivo). A d2c-r original decide sse p_min ≤ 1e-50.
Nada de `src/` muda. Uso: python extrair.py <base> [--n N] [--jobs 24]
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
import random
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
sys.path[:0] = [RAIZ]

from comum import DADOS_SAIDA, execucao, instantes as I, metodos as M, rapido  # noqa: E402

BASES = {"rcaeval": "rcaeval/adaptar.py", "openrca-market": "openrca-market/adaptar.py", "eadro": "eadro/adaptar.py"}
SAIDA = os.path.join(DADOS_SAIDA, "d9a")
MARGEM, K_MIN, K_MAX = 1e-3, 2, 3


def _amostra(base: str, ids: list[str], n: int | None) -> list[str]:
    if not n or n >= len(ids):
        return ids
    # estratificada por grupo (suíte/cloudbed), semente fixa
    grupos: dict[str, list[str]] = {}
    for i in ids:
        grupos.setdefault(i.split("/")[0], []).append(i)
    rnd = random.Random(f"20261018-{base}")
    pesos = {"RE2-TT": 0.5}   # RE2-TT custa ~10× um caso OB: metade da cota
    out = []
    for g, lst in sorted(grupos.items()):
        k = max(1, round(n * len(lst) / len(ids) * pesos.get(g, 1.0)))
        out += rnd.sample(sorted(lst), min(k, len(lst)))
    return sorted(out)


def _sombras(caso: I.Caso):
    """Histórico da própria sessão para os casos de falha: até 3 janelas **dentro do pré-falha**, terminando na
    injeção, 60 s e 120 s antes (cada uma com os seus 150 s de referência dentro do pré-falha). Período `sombra`;
    não é medido, só serve de histórico para as variantes calibradas na sessão."""
    from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: PLC0415
    if not (caso.falha and caso.pre):
        return
    fat = I.Fatiador(caso.eventos)
    j = I.JANELA * 1_000_000
    for i in (2, 1, 0):
        te = caso.pre[1] - i * I.PASSO * 1_000_000
        if te - j - I.REF * 1_000_000 < caso.pre[0]:
            continue
        dentro = fat.entre(te - j, te)
        n = len({e.case_id for e in dentro})
        if n < I.MIN_TRACES:
            continue
        yield "sombra", I._dt(te), EntradaIncidente(
            incidente_id=f"{caso.id}@sombra{te}", janela=(I._dt(te - j), I._dt(te)), abertura_incidente=I._dt(te),
            traces=dentro, traces_lookback=fat.entre(max(caso.pre[0], te - j - I.LOOKBACK * 1_000_000), te - j),
            metricas={}, eventos_k8s=[], config_sistema={"entry_services": caso.sistema["entry_services"]}), n


def _job(job: tuple[str, str]) -> str:
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    from src.application.stage3.abordagens import d5_portao as d5  # noqa: PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    from src.application.stage3.abordagens import referencia  # noqa: PLC0415
    base, caso_id = job
    destino = os.path.join(SAIDA, base, f"{caso_id.replace('/', '__')}.jsonl.gz")
    if os.path.exists(destino):
        return f"{caso_id}: já feito"
    t0 = time.monotonic()
    caso = execucao._modulo(os.path.join(RAIZ, BASES[base])).carregar(caso_id)
    if caso is None:
        return f"{caso_id}: fora"
    sis = M.cfg_sistema(caso.sistema)
    cfg9 = d9._cfg({**sis, **M.PORTAO_D9})
    rapido.ativar()
    linhas = []
    hist_sombra: list[float] = []
    hist_normal: list[float] = []
    for periodo, t, ent, n in list(_sombras(caso)) + list(I.entradas(caso, I.REF)):
        rapido.limpar()
        raiz = d5._entradas(ent, cfg9)
        ev_ref = d5._eventos_ref(ent, cfg9)
        inc = referencia.estatisticas(ent.traces, servicos_raiz=raiz)
        ref = referencia.estatisticas(ev_ref, servicos_raiz=raiz)
        med = d5.medir(inc, ref, cfg9)
        ctx = d9.contexto(list(ent.traces), ev_ref, ref, cfg9)
        try:
            d = d2cr.decidir(ent, {}, {**sis, "q": 1.0})
            d2 = {"status": d.status, "motivo": d.motivo_abstencao, "p_min": (d.evidencias or {}).get("p_min_ajustado"),
                  "ranking": [i.servico for i in d.ranking][:3]}
        except Exception as exc:  # noqa: BLE001
            d2 = {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}"[:200], "p_min": None, "ranking": []}
        pm = float(d2["p_min"]) if d2.get("p_min") is not None and d2["status"] != "falhou" else 1.0
        h = hist_sombra[-K_MAX:] if periodo == "falha" else hist_normal[-K_MAX:]
        d2ca: dict = {"status": "sem_historico", "ranking": [], "q": None, "n_hist": len(h)}
        if periodo != "sombra" and len(h) >= K_MIN:
            q = MARGEM * min(h)
            try:
                da = d2cr.decidir(ent, {}, {**sis, "q": q})
                d2ca = {"status": da.status, "ranking": [i.servico for i in da.ranking][:3] if da.status == "decidiu"
                        else [], "q": q, "n_hist": len(h)}
            except Exception as exc:  # noqa: BLE001
                d2ca = {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}"[:200], "ranking": [], "q": q,
                        "n_hist": len(h)}
        (hist_sombra if periodo == "sombra" else hist_normal if periodo == "normal" else []).append(pm)
        linhas.append({"base": base, "grupo": caso.grupo, "caso": caso.id, "tipo": caso.tipo, "gabarito": caso.gabarito,
                       "periodo": periodo, "t": t.isoformat(), "n_traces": n,
                       "na_baseline": bool(caso.extra.get("na_baseline")),
                       "n_eventos_ref": len(ev_ref), "efeitos": med["efeitos"],
                       "ctx": {"deps": ctx["deps"], "filhos": {k: sorted(v) for k, v in ctx["filhos"].items()},
                               "sumidos": ctx["sumidos"]}, "d2cr": d2, "d2ca": d2ca})
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("".join(json.dumps(x, default=str) + "\n" for x in linhas))
    os.replace(destino + ".tmp", destino)
    return f"{caso_id}: {len(linhas)} instantes, {time.monotonic() - t0:.0f}s"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", choices=sorted(BASES))
    ap.add_argument("--n", type=int)
    ap.add_argument("--excluir", help="arquivo com ids fora da amostra (ex.: amostra do pré-teste)")
    ap.add_argument("--semente", default=None, help="semente da amostra (padrão: a do pré-teste)")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    mod = execucao._modulo(os.path.join(RAIZ, BASES[args.base]))
    ids = [i for i in mod.listar() if args.base != "eadro" or i.startswith("SN/")]   # Eadro: só SN (TT fora)
    if args.excluir:
        with open(args.excluir) as f:
            fora = {x.strip() for x in f if x.strip()}
        ids = [i for i in ids if i not in fora]
    ids = _amostra(args.semente or args.base, ids, args.n)
    print(f"{args.base}: {len(ids)} casos", flush=True)
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(args.jobs) as ex:
        for msg in ex.map(_job, [(args.base, i) for i in ids]):
            print(msg, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
