# Custo de execução do método por instante (análise adicional, fora do protocolo)

`custo.py --n 3 --n-rastros 2`. Um processo, sem paralelismo; processador: Intel(R) Xeon(R) Silver 4116 CPU @ 2.10GHz; Python 3.12.3. Tempo de cada decisão com os dados do instante já na memória (a leitura dos arquivos fica de fora). Memória máxima do processo durante toda a medição: 2817 MB. Duração total: 876 s.

## Parte de métricas (escore por família, normalização, Portão de Métricas e ordenação)

| conjunto | instantes | colunas (mediana) | famílias (mediana) | ms por instante: mediana \| p95 \| máx. |
|---|---|---|---|---|
| RCAEval inédito, RE1-OB | 87 | 49 | 5 | 19.5 | 20.1 | 20.3 |
| RCAEval inédito, RE1-SS | 21 | 436 | 48 | 135.3 | 139.7 | 140.3 |
| RCAEval inédito, RE1-TT | 33 | 1189 | 48 | 381.4 | 397.2 | 399.2 |
| RCAEval inédito, RE2-SS | 51 | 74 | 7 | 28.4 | 29.2 | 29.3 |
| RCAEval inédito, RE3-SS | 51 | 80 | 8 | 30.5 | 30.9 | 32.5 |
| RCAEval com rastros (RE2, RE3) | 96 | 196 | 8 | 72.5 | 135.0 | 142.4 |

## Parte de rastros (Portão de Rastros: contraste da sessão e testes da composição)

| conjunto | instantes | rastros por janela (mediana) | ms por instante: mediana \| p95 \| máx. |
|---|---|---|---|
| RCAEval com rastros (RE2, RE3), 8 casos | 96 | 596 (máx. 1680) | 2583.4 | 16909.6 | 18049.1 |

Complexidade por instante: na parte de métricas, mediana e quartis de cada coluna na janela e na referência, ou O(C · n log n) para C colunas e n amostras, mais O(C) para as famílias e a ordenação; na parte de rastros, linear no número de spans da janela e da referência, mais um teste por atividade e por relação de chamada.
