#!/usr/bin/env python3
"""TORAI do RCAEval 1.8.0 nos casos multifonte do RCAEval com rastros (pós-hoc, fora do protocolo).

O artigo deixava o TORAI (Pham et al., 2026) como comparação futura: é o método multifonte sem rótulos de falha mais
próximo do nosso na tabela de posicionamento. O pacote traz a função `RCAEval.e2e.torai`, que combina métricas, séries
de logs e séries de rastros, agrupa os serviços por severidade (mistura gaussiana) e refina cada grupo com o RCD.

Entrada, como no `main.py` oficial com `--method torai --length 10` (o uso indicado em `docs/TORAI.md`):
- `simple_metrics.csv` sem as colunas `_latency-50` (no Train Ticket, só as colunas `ts-`), infinitos → NaN, `ffill`
  e 0; 300 linhas (1 s) antes e 300 depois do horário da injeção; `_latency-90` → `_latency`;
- `logts.csv`, `tracets_err.csv` e `tracets_lat.csv` (15 s): 20 linhas antes e 20 depois;
- `dataset` = `torai-ob` ou `torai-tt`.
Só o RE2 distribui as séries de logs e de rastros prontas (`logts.csv`, `tracets_*.csv`); o RE3 não as tem e fica de
fora, para não rodar o método com uma entrada montada por nós. O TORAI recebe o horário da injeção, como os demais
comparadores do pacote.

Precisa do `causal-learn` 0.1.2.3 com os arquivos de `lib/causallearn` do repositório do RCAEval (`script/link.sh`),
como o RCD. Semente 0 (a mistura gaussiana usa `random_state=0`), no máximo `TEMPO_MAX` s por caso; ranking vazio
(exceção ou tempo esgotado) conta como erro.

Uso:
  python comparadores_torai.py --rodar [--jobs 24] [--amostra 2]
  python comparadores_torai.py --relatorio        → resultado-comparador-torai.md
"""
from __future__ import annotations

import argparse
import contextlib
import io
import os
import pickle
import signal
import sys
import time
import warnings
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import robustez as R  # noqa: E402

CI, E2, O = R.CI, R.E2, R.O
SAIDA = os.path.join(O.CACHE, "outros-comparadores")
TEMPO_MAX = 900   # s por caso
LENGTH = 10       # min, como em docs/TORAI.md
SUITES = ("RE2-OB", "RE2-TT")


class _Esgotado(Exception):
    pass


def _alarme(*_: Any) -> None:
    raise _Esgotado


def entradas() -> list[str]:
    """Casos do RCAEval com rastros (unidades do `robustez.py`) das suítes com séries de logs e de rastros."""
    return [c for c in sorted(R.unidade_c(8)["baro"]) if c.split("/")[0] in SUITES]


def _janela(df: pd.DataFrame, inj: float, n: int) -> pd.DataFrame:
    return pd.concat([df[df["time"] < inj].tail(n), df[df["time"] >= inj].head(n)], ignore_index=True)


def carregar(caso: str) -> tuple[dict[str, pd.DataFrame], int, str]:
    suite, resto = caso.split("/", 1)
    pasta = os.path.join(CI.ORIGEM, suite, suite, resto)
    data = pd.read_csv(os.path.join(pasta, "simple_metrics.csv"))
    if "time.1" in data:
        data = data.drop(columns=["time.1"])
    data = data.loc[:, ~data.columns.str.endswith("_latency-50")]
    if suite.endswith("TT"):
        t = data["time"]
        data = data.loc[:, data.columns.str.startswith("ts-")]
        data["time"] = t
    data = data.replace([np.inf, -np.inf], np.nan).ffill().fillna(0)
    with open(os.path.join(pasta, "inject_time.txt")) as f:
        inj = int(f.readlines()[0].strip())
    data = _janela(data, inj, LENGTH * 60 // 2)
    data = data.rename(columns={c: c.replace("_latency-90", "_latency") for c in data.columns if c.endswith("_latency-90")})
    n = LENGTH * 4 // 2
    logts = _janela(pd.read_csv(os.path.join(pasta, "logts.csv")), inj, n)
    err = _janela(pd.read_csv(os.path.join(pasta, "tracets_err.csv")), inj, n)
    lat = _janela(pd.read_csv(os.path.join(pasta, "tracets_lat.csv")), inj, n)
    return {"metric": data, "logts": logts, "tracets_err": err, "tracets_lat": lat}, inj, "torai-" + suite[-2:].lower()


def _job(caso: str) -> tuple[str, list[str], str | None, float]:
    warnings.simplefilter("ignore")
    signal.signal(signal.SIGALRM, _alarme)
    t0 = time.time()
    try:
        from RCAEval.e2e.torai import torai  # noqa: PLC0415
        data, inj, ds = carregar(caso)
        np.random.seed(0)
        signal.alarm(TEMPO_MAX)
        try:
            with contextlib.redirect_stdout(io.StringIO()):   # o pacote imprime o número de grupos
                ranks = torai(data, inj, dataset=ds, anomalies=None, dk_select_useful=False)["ranks"]
        finally:
            signal.alarm(0)
        ordem: list[str] = []
        for r in ranks:
            s = str(r).split("_", 1)[0]
            s = "frontend" if s == "frontendservice" else s
            if s not in ordem:
                ordem.append(s)
        return caso, ordem, None, time.time() - t0
    except _Esgotado:
        return caso, [], f"tempo esgotado (> {TEMPO_MAX} s)", time.time() - t0
    except Exception as exc:  # noqa: BLE001
        return caso, [], f"{type(exc).__name__}: {str(exc)[:80]}", time.time() - t0


def rodar(jobs: int, amostra: int | None) -> None:
    os.makedirs(SAIDA, exist_ok=True)
    arq = os.path.join(SAIDA, "torai.pkl")
    feito: dict[str, tuple[list[str], str | None, float]] = {}
    if os.path.exists(arq):
        with open(arq, "rb") as f:
            feito = pickle.load(f)
    todos = entradas()
    if amostra:
        todos = [c for s in SUITES for c in [x for x in todos if x.startswith(s)][:amostra]]
    pend = [c for c in todos if c not in feito]
    print(f"torai: {len(feito)} feitos, {len(pend)} pendentes", flush=True)
    from concurrent.futures import ProcessPoolExecutor, as_completed  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        futs = [ex.submit(_job, c) for c in pend]
        for i, fu in enumerate(as_completed(futs), 1):
            c, rk, err, dt = fu.result()
            feito[c] = (rk, err, dt)
            if amostra:
                print(f"  {c}: {dt:.0f} s, {rk[:3]} {err or ''}", flush=True)
            if i % 10 == 0 or i == len(futs):
                with open(arq + ".tmp", "wb") as f:
                    pickle.dump(feito, f)
                os.replace(arq + ".tmp", arq)
                print(f"torai: {i}/{len(futs)}", flush=True)


def relatorio() -> int:
    u = R.unidade_c(8)
    with open(os.path.join(SAIDA, "torai.pkl"), "rb") as f:
        res = pickle.load(f)
    norm = R.cal_original(u)["norm"]
    primeiro: dict[str, dict] = {}
    for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
        if x["periodo"] == "falha" and x["esp"] and x["caso"] not in primeiro and x["caso"].split("/")[0] in SUITES:
            primeiro[x["caso"]] = x
    esp = {c: x["esp"] for c, x in primeiro.items()}
    rks = {"nosso": {c: E2.ordem_completa(x["f"], norm.get(x["grupo"], {})) for c, x in primeiro.items()},
           "TORAI": {c: res.get(c, ([], "ausente", 0.0))[0] for c in primeiro}}
    for b in ("BARO", "N-Sigma"):
        rks[b] = {c: (u["baro"].get(c) or {}).get(b, []) for c in primeiro}

    def acs(rk: dict[str, list[str]], cs: list[str]) -> str:
        a = {k: np.mean([esp[c] in rk[c][:k] for c in cs]) for k in range(1, 6)}
        return f"{a[1]:.3f} / {a[3]:.3f} / {np.mean(list(a.values())):.3f}"

    rng = np.random.default_rng(2026102401)
    out = ["# TORAI oficial nos casos multifonte do RCAEval com rastros (pós-hoc, fora do protocolo)", "",
           f"`comparadores_torai.py`. RCAEval 1.8.0, entrada do `main.py` com `--length {LENGTH}` (5 min antes e 5 depois "
           f"do horário da injeção); semente 0; no máximo {TEMPO_MAX} s por caso. Ranking vazio conta como erro. O nosso "
           "método: 1º instante de falha, ordem completa (como na Tabela de comparação com a literatura). Só o RE2 "
           "(Online Boutique e Train Ticket) distribui as séries de logs e de rastros que o TORAI lê.", "",
           "## AC@1 / AC@3 / Avg@5 por caso, no nível de serviço", "",
           "| suíte | casos | nosso | BARO | N-Sigma | TORAI | vazios TORAI |", "|---|---|---|---|---|---|---|"]
    for s in (*SUITES, "RE2 (as duas)"):
        cs = [c for c in esp if s.startswith("RE2 (") or c.startswith(s)]
        out.append(f"| {s} | {len(cs)} | {acs(rks['nosso'], cs)} | {acs(rks['BARO'], cs)} | {acs(rks['N-Sigma'], cs)} | "
                   f"{acs(rks['TORAI'], cs)} | {sum(1 for c in cs if not rks['TORAI'][c])} |")
    a1 = {k: {c: float(rks[k][c][:1] == [esp[c]]) for c in esp} for k in rks}
    d, p = R._perm_ac(a1["nosso"], a1["TORAI"], rng)
    r3 = (R.ler("resultados") or {}).get("R3", [])
    # 3 do N-Sigma, 6 do CIRCA e do RCD e 4 do MicroRank e do TraceRCA (relatórios anteriores), mais esta
    fixos = [0.0050, 0.4280, 0.0592] + [0.0001] * 6 + [0.0001] * 4
    ps = [c["p"] for c in r3] + fixos + [p]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    out += ["", f"## Permutação pareada em AC@1 (10.000; Holm sobre {len(ps)} = R3 + 3 do N-Sigma + 6 do CIRCA e do RCD "
            "+ 4 do MicroRank e do TraceRCA + 1)", "", "| casos | Δ AC@1 (nosso − TORAI) | p | p Holm |", "|---|---|---|---|",
            f"| {len(esp)} | {d:+.3f} | {p:.4f} | {holm[-1]:.4f} |"]
    ok = [c for c in esp if rks["TORAI"][c]]
    if ok and len(ok) < len(esp):
        ds, ps_ = R._perm_ac({c: a1["nosso"][c] for c in ok}, {c: a1["TORAI"][c] for c in ok}, rng)
        out += ["", "## Só os casos em que o TORAI terminou", "", "| casos | AC@1 / AC@3 / Avg@5 nosso | TORAI | Δ AC@1 | p |",
                "|---|---|---|---|---|", f"| {len(ok)} de {len(esp)} | {acs(rks['nosso'], ok)} | {acs(rks['TORAI'], ok)} | "
                f"{ds:+.3f} | {ps_:.4f} |"]
    # validação contra a documentação do método (docs/TORAI.md do RCAEval): Avg@5 do TORAI por tipo de causa
    tipos = sorted({primeiro[c]["tipo"] for c in esp})
    out += ["", "## Avg@5 do TORAI por tipo de causa (validação contra a documentação do RCAEval)", "",
            "| suíte | " + " | ".join(tipos) + " |", "|---|" + "---|" * len(tipos)]
    for s in SUITES:
        cel = []
        for t in tipos:
            cs = [c for c in esp if c.startswith(s) and primeiro[c]["tipo"] == t]
            cel.append(f"{np.mean([np.mean([esp[c] in rks['TORAI'][c][:k] for c in cs]) for k in range(1, 6)]):.2f} "
                       f"({len(cs)})" if cs else "—")
        out.append(f"| {s} | " + " | ".join(cel) + " |")
    tempos = [res[c][2] for c in esp if c in res]
    falhas: dict[str, int] = {}
    for c in esp:
        e = res.get(c, ([], "ausente", 0.0))[1]
        if e:
            falhas[e] = falhas.get(e, 0) + 1
    out += ["", "## Tempo e falhas", "", f"- tempo por caso: mediana {np.median(tempos):.0f} s, máximo {max(tempos):.0f} s "
            f"({len(tempos)} casos)", *([f"- {e}: {n}×" for e, n in sorted(falhas.items())] or ["- nenhuma falha"])]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-comparador-torai.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rodar", action="store_true")
    ap.add_argument("--relatorio", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    ap.add_argument("--amostra", type=int)
    a = ap.parse_args()
    if a.rodar:
        rodar(a.jobs, a.amostra)
    if a.relatorio:
        return relatorio()
    return 0


if __name__ == "__main__":
    sys.exit(main())
