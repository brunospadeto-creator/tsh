#!/usr/bin/env python3
"""Números do artigo que não tinham relatório próprio (análise adicional, só leitura dos caches; sem recálculo do método).

1. Instantes normais / com causa por conjunto (`tab:bases`), dos caches do `operacional.py`.
2. Frações dos sorteios de baseline do R1 abaixo do critério (S5), do `robustez/R1.pkl`.
3. OpenRCA Market sem os casos cuja falha anterior (qualquer registro do `record.csv`, inclusive em nó) começou menos
   de 20 min antes (S6): F1@1 e AC@1 do HMR e AC@1 do BARO, com a calibração registrada (`robustez.cal_original`).

Uso: `complementos.py` → `resultado-complementos.md`.
"""
from __future__ import annotations

import os
import pickle
import sys
import warnings
from collections import defaultdict

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import operacional as OP  # noqa: E402
import robustez as R  # noqa: E402

LIMITE_ANTERIOR = 20 * 60


def contagens() -> list[str]:
    d: dict = {}
    for parte in ("publicas", "teastore"):
        with open(os.path.join(OP.SAIDA, f"{parte}.pkl"), "rb") as f:
            d.update(pickle.load(f))
    out = ["| conjunto | casos com instantes com causa | instantes normais | instantes com causa |", "|---|---|---|---|"]
    for b in OP.BASES:
        pc = d[b]["nosso"]
        out.append(f"| {b} | {sum(1 for c in pc.values() if c['ne'])} | {sum(c['nn'] for c in pc.values())} | "
                   f"{sum(c['ne'] for c in pc.values())} |")
    return out


def fracoes_r1() -> list[str]:
    r1 = R.ler("R1")
    a = [x["g-m∨t|mf"] for x in r1["A"]]
    t = [x["g-m∨t∨k|mfk@B"] for x in r1["TeaStore"]]

    def fr(v: list, i: int, lim: float, acima: bool = False) -> str:
        n = sum(1 for x in v if (x[i] > lim if acima else x[i] < lim))
        return f"{n} de {len(v)} ({n / len(v):.1%})"
    return ["| conjunto | F1@1 < 0,6 | F1@2 < 0,7 | alarme > 20% |", "|---|---|---|---|",
            f"| RCAEval inédito (HMR) | {fr(a, 0, 0.6)} | {fr(a, 1, 0.7)} | {fr(a, 2, 0.2, True)} |",
            f"| TeaStore inédito (HTS) | {fr(t, 0, 0.6)} | {fr(t, 1, 0.7)} | {fr(t, 2, 0.2, True)} |"]


def market_sem_contaminados() -> list[str]:
    plano = R.O._ad("openrca-market").casos()
    inicios: dict[str, list[float]] = defaultdict(list)
    for cb in {v["cb"] for v in plano.values()}:
        for r in R.O._ad("openrca-market")._registros(cb):
            inicios[cb].append(float(r["timestamp"]))
    contaminados = set()
    for c, v in plano.items():
        if "falha" not in v:
            continue
        t = v["falha"][0]
        if any(0 < t - x < LIMITE_ANTERIOR for x in inicios[v["cb"]]):
            contaminados.add(c)
    u = R.unidade_m(1)
    cal = R.cal_original(u)
    pc = R.avaliar_orig(u, cal)["g-m∨t|mf"]
    casos = sorted(c for c in pc if pc[c]["ne"])
    limpos = [c for c in casos if c not in contaminados]
    nos, baro = R.ac1_casos(u, cal["norm"])

    def ac(dd: dict, cs: list[str]) -> float:
        return sum(dd[c] for c in cs) / len(cs)
    # o F1@1 inclui os instantes normais (casos sem instante com causa) nos dois recortes
    normais = [c for c in pc if not pc[c]["ne"]]
    f_todos = R.f1([pc[c] for c in casos + normais])
    f_limpos = R.f1([pc[c] for c in limpos + normais])
    return [f"Casos de falha: {len(casos)}; com falha anterior a menos de 20 min: "
            f"{sum(1 for c in casos if c in contaminados)}.", "",
            "| recorte | casos | F1@1 HMR | AC@1 HMR | AC@1 BARO |", "|---|---|---|---|---|",
            f"| todos | {len(casos)} | {f_todos:.3f} | {ac(nos, casos):.3f} | {ac(baro, casos):.3f} |",
            f"| sem os contaminados | {len(limpos)} | {f_limpos:.3f} | {ac(nos, limpos):.3f} | {ac(baro, limpos):.3f} |"]


def main() -> int:
    warnings.simplefilter("ignore", RuntimeWarning)
    out = ["# Números complementares do artigo (análise adicional, só leitura dos caches)", "",
           "`complementos.py`. Nenhum parâmetro do método é recalculado: as contagens vêm dos caches do "
           "`operacional.py`, as frações do `robustez/R1.pkl` e o recorte do Market da unidade e da calibração "
           "registradas do `robustez.py`.", "",
           "## 1. Instantes por conjunto (`tab:bases`)", "", *contagens(), "",
           "## 2. Sorteios de baseline do R1 abaixo do critério (S5)", "", *fracoes_r1(), "",
           "## 3. OpenRCA Market sem os casos com falha anterior recente (S6)", "", *market_sem_contaminados()]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-complementos.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
