# Protocolo completo do `g-m∨t|mf` — TeaStore, RCAEval e OpenRCA Market (pré-registro, 18/10/2026)

Pedido do usuário: registrar e executar o protocolo completo, **todas as partes**. O Eadro SN fica fora
(`../RESULTADO.md` §13). Este documento é commitado **antes** de qualquer execução das partes confirmatórias A e B.
O que foi visto até aqui está no `PROTOCOLO.md`: as iterações 1–5 e a generalização. Nenhum número de A ou de B foi
visto.

## 1. Hipótese e método congelado

**Hipótese:** o `g-m∨t|mf` mantém, em dados que nunca viu, a meta do ciclo: **F1@1 ≥ 0,6 e F1@2 ≥ 0,7** com portão,
com **alarme ≤ 20%**.

**Método:** congelado no commit deste pré-registro. Os arquivos ficam como estão:

| arquivo | sha256 (12) | papel |
|---|---|---|
| `bases-externas/metricas-rz/ciclo.py` | `40d86a363ed2` | `escores(familia=True)`, `normalizadores`, `tau_gate`, `ranking_rzl`, `_u` |
| `bases-externas/metricas-rz/outras.py` | `35de2d920c9a` | adaptadores Eadro e Market e portão de traces nas bases abertas |
| `bases-externas/baseline-dinamica/calib.py` | `8703dc7a6b43` | λ e q pela baseline (`d9-b+c@0.01`) |
| `bases-externas/baseline-dinamica/rcaeval.py` | `0d05ed8ff492` | decisões do portão de traces no RCAEval |
| `experimento-falhas/teastore/stage3-online/replay/metricas_rz_teastore.py` | `4a1293f3a0ea` | adaptador TeaStore (métricas por serviço) |
| `experimento-falhas/teastore/stage3-online/replay/baseline_dinamica.py` | `d9edbf430618` | portão de traces no TeaStore (`d9-b+c@0.01`, `d9-k-b+c@0.01`) |

**Portões:**
- `g-m`: `max_v s(v) ≥ τ`, com τ da baseline e FP_ALVO 0,05;
- `t`: `d9-b+c@0.01`;
- decisão: `g-m` OU `t`.

**Ranking:** `m-rzf`.

**O que pode mudar depois deste commit:**
- **código novo, só de entrada:** o adaptador do RCAEval só com métricas (§3) e a troca de conjunto nos scripts de
  medida do TeaStore (§6). Eles leem dados e escolhem instantes e casos, sem nenhuma regra de decisão ou de ranking;
- **correções:** só de leitura de dado (formato, relógio, nome de serviço), achadas na rodada de teste (§5), e por
  emenda commitada antes da rodada oficial.

## 2. Material

| parte | base / conjunto | casos | já visto pelo método? | papel |
|---|---|---|---|---|
| **A** | RCAEval **RE1-OB, RE1-SS, RE1-TT** (`data.csv`, só métricas, 5 tipos × 25) | 375 | não | **confirmatório** |
| **A** | RCAEval **RE2-SS** (`simple_metrics.csv`, só métricas, 6 tipos × 15) | 90 | não | **confirmatório** |
| **A** | RCAEval **RE3-SS** (`simple_metrics.csv`; traces em 13, não usados) | 30 | não | **confirmatório** |
| **B** | TeaStore **lote novo**, 4 lotes × 6 cenários (h1–h6 × 2, g1–g6 × 2), sementes 20261041–44 | 24 | não | **confirmatório** |
| C | RCAEval RE2/RE3 OB e TT (com traces) | 240 | sim (ciclo) | descritivo |
| C | OpenRCA Market (2 cloudbeds, 2 dias) | 77 | sim | descritivo |
| C | TeaStore definitiva | 24 | sim | descritivo |

O Market não tem dias inéditos, e os casos do RCAEval com traces já foram usados no ciclo. Por isso as duas bases
só entram como descritivas.

Na parte A não há traces: o RE1 e o Sock Shop não têm. O canal `t` fica ausente e nunca abre, e o `g-m∨t|mf` se
reduz ao `g-m|mf`. A parte A testa a **metade de métricas** do método; a parte B testa o método inteiro.

## 3. Parte A — RCAEval inédito (regras fixas)

| item | regra |
|---|---|
| leitura | `data.csv` (RE1) ou `simple_metrics.csv` (RE2-SS, RE3-SS); colunas `<serviço>_<família>` (o `rsplit("_", 1)` do `ciclo.escores`); `time` em s; `inject_time.txt` |
| gabarito | o serviço do nome da pasta (`<serviço>_<tipo>`); o tipo é o sufixo |
| instantes de falha | de `injeção + 120 s` até `min(fim, injeção + 600 s)`, passo de 60 s |
| instantes normais | de `início + 270 s` até a injeção, passo de 60 s |
| referência | falha: `[injeção − 600, injeção)`; normal: `[t − 720, t − 120)`; as duas cortadas no início do caso (no RE1 o pré-falha tem ≥ 360 s) |
| baseline | por suíte, casos sorteados com a semente `20261019-<suíte>`, na ordem do sorteio, até somar **≥ 20 janelas normais**, com no mínimo 5 casos. Os instantes normais desses casos ficam fora do alarme, mas os de falha entram |
| τ e N | `ciclo.normalizadores` (percentil 95) e `ciclo.tau_gate` (FP 0,05) sobre as janelas da baseline de cada suíte |
| comparadores | `m-rz` (iteração 1: z bruto, guarda numérica antiga) e `cpu-max` (só a família `cpu`, maior z), os dois com o mesmo portão `g-m` |
| resultado primário | **um só**, juntando as 5 suítes (495 casos menos os 15 da rodada de teste) |
| secundários | por suíte, por sistema (OB, SS, TT) e por tipo de falha: descritivos |

## 4. Parte B — TeaStore, lote novo (regras fixas)

- **Coleta:** `experimento-falhas/teastore/run-metricas-rz-lotes.sh`, cópia do driver da coleta inédita com:
  - sementes 20261041–44 (nunca usadas);
  - baseline fixa 32c273a6, a mesma da definitiva;
  - durações do congelamento;
  - lote abortado recomeça inteiro com a mesma semente, até 3 tentativas.
- O harness, a imagem, o `congelamento.json` e o `stage3_config` não mudam.
- **O cluster é ligado pelo usuário.** O driver só começa depois disso.
- **Medida offline,** idêntica à da definitiva, com o conjunto trocado para os 4 runs novos:
  - portão de traces: `baseline_dinamica.py`, com λ e q da 32c273a6;
  - métricas: `metricas_rz_teastore.py`, com a baseline das métricas no trecho da sessão antes do normal medido,
    como na definitiva;
  - comparadores pelos mesmos scripts: d9-k, d9-k+a, v-cons-b e d9-k-b+c@0.01;
  - instantes, D0.4 e gabarito: os da definitiva.
- Cenário que não passa no verificador da falha não é coletado e fica registrado. Lote que não fecha em 3
  tentativas: o resultado sai com os lotes completos, e a ausência é declarada.

## 5. Rodada de teste (antes das oficiais)

- **A:** 15 casos sorteados (semente `20261019-teste`, 3 por suíte), com saída separada. Confere:
  - instantes por caso;
  - escores finitos;
  - serviço do gabarito presente nas colunas;
  - janelas de baseline ≥ 20 por suíte.

  **O F1 não é lido.** Os 15 casos saem da leitura oficial.
- **B:** o pré-voo do `coleta-lote-stage3.sh`, que confere o congelamento, e a checagem dos pacotes contínuos do
  1º cenário. Os resultados não são lidos.

## 6. Leitura fixada antes de rodar

| parte | confirma se | não confirma se |
|---|---|---|
| **A** (480 casos) | F1@1 ≥ 0,6 **e** F1@2 ≥ 0,7 **e** alarme ≤ 20%, nos valores pontuais | qualquer um dos três falha |
| **B** (24 cenários) | idem | idem |
| C | — (só reportado) | — |

- Comparação com os anteriores, só descritiva:
  - McNemar no top-1 com portão: `g-m∨t|mf` contra d9-k e d9-k+a (B), e contra `m-rz` e `cpu-max` (A);
  - ΔF1@1 com IC por bootstrap.
- O intervalo de confiança é reportado, mas não entra no critério.
- Uma hipótese primária por parte, sem correção por múltiplas comparações.
- Nada é recalibrado com A ou B. O resultado sai como estiver, inclusive se não confirmar.

## 7. Etapas

| # | etapa | onde roda | tempo |
|---|---|---|---|
| 1 | commit e push deste pré-registro e do driver | — | 5 min |
| 2 | adaptador A (`confirmatorio_a.py`) | offline | ~40 min |
| 3 | rodada de teste A (15 casos, sem F1) | offline | ≤ 10 min |
| 4 | **rodada oficial A** → `resultado-confirmatorio-A.md` | offline | ≤ 10 min |
| 5 | descritivos C com o código congelado → `resultado-descritivo-C.md` | offline | ~5 min |
| 6 | **coleta B** (usuário liga o cluster; driver em segundo plano) | cluster | ~29 h (4 × ~7,3 h) |
| 7 | **rodada oficial B** → `resultados/protocolo-metricas-rz/resultado-confirmatorio-B.md` | offline | ~20 min |
| 8 | `RESULTADO.md`, `session.md`, commit | — | 15 min |

## Emenda 1 (18/10/2026, antes de qualquer execução da parte B): sem coleta nova

Decisão do usuário: não coletar de novo, e aproveitar toda a coleta já feita no TeaStore e todas as bases definidas.
A parte A já rodou e confirmou (`resultado-confirmatorio-A.md`); esta emenda não a altera.

**B passa a ser B′, confirmatório nos cenários gravados que o `g-m∨t|mf` nunca viu:**

| origem | cenários | baseline | estado |
|---|---|---|---|
| dev com pacotes de métricas: `20261013T051436Z` (h3) e `20261013T061915Z` / `20261013T143247Z` (g1–g6 cada) | 13 | 547ba505 | vistos por outros métodos, **nunca** pelo `g-m∨t\|mf` |
| 1ª tentativa abortada do lote C2 da definitiva (`20261016T075241Z`: h1, h3, h4, h5) | 4 | 32c273a6 | nunca analisados por nenhum método. O h2 fica fora porque não tem período de referência (`AI.periodos` vazio), a regra de sempre |

Os 41 cenários do dev sem pacotes contínuos e os 18 do confirmatório (nenhum com pacotes) não têm série de métricas.
Por isso não entram.

**Medida em B′:** os executores já existentes, em modo confirmatório (D0.4 na hora), com saída em
`resultados/protocolo-metricas-rz/b-ineditos/`:
- `paridade_solucoes.rodar_caso`: d9-k e v-cons-b (os artefatos da baseline de cada coleção já existem);
- `hibrido_d9a.rodar_caso`: d9-k+a e d2c-r;
- `baseline_dinamica.rodar_caso`: d9-b+c@0.01 e d9-k-b+c@0.01. O λ e o q saem da baseline de cada coleção; a
  547ba505 é calibrada pela mesma regra;
- métricas: as funções do `metricas_rz_teastore.py`, com a baseline das métricas no trecho de cada uma das 17
  sessões antes do normal medido (a regra da definitiva).

Os instantes são os comuns a todos os modos.

**Rodada de teste de B′:** checagem das séries de métricas por cenário (serviços, escores finitos, gabarito presente,
janelas de baseline), sem F1.

**Leitura de B′:** a mesma do §6: F1@1 ≥ 0,6 **e** F1@2 ≥ 0,7 **e** alarme ≤ 20%. A comparação com d9-k, d9-k+a,
v-cons-b, d2c-r e d9-k-b+c@0.01 é descritiva (McNemar e ΔF1@1).

**Descritivos C completos, para subsidiar o artigo,** em todas as bases (RCAEval com traces, Market, TeaStore
definitiva e B′):
- **ablação:** `g-m|mf` (só métricas), `d9-b+c@0.01|mf` (só traces) e `m-rzf` (sem portão);
- **comparadores** nos mesmos instantes;
- **tabela consolidada final:** as bases, as partes confirmatórias e descritivas e as ressalvas (método desenhado no
  RCAEval; adaptador do TeaStore corrigido na definitiva; A testa só a metade de métricas).

O driver `run-metricas-rz-lotes.sh` fica no repositório e não é executado.

## Resultados (18/10/2026)

| parte | F1@1 [IC 95%] | F1@2 | alarme | leitura fixada |
|---|---|---|---|---|
| A — RCAEval inédito (480 casos, só métricas) | 0.614 [0.572–0.654] | 0.704 | 6.6% | **CONFIRMA** |
| B′ — TeaStore, 17 cenários inéditos | 0.601 [0.374–0.800] | **0.656** | 15.3% | **NÃO CONFIRMA** (F1@2 < 0,7) |

- **B′:** os comparadores com traces e K8s ficam acima, mas nenhum McNemar é significativo com 17 cenários: d9-k+a
  0.959, d9-k 0.921, v-cons-b 0.885.
- **Pós-hoc, não muda a leitura:** em B′ o `g-m|mf` sozinho dá 0.647 / 0.706 com alarme de 0%. O alarme de 15,3% do
  `g-m∨t|mf` vem todo do portão de traces (`d9-b+c@0.01`).
- Arquivos: `resultado-confirmatorio-A.md`, `resultados/protocolo-metricas-rz/b-ineditos/resultado-confirmatorio-B.md`
  e `resultado-descritivo-C.md`.

## Emenda 2 (18/10/2026, antes de rodar qualquer item abaixo): comparação com a literatura, métricas usuais, sensibilidade e método novo com eventos K8s

Pedido do usuário: acatar as sugestões (BARO e AC@k), deixar as validações mais completas e acrescentar a
contribuição de que eventos K8s melhoram a descoberta, num método novo aplicado ao TeaStore com este protocolo.
**Nada do que já foi lido (A, B′, C) é recalculado com outra regra.** Os itens abaixo são novos e nenhum foi rodado.

### E2.1 Comparadores publicados (código oficial)

- **BARO** (Pham et al., FSE 2024) e **N-Sigma**, pela implementação oficial do pacote `RCAEval` 1.8.0
  (`RCAEval.e2e.baro` e `nsigma`, sem alteração; instalado sem dependências no venv do experimento).
- Entrada: o **mesmo arquivo de métricas** que o `g-m∨t|mf` usa (`data.csv`, `simple_metrics.csv`, a série por
  serviço do Market e do TeaStore), com a coluna `time`. `inject_time` = a injeção do caso (no TeaStore, o fim do
  normal; no Market, o `timestamp` do registro).
- O BARO e o N-Sigma recebem o horário da injeção (oráculo, como no RCAEval). O `g-m∨t|mf` não recebe; só a
  referência dos instantes de falha usa o pré-falha, a mesma regra de todos os métodos do avaliador.
- **Janela de dados por caso:**
  - RCAEval: o arquivo inteiro;
  - Market: `[injeção − 600, injeção + 600)`;
  - TeaStore: da 1ª amostra da sessão até o fim do período estável.
- Ranking de serviço (nível "coarse" do RCAEval): o serviço de cada coluna (`rsplit("_", 1)[0]`), na ordem da 1ª
  aparição.
- **Validação da chamada:** o BARO no RE2-TT deve ficar perto do publicado (Tabela 6 do RCAEval: AC@1 0.67, AC@3
  0.82, Avg@5 0.80). A diferença é reportada como estiver; o arquivo de métricas pode diferir do usado no artigo.

### E2.2 Métricas usuais

**Por caso:** AC@1, AC@3 e Avg@5 (média de AC@1..AC@5), em nível de serviço.

| método | ranking usado no caso |
|---|---|
| BARO e N-Sigma | uma vez, com todos os dados pós-injeção |
| `g-m∨t\|mf` | ordem completa do `m-rzf` (os escores `_u`, sem corte em 3) no **1º instante de falha** (injeção + 120 s, só os primeiros 120 s de falha). Também no **último instante**, como secundário |
| métodos de traces | o ranking forçado no 1º instante. Avg@5 não se aplica (top-3); vai AC@1 e AC@3 |

**Por instante:** as tabelas F1 continuam, com uma coluna AC@3 a mais (o "sabendo" top-3).

**Comparação controlada do ranking:** `BARO-janela` aplica o `RobustScaler` do BARO (máximo do escore na janela de
120 s, com a mesma referência do instante) dentro do portão `g-m`, contra o `m-rzf`. Isso isola a contribuição da
normalização pela baseline e da reserva pela família.

**Onde se aplica:** A (480), C (RCAEval 240, Market 77, TeaStore definitiva 24) e B′ (17). Tudo descritivo: a meta
de A e B′ já foi lida.

### E2.3 Sensibilidade do FP_ALVO (descritiva)

FP_ALVO do `g-m` em 0,01, 0,05 (registrado) e 0,10. O portão de traces fica em 0,01. Em todas as bases.

### E2.4 Método novo: `g-m∨t∨k|mfk`, com eventos K8s de sintoma

**Definição,** igual à extensão que transformou a d9 na d9-k, sem parâmetro novo:
- **portão:** `g-m` OU `d9-b+c@0.01` OU **evento K8s de sintoma** num serviço. O serviço é dado por
  `d9k.servico_k8s(ent, d9k._cfg(sis))`, sobre os eventos limpos (Fase 0: BackOff, OOMKilled, Unhealthy, Evicted)
  vistos até o instante, como na d9-k;
- **ranking:** o `m-rzf`, com o serviço K8s promovido ao 1º lugar (`d9k._promover(rk, svc, 3)`).

Só o TeaStore tem eventos K8s; nas bases abertas o método é idêntico ao `g-m∨t|mf`.

**Conjuntos:** B′ (17 cenários) e definitiva (24). O método novo nunca rodou em nenhum dos dois.

**Hipóteses e leitura fixada:**

| hipótese | conjunto | confirma se |
|---|---|---|
| **H-k1: eventos K8s melhoram a descoberta** | B′ + definitiva (41 cenários, pareado com o `g-m∨t\|mf` nos mesmos instantes) | ΔF1@1 > 0 **e** IC 95% (bootstrap de cenário, 2000 reamostragens) todo acima de 0 |
| **H-k2: o método novo atinge a meta** | B′ (17, inéditos) | F1@1 ≥ 0,6 **e** F1@2 ≥ 0,7 **e** alarme ≤ 20% |

**Descritivos:**
- definitiva sozinha e B′ sozinha;
- McNemar `g-m∨t∨k|mfk` contra `g-m∨t|mf`, d9-k e d9-k+a;
- a mesma evidência nos métodos de traces já medidos: d9-k contra d9, e d9-k+a contra d9+a.

### E2.5 Rodadas

1. Teste ≤ 10 min, sem ler resultados:
   - o BARO roda em 3 casos por base e devolve serviços do gabarito;
   - o `servico_k8s` é calculado nos 41 cenários, com contagem de instantes com sintoma.
2. Oficial, em uma ou duas passadas: `emenda2.py` (RCAEval e Market) e `replay/metricas_rz_k8s.py` (TeaStore).
3. Tabela consolidada para o artigo em `RESULTADO-ARTIGO.md`.

## Emenda 3 (18/10/2026, antes de rodar): robustez estatística — "foi sorte?"

Pedido do usuário: execuções repetidas, por até 9 h, para afirmar ou derrubar qualquer alegação de sorte. Tudo
offline. Sementes `20261019-R<n>-<i>`. A ordem é fixa (R1 → R8); há checkpoint por etapa e **teto de 9 h**. Se o
teto chegar, o relatório sai com as repetições completas de cada etapa, declaradas. O número de repetições não
muda depois de começar.

**Conclusões testadas:**

| conclusão | resultado lido |
|---|---|
| **K-A** | A atinge a meta (F1@1 ≥ 0,6, F1@2 ≥ 0,7, alarme ≤ 20%) |
| **K-B** | B′ com K8s (`g-m∨t∨k\|mfk`) atinge a meta |
| **K-k1** | K8s melhora (ΔF1@1 > 0 contra `g-m∨t\|mf`, 41 cenários) |
| **K-RC** | `g-m∨t\|mf` > d9 e d9+a no RCAEval com traces |
| **K-M** | `g-m∨t\|mf` > d9 no Market |

**Etapas:**

| # | pergunta | repetição | n | critério de robustez |
|---|---|---|---|---|
| R1 | sorte da baseline? | sorteia outra baseline e recalibra N, τ, λ e q do zero. RCAEval A: casos sorteados até ≥ 20 janelas e ≥ 5 casos; RCAEval C: 5 casos por suíte (os normais deles saem do alarme). Market: reamostragem com reposição das janelas do trecho de baseline de cada cloudbed. TeaStore: reamostragem das janelas antes do normal (métricas) e das janelas da baseline da coleção (λ e q) | 500 | a conclusão vale em ≥ 95% dos sorteios |
| R2 | sorte dos casos? | bootstrap de caso ou cenário | 10.000 | IC 95% e P(meta) reportados; K-A e K-B robustos se P(meta) ≥ 0,5 (descritivo) |
| R3 | sorte nas diferenças? | permutação pareada (troca do rótulo do método por caso), estatística ΔF1@1 ou ΔAC@1 | 10.000 × 12 comparações | p < 0,05 depois de Holm sobre as 12 |
| R4 | placebo do K8s | promove um serviço aleatório (uniforme entre os do TeaStore) nos mesmos instantes com evento K8s | 10.000 | ΔF1@1 real acima do percentil 95 do placebo |
| R5 | sorte das constantes? | janela {60, 120, 180} s × referência {300, 600, 900} s, só no lado das métricas (o portão de traces fica como está) | 9 | fração da grade em que cada conclusão vale (descritivo) |
| R6 | um grupo puxa a média? | deixa um grupo de fora (suíte, sistema, tipo de falha, cloudbed, lote, grupo h/g) | ~40 | nenhuma retirada isolada inverte a conclusão |
| R7 | sorte da divisão dev/holdout? | 1.000 divisões estratificadas novas no RCAEval C | 1.000 | percentil da queda observada (0.066) na distribuição |
| R8 | perto do acaso? | ranking aleatório com o mesmo portão | 10.000 | F1@1 real acima do percentil 99 |

**As 12 comparações de R3:**
- A: `g-m∨t|mf` × `m-rz|g-m`; × `cpu-max|g-m`; AC@1 por caso × BARO oficial;
- RCAEval C: × d9; × d9+a; AC@1 × BARO;
- Market: × d9; AC@1 × BARO;
- TeaStore (41): `g-m∨t∨k|mfk` × `g-m∨t|mf`; × d9-k+a; AC@1 × BARO; d9-k × d9.

**Aproximação declarada:** em R1, a decisão da d2c-b é `p_min ≤ q` com ranking não vazio pelo registro, sem refazer
o ranking exato.

**Leitura:** a conclusão que falhar em R1, R3 ou R4 passa a "não robusta" no artigo.

**Arquivos:** `robustez.py` (bases abertas e consolidação) e `replay/robustez_cache_teastore.py` (cache por instante
do TeaStore). Saída: `resultado-robustez.md`.
