# Emenda 3 — robustez estatística do `g-m∨t|mf` e do `g-m∨t∨k|mfk`

`PROTOCOLO-COMPLETO.md` emenda 3. Início 2026-10-19 12:35, teto 9 h; gerado 2026-10-19 12:35.

## Reprodução (calibração registrada)

| base | modo | F1@1 | F1@2 | alarme |
|---|---|---|---|---|
| A | g-m∨t|mf | 0.614 | 0.704 | 6.6% |
| RCAEval-C | g-m∨t|mf | 0.687 | 0.826 | 15.4% |
| Market | g-m∨t|mf | 0.428 | 0.602 | 16.5% |
| TeaStore | g-m∨t|mf | 0.557 | 0.682 | 10.2% |
| TeaStore B′ | g-m∨t|mf | 0.601 | 0.656 | 15.3% |
| TeaStore | g-m∨t∨k|mfk | 0.650 | 0.775 | 10.2% |
| TeaStore B′ | g-m∨t∨k|mfk | 0.710 | 0.765 | 15.3% |

Conclusões na calibração registrada: K-A = sim, K-RC = sim, K-M = sim, K-B = sim, K-k1 = sim

## R1 — sorteio de baseline

| base | sorteios | conclusão | fração em que vale | F1@1 mediana [2,5%–97,5%] |
|---|---|---|---|---|
| A | 500 | K-A | 86.8% (**não robusto**) | 0.663 [0.575–0.727] |
| RCAEval-C | 500 | K-RC | 100.0% (robusto) | 0.692 [0.648–0.713] |
| Market | 500 | K-M | 100.0% (robusto) | 0.352 [0.232–0.512] |
| TeaStore | 500 | K-B | 79.8% (**não robusto**) | 0.641 [0.612–0.665] |
| TeaStore | 500 | K-k1 | 100.0% (robusto) | 0.641 [0.612–0.665] |
| TeaStore B′ | 500 | F1@1 de g-m∨t∨k|mfk | — | 0.710 [0.668–0.743] |

## R2 — bootstrap de caso (10.000)

| base | modo | conjunto | n | F1@1 [IC 95%] | F1@2 IC 95% | P(meta) |
|---|---|---|---|---|---|---|
| A | g-m∨t|mf | todos | 479 | 0.614 [0.572–0.653] | 0.667–0.738 | 55.4% |
| RCAEval-C | g-m∨t|mf | todos | 240 | 0.687 [0.640–0.731] | 0.793–0.858 | 100.0% |
| Market | g-m∨t|mf | todos | 88 | 0.428 [0.332–0.524] | 0.509–0.683 | 0.0% |
| TeaStore | g-m∨t∨k|mfk | todos | 41 | 0.650 [0.508–0.782] | 0.656–0.884 | 75.6% |
| TeaStore | g-m∨t∨k|mfk | B′ | 17 | 0.710 [0.492–0.909] | 0.570–0.944 | 70.0% |
| TeaStore | g-m∨t|mf | todos | 41 | 0.557 [0.412–0.699] | 0.546–0.810 | 24.2% |

## R3 — permutação pareada (10.000 por comparação; Holm sobre as 12)

| base | medida | a | b | Δ (a − b) | p | p Holm | robusto |
|---|---|---|---|---|---|---|---|
| A | F1@1 | g-m∨t|mf | m-rz|g-m | +0.092 | 0.0001 | 0.0012 | sim |
| A | F1@1 | g-m∨t|mf | cpu-max|g-m | +0.129 | 0.0001 | 0.0012 | sim |
| A | AC@1 por caso | g-m∨t|mf (1º instante) | BARO oficial | +0.414 | 0.0001 | 0.0012 | sim |
| RCAEval-C | F1@1 | g-m∨t|mf | d9 (= d9-k) | +0.379 | 0.0001 | 0.0012 | sim |
| RCAEval-C | F1@1 | g-m∨t|mf | d9+a (= d9-k+a) | +0.338 | 0.0001 | 0.0012 | sim |
| RCAEval-C | AC@1 por caso | g-m∨t|mf (1º instante) | BARO oficial | +0.377 | 0.0001 | 0.0012 | sim |
| Market | F1@1 | g-m∨t|mf | d9 (= d9-k) | +0.274 | 0.0001 | 0.0012 | sim |
| Market | AC@1 por caso | g-m∨t|mf (1º instante) | BARO oficial | +0.429 | 0.0001 | 0.0012 | sim |
| TeaStore | F1@1 | g-m∨t∨k|mfk | g-m∨t|mf | +0.093 | 0.1222 | 0.1222 | não |
| TeaStore | F1@1 | g-m∨t∨k|mfk | d9-k+a | -0.321 | 0.0001 | 0.0012 | sim |
| TeaStore | AC@1 por caso | g-m∨t∨k|mfk (1º instante) | BARO oficial | -0.171 | 0.0165 | 0.0495 | sim |
| TeaStore | F1@1 | d9-k | d9 | +0.136 | 0.0343 | 0.0686 | não |

## R4 — placebo do K8s (serviço aleatório nos mesmos instantes)

ΔF1@1 real +0.093; placebo (10000 sorteios, 50 instantes com K8s): média -0.106, percentil 95 -0.088; p = 0.0001 → **robusto**.

## R5 — grade de constantes (janela × referência das métricas)

| janela | referência | K-A | K-B | K-M | K-RC | K-k1 | F1@1 por base |
|---|---|---|---|---|---|---|---|
| 60 | 300 | sim | não | sim | sim | sim | A 0.654; RCAEval-C 0.599; Market 0.335; TeaStore 0.624 |
| 60 | 600 | sim | sim | sim | sim | sim | A 0.614; RCAEval-C 0.661; Market 0.279; TeaStore 0.644 |
| 60 | 900 | sim | sim | sim | sim | sim | A 0.606; RCAEval-C 0.683; Market 0.407; TeaStore 0.644 |
| 120 | 300 | sim | não | sim | sim | sim | A 0.623; RCAEval-C 0.634; Market 0.331; TeaStore 0.649 |
| 120 | 600 | sim | sim | sim | sim | sim | A 0.614; RCAEval-C 0.687; Market 0.428; TeaStore 0.650 |
| 120 | 900 | não | sim | sim | sim | sim | A 0.595; RCAEval-C 0.711; Market 0.438; TeaStore 0.650 |
| 180 | 300 | sim | sim | sim | sim | sim | A 0.631; RCAEval-C 0.606; Market 0.365; TeaStore 0.648 |
| 180 | 600 | sim | sim | sim | sim | sim | A 0.633; RCAEval-C 0.677; Market 0.307; TeaStore 0.604 |
| 180 | 900 | sim | sim | sim | sim | sim | A 0.617; RCAEval-C 0.699; Market 0.323; TeaStore 0.599 |

Fração da grade em que vale: K-A 89%, K-B 78%, K-M 100%, K-RC 100%, K-k1 100%

## R6 — deixa um grupo de fora

76 recortes; 14 invertem alguma conclusão.

| base | fora | n casos | conclusões |
|---|---|---|---|
| A | grupo=RE1-OB | 358 | K-A=não |
| A | grupo=RE2-SS | 393 | K-A=não |
| A | grupo=RE3-SS | 453 | K-A=não |
| A | sistema=OB | 358 | K-A=não |
| A | sistema=SS | 244 | K-A=não |
| A | tipo=disk | 393 | K-A=não |
| A | tipo=f1 | 472 | K-A=não |
| A | tipo=f3 | 470 | K-A=não |
| A | tipo=mem | 393 | K-A=não |
| A | tipo=socket | 465 | K-A=não |
| TeaStore | grupo=B′ | 24 | K-B=não, K-k1=sim |
| TeaStore | sistema=g | 17 | K-B=sim, K-k1=não |
| TeaStore | sistema=h | 24 | K-B=não, K-k1=sim |
| TeaStore | tipo=g4-db-memory-limit | 37 | K-B=sim, K-k1=não |

## R7 — divisões dev/holdout aleatórias (RCAEval C, 1.000)

Queda observada dev − holdout = +0.069; percentil 96.3 da distribuição (5%–95%: -0.071 a +0.061) → **acima do esperado: sinal de ajuste ao dev**.

## R8 — acaso (ranking aleatório, mesmo portão; 10.000)

| base | modo | F1@1 real | acaso média | acaso p99 | acima do p99 |
|---|---|---|---|---|---|
| A | g-m∨t|mf | 0.614 | 0.038 | 0.047 | sim |
| RCAEval-C | g-m∨t|mf | 0.687 | 0.045 | 0.056 | sim |
| Market | g-m∨t|mf | 0.428 | 0.067 | 0.094 | sim |
| TeaStore | g-m∨t∨k|mfk | 0.650 | 0.139 | 0.195 | sim |

