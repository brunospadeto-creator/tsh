# CIRCA e RCD oficiais nos mesmos casos (pós-hoc, fora do protocolo)

`outros_comparadores.py`. RCAEval 1.8.0; entrada igual à do BARO e do N-Sigma (`emenda2.oficiais`); semente 0. Ranking vazio conta como erro. O nosso método: 1º instante de falha, ordem completa (como na Tabela de comparação com a literatura). CausalRCA fora: > 25 min num caso do RE1-OB.

## AC@1 / AC@3 / Avg@5 por caso, no nível de serviço

| conjunto | casos | nosso | BARO | N-Sigma | CIRCA | RCD | vazios CIRCA | vazios RCD |
|---|---|---|---|---|---|---|---|---|
| A | 474 | 0.709 / 0.903 / 0.870 | 0.295 / 0.673 / 0.611 | 0.631 / 0.865 / 0.824 | 0.281 / 0.475 / 0.437 | 0.283 / 0.395 / 0.377 | 219 | 33 |
| RCAEval-C | 239 | 0.782 / 0.950 / 0.916 | 0.406 / 0.858 / 0.776 | 0.753 / 0.883 / 0.864 | 0.305 / 0.444 / 0.419 | 0.322 / 0.368 / 0.366 | 120 | 54 |
| Market | 77 | 0.649 / 0.883 / 0.857 | 0.221 / 0.636 / 0.579 | 0.506 / 0.714 / 0.678 | 0.000 / 0.000 / 0.000 | 0.247 / 0.403 / 0.371 | 77 | 0 |

## Permutação pareada em AC@1 (10.000; Holm sobre 21 = R3 + 3 do N-Sigma + 6)

| conjunto | comparação | Δ AC@1 | p | p Holm |
|---|---|---|---|---|
| A | nosso − CIRCA | +0.428 | 0.0001 | 0.0021 |
| A | nosso − RCD | +0.426 | 0.0001 | 0.0021 |
| RCAEval-C | nosso − CIRCA | +0.477 | 0.0001 | 0.0021 |
| RCAEval-C | nosso − RCD | +0.460 | 0.0001 | 0.0021 |
| Market | nosso − CIRCA | +0.649 | 0.0001 | 0.0021 |
| Market | nosso − RCD | +0.403 | 0.0001 | 0.0021 |

## Só os casos em que o método terminou (o nosso, nos mesmos casos; Holm sobre estas 5)

| conjunto | método | casos | AC@1 nosso / método | AC@3 nosso / método | Δ AC@1 | p | p Holm | suítes com falha |
|---|---|---|---|---|---|---|---|---|
| A | CIRCA | 255 de 474 | 0.737 / 0.522 | 0.867 / 0.882 | +0.216 | 0.0001 | 0.0005 | RE1-SS, RE1-TT |
| A | RCD | 441 de 474 | 0.721 / 0.304 | 0.907 / 0.424 | +0.417 | 0.0001 | 0.0005 | RE1-TT |
| RCAEval-C | CIRCA | 119 de 239 | 0.908 / 0.613 | 0.966 / 0.891 | +0.294 | 0.0001 | 0.0005 | RE2-TT, RE3-TT |
| RCAEval-C | RCD | 185 de 239 | 0.800 / 0.416 | 0.957 / 0.476 | +0.384 | 0.0001 | 0.0005 | RE2-OB, RE2-TT, RE3-OB, RE3-TT |
| Market | RCD | 77 de 77 | 0.649 / 0.247 | 0.883 / 0.403 | +0.403 | 0.0001 | 0.0005 | — |

## Holm sobre as 21 comparações (p bruto → p Holm)

| comparação | p | p Holm |
|---|---|---|
| R3 A F1@1: g-m∨t|mf − m-rz|g-m | 0.0001 | 0.0021 |
| R3 A F1@1: g-m∨t|mf − cpu-max|g-m | 0.0001 | 0.0021 |
| R3 A AC@1 por caso: g-m∨t|mf (1º instante) − BARO oficial | 0.0001 | 0.0021 |
| R3 RCAEval-C F1@1: g-m∨t|mf − d9 (= d9-k) | 0.0001 | 0.0021 |
| R3 RCAEval-C F1@1: g-m∨t|mf − d9+a (= d9-k+a) | 0.0001 | 0.0021 |
| R3 RCAEval-C AC@1 por caso: g-m∨t|mf (1º instante) − BARO oficial | 0.0001 | 0.0021 |
| R3 Market F1@1: g-m∨t|mf − d9 (= d9-k) | 0.0001 | 0.0021 |
| R3 Market AC@1 por caso: g-m∨t|mf (1º instante) − BARO oficial | 0.0001 | 0.0021 |
| R3 TeaStore F1@1: g-m∨t∨k|mfk − g-m∨t|mf | 0.1222 | 0.2444 |
| R3 TeaStore F1@1: g-m∨t∨k|mfk − d9-k+a | 0.0001 | 0.0021 |
| R3 TeaStore AC@1 por caso: g-m∨t∨k|mfk (1º instante) − BARO oficial | 0.0165 | 0.0825 |
| R3 TeaStore F1@1: d9-k − d9 | 0.0343 | 0.1372 |
| N-Sigma A | 0.0050 | 0.0300 |
| N-Sigma RCAEval-C | 0.4280 | 0.4280 |
| N-Sigma Market | 0.0592 | 0.1776 |
| A CIRCA | 0.0001 | 0.0021 |
| A RCD | 0.0001 | 0.0021 |
| RCAEval-C CIRCA | 0.0001 | 0.0021 |
| RCAEval-C RCD | 0.0001 | 0.0021 |
| Market CIRCA | 0.0001 | 0.0021 |
| Market RCD | 0.0001 | 0.0021 |

## Falhas por suíte (ranking vazio)

| método | conjunto/suíte | falhas | casos |
|---|---|---|---|
| CIRCA | A/RE1-OB | 0 | 122 |
| CIRCA | A/RE1-SS | 100 | 122 |
| CIRCA | A/RE1-TT | 122 | 122 |
| CIRCA | A/RE2-SS | 0 | 87 |
| CIRCA | A/RE3-SS | 0 | 27 |
| CIRCA | Market | 77 | 77 |
| CIRCA | RCAEval-C/RE2-OB | 0 | 90 |
| CIRCA | RCAEval-C/RE2-TT | 90 | 90 |
| CIRCA | RCAEval-C/RE3-OB | 0 | 30 |
| CIRCA | RCAEval-C/RE3-TT | 30 | 30 |
| RCD | A/RE1-OB | 0 | 122 |
| RCD | A/RE1-SS | 0 | 122 |
| RCD | A/RE1-TT | 33 | 122 |
| RCD | A/RE2-SS | 0 | 87 |
| RCD | A/RE3-SS | 0 | 27 |
| RCD | Market | 0 | 77 |
| RCD | RCAEval-C/RE2-OB | 7 | 90 |
| RCD | RCAEval-C/RE2-TT | 23 | 90 |
| RCD | RCAEval-C/RE3-OB | 3 | 30 |
| RCD | RCAEval-C/RE3-TT | 21 | 30 |

## Erros

Quando o CIRCA falha, o decorador `rca` do pacote cai num `IndexError` e esconde o motivo. Pelo log da execução, as 419 falhas do CIRCA são 381 por tempo esgotado e 38 por matriz de correlação singular (teste fisherz).

- A / CIRCA: IndexError: tuple index out of range
- A / RCD: tempo esgotado (> 900 s)
- RCAEval-C / CIRCA: IndexError: tuple index out of range
- RCAEval-C / RCD: tempo esgotado (> 900 s)
- Market / CIRCA: IndexError: tuple index out of range
