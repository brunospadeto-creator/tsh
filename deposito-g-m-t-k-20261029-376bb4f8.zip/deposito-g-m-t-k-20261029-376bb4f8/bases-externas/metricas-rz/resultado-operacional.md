# Protocolo operacional: nosso escore × BARO e N-Sigma na janela, mesmo portão (análise adicional)

`operacional.py`. Por instante, sem o horário da injeção, janela de 120 s, mesmos portões e instantes. Nosso = HMR (`g-m∨t|mf`) em todas as bases: os mesmos sinais (métricas) dos comparadores; o HTS (com eventos K8s) responde à P2 e aparece só no fim. IC 95% por bootstrap de caso (10000); permutação pareada por caso (10000); Holm sobre as 10 comparações.

| base | casos | nosso F1@1 [IC 95%] | BARO-janela | N-Sigma-janela | alarme (igual nos três) |
|---|---|---|---|---|---|
| RCAEval inédito | 474 | 0.614 [0.572–0.654] | 0.284 [0.250–0.319] | 0.566 [0.523–0.608] | 6.6% |
| RCAEval com rastros | 239 | 0.687 [0.640–0.732] | 0.437 [0.392–0.483] | 0.630 [0.583–0.677] | 15.4% |
| OpenRCA Market | 77 | 0.428 [0.332–0.525] | 0.211 [0.151–0.277] | 0.360 [0.268–0.451] | 16.5% |
| TeaStore inédito | 17 | 0.601 [0.374–0.820] | 0.273 [0.111–0.446] | 0.317 [0.152–0.495] | 15.3% |
| TeaStore definitiva | 24 | 0.524 [0.327–0.714] | 0.210 [0.105–0.320] | 0.210 [0.106–0.320] | 6.7% |

| base | comparação | ΔF1@1 | p | p (Holm) |
|---|---|---|---|---|
| RCAEval inédito | nosso − BARO-janela | +0.330 | 0.0001 | 0.0010 |
| RCAEval inédito | nosso − N-Sigma-janela | +0.048 | 0.0025 | 0.0100 |
| RCAEval com rastros | nosso − BARO-janela | +0.250 | 0.0001 | 0.0010 |
| RCAEval com rastros | nosso − N-Sigma-janela | +0.056 | 0.0001 | 0.0010 |
| OpenRCA Market | nosso − BARO-janela | +0.217 | 0.0001 | 0.0010 |
| OpenRCA Market | nosso − N-Sigma-janela | +0.069 | 0.1433 | 0.1433 |
| TeaStore inédito | nosso − BARO-janela | +0.328 | 0.0043 | 0.0100 |
| TeaStore inédito | nosso − N-Sigma-janela | +0.284 | 0.0030 | 0.0100 |
| TeaStore definitiva | nosso − BARO-janela | +0.315 | 0.0006 | 0.0036 |
| TeaStore definitiva | nosso − N-Sigma-janela | +0.315 | 0.0007 | 0.0036 |

TeaStore com eventos (HTS, P2; descritivo): TeaStore inédito F1@1 0.710; TeaStore definitiva F1@1 0.605.
