# Análises adicionais da revisão (pós-hoc, fora do protocolo)

`extras_revisao.py` (`ANALISE-QUALIDADE.md` §10.1 itens 3–5). Unidades e calibrações registradas do `robustez.py` (sem a cópia `multi-source-data`).

## Item 3 — escada do escore (mesmo portão, mesmos instantes)

| base | degrau | F1@1 | F1@2 | Top-1 condicionado |
|---|---|---|---|---|
| A | E0 BARO na Janela | 0.284 | 0.570 | 37.8% |
| A | E1 + valor absoluto | 0.268 | 0.553 | 36.4% |
| A | E2 + mediana da janela | 0.516 | 0.674 | 56.7% |
| A | E3 + reserva por família | 0.613 | 0.702 | 70.5% |
| A | E4 + log e baseline (método) | 0.614 | 0.704 | 69.8% |
| RCAEval-C | E0 BARO na Janela | 0.437 | 0.705 | 46.0% |
| RCAEval-C | E1 + valor absoluto | 0.428 | 0.706 | 45.1% |
| RCAEval-C | E2 + mediana da janela | 0.697 | 0.800 | 73.9% |
| RCAEval-C | E3 + reserva por família | 0.671 | 0.810 | 71.0% |
| RCAEval-C | E4 + log e baseline (método) | 0.687 | 0.826 | 72.6% |

## Item 4 — permutação contra o N-Sigma (10.000; Holm sobre 15 = R3 + 3)

| base | casos | AC@1 nosso | AC@1 N-Sigma | Δ | p | p Holm |
|---|---|---|---|---|---|---|
| A | 474 | 0.709 | 0.631 | +0.078 | 0.0050 | 0.0300 |
| RCAEval-C | 239 | 0.782 | 0.753 | +0.029 | 0.4280 | 0.4280 |
| Market | 77 | 0.649 | 0.506 | +0.143 | 0.0592 | 0.1776 |

Holm das 12 do R3 recalculado sobre as 15:

| base | medida | a | b | Δ | p | p Holm (15) |
|---|---|---|---|---|---|---|
| A | F1@1 | g-m∨t|mf | m-rz|g-m | +0.092 | 0.0001 | 0.0015 |
| A | F1@1 | g-m∨t|mf | cpu-max|g-m | +0.129 | 0.0001 | 0.0015 |
| A | AC@1 por caso | g-m∨t|mf (1º instante) | BARO oficial | +0.414 | 0.0001 | 0.0015 |
| RCAEval-C | F1@1 | g-m∨t|mf | d9 (= d9-k) | +0.379 | 0.0001 | 0.0015 |
| RCAEval-C | F1@1 | g-m∨t|mf | d9+a (= d9-k+a) | +0.338 | 0.0001 | 0.0015 |
| RCAEval-C | AC@1 por caso | g-m∨t|mf (1º instante) | BARO oficial | +0.377 | 0.0001 | 0.0015 |
| Market | F1@1 | g-m∨t|mf | d9 (= d9-k) | +0.274 | 0.0001 | 0.0015 |
| Market | AC@1 por caso | g-m∨t|mf (1º instante) | BARO oficial | +0.429 | 0.0001 | 0.0015 |
| TeaStore | F1@1 | g-m∨t∨k|mfk | g-m∨t|mf | +0.093 | 0.1222 | 0.2444 |
| TeaStore | F1@1 | g-m∨t∨k|mfk | d9-k+a | -0.321 | 0.0001 | 0.0015 |
| TeaStore | AC@1 por caso | g-m∨t∨k|mfk (1º instante) | BARO oficial | -0.171 | 0.0165 | 0.0825 |
| TeaStore | F1@1 | d9-k | d9 | +0.136 | 0.0343 | 0.1372 |

## Item 5 — F1@1 somado por instantes × médio por caso

| base | modo | casos | F1@1 somado | F1@1 médio por caso | mediana por caso |
|---|---|---|---|---|---|
| A | g-m∨t|mf | 474 | 0.614 | 0.466 | 0.263 |
| RCAEval-C | g-m∨t|mf | 239 | 0.687 | 0.685 | 0.889 |
| Market | g-m∨t|mf | 77 | 0.428 | 0.381 | 0.222 |
| TeaStore | g-m∨t|mf | 41 | 0.557 | 0.559 | 0.909 |
| TeaStore | g-m∨t∨k|mfk | 41 | 0.650 | 0.655 | 0.909 |
