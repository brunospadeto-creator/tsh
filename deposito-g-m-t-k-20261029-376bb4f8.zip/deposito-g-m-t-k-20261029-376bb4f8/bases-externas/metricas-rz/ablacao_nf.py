#!/usr/bin/env python3
"""Ablação da normalização pela baseline (N_f) no Portão de Métricas (pós-hoc, fora do protocolo).

Usa as unidades registradas do `robustez.py` (checkpoints em `DADOS_SAIDA/metricas-rz/robustez/`). Em cada base, o
escore do portão passa de `max_f log(1+z_f)/log(1+N_f)` para `max_f log(1+z_f)`, sobre as **mesmas** famílias
(as com N_f > 0), e o τ é recalibrado do mesmo modo (quantil da baseline, mesma taxa-alvo, mesmas exclusões). O
Portão de Rastros, os instantes e a ordenação não mudam; uma segunda variante tira o N_f também da ordenação.

Saída: `resultado-ablacao-nf.md`. Uso: python ablacao_nf.py [--jobs 16]
"""
from __future__ import annotations

import argparse
import os
import sys
import warnings
from typing import Any

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import robustez as R  # noqa: E402

CI = R.CI
U_ORIG, RANK_ORIG = CI._u, CI.ranking_rzl
MODOS = ("g-m∨t|mf", "g-m|mf")


def _u_sem_nf(es: dict[str, dict[str, float]], n: dict[str, float]) -> dict[str, float]:
    """`max_f log(1+z_f)` nas famílias com N_f > 0 (as mesmas do método)."""
    return {s: max((float(np.log1p(v)) for f, v in fams.items() if n.get(f, 0) > 0), default=0.0)
            for s, fams in es.items()}


def _variante(u: dict, ordem_sem_nf: bool) -> tuple[dict[str, Any], dict]:
    """Calibra e avalia com o escore sem N_f no portão (e, se pedido, na ordenação)."""
    CI._u = _u_sem_nf
    CI.ranking_rzl = RANK_ORIG if ordem_sem_nf else (lambda es, n: CI.ordenar(U_ORIG(es, n)))
    try:
        cal = R.cal_original(u)
        return cal, R.avaliar_orig(u, cal)
    finally:
        CI._u, CI.ranking_rzl = U_ORIG, RANK_ORIG


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    args = ap.parse_args()
    warnings.simplefilter("ignore", RuntimeWarning)
    us = {"A": R.unidade_a(args.jobs), "RCAEval-C": R.unidade_c(args.jobs), "Market": R.unidade_m(args.jobs),
          "TeaStore": R.unidade_t()}
    rng = np.random.default_rng(2026102801)
    out = ["# Ablação do N_f no Portão de Métricas (pós-hoc, fora do protocolo)", "",
           "`ablacao_nf.py`. Mesmas famílias (N_f > 0), mesma taxa-alvo e mesmas exclusões; τ recalibrado. "
           "Permutação pareada por caso (sinal trocado, bilateral) do F1@1 contra o método.", "",
           "| base | modo | variante | τ por grupo | F1@1 | F1@2 | alarme | ΔF1@1 | p |",
           "|---|---|---|---|---|---|---|---|---|"]
    for nome, u in us.items():
        cal = R.cal_original(u)
        pc = R.avaliar_orig(u, cal)
        vs = {"método": (cal, pc), "sem N_f no portão": _variante(u, False),
              "sem N_f no portão e na ordem": _variante(u, True)}
        for m in MODOS:
            if nome == "A" and m == "g-m∨t|mf":
                continue   # sem rastros: igual ao g-m|mf
            for v, (c, p) in vs.items():
                f1, f2, al = R.resumo(p[m])
                taus = ", ".join(f"{g} {t:.3f}" for g, t in sorted(c["tau"].items()))
                if v == "método":
                    d, pv = "—", "—"
                else:
                    dd, pp = R._perm_f1(p[m], pc[m], rng)
                    d, pv = f"{dd:+.3f}", f"{pp:.4f}"
                out.append(f"| {nome} | {m} | {v} | {taus} | {f1:.3f} | {f2:.3f} | {al:.1%} | {d} | {pv} |")
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-ablacao-nf.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    sys.exit(main())
