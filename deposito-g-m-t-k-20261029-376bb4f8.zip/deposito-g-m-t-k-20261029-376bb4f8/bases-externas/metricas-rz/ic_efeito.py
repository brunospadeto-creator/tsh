#!/usr/bin/env python3
"""Intervalos e tamanhos de efeito pedidos pelos revisores simulados (análise adicional, fora do protocolo).

1. IC 95% por *bootstrap* de casos (10 000 reamostragens) para cada célula da `tab:literature`:
   - protocolo operacional: F1@1 por instante, dos caches do `operacional.py` (nosso, BARO-janela, N-Sigma-janela);
   - protocolo do RCAEval: AC@1 por caso no 1º instante com causa, das unidades e calibrações registradas do
     `robustez.py` (nosso HMR, BARO e N-Sigma oficiais).
2. Tamanho de efeito das 12 comparações do teste de permutação registrado (R3): Cliff's δ pareado por caso,
   δ = (casos em que A vence − casos em que B vence) / casos, com o F1@1 de cada caso nas comparações em F1@1 e o
   acerto no 1º lugar nas comparações em AC@1; junto, vitórias / empates / derrotas.

Só leitura dos caches; nenhum parâmetro do método é recalculado. Uso: `ic_efeito.py` → `resultado-ic-efeito.md`.
"""
from __future__ import annotations

import math
import os
import pickle
import sys
import warnings
from collections import Counter

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import operacional as OP  # noqa: E402
import robustez as R  # noqa: E402

N = 10_000
RNG = np.random.default_rng(2026102401)


def ic_f1(pc: dict[str, Counter]) -> tuple[float, float, float]:
    cs = sorted(pc)
    a = R._arr(pc, cs)
    idx = RNG.integers(0, len(cs), size=(N, len(cs)))
    v = R._f1v(a[idx].sum(axis=1), 0)
    return float(R._f1v(a.sum(0), 0)), *np.nanpercentile(v, [2.5, 97.5]).tolist()


def ic_media(d: dict[str, float]) -> tuple[float, float, float]:
    v = np.array([d[c] for c in sorted(d)], dtype=float)
    idx = RNG.integers(0, len(v), size=(N, len(v)))
    return float(v.mean()), *np.percentile(v[idx].mean(axis=1), [2.5, 97.5]).tolist()


def fmt(t: tuple[float, float, float]) -> str:
    return f"{t[0]:.3f} [{t[1]:.3f}, {t[2]:.3f}]"


def f1_caso(c: Counter) -> float:
    tp, fp, fn = c["tp1"], c["dec"] - c["tp1"] + c["al"], c["ne"] - c["tp1"]
    return 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else math.nan


def cliff(a: dict, b: dict) -> tuple[float, int, int, int]:
    cs = [c for c in sorted(set(a) & set(b)) if not (math.isnan(a[c]) or math.isnan(b[c]))]
    v = sum(1 for c in cs if a[c] > b[c])
    d = sum(1 for c in cs if a[c] < b[c])
    return (v - d) / len(cs), v, len(cs) - v - d, d


def primeiro(u: dict) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
        if x["periodo"] == "falha" and x["esp"] and x["caso"] not in out:
            out[x["caso"]] = x
    return out


def ac_ns(u: dict) -> dict[str, float]:
    return {c: float(((u["baro"].get(c) or {}).get("N-Sigma", []))[:1] == [x["esp"]]) for c, x in primeiro(u).items()}


def main() -> int:
    warnings.simplefilter("ignore", RuntimeWarning)
    d: dict = {}
    for parte in ("publicas", "teastore"):
        with open(os.path.join(OP.SAIDA, f"{parte}.pkl"), "rb") as f:
            d.update(pickle.load(f))
    out = ["# IC por bootstrap da tabela de comparação e tamanhos de efeito (análise adicional, fora do protocolo)", "",
           "`ic_efeito.py`. Bootstrap de casos com 10 000 reamostragens (semente 2026102401). Só leitura dos caches "
           "do `operacional.py` e das unidades e calibrações registradas do `robustez.py`.", "",
           "## 1. Protocolo operacional: F1@1 por instante [IC 95%]", "",
           "| base | BARO-janela | N-Sigma-janela | nosso (HMR) |", "|---|---|---|---|"]
    for b in OP.BASES:
        out.append(f"| {b} | {fmt(ic_f1(d[b]['BARO-janela']))} | {fmt(ic_f1(d[b]['N-Sigma-janela']))} | "
                   f"{fmt(ic_f1(d[b]['nosso']))} |")
    us = {"A": R.unidade_a(8), "RCAEval-C": R.unidade_c(8), "Market": R.unidade_m(8), "TeaStore": R.unidade_t()}
    cals = {n: R.cal_original(u) for n, u in us.items()}
    pcs = {n: R.avaliar_orig(u, cals[n]) for n, u in us.items()}
    out += ["", "## 2. Protocolo do RCAEval: AC@1 por caso no 1º instante com causa [IC 95%]", "",
            "| base | casos | BARO | N-Sigma | nosso (HMR) |", "|---|---|---|---|---|"]
    acs = {}
    for nome, rot in (("A", "RCAEval inédito"), ("RCAEval-C", "RCAEval com rastros"), ("Market", "OpenRCA Market")):
        nos, baro = R.ac1_casos(us[nome], cals[nome]["norm"])
        ns = ac_ns(us[nome])
        acs[nome] = (nos, baro)
        out.append(f"| {rot} | {len(nos)} | {fmt(ic_media(baro))} | {fmt(ic_media(ns))} | {fmt(ic_media(nos))} |")
    u = us["TeaStore"]
    tea_k = ({}, {})
    for cj, rot in (("B′", "TeaStore inédito"), ("definitiva", "TeaStore definitiva")):
        sub = {"inst": [x for x in u["inst"] if x["grupo"] == cj], "baro": u["baro"]}
        nos, baro = R.ac1_casos(sub, {cj: cals["TeaStore"]["norm"][cj]})
        nk, _ = R.ac1_casos(sub, {cj: cals["TeaStore"]["norm"][cj]}, k8s=True)
        tea_k[0].update(nk)
        tea_k[1].update(baro)
        out.append(f"| {rot} | {len(nos)} | {fmt(ic_media(baro))} | {fmt(ic_media(ac_ns(sub)))} | "
                   f"{fmt(ic_media(nos))} |")
    # 3. tamanhos de efeito das 12 comparações do R3, na mesma ordem
    comps = []
    p = pcs["A"]
    f = {m: {c: f1_caso(v) for c, v in p[m].items() if v["ne"]} for m in ("g-m∨t|mf", "m-rz|g-m", "cpu-max|g-m")}
    comps += [("RCAEval inédito", "F1@1", "HMR − Desvio Bruto", cliff(f["g-m∨t|mf"], f["m-rz|g-m"])),
              ("RCAEval inédito", "F1@1", "HMR − maior desvio de CPU", cliff(f["g-m∨t|mf"], f["cpu-max|g-m"])),
              ("RCAEval inédito", "AC@1", "HMR − BARO", cliff(*acs["A"]))]
    p = pcs["RCAEval-C"]
    f = {m: {c: f1_caso(v) for c, v in p[m].items() if v["ne"]} for m in ("g-m∨t|mf", "d9", "d9+a")}
    comps += [("RCAEval com rastros", "F1@1", "HMR − CS", cliff(f["g-m∨t|mf"], f["d9"])),
              ("RCAEval com rastros", "F1@1", "HMR − CR", cliff(f["g-m∨t|mf"], f["d9+a"])),
              ("RCAEval com rastros", "AC@1", "HMR − BARO", cliff(*acs["RCAEval-C"]))]
    p = pcs["Market"]
    f = {m: {c: f1_caso(v) for c, v in p[m].items() if v["ne"]} for m in ("g-m∨t|mf", "d9")}
    comps += [("OpenRCA Market", "F1@1", "HMR − CS", cliff(f["g-m∨t|mf"], f["d9"])),
              ("OpenRCA Market", "AC@1", "HMR − BARO", cliff(*acs["Market"]))]
    p = pcs["TeaStore"]
    f = {m: {c: f1_caso(v) for c, v in p[m].items() if v["ne"]} for m in ("g-m∨t∨k|mfk", "g-m∨t|mf", "d9-k+a", "d9-k", "d9")}
    comps += [("TeaStore", "F1@1", "HTS − HMR", cliff(f["g-m∨t∨k|mfk"], f["g-m∨t|mf"])),
              ("TeaStore", "F1@1", "HTS − COR", cliff(f["g-m∨t∨k|mfk"], f["d9-k+a"])),
              ("TeaStore", "AC@1", "HTS − BARO", cliff(*tea_k)),
              ("TeaStore", "F1@1", "CSO − CS", cliff(f["d9-k"], f["d9"]))]
    out += ["", "## 3. Tamanho de efeito das 12 comparações do teste de permutação registrado (Cliff's δ pareado por "
            "caso)", "", "Por convenção, |δ| < 0,147 é desprezível, < 0,33 pequeno, < 0,474 médio e acima disso grande.",
            "", "| base | medida | comparação | δ | vitórias / empates / derrotas |", "|---|---|---|---|---|"]
    out += [f"| {b} | {m} | {c} | {e[0]:+.3f} | {e[1]} / {e[2]} / {e[3]} |" for b, m, c, e in comps]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-ic-efeito.md"), "w") as fh:
        fh.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
