#!/usr/bin/env python3
"""PDiagnose e o passo de desvio de Fukuda et al. (2025) nos mesmos casos (pós-hoc, fora do protocolo).

Pedidos pelos revisores simulados (`artigo_em_construcao/g-m-t-k/sintese_analises.md`, B3). Os dois recebem o
horário da injeção, como o BARO e o N-Sigma, e são comparados no protocolo do RCAEval (AC@1 por caso, no nível de
serviço, contra o HMR no 1º instante com causa e ordem completa).

- **PDiagnose**: o RCAEval 1.8.0 traz `RCAEval/e2e/pdiagnose.py` como script de exemplo, com o caminho de um caso
  fixo no código, sem a função de entrada dos outros métodos. Aqui o corpo do `main()` vira uma função, com a mesma
  conta (ALPHA = 5): métricas do `simple_metrics.csv` acima de média + 3 desvios do período normal, mensagens com
  `error|fail` no `logs.csv` por contêiner e spans acima de média + 3 desvios da duração normal de cada operação no
  `traces.csv`, somados por serviço. Duas mudanças mínimas, para não falhar fora do caso de exemplo: o nome da
  coluna de métrica é dividido só no primeiro `_` (o script quebra com mais de um) e serviços que só aparecem nos
  logs ou nos rastros entram na soma com zero (o script dá `KeyError`). Só o RE2 tem métricas, logs e rastros juntos
  (179 casos, os mesmos do TORAI).
- **Fukuda et al. (ICWS 2025), Eqs. 1–2**: razão de desvio d = med(depois) / med(antes) de cada coluna, aqui
  simétrica (max(d, 1/d)), ajustada pela mediana das razões P75/P25 das colunas do mesmo tipo de métrica nos outros
  serviços (a = d / med q). O ponto de mudança de cada série é substituído pelo horário da injeção, que os outros
  comparadores do pacote também recebem, e a busca de árvores de propagação não é reimplementada: os serviços são
  ordenados pelo maior `a` das suas colunas. É uma reimplementação **parcial**, feita por nós, do passo de desvio.
  Mesmas séries do CIRCA e do RCD (`outros_comparadores._serie`), nos três conjuntos públicos.

Uso:
  python comparadores_novos.py --rodar [--jobs 16]
  python comparadores_novos.py --relatorio        → resultado-comparadores-novos.md
"""
from __future__ import annotations

import argparse
import os
import pickle
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import outros_comparadores as OC  # noqa: E402
import robustez as R  # noqa: E402

CI, E2, O = R.CI, R.E2, R.O
SAIDA = os.path.join(O.CACHE, "outros-comparadores")
SUITES_MM = ("RE2-OB", "RE2-TT")
ALPHA = 5


def pdiagnose(pasta: str) -> list[str]:
    metric_df = pd.read_csv(os.path.join(pasta, "simple_metrics.csv"))
    log_df = pd.read_csv(os.path.join(pasta, "logs.csv"))
    span_df = pd.read_csv(os.path.join(pasta, "traces.csv"),
                          usecols=["serviceName", "methodName", "operationName", "startTime", "duration"])
    span_df["methodName"] = span_df["methodName"].fillna(span_df["operationName"])
    span_df["operation"] = span_df["serviceName"] + "_" + span_df["methodName"]
    with open(os.path.join(pasta, "inject_time.txt")) as f:
        inject_time = int(f.readline())
    metric_df = metric_df.loc[:, ~metric_df.columns.duplicated()]
    normal = metric_df[metric_df["time"] < inject_time]
    anomal = metric_df[metric_df["time"] >= inject_time]
    cols = [m for m in normal.columns if "time" not in m]
    service: dict[str, float] = {}
    for m in cols:
        mu, sd = normal[m].mean(), normal[m].std()
        q = int((anomal[m] >= mu + 3 * sd).sum())
        s = m.split("_", 1)[0]
        service[s] = service.get(s, 0) + ALPHA * q
    msg = log_df["message"].astype(str).str.contains("error|fail")
    for c, n in log_df[msg].groupby("container_name").size().items():
        service[c] = service.get(c, 0) + ALPHA * int(n)
    inj_us = inject_time * 1_000_000
    fim = span_df["startTime"] + span_df["duration"]
    norm_sp, anom_sp = span_df[fim < inj_us], span_df[fim >= inj_us].copy()
    g = norm_sp.groupby("operation")["duration"]
    slo_mu, slo_sd = (g.mean() / 1_000).round(2), (g.std() / 1_000).round(2)
    anom_sp["mu"] = anom_sp["operation"].map(slo_mu)
    anom_sp["sd"] = anom_sp["operation"].map(slo_sd)
    anom_sp["abn"] = anom_sp["duration"] / 1_000 >= anom_sp["mu"] + 3 * anom_sp["sd"]
    for s, n in anom_sp.groupby("serviceName")["abn"].sum().items():
        s = "frontend" if s == "frontendservice" else s
        service[s] = service.get(s, 0) + ALPHA * int(n)
    return [k for k, _ in sorted(service.items(), key=lambda kv: -kv[1])]


def fukuda(tempo: np.ndarray, val: np.ndarray, cols: list[str], inj: float) -> list[str]:
    antes, depois = val[tempo < inj], val[tempo >= inj]
    eps = 1e-12
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        mb, md = np.nanmedian(antes, axis=0), np.nanmedian(depois, axis=0)
        d = (np.abs(md) + eps) / (np.abs(mb) + eps)
        d = np.maximum(d, 1 / d)
        p75, p25 = np.nanpercentile(val, 75, axis=0), np.nanpercentile(val, 25, axis=0)
        q = (np.abs(p75) + eps) / (np.abs(p25) + eps)
    svc = [E2.servico_col(c) for c in cols]
    tipo = [c.rsplit("_", 1)[1] for c in cols]
    score: dict[str, float] = {}
    for i, (s, u) in enumerate(zip(svc, tipo, strict=True)):
        outros = [q[j] for j in range(len(cols)) if tipo[j] == u and svc[j] != s and np.isfinite(q[j])]
        a = d[i] / (float(np.median(outros)) if outros else 1.0)
        if np.isfinite(a):
            score[s] = max(score.get(s, -np.inf), float(a))
    return [k for k, _ in sorted(score.items(), key=lambda kv: (-kv[1], kv[0]))]


def _job(job: tuple[str, str, Any, str]) -> tuple[str, str, str, list[str], str | None, float]:
    warnings.simplefilter("ignore")
    conj, caso, chave, metodo = job
    t0 = time.time()
    try:
        if metodo == "pdiagnose":
            suite, resto = caso.split("/", 1)
            rk = pdiagnose(os.path.join(CI.ORIGEM, suite, suite, resto))
        else:
            tempo, val, cols, inj, _ = OC._serie(chave)
            rk = fukuda(tempo, val, cols, inj)
        return conj, caso, metodo, rk, None, time.time() - t0
    except Exception as exc:  # noqa: BLE001
        return conj, caso, metodo, [], f"{type(exc).__name__}: {str(exc)[:80]}", time.time() - t0


def rodar(jobs: int) -> None:
    ent = OC.entradas()
    lista = [(c, k, ch, "fukuda") for c, k, ch in ent]
    lista += [(c, k, ch, "pdiagnose") for c, k, ch in ent if c == "RCAEval-C" and k.split("/")[0] in SUITES_MM]
    res: dict[tuple[str, str, str], tuple[list[str], str | None, float]] = {}
    with ProcessPoolExecutor(jobs) as ex:
        for i, (conj, caso, m, rk, err, dt) in enumerate(ex.map(_job, lista, chunksize=2), 1):
            res[(conj, caso, m)] = (rk, err, dt)
            if i % 100 == 0:
                print(f"{i}/{len(lista)}", flush=True)
    os.makedirs(SAIDA, exist_ok=True)
    with open(os.path.join(SAIDA, "novos.pkl"), "wb") as f:
        pickle.dump(res, f)


def relatorio() -> int:
    with open(os.path.join(SAIDA, "novos.pkl"), "rb") as f:
        res = pickle.load(f)
    us = {"A": R.unidade_a(8), "RCAEval-C": R.unidade_c(8), "Market": R.unidade_m(8)}
    rng = np.random.default_rng(2026102402)
    out = ["# PDiagnose e o passo de desvio de Fukuda et al. nos mesmos casos (pós-hoc, fora do protocolo)", "",
           "`comparadores_novos.py`. Protocolo do RCAEval: AC@1 / AC@3 / Avg@5 por caso, no nível de serviço; o nosso "
           "método (HMR) no 1º instante com causa e ordem completa, como na Tabela de comparação com a literatura. "
           "Ranking vazio conta como erro. Ver o cabeçalho do script para as adaptações de cada método.", "",
           "| conjunto | método | casos | nosso | método | Δ AC@1 | p (permutação, 10 000) | p Holm |", "|---|---|---|---|---|---|---|---|"]
    tempos: dict[str, list[float]] = {}
    linhas: list[list] = []
    falhas: dict[str, int] = {}
    for nome, rot in (("A", "RCAEval inédito"), ("RCAEval-C", "RCAEval com rastros"), ("Market", "OpenRCA Market")):
        u = us[nome]
        norm = R.cal_original(u)["norm"]
        primeiro: dict[str, dict] = {}
        for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
            if x["periodo"] == "falha" and x["esp"] and x["caso"] not in primeiro:
                primeiro[x["caso"]] = x
        nos = {c: E2.ordem_completa(x["f"], norm.get(x["grupo"], {})) for c, x in primeiro.items()}
        for m, lab in (("fukuda", "Fukuda et al. (passo de desvio)"), ("pdiagnose", "PDiagnose")):
            cs = [c for c in primeiro if (nome, c, m) in res]
            if m == "pdiagnose":
                cs = [c for c in cs if c.split("/")[0] in SUITES_MM]
            if not cs:
                continue
            rk = {c: res[(nome, c, m)][0] for c in cs}
            for c in cs:
                tempos.setdefault(m, []).append(res[(nome, c, m)][2])
                if res[(nome, c, m)][1]:
                    falhas[f"{lab}: {res[(nome, c, m)][1]}"] = falhas.get(f"{lab}: {res[(nome, c, m)][1]}", 0) + 1

            def acs(r: dict[str, list[str]]) -> str:
                a = {k: np.mean([primeiro[c]["esp"] in r[c][:k] for c in cs]) for k in range(1, 6)}
                return f"{a[1]:.3f} / {a[3]:.3f} / {np.mean(list(a.values())):.3f}"
            a1n = {c: float(nos[c][:1] == [primeiro[c]["esp"]]) for c in cs}
            a1m = {c: float(rk[c][:1] == [primeiro[c]["esp"]]) for c in cs}
            dlt, p = R._perm_ac(a1n, a1m, rng)
            sufixo = " (RE2)" if m == "pdiagnose" else ""
            linhas.append([f"| {rot}{sufixo} | {lab} | {len(cs)} | {acs(nos)} | {acs(rk)} | {dlt:+.3f} | {p:.4f} |", p])
    ps = [x[1] for x in linhas]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    out += [f"{x[0]} {h:.4f} |" for x, h in zip(linhas, holm, strict=True)]
    out += ["", f"p Holm sobre estas {len(ps)} comparações (análise adicional, à parte das 26 dos outros comparadores).",
            "", "## Tempo e falhas", ""]
    out += [f"- {m}: tempo por caso mediana {np.median(v):.2f} s, máximo {max(v):.2f} s ({len(v)} casos)"
            for m, v in tempos.items()]
    out += [f"- {e}: {n}×" for e, n in sorted(falhas.items())] or ["- nenhuma falha"]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-comparadores-novos.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rodar", action="store_true")
    ap.add_argument("--relatorio", action="store_true")
    ap.add_argument("--jobs", type=int, default=16)
    a = ap.parse_args()
    if a.rodar:
        rodar(a.jobs)
    if a.relatorio:
        return relatorio()
    return 0


if __name__ == "__main__":
    sys.exit(main())
