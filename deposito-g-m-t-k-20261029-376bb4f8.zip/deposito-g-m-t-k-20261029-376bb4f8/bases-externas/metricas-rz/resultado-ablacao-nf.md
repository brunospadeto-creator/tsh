# Ablação do N_f no Portão de Métricas (pós-hoc, fora do protocolo)

`ablacao_nf.py`. Mesmas famílias (N_f > 0), mesma taxa-alvo e mesmas exclusões; τ recalibrado. Permutação pareada por caso (sinal trocado, bilateral) do F1@1 contra o método.

| base | modo | variante | τ por grupo | F1@1 | F1@2 | alarme | ΔF1@1 | p |
|---|---|---|---|---|---|---|---|---|
| A | g-m|mf | método | RE1-OB 3.054, RE1-SS 8.029, RE1-TT 12.208, RE2-SS 3.322, RE3-SS 2.496 | 0.614 | 0.704 | 6.6% | — | — |
| A | g-m|mf | sem N_f no portão | RE1-OB 3.401, RE1-SS 10.869, RE1-TT 13.412, RE2-SS 4.673, RE3-SS 4.899 | 0.504 | 0.582 | 7.1% | -0.110 | 0.0001 |
| A | g-m|mf | sem N_f no portão e na ordem | RE1-OB 3.401, RE1-SS 10.869, RE1-TT 13.412, RE2-SS 4.673, RE3-SS 4.899 | 0.496 | 0.570 | 7.1% | -0.118 | 0.0001 |
| RCAEval-C | g-m∨t|mf | método | RE2-OB 2.736, RE2-TT 4.263, RE3-OB 2.798, RE3-TT 5.175 | 0.687 | 0.826 | 15.4% | — | — |
| RCAEval-C | g-m∨t|mf | sem N_f no portão | RE2-OB 3.166, RE2-TT 5.663, RE3-OB 6.587, RE3-TT 7.425 | 0.693 | 0.832 | 13.6% | +0.007 | 0.0023 |
| RCAEval-C | g-m∨t|mf | sem N_f no portão e na ordem | RE2-OB 3.166, RE2-TT 5.663, RE3-OB 6.587, RE3-TT 7.425 | 0.683 | 0.823 | 13.6% | -0.003 | 0.7493 |
| RCAEval-C | g-m|mf | método | RE2-OB 2.736, RE2-TT 4.263, RE3-OB 2.798, RE3-TT 5.175 | 0.632 | 0.775 | 5.8% | — | — |
| RCAEval-C | g-m|mf | sem N_f no portão | RE2-OB 3.166, RE2-TT 5.663, RE3-OB 6.587, RE3-TT 7.425 | 0.602 | 0.748 | 3.9% | -0.030 | 0.0061 |
| RCAEval-C | g-m|mf | sem N_f no portão e na ordem | RE2-OB 3.166, RE2-TT 5.663, RE3-OB 6.587, RE3-TT 7.425 | 0.608 | 0.744 | 3.9% | -0.024 | 0.0448 |
| Market | g-m∨t|mf | método | cloudbed-1 3.474, cloudbed-2 19.470 | 0.428 | 0.602 | 16.5% | — | — |
| Market | g-m∨t|mf | sem N_f no portão | cloudbed-1 28.666, cloudbed-2 29.647 | 0.338 | 0.473 | 6.6% | -0.090 | 0.0191 |
| Market | g-m∨t|mf | sem N_f no portão e na ordem | cloudbed-1 28.666, cloudbed-2 29.647 | 0.161 | 0.326 | 6.6% | -0.267 | 0.0001 |
| Market | g-m|mf | método | cloudbed-1 3.474, cloudbed-2 19.470 | 0.304 | 0.477 | 12.4% | — | — |
| Market | g-m|mf | sem N_f no portão | cloudbed-1 28.666, cloudbed-2 29.647 | 0.098 | 0.130 | 2.5% | -0.206 | 0.0021 |
| Market | g-m|mf | sem N_f no portão e na ordem | cloudbed-1 28.666, cloudbed-2 29.647 | 0.084 | 0.120 | 2.5% | -0.220 | 0.0008 |
| TeaStore | g-m∨t|mf | método | B′ 1.854, definitiva 2.692 | 0.557 | 0.682 | 10.2% | — | — |
| TeaStore | g-m∨t|mf | sem N_f no portão | B′ 2.865, definitiva 3.173 | 0.556 | 0.681 | 10.7% | -0.001 | 1.0000 |
| TeaStore | g-m∨t|mf | sem N_f no portão e na ordem | B′ 2.865, definitiva 3.173 | 0.556 | 0.671 | 10.7% | -0.001 | 1.0000 |
| TeaStore | g-m|mf | método | B′ 1.854, definitiva 2.692 | 0.600 | 0.735 | 0.0% | — | — |
| TeaStore | g-m|mf | sem N_f no portão | B′ 2.865, definitiva 3.173 | 0.599 | 0.733 | 0.5% | -0.001 | 1.0000 |
| TeaStore | g-m|mf | sem N_f no portão e na ordem | B′ 2.865, definitiva 3.173 | 0.599 | 0.723 | 0.5% | -0.001 | 1.0000 |
