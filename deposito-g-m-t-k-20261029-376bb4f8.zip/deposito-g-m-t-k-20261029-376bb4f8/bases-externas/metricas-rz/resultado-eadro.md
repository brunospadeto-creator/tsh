# `g-m∨t|mf` sem mudança — Eadro SN (teste de 10 min, exploratório)

`outras.py` / `PROTOCOLO.md` §Generalização. Mesmo código do RCAEval; só o adaptador de métricas é da base. Todos os instantes dos registros do `../d9a/` (fora a sombra). Sem K8s: d9 = d9-k.

| grupo | janelas da baseline | λ (FP 0,01) | q d2c-b (FP 0,01) | famílias com N | τ do g-m |
|---|---|---|---|---|---|
| SN | 20 | 1.189 | 1.46e-01 | 5 | 3.196 |

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 31 | 22 | 0.036 [0.000–0.111] | 0.036 | 4.5% | 22.6% | 3.2% | 3.2% |
| d9+a | 31 | 22 | 0.035 [0.000–0.109] | 0.035 | 4.5% | 19.4% | 3.2% | 3.2% |
| d9-b+c@0.01 | 31 | 22 | 0.067 [0.000–0.169] | 0.067 | 9.1% | 12.9% | 3.2% | 3.2% |
| m-rzf | 31 | 22 | 0.214 [0.098–0.373] | 0.238 | 100.0% | 0.0% | 29.0% | 32.3% |
| g-m|mf | 31 | 22 | 0.286 [0.152–0.452] | 0.317 | 4.5% | 0.0% | 29.0% | 32.3% |
| g-m∨t|mf | 31 | 22 | 0.277 [0.152–0.431] | 0.308 | 13.6% | 0.0% | 29.0% | 32.3% |
| g-m∧t|mf | 31 | 22 | 0.310 [0.160–0.483] | 0.345 | 0.0% | 12.9% | 29.0% | 32.3% |

- ΔF1@1 g-m∨t|mf − d9 = +0.241 [IC 95% +0.108 a +0.397]
- ΔF1@1 g-m∨t|mf − d9-b+c@0.01 = +0.210 [IC 95% +0.048 a +0.389]
- ΔF1@1 g-m|mf − d9 = +0.250 [IC 95% +0.112 a +0.410]
