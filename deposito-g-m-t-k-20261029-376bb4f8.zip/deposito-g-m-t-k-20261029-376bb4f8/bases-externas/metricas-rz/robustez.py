#!/usr/bin/env python3
"""Emenda 3 do `PROTOCOLO-COMPLETO.md`: robustez estatística ("foi sorte?"), R1–R8, com teto de 9 h e checkpoint por
etapa. Só usa o código congelado (`ciclo`, `calib`, `outras`, `confirmatorio_a`) e os registros/caches já gravados.

Unidade de avaliação = lista de instantes com: caso, grupo, período, gabarito, escores `f` das métricas, efeitos e
p_min (portão de traces recalibrável), serviço K8s (TeaStore) e as decisões dos comparadores. A calibração (N e τ das
métricas; λ e q dos traces) é refeita a cada sorteio de baseline (R1) e em cada ponto da grade (R5).

Uso: python robustez.py [--etapas R1,R2,...] [--jobs 24]
Saída: `resultado-robustez.md` e checkpoints em `DADOS_SAIDA/metricas-rz/robustez/`.
"""
from __future__ import annotations

import argparse
import datetime
import math
import os
import pickle
import random
import subprocess
import sys
import time
import warnings
from collections import Counter, defaultdict
from typing import Any

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import confirmatorio_a as CA  # noqa: E402
import emenda2 as E2  # noqa: E402
import outras as O  # noqa: E402

CI = O.CI
calib = O.calib
CK = os.path.join(O.CACHE, "robustez")
REPLAY = os.path.join(os.path.dirname(os.path.dirname(AQUI)), "experimento-falhas", "teastore", "stage3-online", "replay")
CACHE_TS = os.path.join(os.path.dirname(REPLAY), "resultados", "protocolo-metricas-rz", "robustez", "cache-teastore.pkl")
INICIO = datetime.datetime(2026, 10, 18, 21, 44, 15).timestamp()   # registro da emenda 3 (−04)
# recálculo (ex.: sem a cópia de `comum.DUPLICADOS`): `ROBUSTEZ_INICIO_AGORA=1` conta o teto de 9 h a partir de agora
if os.environ.get("ROBUSTEZ_INICIO_AGORA"):
    INICIO = time.time()
TETO = INICIO + 9 * 3600
PY = sys.executable
N_R1, N_BOOT, N_PERM, N_PLAC, N_SPLIT, N_ACASO = 500, 10_000, 10_000, 10_000, 1_000, 10_000
GRADE = [(j, r) for j in (60, 120, 180) for r in (300, 600, 900)]
META = (0.6, 0.7, 0.20)


def resta() -> float:
    return TETO - time.time()


def _ck(nome: str) -> str:
    return os.path.join(CK, f"{nome}.pkl")


def guardar(nome: str, obj: Any) -> None:
    os.makedirs(CK, exist_ok=True)
    with open(_ck(nome) + ".tmp", "wb") as f:
        pickle.dump(obj, f)
    os.replace(_ck(nome) + ".tmp", _ck(nome))


def ler(nome: str) -> Any:
    if os.path.exists(_ck(nome)):
        with open(_ck(nome), "rb") as f:
            return pickle.load(f)
    return None


# ================================================================ unidades (montagem dos dados)

def _job_a(job: tuple[str, str]) -> dict[str, Any]:
    warnings.simplefilter("ignore", RuntimeWarning)
    suite, caso = job
    tempo, val, cols, inj = CA.ler(suite, caso)
    ini = float(tempo[0])
    inst = []
    for periodo, t in CA.instantes(tempo, inj):
        ref = (max(ini, inj - CI.REF), inj) if periodo == "falha" else (max(ini, t - CI.JANELA - CI.REF), t - CI.JANELA)
        inst.append({"periodo": periodo, "t": t, "f": CI.escores(tempo, val, cols, t, ref, familia=True),
                     "z": CI.escores(tempo, val, cols, t, ref, familia=False)})
    of = E2.oficiais(tempo, val, cols, inj, suite.lower()) if CI.JANELA == 120 and CI.REF == 600 else {}
    return {"suite": suite, "caso": caso, "inst": inst, "of": of}


def unidade_a(jobs: int, grade: tuple[int, int] = (120, 600)) -> dict[str, Any]:
    nome = f"u-A-{grade[0]}-{grade[1]}"
    u = ler(nome)
    if u is not None:
        return u
    CI.JANELA, CI.REF = grade
    cs = CA.casos()
    teste = CA.sorteio_teste(cs)
    lista = [(s, c) for s in CA.SUITES for c in cs[s] if f"{s}/{c}" not in teste]
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        res = list(ex.map(_job_a, lista, chunksize=2))
    CI.JANELA, CI.REF = 120, 600
    inst, baro = [], {}
    for r in res:
        c = f"{r['suite']}/{r['caso']}"
        svc, tipo = CA.gabarito(r["caso"])
        baro[c] = r["of"]
        for x in r["inst"]:
            rz, rc = CI.ranking_rz(x["z"]), CA._cpu(x["f"])
            inst.append({"caso": c, "grupo": r["suite"], "periodo": x["periodo"], "t": x["t"], "esp": svc,
                         "tipo": tipo, "sistema": r["suite"].split("-")[1], "f": x["f"],
                         "comp": {"m-rz|g-m": rz, "cpu-max|g-m": rc}})
    u = {"nome": "A", "inst": inst, "baro": baro, "tem_traces": False}
    guardar(nome, u)
    return u


def _job_c(job: tuple[str, list[tuple[str, str]]]) -> dict[str, Any]:
    warnings.simplefilter("ignore", RuntimeWarning)
    caso, its = job
    df, inj = CI._serie(caso)
    tempo, val, cols = df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns)
    f = {}
    for periodo, ts in its:
        t = O._ts(ts)
        ref = (inj - CI.REF, inj) if periodo == "falha" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        f[ts] = CI.escores(tempo, val, cols, t, ref, familia=True)
    of = E2.oficiais(tempo, val, cols, inj, caso.split("/")[0].lower()) if CI.JANELA == 120 and CI.REF == 600 else {}
    return {"caso": caso, "f": f, "of": of}


def unidade_c(jobs: int, grade: tuple[int, int] = (120, 600)) -> dict[str, Any]:
    nome = f"u-C-{grade[0]}-{grade[1]}"
    u = ler(nome)
    if u is not None:
        return u
    D = CI._d9a()  # noqa: N806
    linhas = CI.BD.carregar()
    por: dict[str, list] = defaultdict(list)
    for x in linhas:
        por[x["caso"]].append((x["periodo"], x["t"]))
    CI.JANELA, CI.REF = grade
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        res = {r["caso"]: r for r in ex.map(_job_c, list(por.items()), chunksize=2)}
    CI.JANELA, CI.REF = 120, 600
    inst = []
    for x in linhas:
        d0 = D.decisoes(x)
        d2 = x["d2cr"]
        inst.append({"caso": x["caso"], "grupo": x["grupo"], "periodo": x["periodo"], "t": x["t"], "esp": x["gabarito"],
                     "tipo": x["tipo"], "sistema": x["grupo"], "na_baseline": bool(x.get("na_baseline")),
                     "f": res[x["caso"]]["f"][x["t"]], "efeitos": x["efeitos"], "p_min": CI.BD._pm(x),
                     "rk2": d2["status"] != "falhou" and bool(d2["ranking"]),
                     "comp": {m: (d0[m]["dec"], d0[m]["rk"], d0[m]["f"]) for m in ("d9", "d9+a")}})
    u = {"nome": "RCAEval-C", "inst": inst, "baro": {c: r["of"] for c, r in res.items()}, "tem_traces": True}
    guardar(nome, u)
    return u


def _job_m(job: tuple[str, str, list[tuple[str, float, tuple[float, float]]]]) -> dict[str, Any]:
    warnings.simplefilter("ignore", RuntimeWarning)
    cb, dia, its = job
    tempo, val, cols = O.series_market(cb, dia)
    return {k: CI.escores(tempo, val, cols, t, ref, familia=True) for k, t, ref in its}


def unidade_m(jobs: int, grade: tuple[int, int] = (120, 600)) -> dict[str, Any]:
    nome = f"u-M-{grade[0]}-{grade[1]}"
    u = ler(nome)
    if u is not None:
        return u
    D = CI._d9a()  # noqa: N806
    linhas = D.carregar("openrca-market")
    bt = O.baseline_traces("openrca-market", jobs)
    plano = O._ad("openrca-market").casos()
    CI.JANELA, CI.REF = grade
    pedidos: dict[tuple[str, str], list] = defaultdict(list)
    for x in linhas:
        v = plano[x["caso"]]
        t = O._ts(x["t"])
        ref = (v["pre"][0], v["pre"][1]) if x["periodo"] == "falha" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        pedidos[(v["cb"], v["dia"])].append(((x["caso"], x["t"]), t, ref))
    for g, b in O._baselines("openrca-market").items():
        v = plano[b["id"]]
        for t in bt[g]["t"]:
            pedidos[(v["cb"], v["dia"])].append(((f"baseline/{g}", str(t)), t, (t - CI.JANELA - CI.REF, t - CI.JANELA)))
    es: dict = {}
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        partes = []
        for (cb, dia), its in pedidos.items():
            for i in range(0, len(its), 20):
                partes.append((cb, dia, its[i:i + 20]))
        for r in ex.map(_job_m, partes):
            es.update(r)
    CI.JANELA, CI.REF = 120, 600
    inst, baro = [], {}
    falhas: dict[str, list] = defaultdict(list)
    for x in linhas:
        d0 = D.decisoes(x)
        d2 = x["d2cr"]
        inst.append({"caso": x["caso"], "grupo": x["grupo"], "periodo": x["periodo"], "t": x["t"], "esp": x["gabarito"],
                     "tipo": x["tipo"], "sistema": x["grupo"], "f": es[(x["caso"], x["t"])], "efeitos": x["efeitos"],
                     "p_min": CI.BD._pm(x), "rk2": d2["status"] != "falhou" and bool(d2["ranking"]),
                     "comp": {m: (d0[m]["dec"], d0[m]["rk"], d0[m]["f"]) for m in ("d9", "d9+a")}})
        if x["periodo"] == "falha":
            falhas[x["caso"]].append(x)
    if grade == (120, 600):
        series: dict = {}
        for c in falhas:
            v = plano[c]
            k = (v["cb"], v["dia"])
            if k not in series:
                series[k] = O.series_market(*k)
            tempo, val, cols = series[k]
            inj = float(v["falha"][0])
            a, b = np.searchsorted(tempo, inj - 600, "left"), np.searchsorted(tempo, inj + 600, "left")
            baro[c] = E2.oficiais(tempo[a:b], val[a:b], cols, inj, "openrca-market")
    base_m = {g: [es[(f"baseline/{g}", str(t))] for t in bt[g]["t"]] for g in bt}
    base_t = {g: bt[g]["janelas"] for g in bt}
    u = {"nome": "Market", "inst": inst, "baro": baro, "tem_traces": True, "base_m": base_m, "base_t": base_t}
    guardar(nome, u)
    return u


def unidade_t(grade: tuple[int, int] = (120, 600)) -> dict[str, Any]:
    """TeaStore 41 cenários, do cache do replay (`robustez_cache_teastore.py`)."""
    nome = f"u-T-{grade[0]}-{grade[1]}"
    u = ler(nome)
    if u is not None:
        return u
    arq = CACHE_TS if grade == (120, 600) else CACHE_TS.replace(".pkl", f"-{grade[0]}-{grade[1]}.pkl")
    while grade == (120, 600) and not os.path.exists(arq):   # montado pelo replay/robustez_cache_teastore.py
        time.sleep(30)
    if not os.path.exists(arq):
        subprocess.run([PY, os.path.join(REPLAY, "robustez_cache_teastore.py"), "--grade", str(grade[0]), str(grade[1]),
                        "--saida", arq], check=True, cwd=os.path.dirname(REPLAY))
    with open(arq, "rb") as f:
        cache = pickle.load(f)
    base0 = None
    if grade != (120, 600):
        base0 = unidade_t()
        idx0 = {(y["caso"], y["t"]): y for y in base0["inst"]}
    inst, baro, base_m, base_t = [], {}, {}, {}
    for cj, d in cache["conjuntos"].items():
        inv = d["inv"]
        base_m[cj] = [e for r in d["res"] for e in r["base"].values()]
        for i, r in enumerate(d["res"]):
            c = r["cenario"]
            baro[c] = r["of"]
            for j, x in enumerate(r["inst"]):
                comp = {m: d["comp"][(m, c, x["t"])] for m in ("d9-k", "d9-k+a", "d9", "d9+a", "v-cons-b")
                        if (m, c, x["t"]) in d["comp"]}
                if base0 is None and len(comp) < 5:
                    continue   # instantes comuns a todos os modos (como na emenda 2)
                rec = {"caso": c, "grupo": cj, "periodo": "falha" if x["periodo"] == "estavel" else "normal",
                       "t": x["t"], "esp": inv[c]["esperado"], "tipo": c.split("/")[1], "sistema": inv[c]["grupo"],
                       "colecao": inv[c]["colecao"], "lote": c.split("/")[0], "f": x["f"], "k8s": x["k8s"],
                       "gt_gravado": x["gt"]}
                if base0 is not None:   # grade: traces e comparadores do cache principal
                    b = idx0.get((c, x["t"]))
                    if b is None:
                        continue
                    rec.update({k: b[k] for k in ("efeitos", "p_min", "rk2", "comp")})
                else:
                    rec.update({"efeitos": x["efeitos"], "p_min": x["p_min"], "rk2": x["rk2"], "comp": comp})
                inst.append(rec)
    if base0 is not None:
        base_t = base0["base_t"]
    else:
        base_t = {col: v for col, v in cache["baseline_traces"].items()}
    u = {"nome": "TeaStore", "inst": inst, "baro": baro, "tem_traces": True, "base_m": base_m, "base_t": base_t}
    guardar(nome, u)
    return u


# ================================================================ calibração e avaliação

def calibrar_m(bases: dict[str, list[dict]]) -> tuple[dict[str, dict], dict[str, float]]:
    pseudo, es = [], {}
    for g, fs in bases.items():
        for i, f in enumerate(fs):
            pseudo.append({"periodo": "normal", "na_baseline": True, "grupo": g, "caso": f"b/{g}", "t": i})
            es[(f"b/{g}", i)] = f
    norm = CI.normalizadores(pseudo, es)
    return norm, CI.tau_gate(pseudo, es, norm)


def gate_t(x: dict, cal: dict) -> bool:
    return bool(calib.passou_d9b(x["efeitos"], cal)) or (x["p_min"] <= cal["q_d2cb"] and x["rk2"])


def avaliar(u: dict, norm: dict, tau: dict, calt: dict | None, excluir: set[str] | None = None,
            chave_m=lambda x: x["grupo"], chave_t=lambda x: x["grupo"], placebo: dict | None = None
            ) -> dict[str, dict[str, Counter]]:
    """Contagens por caso dos modos: g-m∨t|mf, g-m|mf, g-m∨t∨k|mfk (TeaStore) e comparadores."""
    from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k  # noqa: PLC0415
    pc: dict[str, dict[str, Counter]] = defaultdict(lambda: defaultdict(Counter))
    excluir = excluir or set()
    for x in u["inst"]:
        if x["periodo"] == "normal" and x["caso"] in excluir:
            continue
        g = chave_m(x)
        n = norm.get(g, {})
        rk = CI.ranking_rzl(x["f"], n)
        gm = max(CI._u(x["f"], n).values(), default=0.0) >= tau[g]
        gt = gate_t(x, calt[chave_t(x)]) if (u["tem_traces"] and calt is not None) else False
        ds = {"g-m∨t|mf": (gm or gt, rk), "g-m|mf": (gm and bool(rk), rk)}
        if "k8s" in x:
            svc = x["k8s"]
            if placebo is not None and svc:
                svc = placebo[(x["caso"], x["t"])]
            ds["g-m∨t∨k|mfk"] = (gm or gt or bool(x["k8s"]), d9k._promover(rk, svc, 3))
        for m, c in x["comp"].items():
            if isinstance(c, tuple):
                ds[m] = (c[0], c[1] if c[0] else [])
            else:   # A: ranking alternativo no portão g-m
                ds[m] = (gm and bool(c), c)
        for m, (dec, lst) in ds.items():
            k = pc[m][x["caso"]]
            if x["periodo"] == "normal":
                k["nn"] += 1
                k["al"] += dec
            elif x["esp"]:
                k["ne"] += 1
                k["dec"] += dec
                k["tp1"] += dec and lst[:1] == [x["esp"]]
                k["tp2"] += dec and x["esp"] in lst[:2]
    return pc


def f1(cs: list[Counter], k: int = 1) -> float:
    tp = sum(c[f"tp{k}"] for c in cs)
    fp = sum(c["dec"] - c[f"tp{k}"] + c["al"] for c in cs)
    fn = sum(c["ne"] - c[f"tp{k}"] for c in cs)
    return 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else math.nan


def alarme(cs: list[Counter]) -> float:
    d = sum(c["nn"] for c in cs)
    return sum(c["al"] for c in cs) / d if d else math.nan


def resumo(pc: dict[str, Counter], casos: list[str] | None = None) -> tuple[float, float, float]:
    cs = [pc[c] for c in (casos if casos is not None else pc)]
    return f1(cs), f1(cs, 2), alarme(cs)


def meta(pc: dict[str, Counter], casos: list[str] | None = None) -> bool:
    a, b, c = resumo(pc, casos)
    return a >= META[0] and b >= META[1] and c <= META[2]


def ac1_casos(u: dict, norm: dict, k8s: bool = False, casos: set[str] | None = None) -> tuple[dict, dict]:
    """AC@1 por caso: nosso (1º instante de falha, ordem completa; com K8s promovido se pedido) e BARO oficial."""
    from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k  # noqa: PLC0415
    primeiro: dict[str, dict] = {}
    for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
        if x["periodo"] == "falha" and x["esp"] and x["caso"] not in primeiro and (casos is None or x["caso"] in casos):
            primeiro[x["caso"]] = x
    nos, baro = {}, {}
    for c, x in primeiro.items():
        o = E2.ordem_completa(x["f"], norm.get(x["grupo"], {}))
        if k8s:
            o = d9k._promover(o, x.get("k8s"), 99)
        nos[c] = float(o[:1] == [x["esp"]])
        b = (u["baro"].get(c) or {}).get("BARO", [])
        baro[c] = float(b[:1] == [x["esp"]])
    return nos, baro


# ================================================================ calibrações originais (as registradas)

def cal_original(u: dict) -> dict[str, Any]:
    if u["nome"] == "A":
        res: dict[str, dict] = defaultdict(lambda: {"inst": []})
        for x in u["inst"]:
            res[x["caso"]]["suite"] = x["grupo"]
            res[x["caso"]]["inst"].append(x)
        base = {s: CA.baseline(res, s, set()) for s in CA.SUITES}
        bm = {s: [x["f"] for c in cc for x in res[c]["inst"] if x["periodo"] == "normal"] for s, cc in base.items()}
        norm, tau = calibrar_m(bm)
        return {"norm": norm, "tau": tau, "calt": None, "excluir": set().union(*base.values())}
    if u["nome"] == "RCAEval-C":
        bm = defaultdict(list)
        bt = defaultdict(list)
        for x in u["inst"]:
            if x["periodo"] == "normal" and x["na_baseline"]:
                bm[x["grupo"]].append(x["f"])
                bt[x["grupo"]].append({"efeitos": x["efeitos"], "p_min": x["p_min"]})
        norm, tau = calibrar_m(bm)
        excl = {x["caso"] for x in u["inst"] if x["na_baseline"]}
        return {"norm": norm, "tau": tau, "calt": {g: calib.calibrar(v, 0.01) for g, v in bt.items()}, "excluir": excl}
    if u["nome"] == "Market":
        norm, tau = calibrar_m(u["base_m"])
        return {"norm": norm, "tau": tau, "calt": {g: calib.calibrar(v, 0.01) for g, v in u["base_t"].items()},
                "excluir": set()}
    norm, tau = calibrar_m(u["base_m"])   # TeaStore: por conjunto (B′ e definitiva)
    return {"norm": norm, "tau": tau, "calt": {c: calib.calibrar(v, 0.01) for c, v in u["base_t"].items()},
            "excluir": set()}


def avaliar_orig(u: dict, cal: dict, **kw: Any) -> dict[str, dict[str, Counter]]:
    kt = (lambda x: x["colecao"]) if u["nome"] == "TeaStore" else (lambda x: x["grupo"])
    return avaliar(u, cal["norm"], cal["tau"], cal["calt"], cal["excluir"], chave_t=kt, **kw)


B_LOTES = {"20261013T051436Z", "20261013T061915Z", "20261013T143247Z", "20261016T075241Z"}


def casos_b(pc: dict) -> list[str]:
    return [c for c in pc if c.split("/")[0] in B_LOTES]


def conclusoes_fix(pcs: dict[str, dict]) -> dict[str, bool]:
    out = {}
    if "A" in pcs:
        out["K-A"] = meta(pcs["A"]["g-m∨t|mf"])
    if "RCAEval-C" in pcs:
        p = pcs["RCAEval-C"]
        f = resumo(p["g-m∨t|mf"])[0]
        out["K-RC"] = f > resumo(p["d9"])[0] and f > resumo(p["d9+a"])[0]
    if "Market" in pcs:
        p = pcs["Market"]
        out["K-M"] = resumo(p["g-m∨t|mf"])[0] > resumo(p["d9"])[0]
    if "TeaStore" in pcs:
        p = pcs["TeaStore"]
        out["K-B"] = meta(p["g-m∨t∨k|mfk"], casos_b(p["g-m∨t∨k|mfk"]))
        out["K-k1"] = resumo(p["g-m∨t∨k|mfk"])[0] > resumo(p["g-m∨t|mf"])[0]
    return out


# ================================================================ R1 — sorteio de baseline

_U: dict[str, Any] = {}


def _r1_um(args: tuple[str, int]) -> dict[str, Any]:
    warnings.simplefilter("ignore", RuntimeWarning)
    nome, i = args
    u = _U[nome]
    rnd = random.Random(f"20261019-R1-{nome}-{i}")
    if nome == "A":
        res: dict[str, list] = defaultdict(list)
        suite = {}
        for x in u["inst"]:
            res[x["caso"]].append(x)
            suite[x["caso"]] = x["grupo"]
        bm, excl = {}, set()
        for s in CA.SUITES:
            cs = sorted(c for c in res if suite[c] == s)
            rnd.shuffle(cs)
            esc, n = [], 0
            for c in cs:
                esc.append(c)
                n += sum(1 for x in res[c] if x["periodo"] == "normal")
                if n >= CA.MIN_JANELAS_BASE and len(esc) >= CA.MIN_CASOS_BASE:
                    break
            bm[s] = [x["f"] for c in esc for x in res[c] if x["periodo"] == "normal"]
            excl |= set(esc)
        norm, tau = calibrar_m(bm)
        pc = avaliar(u, norm, tau, None, excl)
    elif nome == "RCAEval-C":
        por: dict[str, set] = defaultdict(set)
        for x in u["inst"]:
            por[x["grupo"]].add(x["caso"])
        esc = {g: set(rnd.sample(sorted(cs), 5)) for g, cs in por.items()}
        bm, bt = defaultdict(list), defaultdict(list)
        for x in u["inst"]:
            if x["periodo"] == "normal" and x["caso"] in esc[x["grupo"]]:
                bm[x["grupo"]].append(x["f"])
                bt[x["grupo"]].append({"efeitos": x["efeitos"], "p_min": x["p_min"]})
        norm, tau = calibrar_m(bm)
        calt = {g: calib.calibrar(v, 0.01) for g, v in bt.items()}
        pc = avaliar(u, norm, tau, calt, set().union(*esc.values()))
    elif nome == "Market":
        bm = {g: [v[rnd.randrange(len(v))] for _ in v] for g, v in u["base_m"].items()}
        bt = {g: [v[rnd.randrange(len(v))] for _ in v] for g, v in u["base_t"].items()}
        norm, tau = calibrar_m(bm)
        pc = avaliar(u, norm, tau, {g: calib.calibrar(v, 0.01) for g, v in bt.items()})
    else:
        bm = {g: [v[rnd.randrange(len(v))] for _ in v] for g, v in u["base_m"].items()}
        bt = {g: [v[rnd.randrange(len(v))] for _ in v] for g, v in u["base_t"].items()}
        norm, tau = calibrar_m(bm)
        pc = avaliar(u, norm, tau, {g: calib.calibrar(v, 0.01) for g, v in bt.items()}, chave_t=lambda x: x["colecao"])
    out = {"i": i, "conc": conclusoes_fix({nome: pc})}
    for m in ("g-m∨t|mf", "g-m∨t∨k|mfk"):
        if m in pc:
            out[m] = resumo(pc[m])
            if nome == "TeaStore":
                out[m + "@B"] = resumo(pc[m], casos_b(pc[m]))
    return out


def r1(us: dict[str, dict], jobs: int) -> dict[str, Any]:
    feito = ler("R1") or {}
    from multiprocessing import get_context  # noqa: PLC0415
    _U.update(us)
    for nome in us:
        lst = feito.get(nome, [])
        faltam = [i for i in range(N_R1) if i not in {r["i"] for r in lst}]
        with get_context("fork").Pool(jobs) as p:
            for k in range(0, len(faltam), jobs * 4):
                if resta() < 3600 * 2.5:   # reserva para as etapas seguintes
                    break
                lst += p.map(_r1_um, [(nome, i) for i in faltam[k:k + jobs * 4]])
                feito[nome] = lst
                guardar("R1", feito)
                print(f"R1 {nome}: {len(lst)}/{N_R1}", flush=True)
    return feito


# ================================================================ R2 / R3 / R8 (vetorizados por caso)

def _arr(pc: dict[str, Counter], casos: list[str]) -> np.ndarray:
    return np.array([[pc[c][k] for k in ("tp1", "tp2", "dec", "al", "ne", "nn")] for c in casos], dtype=float)


def _f1v(s: np.ndarray, k: int = 0) -> np.ndarray:
    tp, dec, al, ne = s[..., k], s[..., 2], s[..., 3], s[..., 4]
    den = 2 * tp + (dec - tp + al) + (ne - tp)
    return np.where(den > 0, 2 * tp / np.maximum(den, 1e-12), np.nan)


def r2(pcs: dict[str, dict], modos: dict[str, list[tuple[str, list[str] | None]]]) -> dict[str, Any]:
    out = {}
    rng = np.random.default_rng(2026101902)
    for base, lst in modos.items():
        for m, casos in lst:
            pc = pcs[base][m]
            cs = casos if casos is not None else sorted(pc)
            a = _arr(pc, cs)
            idx = rng.integers(0, len(cs), size=(N_BOOT, len(cs)))
            s = a[idx].sum(axis=1)
            f1a, f2a = _f1v(s, 0), _f1v(s, 1)
            al = np.where(s[:, 5] > 0, s[:, 3] / np.maximum(s[:, 5], 1), 0)
            pm = np.mean((f1a >= META[0]) & (f2a >= META[1]) & (al <= META[2]))
            out[(base, m, "B′" if casos is not None else "todos")] = {
                "f1": resumo(pc, cs)[0], "ic": np.nanpercentile(f1a, [2.5, 97.5]).tolist(),
                "f2_ic": np.nanpercentile(f2a, [2.5, 97.5]).tolist(), "p_meta": float(pm), "n": len(cs)}
    return out


def _perm_f1(pa: dict, pb: dict, rng: np.random.Generator) -> tuple[float, float]:
    cs = sorted(set(pa) & set(pb))
    a, b = _arr(pa, cs), _arr(pb, cs)
    obs = float(_f1v(a.sum(0)) - _f1v(b.sum(0)))
    flip = rng.random((N_PERM, len(cs))) < 0.5
    sa = np.where(flip[..., None], b[None], a[None]).sum(1)
    sb = np.where(flip[..., None], a[None], b[None]).sum(1)
    d = _f1v(sa) - _f1v(sb)
    return obs, float((np.sum(np.abs(d) >= abs(obs) - 1e-12) + 1) / (N_PERM + 1))


def _perm_ac(na: dict, nb: dict, rng: np.random.Generator) -> tuple[float, float]:
    cs = sorted(set(na) & set(nb))
    a, b = np.array([na[c] for c in cs]), np.array([nb[c] for c in cs])
    obs = float(a.mean() - b.mean())
    flip = rng.random((N_PERM, len(cs))) < 0.5
    d = np.where(flip, b, a).mean(1) - np.where(flip, a, b).mean(1)
    return obs, float((np.sum(np.abs(d) >= abs(obs) - 1e-12) + 1) / (N_PERM + 1))


def r3(us: dict, cals: dict, pcs: dict) -> list[dict[str, Any]]:
    rng = np.random.default_rng(2026101903)
    comps = []
    p = pcs.get("A")
    if p:
        comps += [("A", "F1@1", "g-m∨t|mf", "m-rz|g-m", _perm_f1(p["g-m∨t|mf"], p["m-rz|g-m"], rng)),
                  ("A", "F1@1", "g-m∨t|mf", "cpu-max|g-m", _perm_f1(p["g-m∨t|mf"], p["cpu-max|g-m"], rng))]
        n, b = ac1_casos(us["A"], cals["A"]["norm"])
        comps.append(("A", "AC@1 por caso", "g-m∨t|mf (1º instante)", "BARO oficial", _perm_ac(n, b, rng)))
    p = pcs.get("RCAEval-C")
    if p:
        comps += [("RCAEval-C", "F1@1", "g-m∨t|mf", "d9 (= d9-k)", _perm_f1(p["g-m∨t|mf"], p["d9"], rng)),
                  ("RCAEval-C", "F1@1", "g-m∨t|mf", "d9+a (= d9-k+a)", _perm_f1(p["g-m∨t|mf"], p["d9+a"], rng))]
        n, b = ac1_casos(us["RCAEval-C"], cals["RCAEval-C"]["norm"])
        comps.append(("RCAEval-C", "AC@1 por caso", "g-m∨t|mf (1º instante)", "BARO oficial", _perm_ac(n, b, rng)))
    p = pcs.get("Market")
    if p:
        comps.append(("Market", "F1@1", "g-m∨t|mf", "d9 (= d9-k)", _perm_f1(p["g-m∨t|mf"], p["d9"], rng)))
        n, b = ac1_casos(us["Market"], cals["Market"]["norm"])
        comps.append(("Market", "AC@1 por caso", "g-m∨t|mf (1º instante)", "BARO oficial", _perm_ac(n, b, rng)))
    p = pcs.get("TeaStore")
    if p:
        comps += [("TeaStore", "F1@1", "g-m∨t∨k|mfk", "g-m∨t|mf", _perm_f1(p["g-m∨t∨k|mfk"], p["g-m∨t|mf"], rng)),
                  ("TeaStore", "F1@1", "g-m∨t∨k|mfk", "d9-k+a", _perm_f1(p["g-m∨t∨k|mfk"], p["d9-k+a"], rng))]
        u = us["TeaStore"]
        nk, b = {}, {}
        for cj in ("B′", "definitiva"):
            sub = {"inst": [x for x in u["inst"] if x["grupo"] == cj], "baro": u["baro"]}
            a1, b1 = ac1_casos(sub, {cj: cals["TeaStore"]["norm"][cj]}, k8s=True)
            nk.update(a1)
            b.update(b1)
        comps.append(("TeaStore", "AC@1 por caso", "g-m∨t∨k|mfk (1º instante)", "BARO oficial", _perm_ac(nk, b, rng)))
        comps.append(("TeaStore", "F1@1", "d9-k", "d9", _perm_f1(p["d9-k"], p["d9"], rng)))
    ps = [c[4][1] for c in comps]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    return [{"base": c[0], "medida": c[1], "a": c[2], "b": c[3], "delta": c[4][0], "p": c[4][1], "p_holm": h}
            for c, h in zip(comps, holm, strict=True)]


def r4(u: dict, cal: dict, pc_real: dict) -> dict[str, Any]:
    svcs = sorted({s for x in u["inst"] for s in x["f"]})
    alvo = [(x["caso"], x["t"]) for x in u["inst"] if x["k8s"]]
    obs = resumo(pc_real["g-m∨t∨k|mfk"])[0] - resumo(pc_real["g-m∨t|mf"])[0]
    base_f1 = resumo(pc_real["g-m∨t|mf"])[0]
    rnd = random.Random("20261019-R4")
    dist = []
    for i in range(N_PLAC):
        if i % 500 == 0 and resta() < 3600 * 1.5:
            break
        plac = {k: rnd.choice(svcs) for k in alvo}
        pc = avaliar_orig(u, cal, placebo=plac)
        dist.append(resumo(pc["g-m∨t∨k|mfk"])[0] - base_f1)
    d = np.array(dist)
    return {"obs": obs, "n": len(d), "p95": float(np.percentile(d, 95)) if len(d) else math.nan,
            "p": float((np.sum(d >= obs - 1e-12) + 1) / (len(d) + 1)) if len(d) else math.nan,
            "media": float(d.mean()) if len(d) else math.nan, "n_inst_k8s": len(alvo), "servicos": svcs}


def r6(us: dict, pcs: dict) -> list[dict[str, Any]]:
    out = []
    for nome, u in us.items():
        attrs = ("grupo", "sistema", "tipo") if nome != "TeaStore" else ("grupo", "lote", "sistema", "tipo")
        caso_attr = {}
        for x in u["inst"]:
            caso_attr[x["caso"]] = {a: x.get(a) for a in attrs}
        p = pcs[nome]
        for a in attrs:
            for v in sorted({ca[a] for ca in caso_attr.values() if ca[a] is not None}, key=str):
                fica = [c for c, ca in caso_attr.items() if ca[a] != v]
                sub = {m: {c: p[m][c] for c in fica if c in p[m]} for m in p}
                out.append({"base": nome, "fora": f"{a}={v}", "n": len(fica), "conc": conclusoes_fix({nome: sub})})
    return out


def r7(u: dict, pc: dict) -> dict[str, Any]:
    estr: dict[tuple, list] = defaultdict(list)
    for c, g, t in sorted({(x["caso"], x["grupo"], x["tipo"]) for x in u["inst"]}):
        estr[(g, t)].append(c)
    obs = None
    gaps = []
    registrada = CI.dividir(u["inst"])   # a divisão do ciclo (mantida sem a cópia de `comum.DUPLICADOS`)
    for i in range(N_SPLIT + 1):
        if i == 0:
            dev = {c for c, v in registrada.items() if v == "dev"}
        else:
            rnd = random.Random(f"20261019-R7-{i}")
            dev = set()
            for k in sorted(estr):
                cs = list(estr[k])
                rnd.shuffle(cs)
                dev |= {c for j, c in enumerate(cs) if j % 2 == 0}
        p = pc["g-m∨t|mf"]
        g = resumo(p, [c for c in p if c in dev])[0] - resumo(p, [c for c in p if c not in dev])[0]
        if i == 0:
            obs = g
        else:
            gaps.append(g)
    gaps_a = np.array(gaps)
    return {"obs": obs, "pct": float(np.mean(gaps_a < obs) * 100), "p95": float(np.percentile(gaps_a, 95)),
            "p5": float(np.percentile(gaps_a, 5))}


def r8(u: dict, cal: dict, modo: str) -> dict[str, Any]:
    """Ranking aleatório com o mesmo portão: acerto top-1 ~ Bernoulli(1/nº de serviços com escore)."""
    pc = avaliar_orig(u, cal)
    rng = np.random.default_rng(2026101908)
    obs = resumo(pc[modo])[0]
    casos = sorted(pc[modo])
    idx = {c: i for i, c in enumerate(casos)}
    fixo = np.zeros(4)   # dec, al, ne, nn (não dependem do ranking)
    for c in casos:
        k = pc[modo][c]
        fixo += [k["dec"], k["al"], k["ne"], k["nn"]]
    probs = []
    for x in u["inst"]:
        if x["periodo"] == "falha" and x["esp"] and x["caso"] in idx:
            n = len(x["f"]) or 1
            probs.append(1.0 / n)
    # aproximação: o portão decide em toda falha em que decidiu; usa a taxa de decisão do caso
    taxa_dec = fixo[0] / max(fixo[2], 1)
    pr = np.array(probs) * taxa_dec
    tp = rng.binomial(1, np.broadcast_to(pr, (N_ACASO, len(pr)))).sum(1)
    dec, al, ne = fixo[0], fixo[1], fixo[2]
    f = 2 * tp / (2 * tp + (dec - tp + al) + (ne - tp))
    return {"obs": obs, "p99": float(np.percentile(f, 99)), "media": float(f.mean())}


# ================================================================ relatório

def relatorio(us, cals, pcs, R) -> str:
    out = ["# Emenda 3 — robustez estatística do `g-m∨t|mf` e do `g-m∨t∨k|mfk`", "",
           f"`PROTOCOLO-COMPLETO.md` emenda 3. Início {datetime.datetime.fromtimestamp(INICIO):%Y-%m-%d %H:%M}, teto 9 h; "
           f"gerado {datetime.datetime.now():%Y-%m-%d %H:%M}.", ""]
    conc0 = conclusoes_fix(pcs)
    out += ["## Reprodução (calibração registrada)", "", "| base | modo | F1@1 | F1@2 | alarme |", "|---|---|---|---|---|"]
    for nome, p in pcs.items():
        for m in ("g-m∨t|mf", "g-m∨t∨k|mfk"):
            if m in p:
                a, b, c = resumo(p[m])
                out.append(f"| {nome} | {m} | {a:.3f} | {b:.3f} | {c:.1%} |")
                if nome == "TeaStore":
                    a, b, c = resumo(p[m], casos_b(p[m]))
                    out.append(f"| TeaStore B′ | {m} | {a:.3f} | {b:.3f} | {c:.1%} |")
    out += ["", "Conclusões na calibração registrada: " + ", ".join(f"{k} = {'sim' if v else 'não'}" for k, v in conc0.items()), ""]
    if "R1" in R:
        out += ["## R1 — sorteio de baseline", "", "| base | sorteios | conclusão | fração em que vale | F1@1 mediana [2,5%–97,5%] |",
                "|---|---|---|---|---|"]
        for nome, lst in R["R1"].items():
            if not lst:
                continue
            m = "g-m∨t∨k|mfk" if nome == "TeaStore" else "g-m∨t|mf"
            f = np.array([r[m][0] for r in lst])
            for k in lst[0]["conc"]:
                fr = np.mean([r["conc"][k] for r in lst])
                out.append(f"| {nome} | {len(lst)} | {k} | {fr:.1%} {'(robusto)' if fr >= 0.95 else '(**não robusto**)'} | "
                           f"{np.median(f):.3f} [{np.percentile(f, 2.5):.3f}–{np.percentile(f, 97.5):.3f}] |")
            if nome == "TeaStore":
                fb = np.array([r[m + "@B"][0] for r in lst])
                out.append(f"| TeaStore B′ | {len(lst)} | F1@1 de {m} | — | {np.median(fb):.3f} "
                           f"[{np.percentile(fb, 2.5):.3f}–{np.percentile(fb, 97.5):.3f}] |")
        out.append("")
    if "R2" in R:
        out += ["## R2 — bootstrap de caso (10.000)", "", "| base | modo | conjunto | n | F1@1 [IC 95%] | F1@2 IC 95% | P(meta) |",
                "|---|---|---|---|---|---|---|"]
        for (b, m, cj), v in R["R2"].items():
            out.append(f"| {b} | {m} | {cj} | {v['n']} | {v['f1']:.3f} [{v['ic'][0]:.3f}–{v['ic'][1]:.3f}] | "
                       f"{v['f2_ic'][0]:.3f}–{v['f2_ic'][1]:.3f} | {v['p_meta']:.1%} |")
        out.append("")
    if "R3" in R:
        out += ["## R3 — permutação pareada (10.000 por comparação; Holm sobre as 12)", "",
                "| base | medida | a | b | Δ (a − b) | p | p Holm | robusto |", "|---|---|---|---|---|---|---|---|"]
        for c in R["R3"]:
            out.append(f"| {c['base']} | {c['medida']} | {c['a']} | {c['b']} | {c['delta']:+.3f} | {c['p']:.4f} | "
                       f"{c['p_holm']:.4f} | {'sim' if c['p_holm'] < 0.05 else 'não'} |")
        out.append("")
    if "R4" in R:
        v = R["R4"]
        out += ["## R4 — placebo do K8s (serviço aleatório nos mesmos instantes)", "",
                f"ΔF1@1 real {v['obs']:+.3f}; placebo ({v['n']} sorteios, {v['n_inst_k8s']} instantes com K8s): média "
                f"{v['media']:+.3f}, percentil 95 {v['p95']:+.3f}; p = {v['p']:.4f} → "
                f"**{'robusto' if v['obs'] > v['p95'] else 'não robusto'}**.", ""]
    if "R5" in R:
        out += ["## R5 — grade de constantes (janela × referência das métricas)", "",
                "| janela | referência | " + " | ".join(sorted({k for g in R["R5"].values() for k in g["conc"]})) + " | F1@1 por base |",
                "|---|---|" + "---|" * (len({k for g in R["R5"].values() for k in g["conc"]}) + 1)]
        ks = sorted({k for g in R["R5"].values() for k in g["conc"]})
        for (j, r), g in sorted(R["R5"].items()):
            out.append(f"| {j} | {r} | " + " | ".join("sim" if g["conc"].get(k) else "não" for k in ks) + " | "
                       + "; ".join(f"{b} {v:.3f}" for b, v in g["f1"].items()) + " |")
        fr = {k: np.mean([g["conc"].get(k, False) for g in R["R5"].values()]) for k in ks}
        out += ["", "Fração da grade em que vale: " + ", ".join(f"{k} {v:.0%}" for k, v in fr.items()), ""]
    if "R6" in R:
        inv = [x for x in R["R6"] if not all(x["conc"].get(k, v) == v for k, v in conc0.items() if k in x["conc"])]
        out += ["## R6 — deixa um grupo de fora", "", f"{len(R['R6'])} recortes; {len(inv)} invertem alguma conclusão.", ""]
        if inv:
            out += ["| base | fora | n casos | conclusões |", "|---|---|---|---|"]
            out += [f"| {x['base']} | {x['fora']} | {x['n']} | " + ", ".join(f"{k}={'sim' if v else 'não'}"
                                                                          for k, v in x["conc"].items()) + " |" for x in inv]
            out.append("")
    if "R7" in R:
        v = R["R7"]
        out += ["## R7 — divisões dev/holdout aleatórias (RCAEval C, 1.000)", "",
                f"Queda observada dev − holdout = {v['obs']:+.3f}; percentil {v['pct']:.1f} da distribuição "
                f"(5%–95%: {v['p5']:+.3f} a {v['p95']:+.3f}) → "
                f"**{'compatível com sorte da divisão' if v['obs'] <= v['p95'] else 'acima do esperado: sinal de ajuste ao dev'}**.", ""]
    if "R8" in R:
        out += ["## R8 — acaso (ranking aleatório, mesmo portão; 10.000)", "", "| base | modo | F1@1 real | acaso média | acaso p99 | acima do p99 |",
                "|---|---|---|---|---|---|"]
        for (b, m), v in R["R8"].items():
            out.append(f"| {b} | {m} | {v['obs']:.3f} | {v['media']:.3f} | {v['p99']:.3f} | {'sim' if v['obs'] > v['p99'] else 'não'} |")
        out.append("")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--etapas", default="R1,R2,R3,R4,R5,R6,R7,R8")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    warnings.simplefilter("ignore", RuntimeWarning)
    etapas = args.etapas.split(",")
    t0 = time.time()
    us = {"A": unidade_a(args.jobs), "RCAEval-C": unidade_c(args.jobs), "Market": unidade_m(args.jobs), "TeaStore": unidade_t()}
    print(f"unidades prontas em {time.time() - t0:.0f}s; resta {resta() / 3600:.1f} h", flush=True)
    cals = {n: cal_original(u) for n, u in us.items()}
    pcs = {n: avaliar_orig(u, cals[n]) for n, u in us.items()}
    ut = us["TeaStore"]
    dif = sum(1 for x in ut["inst"] if gate_t(x, cals["TeaStore"]["calt"][x["colecao"]]) != x["gt_gravado"])
    print(f"reprodução: portão de traces TeaStore recalculado × gravado: {dif} diferenças em {len(ut['inst'])}; "
          + "; ".join(f"{n} {resumo(p['g-m∨t∨k|mfk' if n == 'TeaStore' else 'g-m∨t|mf'])}" for n, p in pcs.items()),
          flush=True)
    R = ler("resultados") or {}
    if "R1" in etapas:
        R["R1"] = r1(us, args.jobs)
        guardar("resultados", R)
    if "R2" in etapas and "R2" not in R:
        R["R2"] = r2(pcs, {"A": [("g-m∨t|mf", None)], "RCAEval-C": [("g-m∨t|mf", None)], "Market": [("g-m∨t|mf", None)],
                           "TeaStore": [("g-m∨t∨k|mfk", None), ("g-m∨t∨k|mfk", casos_b(pcs["TeaStore"]["g-m∨t∨k|mfk"])),
                                        ("g-m∨t|mf", None)]})
        guardar("resultados", R)
    if "R3" in etapas and "R3" not in R:
        R["R3"] = r3(us, cals, pcs)
        guardar("resultados", R)
    if "R4" in etapas and "R4" not in R:
        R["R4"] = r4(us["TeaStore"], cals["TeaStore"], pcs["TeaStore"])
        guardar("resultados", R)
    if "R5" in etapas:
        g5 = R.get("R5", {})
        for gr in GRADE:
            if gr in g5:
                continue
            if resta() < 3600 * 0.75:
                print("R5: teto próximo, parando a grade", flush=True)
                break
            ug = {"A": unidade_a(args.jobs, gr), "RCAEval-C": unidade_c(args.jobs, gr), "Market": unidade_m(args.jobs, gr),
                  "TeaStore": unidade_t(gr)}
            pg = {}
            for n, u in ug.items():
                cal = cals[n] if n not in ("Market", "TeaStore") else None
                if n == "A":   # mesma escolha de casos de baseline, escores da grade
                    res: dict[str, list] = defaultdict(list)
                    for x in u["inst"]:
                        res[x["caso"]].append(x)
                    bm = defaultdict(list)
                    for c in cals["A"]["excluir"]:
                        bm[c.split("/")[0]] += [x["f"] for x in res[c] if x["periodo"] == "normal"]
                    norm, tau = calibrar_m(bm)
                    pg[n] = avaliar(u, norm, tau, None, cals["A"]["excluir"])
                elif n == "RCAEval-C":
                    bm = defaultdict(list)
                    for x in u["inst"]:
                        if x["periodo"] == "normal" and x["na_baseline"]:
                            bm[x["grupo"]].append(x["f"])
                    norm, tau = calibrar_m(bm)
                    pg[n] = avaliar(u, norm, tau, cals[n]["calt"], cals[n]["excluir"])
                else:
                    norm, tau = calibrar_m(u["base_m"])
                    pg[n] = avaliar(u, norm, tau, cals[n]["calt"], chave_t=(lambda x: x["colecao"]) if n == "TeaStore" else (lambda x: x["grupo"]))
                del cal
            g5[gr] = {"conc": conclusoes_fix(pg),
                      "f1": {n: resumo(p["g-m∨t∨k|mfk" if n == "TeaStore" else "g-m∨t|mf"])[0] for n, p in pg.items()}}
            R["R5"] = g5
            guardar("resultados", R)
            print(f"R5 {gr}: {g5[gr]['conc']}", flush=True)
    if "R6" in etapas and "R6" not in R:
        R["R6"] = r6(us, pcs)
        guardar("resultados", R)
    if "R7" in etapas and "R7" not in R:
        R["R7"] = r7(us["RCAEval-C"], pcs["RCAEval-C"])
        guardar("resultados", R)
    if "R8" in etapas and "R8" not in R:
        R["R8"] = {(n, m): r8(us[n], cals[n], m) for n, m in (("A", "g-m∨t|mf"), ("RCAEval-C", "g-m∨t|mf"),
                                                                ("Market", "g-m∨t|mf"), ("TeaStore", "g-m∨t∨k|mfk"))}
        guardar("resultados", R)
    texto = relatorio(us, cals, pcs, R)
    with open(os.path.join(AQUI, "resultado-robustez.md"), "w") as f:
        f.write(texto)
    print(texto)
    print(f"fim; resta {resta() / 3600:.1f} h", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
