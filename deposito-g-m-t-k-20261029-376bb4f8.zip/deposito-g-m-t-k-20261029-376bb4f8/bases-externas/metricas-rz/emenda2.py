#!/usr/bin/env python3
"""Emenda 2 do `PROTOCOLO-COMPLETO.md` no RCAEval (A: 480 inéditos só métricas; C: 240 com traces) e no Market (77).

- E2.1: BARO e N-Sigma **oficiais** (`RCAEval.e2e.baro` / `nsigma`, pacote 1.8.0, sem alteração), no mesmo arquivo
  de métricas do `g-m∨t|mf`, uma vez por caso; validação do BARO no RE2-TT contra a Tabela 6 do RCAEval.
- E2.2: AC@1, AC@3 e Avg@5 por caso (serviço). `g-m∨t|mf` = ordem completa do `m-rzf` no 1º instante de falha
  (secundário: último instante). Por instante: F1 + AC@3 e o `BARO-janela` (RobustScaler do BARO na janela de 120 s,
  mesma referência) no lugar do `m-rzf`, com os mesmos portões.
- E2.3: sensibilidade do FP_ALVO do `g-m` (0,01 / 0,05 / 0,10).

Código congelado (`ciclo.py`, `outras.py`, `confirmatorio_a.py`) só é chamado. `--teste`: BARO em 3 casos por base,
confere que devolve serviços do gabarito (sem resultado). Saída: `resultado-emenda2.md`.
Uso: python emenda2.py [--teste] [--jobs 24]
"""
from __future__ import annotations

import argparse
import math
import os
import random
import sys
import warnings
from collections import Counter, defaultdict
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import confirmatorio_a as CA  # noqa: E402
import outras as O  # noqa: E402

CI = O.CI
FPS_G = (0.01, 0.05, 0.10)
PUBLICADO_RE2TT = {"AC@1": 0.67, "AC@3": 0.82, "Avg@5": 0.80}   # RCAEval (WWW'25), Tabela 6, BARO métrica, média


# ---------------------------------------------------------------- utilitários (também usados no TeaStore)

def servico_col(col: str) -> str:
    return col.split("__")[0] if "__" in col else col.rsplit("_", 1)[0]


def servicos_em_ordem(cols: list[str]) -> list[str]:
    out: list[str] = []
    for c in cols:
        s = servico_col(c)
        if s not in out:
            out.append(s)
    return out


def oficiais(tempo: np.ndarray, val: np.ndarray, cols: list[str], inj: float, dataset: str) -> dict[str, list[str]]:
    """BARO e N-Sigma oficiais (RCAEval 1.8.0) → ranking de serviços. Colunas renomeadas só para serem únicas."""
    from RCAEval.e2e import baro, nsigma  # noqa: PLC0415
    nomes = [f"{servico_col(c)}__{i}_{c.rsplit('_', 1)[1]}" for i, c in enumerate(cols)]
    df = pd.DataFrame(val, columns=nomes)
    df.insert(0, "time", tempo)
    out = {}
    for nome, fn in (("BARO", baro), ("N-Sigma", nsigma)):
        try:
            out[nome] = servicos_em_ordem(fn(data=df, inject_time=inj, dataset=dataset)["ranks"])
        except Exception:  # noqa: BLE001
            out[nome] = []
    return out


def baro_janela(tempo: np.ndarray, val: np.ndarray, cols: list[str], t: float, ref: tuple[float, float]) -> list[str]:
    """RobustScaler do BARO (centro = mediana, escala = IQR; IQR 0 → 1, como o sklearn) ajustado na referência do
    instante; escore = máximo na janela de 120 s; serviço = sua melhor coluna."""
    a, b = np.searchsorted(tempo, t - CI.JANELA, "right"), np.searchsorted(tempo, t, "right")
    r0, r1 = np.searchsorted(tempo, ref[0], "left"), np.searchsorted(tempo, ref[1], "left")
    jan, rf = val[a:b], val[r0:r1]
    if len(jan) == 0 or len(rf) == 0:
        return []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        med = np.nanmedian(rf, axis=0)
        iqr = np.nanpercentile(rf, 75, axis=0) - np.nanpercentile(rf, 25, axis=0)
        iqr = np.where(iqr > 0, iqr, 1.0)
        z = np.nanmax((jan - med) / iqr, axis=0)
    por: dict[str, float] = {}
    for c, v in zip(cols, z, strict=True):
        if np.isfinite(v):
            s = servico_col(c)
            por[s] = max(por.get(s, -np.inf), float(v))
    return [s for s, _ in sorted(por.items(), key=lambda kv: (-kv[1], kv[0]))]


def ordem_completa(e: dict[str, dict[str, float]], norm: dict[str, float]) -> list[str]:
    u = CI._u(e, norm)
    return [s for s, _ in sorted(u.items(), key=lambda kv: (-kv[1], kv[0]))]


def ac(rks: list[list[str]], esps: list[str]) -> dict[str, float]:
    n = len(rks)
    if not n:
        return {"AC@1": math.nan, "AC@3": math.nan, "Avg@5": math.nan, "n": 0}
    a = {k: sum(e in r[:k] for r, e in zip(rks, esps, strict=True)) / n for k in range(1, 6)}
    return {"AC@1": a[1], "AC@3": a[3], "Avg@5": sum(a.values()) / 5, "n": n}


def contar(pc: dict, caso: str, periodo: str, esp: str | None, ds: dict[str, tuple[bool, list[str]]]) -> None:
    for m, (dec, rk) in ds.items():
        c = pc[m][caso]
        if periodo == "normal":
            c["nn"] += 1
            c["al"] += dec
        elif esp:
            c["ne"] += 1
            c["dec"] += dec
            for k in (1, 2):
                c[f"tp{k}"] += dec and esp in rk[:k]
            for k in (1, 2, 3):
                c[f"o{k}"] += esp in rk[:k]


def tabela_inst(D: Any, pc: dict, casos: list[str], modos: tuple[str, ...]) -> list[str]:  # noqa: N803
    out = ["| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |",
           "|---|---|---|---|---|---|---|---|"]
    for m in modos:
        cs = [pc[m][c] for c in casos if c in pc[m]]
        ic = D.boot([c for c in casos if c in pc[m]], lambda s, m=m: D.f1([pc[m][c] for c in s]))
        out.append(f"| {m} | {sum(1 for c in cs if c['ne'])} | {D._f(D.f1(cs))} [{D._f(ic[0])}–{D._f(ic[1])}] | "
                   f"{D._f(D.f1(cs, 2))} | {D._p(D.taxa(cs, 'al', 'nn'))} | {D._p(1 - D.taxa(cs, 'dec', 'ne'))} | "
                   f"{D._p(D.media(cs, 'o1'))} | {D._p(D.media(cs, 'o3'))} |")
    return out


def tabela_caso(por: dict[str, tuple[list[list[str]], list[str]]]) -> list[str]:
    out = ["| método | casos | AC@1 | AC@3 | Avg@5 |", "|---|---|---|---|---|"]
    for m, (rks, esps) in por.items():
        a = ac(rks, esps)
        out.append(f"| {m} | {a['n']} | {a['AC@1']:.3f} | {a['AC@3']:.3f} | {a['Avg@5']:.3f} |")
    return out


def _tau(pseudo: list[dict], es: dict, norm: dict) -> dict[float, dict[str, float]]:
    return {fp: CI.tau_gate(pseudo, es, norm, fp) for fp in FPS_G}


# ---------------------------------------------------------------- RCAEval A (480 inéditos, só métricas)

def _job_a(job: tuple[str, str]) -> dict[str, Any]:
    warnings.simplefilter("ignore", RuntimeWarning)
    suite, caso = job
    tempo, val, cols, inj = CA.ler(suite, caso)
    ini = float(tempo[0])
    inst = []
    for periodo, t in CA.instantes(tempo, inj):
        ref = (max(ini, inj - CI.REF), inj) if periodo == "falha" else (max(ini, t - CI.JANELA - CI.REF), t - CI.JANELA)
        inst.append({"periodo": periodo, "t": t, "f": CI.escores(tempo, val, cols, t, ref, familia=True),
                     "bj": baro_janela(tempo, val, cols, t, ref)})
    return {"suite": suite, "caso": caso, "inst": inst, "of": oficiais(tempo, val, cols, inj, suite.lower())}


def parte_a(D: Any, jobs: int) -> list[str]:  # noqa: N803
    cs = CA.casos()
    teste = CA.sorteio_teste(cs)
    lista = [(s, c) for s in CA.SUITES for c in cs[s] if f"{s}/{c}" not in teste]
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        res = {f"{r['suite']}/{r['caso']}": r for r in ex.map(_job_a, lista, chunksize=2)}
    base = {s: CA.baseline(res, s, set()) for s in CA.SUITES}
    pseudo, es = [], {}
    for s, cc in base.items():
        for c in cc:
            for x in res[c]["inst"]:
                if x["periodo"] == "normal":
                    pseudo.append({"periodo": "normal", "na_baseline": True, "grupo": s, "caso": c, "t": x["t"]})
                    es[(c, x["t"])] = x["f"]
    norm = CI.normalizadores(pseudo, es)
    taus = _tau(pseudo, es, norm)
    na_base = set().union(*base.values())
    modos = ("g-m∨t|mf", "g-m∨t|BARO-janela", "g-m∨t|mf @FP0,01", "g-m∨t|mf @FP0,10")
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in modos}
    caso: dict[str, tuple[list, list]] = {m: ([], []) for m in ("BARO (oficial)", "N-Sigma (oficial)",
                                                                  "g-m∨t|mf — 1º instante", "g-m∨t|mf — último instante")}
    for c, r in res.items():
        s, esp = r["suite"], CA.gabarito(r["caso"])[0]
        n = norm.get(s, {})
        falhas = [x for x in r["inst"] if x["periodo"] == "falha"]
        if falhas:
            for nome, rk in (("BARO (oficial)", r["of"]["BARO"]), ("N-Sigma (oficial)", r["of"]["N-Sigma"]),
                             ("g-m∨t|mf — 1º instante", ordem_completa(falhas[0]["f"], n)),
                             ("g-m∨t|mf — último instante", ordem_completa(falhas[-1]["f"], n))):
                caso[nome][0].append(rk)
                caso[nome][1].append(esp)
        for x in r["inst"]:
            if x["periodo"] == "normal" and c in na_base:
                continue
            rk = CI.ranking_rzl(x["f"], n)
            umax = max(CI._u(x["f"], n).values(), default=0.0)
            g = {fp: umax >= taus[fp][s] for fp in FPS_G}
            contar(pc, c, x["periodo"], esp, {"g-m∨t|mf": (g[0.05] and bool(rk), rk),
                                              "g-m∨t|BARO-janela": (g[0.05] and bool(x["bj"]), x["bj"]),
                                              "g-m∨t|mf @FP0,01": (g[0.01] and bool(rk), rk),
                                              "g-m∨t|mf @FP0,10": (g[0.10] and bool(rk), rk)})
    todos = sorted(res)
    out = ["## A — RCAEval inédito, só métricas (480 casos; sem traces: `g-m∨t` = `g-m`)", "",
           "### Por caso (AC@k, serviço)", "", *tabela_caso(caso), "",
           "### Por instante", "", *tabela_inst(D, pc, todos, modos), ""]
    for sis in ("OB", "SS", "TT"):
        sub = [c for c in todos if c.split("/")[0].endswith("-" + sis)]
        cs_sub = {m: ([rk for rk, cc in zip(v[0], [c for c in todos if any(x["periodo"] == "falha" for x in res[c]["inst"])], strict=True)
                       if cc in sub], []) for m, v in caso.items()}
        del cs_sub
        out += [f"#### sistema {sis} ({len(sub)} casos), por instante", "", *tabela_inst(D, pc, sub, modos[:2]), ""]
    return out


# ---------------------------------------------------------------- RCAEval C (240 com traces)

def _job_c(job: tuple[str, list[tuple[str, str]]]) -> dict[str, Any]:
    warnings.simplefilter("ignore", RuntimeWarning)
    caso, its = job
    df, inj = CI._serie(caso)
    tempo, val, cols = df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns)
    inst = {}
    for periodo, ts in its:
        t = O._ts(ts)
        ref = (inj - CI.REF, inj) if periodo == "falha" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        inst[ts] = baro_janela(tempo, val, cols, t, ref)
    return {"caso": caso, "bj": inst, "of": oficiais(tempo, val, cols, inj, caso.split("/")[0].lower())}


def parte_c_rcaeval(D: Any, jobs: int) -> list[str]:  # noqa: N803
    linhas = CI.BD.carregar()
    cals = CI.BD.calibracoes(linhas, 0.01)
    ex = CI.BD.exatos()
    esf = CI.escores_metricas(linhas, familia=True)
    nf = CI.normalizadores(linhas, esf)
    taus = {fp: CI.tau_gate(linhas, esf, nf, fp) for fp in FPS_G}
    por: dict[str, list] = defaultdict(list)
    for x in linhas:
        por[x["caso"]].append((x["periodo"], x["t"]))
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as exe:
        res = {r["caso"]: r for r in exe.map(_job_c, list(por.items()), chunksize=2)}
    modos = ("g-m∨t|mf", "g-m∨t|BARO-janela", "g-m|mf", "g-m|BARO-janela", "g-m∨t|mf @FP0,01", "g-m∨t|mf @FP0,10")
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in modos}
    caso: dict[str, tuple[list, list]] = {m: ([], []) for m in ("BARO (oficial)", "N-Sigma (oficial)",
                                                                  "g-m∨t|mf — 1º instante", "g-m∨t|mf — último instante",
                                                                  "d9 (= d9-k) forçado — 1º instante")}
    falhas_por: dict[str, list] = defaultdict(list)
    for x in linhas:
        if x["periodo"] == "falha" and x["gabarito"]:
            falhas_por[x["caso"]].append(x)
    for c, xs in falhas_por.items():
        xs = sorted(xs, key=lambda y: y["t"])
        s, esp = c.split("/")[0], xs[0]["gabarito"]
        f0, fl = esf.get((c, xs[0]["t"]), {}), esf.get((c, xs[-1]["t"]), {})
        d0 = D.decisoes(xs[0])
        for nome, rk in (("BARO (oficial)", res[c]["of"]["BARO"]), ("N-Sigma (oficial)", res[c]["of"]["N-Sigma"]),
                         ("g-m∨t|mf — 1º instante", ordem_completa(f0, nf.get(s, {}))),
                         ("g-m∨t|mf — último instante", ordem_completa(fl, nf.get(s, {}))),
                         ("d9 (= d9-k) forçado — 1º instante", d0["d9"]["f"])):
            caso[nome][0].append(rk)
            caso[nome][1].append(esp)
    for x in linhas:
        if x["periodo"] == "normal" and x.get("na_baseline"):
            continue
        s, k = x["grupo"], (x["caso"], x["t"])
        e = esf.get(k, {})
        rk = CI.ranking_rzl(e, nf.get(s, {}))
        umax = max(CI._u(e, nf.get(s, {})).values(), default=0.0)
        g = {fp: umax >= taus[fp][s] for fp in FPS_G}
        gt = CI.BD.decisoes(x, cals[s], ex.get(x["caso"]), Counter())["d9-b+c"]["dec"]
        bj = res[x["caso"]]["bj"].get(x["t"], [])
        contar(pc, x["caso"], x["periodo"], x["gabarito"], {
            "g-m∨t|mf": (g[0.05] or gt, rk), "g-m∨t|BARO-janela": (g[0.05] or gt, bj),
            "g-m|mf": (g[0.05] and bool(rk), rk), "g-m|BARO-janela": (g[0.05] and bool(bj), bj),
            "g-m∨t|mf @FP0,01": (g[0.01] or gt, rk), "g-m∨t|mf @FP0,10": (g[0.10] or gt, rk)})
    todos = sorted({x["caso"] for x in linhas})
    tt = {m: ([r for r, c in zip(v[0], sorted(falhas_por), strict=False)], []) for m, v in caso.items()}
    del tt
    # validação do BARO no RE2-TT (por caso)
    idx = [i for i, c in enumerate(sorted(falhas_por)) if c.startswith("RE2-TT/")]
    ordem = sorted(falhas_por)
    val_b = ac([caso["BARO (oficial)"][0][ordem.index(ordem[i])] for i in idx],
               [caso["BARO (oficial)"][1][ordem.index(ordem[i])] for i in idx])
    out = ["## C — RCAEval com traces (240 casos; descritivo)", "",
           f"**Validação do BARO oficial no RE2-TT:** AC@1 {val_b['AC@1']:.3f} / AC@3 {val_b['AC@3']:.3f} / Avg@5 "
           f"{val_b['Avg@5']:.3f} ({val_b['n']} casos), publicado (Tabela 6 do RCAEval) 0.67 / 0.82 / 0.80.", "",
           "### Por caso (AC@k, serviço)", "", *tabela_caso(caso), "",
           "### Por instante", "", *tabela_inst(D, pc, todos, modos), ""]
    return out


# ---------------------------------------------------------------- Market (77)

def parte_c_market(D: Any) -> list[str]:  # noqa: N803
    linhas = D.carregar("openrca-market")
    bt = O.baseline_traces("openrca-market", 24)
    cals = {g: O.calib.calibrar(b["janelas"], 0.01) for g, b in bt.items()}
    es = O.escores_todos("openrca-market", linhas, bt)
    pseudo = [{"periodo": "normal", "na_baseline": True, "grupo": g, "caso": f"baseline/{g}", "t": str(t)}
              for g, b in bt.items() for t in b["t"]]
    norm = CI.normalizadores(pseudo, es)
    taus = _tau(pseudo, es, norm)
    plano = O._ad("openrca-market").casos()
    series: dict[str, Any] = {}
    modos = ("g-m∨t|mf", "g-m∨t|BARO-janela", "g-m|mf", "g-m|BARO-janela", "g-m∨t|mf @FP0,01", "g-m∨t|mf @FP0,10")
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in modos}
    caso: dict[str, tuple[list, list]] = {m: ([], []) for m in ("BARO (oficial)", "N-Sigma (oficial)",
                                                                  "g-m∨t|mf — 1º instante", "g-m∨t|mf — último instante",
                                                                  "d9 (= d9-k) forçado — 1º instante")}
    falhas_por: dict[str, list] = defaultdict(list)
    for x in linhas:
        v = plano[x["caso"]]
        chave = f"{v['cb']}/{v['dia']}"
        if chave not in series:
            series[chave] = O.series_market(v["cb"], v["dia"])
        tempo, val, cols = series[chave]
        g = x["grupo"]
        t = O._ts(x["t"])
        ref = (v["pre"][0], v["pre"][1]) if x["periodo"] == "falha" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        bj = baro_janela(tempo, val, cols, t, ref)
        e = es.get((x["caso"], x["t"]), {})
        rk = CI.ranking_rzl(e, norm.get(g, {}))
        umax = max(CI._u(e, norm.get(g, {})).values(), default=0.0)
        gm = {fp: umax >= taus[fp][g] for fp in FPS_G}
        gt = CI.BD.decisoes(x, cals[g], None, Counter())["d9-b+c"]["dec"]
        contar(pc, x["caso"], x["periodo"], x["gabarito"], {
            "g-m∨t|mf": (gm[0.05] or gt, rk), "g-m∨t|BARO-janela": (gm[0.05] or gt, bj),
            "g-m|mf": (gm[0.05] and bool(rk), rk), "g-m|BARO-janela": (gm[0.05] and bool(bj), bj),
            "g-m∨t|mf @FP0,01": (gm[0.01] or gt, rk), "g-m∨t|mf @FP0,10": (gm[0.10] or gt, rk)})
        if x["periodo"] == "falha" and x["gabarito"]:
            falhas_por[x["caso"]].append(x)
    for c, xs in sorted(falhas_por.items()):
        xs = sorted(xs, key=lambda y: y["t"])
        v, g, esp = plano[c], xs[0]["grupo"], xs[0]["gabarito"]
        tempo, val, cols = series[f"{v['cb']}/{v['dia']}"]
        inj = float(v["falha"][0])
        a, b = np.searchsorted(tempo, inj - 600, "left"), np.searchsorted(tempo, inj + 600, "left")
        of = oficiais(tempo[a:b], val[a:b], cols, inj, "openrca-market")
        for nome, rk in (("BARO (oficial)", of["BARO"]), ("N-Sigma (oficial)", of["N-Sigma"]),
                         ("g-m∨t|mf — 1º instante", ordem_completa(es.get((c, xs[0]["t"]), {}), norm.get(g, {}))),
                         ("g-m∨t|mf — último instante", ordem_completa(es.get((c, xs[-1]["t"]), {}), norm.get(g, {}))),
                         ("d9 (= d9-k) forçado — 1º instante", D.decisoes(xs[0])["d9"]["f"])):
            caso[nome][0].append(rk)
            caso[nome][1].append(esp)
    todos = sorted({x["caso"] for x in linhas})
    return ["## C — OpenRCA Market (77 casos; descritivo)", "", "### Por caso (AC@k, serviço)", "", *tabela_caso(caso), "",
            "### Por instante", "", *tabela_inst(D, pc, todos, modos), ""]


def teste() -> int:
    cs = CA.casos()
    rnd = random.Random("20261019-emenda2-teste")
    print("| base | caso | gabarito | BARO top-5 | gabarito na lista do BARO |", "|---|---|---|---|---|", sep="\n")
    for s in ("RE1-OB", "RE2-SS"):
        for c in rnd.sample(cs[s], 3):
            tempo, val, cols, inj = CA.ler(s, c)
            of = oficiais(tempo, val, cols, inj, s.lower())
            esp = CA.gabarito(c)[0]
            print(f"| {s} | {c} | {esp} | {', '.join(of['BARO'][:5])} | {'sim' if esp in of['BARO'] else '**NÃO**'} |")
    linhas = CI.BD.carregar()
    for c in rnd.sample(sorted({x['caso'] for x in linhas}), 3):
        df, inj = CI._serie(c)
        of = oficiais(df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns), inj, c.split("/")[0].lower())
        esp = next(x["gabarito"] for x in linhas if x["caso"] == c)
        print(f"| RCAEval-C | {c} | {esp} | {', '.join(of['BARO'][:5])} | {'sim' if esp in of['BARO'] else '**NÃO**'} |")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--teste", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    if args.teste:
        return teste()
    warnings.simplefilter("ignore", RuntimeWarning)
    D = CI._d9a()  # noqa: N806
    out = ["# Emenda 2 — BARO/N-Sigma oficiais, AC@k, BARO-janela e sensibilidade (RCAEval e Market)", "",
           "`PROTOCOLO-COMPLETO.md` emenda 2. Tudo descritivo (as metas de A e B′ já foram lidas). AC@k por caso em "
           "nível de serviço; `g-m∨t|mf` no 1º instante de falha (só os primeiros 120 s), BARO/N-Sigma com todo o "
           "pós-injeção e o horário da injeção (oráculo).", "",
           *parte_a(D, args.jobs), *parte_c_rcaeval(D, args.jobs), *parte_c_market(D)]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-emenda2.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
