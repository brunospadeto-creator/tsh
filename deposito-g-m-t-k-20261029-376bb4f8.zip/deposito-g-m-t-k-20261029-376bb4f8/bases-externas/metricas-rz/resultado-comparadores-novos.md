# PDiagnose e o passo de desvio de Fukuda et al. nos mesmos casos (pós-hoc, fora do protocolo)

`comparadores_novos.py`. Protocolo do RCAEval: AC@1 / AC@3 / Avg@5 por caso, no nível de serviço; o nosso método (HMR) no 1º instante com causa e ordem completa, como na Tabela de comparação com a literatura. Ranking vazio conta como erro. Ver o cabeçalho do script para as adaptações de cada método.

| conjunto | método | casos | nosso | método | Δ AC@1 | p (permutação, 10 000) | p Holm |
|---|---|---|---|---|---|---|---|
| RCAEval inédito | Fukuda et al. (passo de desvio) | 474 | 0.709 / 0.903 / 0.870 | 0.637 / 0.819 / 0.797 | +0.072 | 0.0109 | 0.0348 |
| RCAEval com rastros | Fukuda et al. (passo de desvio) | 239 | 0.782 / 0.950 / 0.916 | 0.695 / 0.824 / 0.805 | +0.088 | 0.0142 | 0.0348 |
| RCAEval com rastros (RE2) | PDiagnose | 179 | 0.754 / 0.950 / 0.908 | 0.609 / 0.922 / 0.854 | +0.145 | 0.0087 | 0.0348 |
| OpenRCA Market | Fukuda et al. (passo de desvio) | 77 | 0.649 / 0.883 / 0.857 | 0.571 / 0.805 / 0.766 | +0.078 | 0.3407 | 0.3407 |

p Holm sobre estas 4 comparações (análise adicional, à parte das 26 dos outros comparadores).

## Tempo e falhas

- fukuda: tempo por caso mediana 0.48 s, máximo 3.14 s (790 casos)
- pdiagnose: tempo por caso mediana 6.67 s, máximo 94.59 s (179 casos)
- nenhuma falha
