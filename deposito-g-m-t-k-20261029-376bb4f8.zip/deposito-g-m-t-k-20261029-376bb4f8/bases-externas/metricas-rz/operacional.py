#!/usr/bin/env python3
"""Comparação no protocolo operacional (análise adicional, fora do protocolo): o nosso escore, o do BARO e o do
N-Sigma com o mesmo portão, por instante, sem o horário da injeção, nas cinco avaliações.

- `BARO-janela` = `emenda2.baro_janela` (RobustScaler do `RCAEval.e2e.baro` na janela de 120 s, mesma referência).
- `N-Sigma-janela` = o mesmo com o StandardScaler do `RCAEval.e2e.nsigma` (média e desvio; desvio 0 → 1, como o
  sklearn). Os dois oficiais só diferem nisso.
- Os scripts congelados (`emenda2.py`, `replay/metricas_rz_k8s.py`) só são chamados: cada parte roda duas vezes, a
  segunda com `baro_janela` trocado por `nsigma_janela`; os BARO/N-Sigma oficiais (por caso) são desligados.
- Permutação pareada por caso/cenário em F1@1 (`robustez._perm_f1`, 10.000), Holm sobre as 10 comparações.

Uso: `operacional.py --parte publicas` (dados do RCAEval e do Market);
`operacional.py --parte teastore --raiz <checkout com a telemetria do TeaStore>` (p. ex. o depósito do Zenodo);
`operacional.py --relatorio` → `resultado-operacional.md`. Saídas intermediárias em `DADOS_SAIDA/metricas-rz/operacional/`.
"""
from __future__ import annotations

import argparse
import os
import pickle
import sys
import tempfile
import warnings
from collections import Counter
from typing import Any

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import emenda2 as E2  # noqa: E402
import robustez as R  # noqa: E402

CI = E2.CI
SAIDA = os.path.join(E2.O.CACHE, "operacional")
CHAVES = ("tp1", "tp2", "dec", "al", "ne", "nn")
BASES = ("RCAEval inédito", "RCAEval com rastros", "OpenRCA Market", "TeaStore inédito", "TeaStore definitiva")


def nsigma_janela(tempo: np.ndarray, val: np.ndarray, cols: list[str], t: float, ref: tuple[float, float]) -> list[str]:
    """StandardScaler do N-Sigma (centro = média, escala = desvio; desvio 0 → 1, como o sklearn) ajustado na
    referência do instante; escore = máximo na janela de 120 s; serviço = sua melhor coluna."""
    a, b = np.searchsorted(tempo, t - CI.JANELA, "right"), np.searchsorted(tempo, t, "right")
    r0, r1 = np.searchsorted(tempo, ref[0], "left"), np.searchsorted(tempo, ref[1], "left")
    jan, rf = val[a:b], val[r0:r1]
    if len(jan) == 0 or len(rf) == 0:
        return []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        mu = np.nanmean(rf, axis=0)
        dp = np.nanstd(rf, axis=0)
        dp = np.where(dp > 0, dp, 1.0)
        z = np.nanmax((jan - mu) / dp, axis=0)
    por: dict[str, float] = {}
    for c, v in zip(cols, z, strict=True):
        if np.isfinite(v):
            s = E2.servico_col(c)
            por[s] = max(por.get(s, -np.inf), float(v))
    return [s for s, _ in sorted(por.items(), key=lambda kv: (-kv[1], kv[0]))]


def _sem_oficiais(*_a: Any, **_k: Any) -> dict[str, list[str]]:
    return {"BARO": [], "N-Sigma": []}


def _publicas(jobs: int) -> dict[str, dict[str, dict[str, Counter]]]:
    """{base: {modo: {caso: Counter}}} com `nosso`, `BARO-janela` e `N-Sigma-janela`."""
    E2.oficiais = _sem_oficiais
    capt: list[dict] = []
    orig = E2.contar

    def contar(pc: dict, *a: Any) -> None:
        if not capt or capt[-1] is not pc:
            capt.append(pc)
        orig(pc, *a)

    E2.contar = contar
    D = CI._d9a()  # noqa: N806
    partes = (("RCAEval inédito", lambda: E2.parte_a(D, jobs)), ("RCAEval com rastros", lambda: E2.parte_c_rcaeval(D, jobs)),
              ("OpenRCA Market", lambda: E2.parte_c_market(D)))
    out: dict[str, dict[str, dict[str, Counter]]] = {}
    for escore, fn in (("BARO-janela", E2.baro_janela), ("N-Sigma-janela", nsigma_janela)):
        E2.baro_janela = fn
        for base, rodar in partes:
            capt.clear()
            rodar()
            pc = capt[-1]
            out.setdefault(base, {})["nosso"] = dict(pc["g-m∨t|mf"])
            out[base][escore] = dict(pc["g-m∨t|BARO-janela"])
    return out


def _teastore(raiz: str, jobs: int) -> dict[str, dict[str, dict[str, Counter]]]:
    replay = os.path.join(raiz, "experimento-falhas", "teastore", "stage3-online", "replay")
    sys.path.insert(0, replay)
    os.chdir(raiz)
    import metricas_rz_k8s as M  # noqa: PLC0415
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    M.E2.oficiais = _sem_oficiais
    M.SAIDA = tempfile.mkdtemp(prefix="operacional-k8s-")   # avaliar() grava jsonl: fora da árvore de resultados
    nomes = {"B′": "TeaStore inédito", "definitiva": "TeaStore definitiva"}
    out: dict[str, dict[str, dict[str, Counter]]] = {}
    for escore, fn in (("BARO-janela", M.E2.baro_janela), ("N-Sigma-janela", nsigma_janela)):
        M.E2.baro_janela = fn
        cjs = M.conjuntos()
        with ProcessPoolExecutor(jobs) as ex:
            res = {n: list(ex.map(M.caso, [(c, cj) for c in cj["casos"]])) for n, cj in cjs.items()}
        for n, cj in cjs.items():
            pcs, _inv, _o = M.avaliar(n, cj, res[n])
            base = nomes[n]
            for modo, nome in (("g-m∨t|mf", "nosso"), ("g-m∨t∨k|mfk", "HTS"), ("g-m∨t|BARO-janela", escore)):
                out.setdefault(base, {})[nome] = {c: Counter({
                    "tp1": x.get("tp1", 0), "tp2": x.get("tp2", 0), "dec": x.get("dec", 0),
                    "al": x.get("alarme", 0), "ne": x.get("n_est", 0), "nn": x.get("n_nor", 0)})
                    for c, x in pcs[modo].items()}
    return out


def _f1(pc: dict[str, Counter], k: int = 0) -> float:
    return float(R._f1v(R._arr(pc, sorted(pc)).sum(0), k))


def _alarme(pc: dict[str, Counter]) -> float:
    s = R._arr(pc, sorted(pc)).sum(0)
    return float(s[3] / s[5]) if s[5] else float("nan")


def _ic(pc: dict[str, Counter], rng: np.random.Generator) -> tuple[float, float]:
    cs = sorted(pc)
    a = R._arr(pc, cs)
    idx = rng.integers(0, len(cs), size=(R.N_BOOT, len(cs)))
    v = R._f1v(a[idx].sum(axis=1))
    lo, hi = np.nanpercentile(v, [2.5, 97.5])
    return float(lo), float(hi)


def relatorio() -> int:
    d: dict[str, dict[str, dict[str, Counter]]] = {}
    for parte in ("publicas", "teastore"):
        with open(os.path.join(SAIDA, f"{parte}.pkl"), "rb") as f:
            d.update(pickle.load(f))
    rng = np.random.default_rng(2026102301)
    comps = []
    for base in BASES:
        for esc in ("BARO-janela", "N-Sigma-janela"):
            comps.append((base, esc, R._perm_f1(d[base]["nosso"], d[base][esc], rng)))
    ps = [c[2][1] for c in comps]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    rb = np.random.default_rng(2026102302)
    out = ["# Protocolo operacional: nosso escore × BARO e N-Sigma na janela, mesmo portão (análise adicional)", "",
           "`operacional.py`. Por instante, sem o horário da injeção, janela de 120 s, mesmos portões e instantes. "
           f"Nosso = HMR (`g-m∨t|mf`) em todas as bases: os mesmos sinais (métricas) dos comparadores; o HTS (com "
           f"eventos K8s) responde à P2 e aparece só no fim. IC 95% por bootstrap de "
           f"caso ({R.N_BOOT}); permutação pareada por caso ({R.N_PERM}); Holm sobre as {len(comps)} comparações.", "",
           "| base | casos | nosso F1@1 [IC 95%] | BARO-janela | N-Sigma-janela | alarme (igual nos três) |",
           "|---|---|---|---|---|---|"]
    for base in BASES:
        n = d[base]["nosso"]
        lo, hi = _ic(n, rb)
        cel = []
        for esc in ("BARO-janela", "N-Sigma-janela"):
            l2, h2 = _ic(d[base][esc], rb)
            cel.append(f"{_f1(d[base][esc]):.3f} [{l2:.3f}–{h2:.3f}]")
        ncasos = sum(1 for c in n.values() if c["ne"])
        out.append(f"| {base} | {ncasos} | {_f1(n):.3f} [{lo:.3f}–{hi:.3f}] | {cel[0]} | {cel[1]} | {_alarme(n):.1%} |")
    out += ["", "| base | comparação | ΔF1@1 | p | p (Holm) |", "|---|---|---|---|---|"]
    for (base, esc, (delta, p)), h in zip(comps, holm, strict=True):
        out.append(f"| {base} | nosso − {esc} | {delta:+.3f} | {p:.4f} | {h:.4f} |")
    out += ["", "TeaStore com eventos (HTS, P2; descritivo): " + "; ".join(
        f"{b} F1@1 {_f1(d[b]['HTS']):.3f}" for b in ("TeaStore inédito", "TeaStore definitiva")) + "."]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-operacional.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--parte", choices=("publicas", "teastore"))
    ap.add_argument("--raiz", default=os.path.dirname(os.path.dirname(AQUI)))
    ap.add_argument("--jobs", type=int, default=24)
    ap.add_argument("--relatorio", action="store_true")
    args = ap.parse_args()
    warnings.simplefilter("ignore", RuntimeWarning)
    if args.relatorio:
        return relatorio()
    os.makedirs(SAIDA, exist_ok=True)
    dados = _publicas(args.jobs) if args.parte == "publicas" else _teastore(os.path.abspath(args.raiz), args.jobs)
    with open(os.path.join(SAIDA, f"{args.parte}.pkl"), "wb") as f:
        pickle.dump(dados, f)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
