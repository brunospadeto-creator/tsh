# `g-m∨t|mf` sem mudança — OpenRCA Market (teste de 10 min, exploratório)

`outras.py` / `PROTOCOLO.md` §Generalização. Mesmo código do RCAEval; só o adaptador de métricas é da base. Todos os instantes dos registros do `../d9a/` (fora a sombra). Sem K8s: d9 = d9-k.

| grupo | janelas da baseline | λ (FP 0,01) | q d2c-b (FP 0,01) | famílias com N | τ do g-m |
|---|---|---|---|---|---|
| cloudbed-1 | 26 | 1.023 | 8.59e-02 | 26 | 3.474 |
| cloudbed-2 | 26 | 1.074 | 5.00e-01 | 28 | 19.470 |

| método | casos | inst. normais | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |
|---|---|---|---|---|---|---|---|---|
| d9 | 77 | 121 | 0.154 [0.080–0.229] | 0.164 | 0.0% | 81.4% | 21.2% | 34.1% |
| d9+a | 77 | 121 | 0.166 [0.090–0.241] | 0.176 | 0.0% | 79.5% | 21.2% | 34.1% |
| d9-b+c@0.01 | 77 | 121 | 0.214 [0.130–0.294] | 0.268 | 4.1% | 61.2% | 21.2% | 34.1% |
| m-rzf | 77 | 121 | 0.552 [0.464–0.645] | 0.715 | 100.0% | 0.0% | 59.7% | 78.3% |
| g-m|mf | 77 | 121 | 0.304 [0.199–0.405] | 0.477 | 12.4% | 60.5% | 59.7% | 78.3% |
| g-m∨t|mf | 77 | 121 | 0.428 [0.330–0.527] | 0.602 | 16.5% | 39.7% | 59.7% | 78.3% |
| g-m∧t|mf | 77 | 121 | 0.138 [0.077–0.201] | 0.250 | 0.0% | 82.0% | 59.7% | 78.3% |

- ΔF1@1 g-m∨t|mf − d9 = +0.274 [IC 95% +0.150 a +0.398]
- ΔF1@1 g-m∨t|mf − d9-b+c@0.01 = +0.215 [IC 95% +0.097 a +0.337]
- ΔF1@1 g-m|mf − d9 = +0.150 [IC 95% +0.008 a +0.287]
