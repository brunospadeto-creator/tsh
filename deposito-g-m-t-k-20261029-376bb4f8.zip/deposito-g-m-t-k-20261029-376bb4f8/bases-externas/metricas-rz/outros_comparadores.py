#!/usr/bin/env python3
"""CIRCA e RCD oficiais (RCAEval 1.8.0) nos mesmos casos do BARO e do N-Sigma (pós-hoc, fora do protocolo).

Pedido da revisão de 19/10: o "How Far Are We" aponta CausalRCA, RCD, CIRCA,
N-Sigma e BARO como os melhores métodos com métricas, e o artigo só comparava com os dois últimos. O CausalRCA ficou
de fora: num único caso do RE1-OB (50 colunas), passou de 25 min de relógio (> 100 min de CPU) sem terminar.

Entrada igual à do `emenda2.oficiais` (mesmo arquivo de métricas, mesmo horário da injeção, período após a falha todo
no RCAEval e ±600 s no Market). Como no `main.py` do RCAEval, infinitos viram NaN e os NaN são preenchidos com
`ffill` e depois 0 (o BARO tolera NaN; o CIRCA e o RCD, não). Dois ajustes de nome de coluna:
- **CIRCA:** sem a latência p50 (como o `main.py`) e sem colunas com correlação > 0,99 com uma anterior (como o
  `mmcirca` do pacote); sem isso, o teste fisherz falha por matriz singular em mais da metade dos casos. O `rht` do pacote separa cada coluna em `serviço_métrica` pelo "_" e procura `f"{s}_{m}"`; as colunas
  viram `serviço_famíliaÍNDICE` (sem "_" no serviço), e o serviço volta pelo mapa.
- **RCD:** usa as colunas como no BARO. Precisa do `causal-learn` 0.1.2.3 com os quatro arquivos do repositório do RCD
  (como o `script/link.sh` do RCAEval): rodar com `PYTHONPATH=<rcdlib>`.

Semente 0 em todos os casos (o `rht` e o RCD sorteiam). Ranking vazio (exceção ou tempo esgotado) conta como erro,
como no artigo.

Uso:
  python outros_comparadores.py --rodar circa [--jobs 24]
  PYTHONPATH=<rcdlib> python outros_comparadores.py --rodar rcd [--jobs 24]
  python outros_comparadores.py --relatorio        → resultado-outros-comparadores.md
"""
from __future__ import annotations

import argparse
import os
import pickle
import signal
import sys
import warnings
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import robustez as R  # noqa: E402

CA, CI, E2, O = R.CA, R.CI, R.E2, R.O
SAIDA = os.path.join(O.CACHE, "outros-comparadores")
TEMPO_MAX = 900   # s por caso e método


class _Esgotado(Exception):
    pass


def _alarme(*_: Any) -> None:
    raise _Esgotado


def entradas() -> list[tuple[str, str, Any]]:
    """(conjunto, caso, chave de leitura) dos três conjuntos públicos, como nas unidades do `robustez.py`."""
    out: list[tuple[str, str, Any]] = []
    cs = CA.casos()
    teste = CA.sorteio_teste(cs)
    out += [("A", f"{s}/{c}", ("A", s, c)) for s in CA.SUITES for c in cs[s] if f"{s}/{c}" not in teste]
    out += [("RCAEval-C", c, ("C", c)) for c in sorted(R.unidade_c(8)["baro"])]
    out += [("Market", c, ("M", c)) for c in sorted(R.unidade_m(8)["baro"])]
    return out


def _serie(chave: Any) -> tuple[np.ndarray, np.ndarray, list[str], float, str]:
    if chave[0] == "A":
        _, s, c = chave
        tempo, val, cols, inj = CA.ler(s, c)
        return tempo, val, cols, inj, s.lower()
    if chave[0] == "C":
        df, inj = CI._serie(chave[1])
        return (df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns), inj,
                chave[1].split("/")[0].lower())
    v = O._ad("openrca-market").casos()[chave[1]]
    tempo, val, cols = O.series_market(v["cb"], v["dia"])
    inj = float(v["falha"][0])
    a, b = np.searchsorted(tempo, inj - 600, "left"), np.searchsorted(tempo, inj + 600, "left")
    return tempo[a:b], val[a:b], cols, inj, "openrca-market"


def _job(job: tuple[str, str, Any, str]) -> tuple[str, str, list[str], str | None]:
    warnings.simplefilter("ignore")
    conj, caso, chave, metodo = job
    signal.signal(signal.SIGALRM, _alarme)
    try:
        tempo, val, cols, inj, ds = _serie(chave)
        svc = [E2.servico_col(c) for c in cols]
        if metodo == "circa":
            from RCAEval.e2e import circa as fn  # noqa: PLC0415
            limpo = {s: s.replace("_", "-") for s in svc}
            volta = {v: k for k, v in limpo.items()}
            nomes = [f"{limpo[s]}_{c.rsplit('_', 1)[1]}{i}" for i, (s, c) in enumerate(zip(svc, cols, strict=True))]
        else:
            from RCAEval.e2e import rcd as fn  # noqa: PLC0415
            volta = None
            nomes = [f"{s}__{i}_{c.rsplit('_', 1)[1]}" for i, (s, c) in enumerate(zip(svc, cols, strict=True))]
        df = pd.DataFrame(val, columns=nomes).replace([np.inf, -np.inf], np.nan).ffill().fillna(0)
        if metodo == "circa":
            # como o `main.py` (tira a latência p50) e o `mmcirca` do pacote (tira colunas com correlação > 0,99 com
            # uma anterior), para o teste fisherz do PC não falhar por matriz singular
            df = df.loc[:, [c for c, o in zip(nomes, cols, strict=True) if not o.endswith("_latency-50")]]
            corr = df.corr().to_numpy()
            fora = {j for i in range(len(df.columns)) for j in range(i + 1, len(df.columns)) if corr[i, j] > 0.99}
            df = df.drop(columns=[df.columns[j] for j in sorted(fora)])
        df.insert(0, "time", tempo)
        np.random.seed(0)
        signal.alarm(TEMPO_MAX)
        try:
            kw = {"seed": 0} if metodo == "rcd" else {}
            ranks = fn(data=df, inject_time=inj, dataset=ds, **kw)["ranks"]
        finally:
            signal.alarm(0)
        if metodo == "circa":
            ordem: list[str] = []
            for r in ranks:
                s = volta.get(r.split("_")[0], r.split("_")[0])
                if s not in ordem:
                    ordem.append(s)
            return conj, caso, ordem, None
        return conj, caso, E2.servicos_em_ordem(ranks), None
    except _Esgotado:
        return conj, caso, [], f"tempo esgotado (> {TEMPO_MAX} s)"
    except Exception as exc:  # noqa: BLE001
        return conj, caso, [], f"{type(exc).__name__}: {str(exc)[:80]}"


def rodar(metodo: str, jobs: int) -> None:
    os.makedirs(SAIDA, exist_ok=True)
    arq = os.path.join(SAIDA, f"{metodo}.pkl")
    feito: dict[tuple[str, str], tuple[list[str], str | None]] = {}
    if os.path.exists(arq):
        with open(arq, "rb") as f:
            feito = pickle.load(f)
    pend = [(cj, c, ch, metodo) for cj, c, ch in entradas() if (cj, c) not in feito]
    print(f"{metodo}: {len(feito)} feitos, {len(pend)} pendentes", flush=True)
    from concurrent.futures import ProcessPoolExecutor, as_completed  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        futs = [ex.submit(_job, j) for j in pend]
        for i, fu in enumerate(as_completed(futs), 1):
            cj, c, rk, err = fu.result()
            feito[(cj, c)] = (rk, err)
            if i % 20 == 0 or i == len(futs):
                with open(arq + ".tmp", "wb") as f:
                    pickle.dump(feito, f)
                os.replace(arq + ".tmp", arq)
                print(f"{metodo}: {i}/{len(futs)}", flush=True)


def relatorio() -> int:
    us = {"A": R.unidade_a(8), "RCAEval-C": R.unidade_c(8), "Market": R.unidade_m(8)}
    res = {}
    for m in ("circa", "rcd"):
        with open(os.path.join(SAIDA, f"{m}.pkl"), "rb") as f:
            res[m] = pickle.load(f)
    rng = np.random.default_rng(2026101905)
    out = ["# CIRCA e RCD oficiais nos mesmos casos (pós-hoc, fora do protocolo)", "",
           "`outros_comparadores.py`. RCAEval 1.8.0; entrada igual à do BARO e do N-Sigma (`emenda2.oficiais`); "
           "semente 0. Ranking vazio conta como erro. O nosso método: 1º instante de falha, ordem completa "
           "(como na Tabela de comparação com a literatura). CausalRCA fora: > 25 min num caso do RE1-OB.", "",
           "## AC@1 / AC@3 / Avg@5 por caso, no nível de serviço", "",
           "| conjunto | casos | nosso | BARO | N-Sigma | CIRCA | RCD | vazios CIRCA | vazios RCD |",
           "|---|---|---|---|---|---|---|---|---|"]
    novas, erros, subconj = [], {}, []
    for nome, u in us.items():
        norm = R.cal_original(u)["norm"]
        primeiro: dict[str, dict] = {}
        for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
            if x["periodo"] == "falha" and x["esp"] and x["caso"] not in primeiro:
                primeiro[x["caso"]] = x
        rks = {"nosso": {c: E2.ordem_completa(x["f"], norm.get(x["grupo"], {})) for c, x in primeiro.items()}}
        for b in ("BARO", "N-Sigma"):
            rks[b] = {c: (u["baro"].get(c) or {}).get(b, []) for c in primeiro}
        for m, lab in (("circa", "CIRCA"), ("rcd", "RCD")):
            rks[lab] = {c: res[m].get((nome, c), ([], "ausente"))[0] for c in primeiro}
            erros[(nome, lab)] = sorted({res[m].get((nome, c), ([], "ausente"))[1] or "" for c in primeiro} - {""})
        esp = {c: x["esp"] for c, x in primeiro.items()}

        def acs(rk: dict[str, list[str]]) -> str:
            a = {k: np.mean([esp[c] in rk[c][:k] for c in esp]) for k in range(1, 6)}
            return f"{a[1]:.3f} / {a[3]:.3f} / {np.mean(list(a.values())):.3f}"
        vaz = {lab: sum(1 for c in esp if not rks[lab][c]) for lab in ("CIRCA", "RCD")}
        out.append(f"| {nome} | {len(esp)} | {acs(rks['nosso'])} | {acs(rks['BARO'])} | {acs(rks['N-Sigma'])} | "
                   f"{acs(rks['CIRCA'])} | {acs(rks['RCD'])} | {vaz['CIRCA']} | {vaz['RCD']} |")
        a1 = {lab: {c: float(rks[lab][c][:1] == [esp[c]]) for c in esp} for lab in rks}
        for lab in ("CIRCA", "RCD"):
            d, p = R._perm_ac(a1["nosso"], a1[lab], rng)
            novas.append({"base": nome, "b": lab, "delta": d, "p": p})
            ok = [c for c in esp if rks[lab][c]]
            if ok:
                sub = {c: esp[c] for c in ok}
                ac_s = {q: {k: np.mean([sub[c] in rks[q][c][:k] for c in sub]) for k in (1, 3)} for q in ("nosso", lab)}
                ds, ps_ = R._perm_ac({c: a1["nosso"][c] for c in ok}, {c: a1[lab][c] for c in ok}, rng)
                subconj.append({"base": nome, "b": lab, "n": len(ok), "de": len(esp), "ac": ac_s, "delta": ds,
                                "p": ps_, "por_suite": sorted({c.split("/")[0] for c in esp if not rks[lab][c]})})
    r3 = (R.ler("resultados") or {}).get("R3", [])
    ns = [0.0050, 0.4280, 0.0592]   # 3 comparações contra o N-Sigma (`resultado-extras-revisao.md`)
    ps = [c["p"] for c in r3] + ns + [c["p"] for c in novas]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    out += ["", f"## Permutação pareada em AC@1 (10.000; Holm sobre {len(ps)} = R3 + 3 do N-Sigma + {len(novas)})", "",
            "| conjunto | comparação | Δ AC@1 | p | p Holm |", "|---|---|---|---|---|"]
    for k, c in enumerate(novas):
        out.append(f"| {c['base']} | nosso − {c['b']} | {c['delta']:+.3f} | {c['p']:.4f} | "
                   f"{holm[len(r3) + len(ns) + k]:.4f} |")
    hs, mx = [0.0] * len(subconj), 0.0
    for r, i in enumerate(sorted(range(len(subconj)), key=lambda i: subconj[i]["p"])):
        mx = max(mx, min(1.0, (len(subconj) - r) * subconj[i]["p"]))
        hs[i] = mx
    out += ["", "## Só os casos em que o método terminou (o nosso, nos mesmos casos; Holm sobre estas "
            f"{len(subconj)})", "",
            "| conjunto | método | casos | AC@1 nosso / método | AC@3 nosso / método | Δ AC@1 | p | p Holm | "
            "suítes com falha |", "|---|---|---|---|---|---|---|---|---|"]
    for c, h in zip(subconj, hs, strict=True):
        a = c["ac"]
        out.append(f"| {c['base']} | {c['b']} | {c['n']} de {c['de']} | {a['nosso'][1]:.3f} / {a[c['b']][1]:.3f} | "
                   f"{a['nosso'][3]:.3f} / {a[c['b']][3]:.3f} | {c['delta']:+.3f} | {c['p']:.4f} | {h:.4f} | "
                   f"{', '.join(c['por_suite']) or '—'} |")
    rot = [f"R3 {c['base']} {c['medida']}: {c['a']} − {c['b']}" for c in r3] + \
        [f"N-Sigma {b}" for b in ("A", "RCAEval-C", "Market")] + [f"{c['base']} {c['b']}" for c in novas]
    out += ["", f"## Holm sobre as {len(ps)} comparações (p bruto → p Holm)", "",
            "| comparação | p | p Holm |", "|---|---|---|"]
    out += [f"| {r} | {ps[i]:.4f} | {holm[i]:.4f} |" for i, r in enumerate(rot)]
    out += ["", "## Falhas por suíte (ranking vazio)", "", "| método | conjunto/suíte | falhas | casos |", "|---|---|---|---|"]
    for m, lab in (("circa", "CIRCA"), ("rcd", "RCD")):
        tot: dict[str, list[int]] = {}
        for (cj, c), (rk, _e) in sorted(res[m].items()):
            s = f"{cj}/{c.split('/')[0]}" if cj != "Market" else "Market"
            tot.setdefault(s, [0, 0])
            tot[s][0] += not rk
            tot[s][1] += 1
        out += [f"| {lab} | {s} | {f} | {n} |" for s, (f, n) in tot.items()]
    out += ["", "## Erros", "",
            "Quando o CIRCA falha, o decorador `rca` do pacote cai num `IndexError` e esconde o motivo. Pelo log da "
            "execução, as 419 falhas do CIRCA são 381 por tempo esgotado e 38 por matriz de correlação singular "
            "(teste fisherz).", ""]
    out += [f"- {cj} / {lab}: {'; '.join(e[:3])}" for (cj, lab), e in erros.items() if e] or ["- nenhum"]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-outros-comparadores.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rodar", choices=("circa", "rcd"))
    ap.add_argument("--relatorio", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    a = ap.parse_args()
    if a.rodar:
        rodar(a.rodar, a.jobs)
    if a.relatorio:
        return relatorio()
    return 0


if __name__ == "__main__":
    sys.exit(main())
