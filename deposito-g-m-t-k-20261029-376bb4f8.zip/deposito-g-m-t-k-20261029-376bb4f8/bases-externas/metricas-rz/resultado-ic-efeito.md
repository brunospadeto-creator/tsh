# IC por bootstrap da tabela de comparação e tamanhos de efeito (análise adicional, fora do protocolo)

`ic_efeito.py`. Bootstrap de casos com 10 000 reamostragens (semente 2026102401). Só leitura dos caches do `operacional.py` e das unidades e calibrações registradas do `robustez.py`.

## 1. Protocolo operacional: F1@1 por instante [IC 95%]

| base | BARO-janela | N-Sigma-janela | nosso (HMR) |
|---|---|---|---|
| RCAEval inédito | 0.284 [0.249, 0.320] | 0.566 [0.523, 0.608] | 0.614 [0.572, 0.654] |
| RCAEval com rastros | 0.437 [0.392, 0.482] | 0.630 [0.584, 0.677] | 0.687 [0.638, 0.732] |
| OpenRCA Market | 0.211 [0.150, 0.276] | 0.360 [0.267, 0.451] | 0.428 [0.331, 0.521] |
| TeaStore inédito | 0.273 [0.115, 0.451] | 0.317 [0.151, 0.492] | 0.601 [0.376, 0.829] |
| TeaStore definitiva | 0.210 [0.106, 0.321] | 0.210 [0.106, 0.320] | 0.524 [0.327, 0.714] |

## 2. Protocolo do RCAEval: AC@1 por caso no 1º instante com causa [IC 95%]

| base | casos | BARO | N-Sigma | nosso (HMR) |
|---|---|---|---|---|
| RCAEval inédito | 474 | 0.295 [0.253, 0.338] | 0.631 [0.589, 0.675] | 0.709 [0.669, 0.749] |
| RCAEval com rastros | 239 | 0.406 [0.343, 0.469] | 0.753 [0.699, 0.808] | 0.782 [0.728, 0.833] |
| OpenRCA Market | 77 | 0.221 [0.130, 0.312] | 0.506 [0.403, 0.611] | 0.649 [0.545, 0.753] |
| TeaStore inédito | 17 | 0.882 [0.706, 1.000] | 0.882 [0.706, 1.000] | 0.647 [0.412, 0.882] |
| TeaStore definitiva | 24 | 0.833 [0.667, 0.958] | 0.875 [0.750, 1.000] | 0.542 [0.333, 0.750] |

## 3. Tamanho de efeito das 12 comparações do teste de permutação registrado (Cliff's δ pareado por caso)

Por convenção, |δ| < 0,147 é desprezível, < 0,33 pequeno, < 0,474 médio e acima disso grande.

| base | medida | comparação | δ | vitórias / empates / derrotas |
|---|---|---|---|---|
| RCAEval inédito | F1@1 | HMR − Desvio Bruto | +0.080 | 82 / 348 / 44 |
| RCAEval inédito | F1@1 | HMR − maior desvio de CPU | +0.169 | 109 / 336 / 29 |
| RCAEval inédito | AC@1 | HMR − BARO | +0.414 | 241 / 188 / 45 |
| RCAEval com rastros | F1@1 | HMR − CS | +0.502 | 161 / 37 / 41 |
| RCAEval com rastros | F1@1 | HMR − CR | +0.431 | 153 / 36 / 50 |
| RCAEval com rastros | AC@1 | HMR − BARO | +0.377 | 116 / 97 / 26 |
| OpenRCA Market | F1@1 | HMR − CS | +0.377 | 36 / 34 / 7 |
| OpenRCA Market | AC@1 | HMR − BARO | +0.429 | 35 / 40 / 2 |
| TeaStore | F1@1 | HTS − HMR | +0.098 | 4 / 37 / 0 |
| TeaStore | F1@1 | HTS − COR | -0.537 | 1 / 17 / 23 |
| TeaStore | AC@1 | HTS − BARO | -0.171 | 0 / 34 / 7 |
| TeaStore | F1@1 | CSO − CS | +0.146 | 6 / 35 / 0 |
