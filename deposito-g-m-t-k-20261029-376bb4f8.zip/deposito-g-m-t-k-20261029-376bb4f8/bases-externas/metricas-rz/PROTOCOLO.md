# Ciclo de melhoria no RCAEval — meta F1@1 ≥ 0,6 e F1@2 ≥ 0,7 (com portão)

Pedido do usuário em 18/10/2026 (`/loop`): se o RCAEval ficar abaixo da meta, propor e desenvolver um método novo (ou
uma variação com nome novo) e refazer o teste de 10 min, até superar. Nada de `src/` muda, e os métodos já medidos
ficam como estão.

## Regra contra ajuste no teste (fixada antes da 1ª medida)

- Os 241 casos são divididos em **dev** e **holdout**, estratificados por suíte × tipo de falha, com semente
  `20261018-metricas` (`dividir()` em `ciclo.py`).
- Toda escolha entre variantes olha **só o dev**.
- A meta só conta como superada se valer no dev **e** no holdout. O holdout é reportado em cada iteração, mas
  nenhuma escolha é feita por ele.
- Os casos do RCAEval já foram vistos por outros métodos, então tudo aqui é exploratório. Uma confirmação exigiria
  outra base ou dados novos.

## Por que a localização

Com portão perfeito, o F1@1 fica perto do top-1 "sabendo". O melhor top-1 "sabendo" de todos os métodos de traces é
38%. A meta de 0,6 exige localizar muito melhor, e não só ajustar o portão.

## Iteração 1 — `m-rz`: ranking por métricas do próprio serviço (sem K8s)

O RCAEval traz `simple_metrics.csv` por caso, com uma série a cada 1 s por serviço:
cpu, mem, socket, diskio, workload, latency-50/90 e error. Nenhum método anterior usa essa fonte.

- **Janela:** `(t − 120 s, t]`.
- **Referência:** o passado da própria sessão, como nos traces.
  - instante normal: `[t − 120 − 600, t − 120)`;
  - instante de falha: os 600 s antes da injeção.
- **Escore por coluna:** `|mediana(janela) − mediana(ref)| / IQR(ref)`. Se o IQR for 0, usa o desvio-padrão da
  referência. Se este também for 0, usa `1e-9·|mediana| + 1e-12`, uma guarda numérica.
- **Escore do serviço:** o maior escore entre as suas colunas. Todas as métricas entram, sem escolher a dedo.
- **Ranking:** decrescente, top-3.
- **Modos medidos:**
  - `m-rz` sozinho (forçado = o próprio ranking);
  - **portão de traces + ranking `m-rz`**, para cada portão já existente: `d9+a|m`, `d9-b+c|m`,
    `d9-b+c@0.01|m`. Decisão = a do portão; ranking e forçado = os do `m-rz`.
- Leitura: a melhor variante no dev, comparada com a meta.

## Iteração 1 — resultado

Melhor variante no dev: `d9-b+c@0.01|m`, com F1@1 0.453 e F1@2 0.670. No holdout ela deu 0.521 / 0.667. Abaixo da
meta (`resultado-it1.md`).

Diagnóstico no dev: CPU sozinha dá top-1 sabendo de 62%, memória sozinha 68%, todas pelo máximo 52%. As famílias
quase constantes na referência (erro, workload, disco) dominam o máximo.

## Iteração 2 — `m-rzb`: famílias normalizadas pela baseline (fixado antes de medir)

- **Normalizador:** `N(suíte, família)` = percentil 95 (= 1 − FP_ALVO) do z da família, juntando todos os serviços,
  nas janelas normais da baseline da suíte. São os instantes `na_baseline`, os mesmos da d9-b, fora da medida de
  alarme. Se `N` for 0 ou faltar, a família fica de fora.
- **Escore do serviço:** `max_f z_f / N(suíte, f)`. Ranking decrescente.
- Modos: `m-rzb` e os mesmos portões com o ranking `m-rzb` (`…|mb`).

## Iteração 2 — resultado

Melhor no dev: `d9-b+c@0.01|mb`, com F1@1 0.543 e F1@2 **0.707**. No holdout: 0.557 / **0.704**. O F1@2 passa nas
duas metades e o F1@1 não (`resultado-it2.md`).

Diagnóstico no dev:
- traces e métricas são complementares. Em delay, d9 69% contra m-rzb 47%; em f2, 81% contra 46%. O oráculo dos
  dois fica perto de 80%;
- o escore máximo das métricas explode até ~1e17, porque séries constantes na referência caem na guarda numérica.

## Iteração 3 — `m-rzg`: escala log + resíduo pelo grafo de chamadas (fixado antes de medir)

- **Escore da família:** `u_f = log(1+z_f) / log(1+N(suíte, f))`, com `N` da iteração 2. É monotônico em z dentro
  da família, mas impede que a guarda numérica domine.
- **Escore do serviço:** `s(v) = max_f u_f`.
- **Ranking:** `d9.ranquear(…, ctx, "residuo_1")` do produto, com o grafo de chamadas do instante (`ctx` do registro
  `d9a`) e efeitos sintéticos de escore `1 + s(v)`. É a mesma regra de resíduo da d9 (α = 1), aplicada às métricas.
- **Ablação:** `m-rzl` (escala log, sem grafo).
- Modos: os mesmos portões com o ranking `m-rzg` (`…|mg`) e `m-rzl` (`…|ml`).

## Iteração 3 — resultado

O `m-rzg` **piora**: no dev, top-1 sabendo cai de 60% para 49%, e F1@1 fica 0.433 contra 0.543. O resíduo pelo
grafo rebaixa o culpado quando os vizinhos dele também mudam de métrica. A escala log sozinha (`m-rzl`) empata com o
`m-rzb`. Os dois ficam descartados. Melhor configuração até aqui: `d9-b+c@0.01|mb` (`resultado-it3.md`).

## Iteração 4 — fusão traces + métricas, sem parâmetro (fixado antes de medir)

Os rankings são o `m-rzb` (métricas, iteração 2) e o forçado da d9 (traces, `residuo_1`).

- **`f-borda`:** pontos 3, 2, 1 para o top-3 de cada fonte, com pesos iguais. Ordem pela soma; empate decidido pela
  ordem do `m-rzb`.
- **`f-conc`:** se o 1º da d9 está no top-2 do `m-rzb`, ele vai para o 1º lugar e o resto segue a ordem do
  `m-rzb`; senão vale o `m-rzb`.
- Modos: os portões com cada ranking (`…|fb`, `…|fc`). A escolha entre as duas é feita só pelo dev.

## Iteração 4 — resultado

No dev, a melhor é `d9-b+c@0.01|fb` (f-borda), com F1@1 0.554 e F1@2 0.759. No holdout ela dá 0.516 / 0.759: o
F1@1 fica **pior** que o do `m-rzb` (0.557). O ganho de top-1 no dev não se generaliza, e a fusão Borda só melhora
o top-2 (`resultado-it4.md`).

Teto atual: com top-1 de 60%, um portão perfeito dá F1@1 = 0,6. O portão tem 12% de abstenção e 11% de alarme.
Diagnóstico do escore máximo das métricas (dev):
- RE2-OB separa bem (normal p95 2,9 contra falha p10 5,2);
- nas suítes TT, a guarda numérica leva instantes normais a ~28.

## Iteração 5 — guarda por família + portão por métricas (fixado antes de medir)

- **`m-rzf`:** igual ao `m-rzl` (escala log normalizada pela baseline), com outra guarda. Coluna com IQR = 0 e
  desvio = 0 na referência usa a mediana dos IQR positivos das outras colunas da **mesma família** na mesma
  referência, e na falta deles o desvio. Família toda constante → a coluna sai. `N` é recalculado com o z novo.
- **Portão `g-m`:** abre se `max_v s(v) ≥ τ`. `τ` fica logo acima do (⌊0,05·n⌋+1)-ésimo maior `max_v s(v)` nas janelas
  da baseline da suíte (FP_ALVO 0,05, mesma regra da d9-b).
- **Portões medidos:** `g-m`; `g-m ou d9-b+c@0.01`; `g-m e d9-b+c@0.01`. Ranking `m-rzf`, e também `m-rzb` para
  comparar. A escolha é feita pelo dev.

## Iteração 5 — resultado: meta superada no dev **e** no holdout

Variante escolhida pelo dev: **`g-m∨t|mf`**. Portão = `g-m` (métricas) **ou** `d9-b+c@0.01` (traces); ranking =
`m-rzf` (`resultado-it5.md`).

| metade | F1@1 [IC 95%] | F1@2 | alarme | abstenção | top-1 sabendo | top-2 |
|---|---|---|---|---|---|---|
| dev (129 casos) | **0.718** [0.657–0.777] | **0.849** | 16.9% | 2.2% | 76.5% | 90.8% |
| holdout (112 casos) | **0.652** [0.579–0.720] | **0.800** | 13.8% | 4.3% | 68.3% | 84.8% |

- **De onde vem o ganho.** A guarda por família (`m-rzf`) sobe o top-1 sabendo de 60% para 76% (dev) e 68%
  (holdout): a guarda antiga deixava séries constantes dominarem o escore. O portão `g-m ∨ t` derruba a abstenção de
  12% para 2–4%.
- **Custo.** O alarme sobe para 14–17%, contra 9–11% do `d9-b+c@0.01`. O `g-m` sozinho tem 5–6,5% de alarme, mas
  abstém em 23% e fica com F1@1 0.671 (dev) / 0.589 (holdout).
- **Ressalvas.**
  - Exploratório: os casos do RCAEval já tinham sido vistos, e foram 5 iterações escolhidas pelo dev. O holdout
    ficou abaixo do dev (0.652 contra 0.718), sinal de algum ajuste ao dev.
  - O método usa métricas por serviço (`simple_metrics.csv`), uma fonte que os métodos anteriores não usavam.
    Comparar com eles mede também o ganho da fonte nova, não só do método.
  - TeaStore, Market e Eadro não foram medidos. Para isso é preciso adaptar a leitura das métricas de cada base.

## Generalização — `g-m∨t|mf` sem mudança nas outras bases (18/10/2026, teste de 10 min por base)

O método é o mesmo código, sem nada ajustado. Só o adaptador de métricas muda de base para base, e a família é o
nome da métrica em cada uma. Arquivos: `outras.py` (Eadro e Market, saída `resultado-eadro.md` e
`resultado-openrca-market.md`) e `experimento-falhas/teastore/stage3-online/replay/metricas_rz_teastore.py`
(saída `resultados/protocolo-metricas-rz/resultado.md`).

| base | baseline das métricas e do portão | F1@1 `g-m∨t\|mf` | F1@2 | alarme | abstenção | top-1 sabendo | melhor anterior (F1@1) |
|---|---|---|---|---|---|---|---|
| RCAEval (holdout) | instantes `na_baseline` | 0.652 | 0.800 | 13.8% | 4% | 68% | d9-k 0.308 |
| OpenRCA Market | trecho do v-cons-b (30 min por cloudbed) | 0.428 | 0.602 | 16.5% | 40% | 60% | d9-k 0.154 |
| Eadro SN | 1º bloco "no fault" (24 min) | 0.277 | 0.308 | 13.6% | 0% | 29% | v-cons-b 0.071 |
| TeaStore definitiva | métricas: trecho da sessão antes do normal medido (*); traces: 32c273a6 | 0.524 | 0.702 | 6.7% | 0% | 54% | **d9-k+a 0.979**, d9-k 0.887 |

(*) Desvio declarado: a coleção 32c273a6 não tem série de métricas.

Correção feita após a 1ª rodada no TeaStore: as métricas passaram a ser agregadas por serviço (média dos pods), e não
mais por pod. A injeção recria o pod do culpado, e o pod novo não tinha referência: o culpado sumia do ranking (top-1
0%). Isso deixou o adaptador igual ao do RCAEval, que já entrega métricas por serviço.

Leitura:
- nas bases abertas, o ganho sobre os métodos anteriores se repete: Market +0.27 e Eadro +0.24 de F1@1 sobre a d9,
  com IC acima de 0;
- a meta de 0,6 só vale no RCAEval;
- no TeaStore o método **perde** para os anteriores (top-1 54% contra 98%): os traces e os eventos K8s localizam
  melhor que as métricas;
- o alarme fica em 7–17% em todas as bases.

**Decisão (18/10/2026):** por causa do baixo desempenho, o Eadro SN sai das próximas rodadas (`../RESULTADO.md` §13).
As bases ativas passam a ser TeaStore, RCAEval e Market.
