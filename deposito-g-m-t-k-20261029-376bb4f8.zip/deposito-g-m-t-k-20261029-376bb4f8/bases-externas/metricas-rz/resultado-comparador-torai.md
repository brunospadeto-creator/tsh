# TORAI oficial nos casos multifonte do RCAEval com rastros (pós-hoc, fora do protocolo)

`comparadores_torai.py`. RCAEval 1.8.0, entrada do `main.py` com `--length 10` (5 min antes e 5 depois do horário da injeção); semente 0; no máximo 900 s por caso. Ranking vazio conta como erro. O nosso método: 1º instante de falha, ordem completa (como na Tabela de comparação com a literatura). Só o RE2 (Online Boutique e Train Ticket) distribui as séries de logs e de rastros que o TORAI lê.

## AC@1 / AC@3 / Avg@5 por caso, no nível de serviço

| suíte | casos | nosso | BARO | N-Sigma | TORAI | vazios TORAI |
|---|---|---|---|---|---|---|
| RE2-OB | 89 | 0.921 / 0.989 / 0.973 | 0.180 / 0.921 / 0.773 | 0.798 / 0.955 / 0.937 | 0.775 / 0.933 / 0.910 | 0 |
| RE2-TT | 90 | 0.589 / 0.911 / 0.844 | 0.589 / 0.744 / 0.738 | 0.600 / 0.744 / 0.727 | 0.767 / 0.956 / 0.907 | 0 |
| RE2 (as duas) | 179 | 0.754 / 0.950 / 0.908 | 0.385 / 0.832 / 0.755 | 0.698 / 0.849 / 0.831 | 0.771 / 0.944 / 0.908 | 0 |

## Permutação pareada em AC@1 (10.000; Holm sobre 26 = R3 + 3 do N-Sigma + 6 do CIRCA e do RCD + 4 do MicroRank e do TraceRCA + 1)

| casos | Δ AC@1 (nosso − TORAI) | p | p Holm |
|---|---|---|---|
| 179 | -0.017 | 0.7789 | 0.8560 |

## Avg@5 do TORAI por tipo de causa (validação contra a documentação do RCAEval)

| suíte | cpu | delay | disk | loss | mem | socket |
|---|---|---|---|---|---|---|
| RE2-OB | 0.96 (14) | 0.80 (15) | 1.00 (15) | 0.84 (15) | 0.93 (15) | 0.93 (15) |
| RE2-TT | 0.95 (15) | 0.65 (15) | 1.00 (15) | 0.88 (15) | 1.00 (15) | 0.96 (15) |

## Tempo e falhas

- tempo por caso: mediana 32 s, máximo 389 s (179 casos)
- nenhuma falha
