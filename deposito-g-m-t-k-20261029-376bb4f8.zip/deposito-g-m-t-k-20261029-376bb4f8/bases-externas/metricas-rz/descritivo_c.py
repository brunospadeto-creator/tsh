#!/usr/bin/env python3
"""Parte C do `PROTOCOLO-COMPLETO.md` (emenda 1): descritivos completos do `g-m∨t|mf` no RCAEval com traces (240) e
no OpenRCA Market (77), com ablação e comparadores nos mesmos instantes. Só lê os caches do código congelado
(`ciclo.py`, `outras.py`); nenhuma regra nova.

Modos: `g-m∨t|mf`; ablação `g-m|mf` (só métricas), `d9-b+c@0.01|mf` (só traces), `m-rzf` (sem portão);
comparadores `d9` (= d9-k sem K8s), `d9+a` (= d9-k+a sem K8s), `d2c-r`, `d9-b+c@0.01`.
v-cons-b nestas bases: os números já publicados no `../RESULTADO.md` (mesmos casos e instantes).
Saída: `resultado-descritivo-C.md`. Uso: python descritivo_c.py
"""
from __future__ import annotations

import os
import sys
import warnings
from collections import Counter, defaultdict
from typing import Any

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import outras as O  # noqa: E402

CI = O.CI
MODOS = ("g-m∨t|mf", "g-m|mf", "d9-b+c@0.01|mf", "m-rzf", "d9", "d9+a", "d2c-r", "d9-b+c@0.01")


def _contar(pc: dict, caso: str, periodo: str, esp: str | None, ds: dict[str, dict[str, Any]]) -> None:
    for m, d in ds.items():
        c = pc[m][caso]
        if periodo == "normal":
            c["nn"] += 1
            c["al"] += d["dec"]
        elif esp:
            c["ne"] += 1
            c["dec"] += d["dec"]
            for k in (1, 2):
                c[f"tp{k}"] += d["dec"] and esp in d["rk"][:k]
                c[f"o{k}"] += esp in d["f"][:k]


def _modos(d0: dict, d1: dict, rk: list[str], gm: bool) -> dict[str, dict[str, Any]]:
    gt = d1["d9-b+c"]["dec"]
    m = lambda dec: {"dec": dec, "rk": rk if dec else [], "f": rk}  # noqa: E731
    return {"g-m∨t|mf": m(gm or gt), "g-m|mf": m(gm and bool(rk)), "d9-b+c@0.01|mf": m(gt), "m-rzf": m(bool(rk)),
            "d9": d0["d9"], "d9+a": d0["d9+a"], "d2c-r": d0["d2c-r"], "d9-b+c@0.01": d1["d9-b+c"]}


def rcaeval(D: Any) -> list[str]:  # noqa: N803
    linhas = CI.BD.carregar()
    cals = CI.BD.calibracoes(linhas, 0.01)
    ex = CI.BD.exatos()   # rankings exatos da d2c-b, como no `ciclo.portoes`
    esf = CI.escores_metricas(linhas, familia=True)
    nf = CI.normalizadores(linhas, esf)
    tau = CI.tau_gate(linhas, esf, nf)
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in MODOS}
    for x in linhas:
        if x["periodo"] == "normal" and x.get("na_baseline"):
            continue
        s = x["grupo"]
        e = esf.get((x["caso"], x["t"]), {})
        rk = CI.ranking_rzl(e, nf.get(s, {}))
        gm = max(CI._u(e, nf.get(s, {})).values(), default=0.0) >= tau[s]
        _contar(pc, x["caso"], x["periodo"], x["gabarito"],
                _modos(D.decisoes(x), CI.BD.decisoes(x, cals[s], ex.get(x["caso"]), Counter()), rk, gm))
    casos = sorted({x["caso"] for x in linhas})
    parte = CI.dividir(linhas)
    out = ["## RCAEval com traces (RE2/RE3 OB e TT; descritivo: casos usados no ciclo)", "", *D.tabela(pc, casos), "",
           "v-cons-b (`../RESULTADO.md`, mesmos casos e instantes): F1@1 0.305, alarme 8%, sabendo top-1 37%.", ""]
    for nome in ("dev", "holdout"):
        sub = [c for c in casos if parte[c] == nome]
        out += [f"### {nome} ({len(sub)} casos)", "", *D.tabela(pc, sub), ""]
    return out


def market(D: Any) -> list[str]:  # noqa: N803
    linhas = D.carregar("openrca-market")
    bt = O.baseline_traces("openrca-market", 24)
    cals = {g: O.calib.calibrar(b["janelas"], 0.01) for g, b in bt.items()}
    es = O.escores_todos("openrca-market", linhas, bt)
    pseudo = [{"periodo": "normal", "na_baseline": True, "grupo": g, "caso": f"baseline/{g}", "t": str(t)}
              for g, b in bt.items() for t in b["t"]]
    norm = CI.normalizadores(pseudo, es)
    tau = CI.tau_gate(pseudo, es, norm)
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in MODOS}
    for x in linhas:
        g = x["grupo"]
        e = es.get((x["caso"], x["t"]), {})
        rk = CI.ranking_rzl(e, norm.get(g, {}))
        gm = max(CI._u(e, norm.get(g, {})).values(), default=0.0) >= tau[g]
        _contar(pc, x["caso"], x["periodo"], x["gabarito"],
                _modos(D.decisoes(x), CI.BD.decisoes(x, cals[g], None, Counter()), rk, gm))
    casos = sorted({x["caso"] for x in linhas})
    return ["## OpenRCA Market (descritivo: já visto na generalização)", "", *D.tabela(pc, casos), "",
            "v-cons-b (`../RESULTADO.md`, mesmos casos e instantes): F1@1 0.152, alarme 0%, sabendo top-1 27%.", ""]


def main() -> int:
    warnings.simplefilter("ignore", RuntimeWarning)
    D = CI._d9a()  # noqa: N806
    D.METODOS = MODOS
    out = ["# Parte C — descritivos completos do `g-m∨t|mf` (RCAEval com traces e Market)", "",
           "`PROTOCOLO-COMPLETO.md` emenda 1. Código congelado; só leitura dos caches. Sem K8s: d9 = d9-k e "
           "d9+a = d9-k+a. Ablação: `g-m|mf` (só métricas), `d9-b+c@0.01|mf` (só traces), `m-rzf` (sem portão).", "",
           *rcaeval(D), *market(D)]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-descritivo-C.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
