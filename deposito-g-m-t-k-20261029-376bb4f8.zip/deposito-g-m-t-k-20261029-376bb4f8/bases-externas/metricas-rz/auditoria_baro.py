#!/usr/bin/env python3
"""Auditoria do BARO e do N-Sigma oficiais (pós-hoc, fora do protocolo).

Não altera o `emenda2.py` (congelado). Em todos os casos reais do RCAEval (sem a cópia de `comum.DUPLICADOS`), roda
o BARO e o N-Sigma do pacote RCAEval 1.8.0 em três variantes de entrada:

- `artigo`: como no `emenda2.py` — arquivo lido por `confirmatorio_a.ler` (RE1: `data.csv`; RE2/RE3:
  `simple_metrics.csv`), colunas renomeadas para `{serviço}__{i}_{sufixo}`; exceção → ranking vazio, agora contada;
- `simples`: o mesmo arquivo lido cru pelo pandas, só sem as linhas de `time` vazio, sem renomear;
- `completo` (só RE2/RE3): o `metrics.csv` completo, cru, sem as linhas de `time` vazio.

AC@1, AC@3 e Avg@5 por caso no nível de serviço, por suíte, e a contagem de exceções por tipo.
Saída: `resultado-auditoria-baro.md`. Uso: python auditoria_baro.py [--jobs 16]
"""
from __future__ import annotations

import argparse
import os
import sys
import traceback
import warnings
from collections import Counter, defaultdict
from typing import Any

import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import confirmatorio_a as CA  # noqa: E402
import emenda2 as E2  # noqa: E402

from comum import DUPLICADOS  # noqa: E402

SUITES = tuple(f"RE{i}-{s}" for i in (1, 2, 3) for s in ("OB", "SS", "TT"))
PUBLICADO_RE2TT = E2.PUBLICADO_RE2TT


def casos(suite: str) -> list[str]:
    raiz = os.path.join(CA.ORIGEM, suite, suite)
    out = []
    for falha in sorted(os.listdir(raiz)):
        d = os.path.join(raiz, falha)
        if not os.path.isdir(d):
            continue
        for rep in sorted(os.listdir(d)):
            if os.path.exists(os.path.join(d, rep, "inject_time.txt")) and f"{suite}/{falha}/{rep}" not in DUPLICADOS:
                out.append(f"{falha}/{rep}")
    return out


def _rodar(fn: Any, df: pd.DataFrame, inj: float, dataset: str) -> tuple[list[str], str | None]:
    try:
        return E2.servicos_em_ordem(fn(data=df, inject_time=inj, dataset=dataset)["ranks"]), None
    except Exception as exc:  # noqa: BLE001
        return [], f"{type(exc).__name__}: {str(exc)[:80]}"


def _cru(arq: str) -> pd.DataFrame:
    df = pd.read_csv(arq)
    return df[df["time"].notna()].sort_values("time").reset_index(drop=True)


def job(j: tuple[str, str]) -> dict[str, Any]:
    warnings.simplefilter("ignore")
    from RCAEval.e2e import baro, nsigma  # noqa: PLC0415
    suite, caso = j
    pasta = os.path.join(CA.ORIGEM, suite, suite, caso)
    inj = float(open(os.path.join(pasta, "inject_time.txt")).read().strip())
    ds = suite.lower()
    out: dict[str, Any] = {"suite": suite, "caso": caso, "esp": CA.gabarito(caso)[0], "rk": {}, "erro": {}}
    # artigo: exatamente a chamada do emenda2 (renomeação incluída), com a exceção registrada
    tempo, val, cols, _ = CA.ler(suite, caso)
    nomes = [f"{E2.servico_col(c)}__{i}_{c.rsplit('_', 1)[1]}" for i, c in enumerate(cols)]
    df = pd.DataFrame(val, columns=nomes)
    df.insert(0, "time", tempo)
    entradas = {"artigo": df}
    arq = os.path.join(pasta, "data.csv")
    if not os.path.exists(arq):
        arq = os.path.join(pasta, "simple_metrics.csv")
    entradas["simples"] = _cru(arq)
    if not suite.startswith("RE1") and os.path.exists(os.path.join(pasta, "metrics.csv")):
        entradas["completo"] = _cru(os.path.join(pasta, "metrics.csv"))
    for var, d in entradas.items():
        for nome, fn in (("BARO", baro), ("N-Sigma", nsigma)):
            rk, err = _rodar(fn, d, inj, ds)
            out["rk"][(var, nome)] = rk
            if err:
                out["erro"][(var, nome)] = err
    return out


def ac(rks: list[list[str]], esps: list[str]) -> tuple[float, float, float, int]:
    n = len(rks)
    if not n:
        return (float("nan"),) * 3 + (0,)
    a = {k: sum(e in r[:k] for r, e in zip(rks, esps, strict=True)) / n for k in range(1, 6)}
    return a[1], a[3], sum(a.values()) / 5, n


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    args = ap.parse_args()
    jobs = [(s, c) for s in SUITES for c in casos(s)]
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    try:
        with ProcessPoolExecutor(args.jobs) as ex:
            res = list(ex.map(job, jobs, chunksize=2))
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        return 1
    out = ["# Auditoria do BARO e do N-Sigma oficiais (pós-hoc, fora do protocolo)", "",
           "`auditoria_baro.py` (`ANALISE-QUALIDADE.md` §10.1 item 2). RCAEval 1.8.0, sem alteração. AC@k por caso, "
           "serviço. Variantes: `artigo` = entrada do `emenda2.py` (colunas renomeadas); `simples` = mesmo arquivo cru "
           "(sem linhas de `time` vazio); `completo` = `metrics.csv` cru (RE2/RE3). Ranking vazio (exceção) conta "
           "como erro, como no artigo.", "",
           f"{len(res)} casos ({', '.join(f'{s} {sum(r['suite'] == s for r in res)}' for s in SUITES)}).", "",
           "## AC@1 / AC@3 / Avg@5 por suíte", "",
           "| suíte | variante | BARO | N-Sigma | exceções BARO | exceções N-Sigma |", "|---|---|---|---|---|---|"]
    variantes = ("artigo", "simples", "completo")
    for s in SUITES:
        rs = [r for r in res if r["suite"] == s]
        for v in variantes:
            if not any((v, "BARO") in r["rk"] for r in rs):
                continue
            cel = []
            for m in ("BARO", "N-Sigma"):
                sub = [r for r in rs if (v, m) in r["rk"]]
                a1, a3, a5, _ = ac([r["rk"][(v, m)] for r in sub], [r["esp"] for r in sub])
                cel.append(f"{a1:.3f} / {a3:.3f} / {a5:.3f}")
            ne = [sum((v, m) in r["erro"] for r in rs) for m in ("BARO", "N-Sigma")]
            out.append(f"| {s} | {v} | {cel[0]} | {cel[1]} | {ne[0]} | {ne[1]} |")
    rt = [r for r in res if r["suite"] == "RE2-TT"]
    out += ["", f"Publicado para o BARO no RE2-TT (Tabela 6 do RCAEval): AC@1 {PUBLICADO_RE2TT['AC@1']}, "
            f"AC@3 {PUBLICADO_RE2TT['AC@3']}, Avg@5 {PUBLICADO_RE2TT['Avg@5']} ({len(rt)} casos aqui).", "",
            "## Conjuntos do artigo (AC@1 do BARO / N-Sigma)", "",
            "| conjunto | variante | casos | BARO | N-Sigma |", "|---|---|---|---|---|"]
    teste = CA.sorteio_teste(CA.casos())
    conj = {"RCAEval inédito (A)": [r for r in res if r["suite"] in CA.SUITES and f"{r['suite']}/{r['caso']}" not in teste],
            "RCAEval com rastros (C)": [r for r in res if r["suite"] in ("RE2-OB", "RE2-TT", "RE3-OB", "RE3-TT")]}
    for nome, rs in conj.items():
        for v in variantes:
            sub = [r for r in rs if (v, "BARO") in r["rk"]]
            if not sub:
                continue
            a = [ac([r["rk"][(v, m)] for r in sub], [r["esp"] for r in sub])[0] for m in ("BARO", "N-Sigma")]
            out.append(f"| {nome} | {v} | {len(sub)} | {a[0]:.3f} | {a[1]:.3f} |")
    tipos: Counter = Counter()
    for r in res:
        for (v, m), e in r["erro"].items():
            tipos[(v, m, e.split(":")[0])] += 1
    out += ["", "## Exceções por tipo", "", "| variante | método | exceção | casos |", "|---|---|---|---|"]
    out += [f"| {v} | {m} | {e} | {n} |" for (v, m, e), n in sorted(tipos.items())] or ["| — | — | nenhuma | 0 |"]
    exemplos = defaultdict(list)
    for r in res:
        for (v, m), e in r["erro"].items():
            if len(exemplos[(v, m)]) < 3:
                exemplos[(v, m)].append(f"{r['suite']}/{r['caso']}: {e}")
    if exemplos:
        out += ["", "Exemplos:", ""] + [f"- {v}/{m}: " + "; ".join(xs) for (v, m), xs in sorted(exemplos.items())]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-auditoria-baro.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    sys.exit(main())
