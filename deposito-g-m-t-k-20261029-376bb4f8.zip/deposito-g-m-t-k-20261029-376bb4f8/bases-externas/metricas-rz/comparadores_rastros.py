#!/usr/bin/env python3
"""MicroRank e TraceRCA do RCAEval 1.8.0 nos mesmos casos com rastros (pós-hoc, fora do protocolo).

Continuação do `outros_comparadores.py` (CIRCA e RCD), pedida em 20/10: o
artigo só comparava o método com os métodos anteriores baseados em rastros, todos do autor e não publicados. Os dois
métodos do pacote são reescritas feitas pelos autores do RCAEval (`RCAEval/e2e/microrank.py`, `tracerca.py`).

Entrada: a tabela de spans do caso e o horário da injeção em µs (o pacote não converte; os `startTime` e `duration`
são em µs). Os dois métodos separam os spans pelo horário da injeção e devolvem **operações** (`serviço_método`); o
serviço fica na posição da sua primeira operação.
- **RCAEval com rastros:** o `traces.csv` de cada caso, sem mudança. O RE2-OB chama o frontend de `frontendservice`
  (como no `rcaeval/adaptar.py`); no ranking, volta a `frontend`.
- **OpenRCA Market:** a fatia do caso gravada pelo `openrca-market/adaptar.py` (600 s antes da falha e a falha, cortada
  na falha seguinte), com as colunas renomeadas: `trace_id`→`traceID`, `span_id`→`spanID`,
  `parent_span`→`parentSpanID`, serviço = `cmdb_id` sem o sufixo de réplica, `operation_name` como `operationName`
  (o `methodName` fica vazio e o pacote o preenche com o `operationName`), `timestamp` ms → µs; `duration` já em µs.

Os dois métodos tiram o SLO de cada operação só do período normal e o consultam para toda operação do período de
falha: uma operação que só aparece depois da injeção (por exemplo, `OnCommittedResponseWrapper.sendError` no RE3-TT)
dá `KeyError`. Nesse caso, e só nele, o caso é rodado de novo sem os spans dessas operações, e fica marcado como
filtrado no resultado.

Semente 0, no máximo `TEMPO_MAX` s por caso (as duas tentativas somadas); ranking vazio (exceção ou tempo esgotado)
conta como erro.

Uso:
  python comparadores_rastros.py --rodar microrank|tracerca [--jobs 16] [--amostra 3]
  python comparadores_rastros.py --relatorio        → resultado-comparadores-rastros.md
"""
from __future__ import annotations

import argparse
import os
import pickle
import signal
import sys
import time
import warnings
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import robustez as R  # noqa: E402

CI, E2, O = R.CI, R.E2, R.O
SAIDA = os.path.join(O.CACHE, "outros-comparadores")
TEMPO_MAX = 900   # s por caso e método
ALIAS = {"frontendservice": "frontend"}
COLS = ["traceID", "spanID", "parentSpanID", "serviceName", "methodName", "operationName", "startTime", "duration"]


class _Esgotado(Exception):
    pass


def _alarme(*_: Any) -> None:
    raise _Esgotado


def entradas() -> list[tuple[str, str]]:
    """(conjunto, caso) dos dois conjuntos públicos com rastros, como nas unidades do `robustez.py`."""
    return ([("RCAEval-C", c) for c in sorted(R.unidade_c(8)["baro"])] +
            [("Market", c) for c in sorted(R.unidade_m(8)["baro"])])


def _spans(conj: str, caso: str) -> tuple[pd.DataFrame, float]:
    if conj == "RCAEval-C":
        suite, resto = caso.split("/", 1)
        pasta = os.path.join(CI.ORIGEM, suite, suite, resto)
        df = pd.read_csv(os.path.join(pasta, "traces.csv"), usecols=COLS,
                         dtype={"traceID": str, "spanID": str, "parentSpanID": str})
        with open(os.path.join(pasta, "inject_time.txt")) as f:
            inj = float(f.read().strip())
        return df, inj
    ad = O._ad("openrca-market")
    v = ad.casos()[caso]
    m = pd.read_parquet(ad._fatia(caso))
    df = pd.DataFrame({"traceID": m["trace_id"].astype(str), "spanID": m["span_id"].astype(str),
                       "parentSpanID": m["parent_span"].astype(str), "serviceName": m["cmdb_id"].astype(str).map(ad.servico),
                       "methodName": np.nan, "operationName": m["operation_name"].astype(str),
                       "startTime": m["timestamp"].astype("int64") * 1000, "duration": m["duration"].astype("int64")})
    return df, float(v["falha"][0])


def _com_span(conj: str, caso: str) -> set[str]:
    """Serviços com pelo menos um span na entrada do caso (mesmos nomes do ranking)."""
    if conj == "RCAEval-C":
        suite, resto = caso.split("/", 1)
        s = pd.read_csv(os.path.join(CI.ORIGEM, suite, suite, resto, "traces.csv"), usecols=["serviceName"])
        return {ALIAS.get(x, x) for x in s["serviceName"].astype(str).unique()}
    return set(_spans(conj, caso)[0]["serviceName"].unique())


def servicos(ranks: list[str]) -> list[str]:
    ordem: list[str] = []
    for r in ranks:
        s = r.split("_", 1)[0]
        s = ALIAS.get(s, s)
        if s not in ordem:
            ordem.append(s)
    return ordem


def _job(job: tuple[str, str, str]) -> tuple[str, str, list[str], str | None, float, bool]:
    warnings.simplefilter("ignore")
    conj, caso, metodo = job
    signal.signal(signal.SIGALRM, _alarme)
    t0 = time.time()
    try:
        df, inj = _spans(conj, caso)
        if metodo == "microrank":
            from RCAEval.e2e import microrank as fn  # noqa: PLC0415
        else:
            from RCAEval.e2e import tracerca as fn  # noqa: PLC0415
        filtrado = False
        np.random.seed(0)
        signal.alarm(TEMPO_MAX)
        try:
            try:
                ranks = fn(data=df.copy(), inject_time=inj * 1_000_000, dataset=conj.lower())["ranks"]
            except KeyError:
                # operações que só aparecem depois da injeção não têm SLO no pacote: saem da entrada
                op = df["serviceName"] + "_" + df["methodName"].fillna(df["operationName"])
                antes = set(op[df["startTime"] + df["duration"] < inj * 1_000_000])
                df, filtrado = df[op.isin(antes)], True
                np.random.seed(0)
                ranks = fn(data=df.copy(), inject_time=inj * 1_000_000, dataset=conj.lower())["ranks"]
        finally:
            signal.alarm(0)
        return conj, caso, servicos(list(ranks)), None, time.time() - t0, filtrado
    except _Esgotado:
        return conj, caso, [], f"tempo esgotado (> {TEMPO_MAX} s)", time.time() - t0, False
    except Exception as exc:  # noqa: BLE001
        return conj, caso, [], f"{type(exc).__name__}: {str(exc)[:80]}", time.time() - t0, False


def rodar(metodo: str, jobs: int, amostra: int | None) -> None:
    os.makedirs(SAIDA, exist_ok=True)
    arq = os.path.join(SAIDA, f"{metodo}.pkl")
    feito: dict[tuple[str, str], tuple[list[str], str | None, float, bool]] = {}
    if os.path.exists(arq):
        with open(arq, "rb") as f:
            feito = pickle.load(f)
    todos = entradas()
    if amostra:   # teste: os `amostra` primeiros casos de cada suíte e do Market
        por: dict[str, list] = {}
        for cj, c in todos:
            por.setdefault(c.split("/")[0] if cj == "RCAEval-C" else cj, []).append((cj, c))
        todos = [x for v in por.values() for x in v[:amostra]]
    pend = [(cj, c, metodo) for cj, c in todos if (cj, c) not in feito]
    print(f"{metodo}: {len(feito)} feitos, {len(pend)} pendentes", flush=True)
    from concurrent.futures import ProcessPoolExecutor, as_completed  # noqa: PLC0415
    with ProcessPoolExecutor(jobs) as ex:
        futs = [ex.submit(_job, j) for j in pend]
        for i, fu in enumerate(as_completed(futs), 1):
            cj, c, rk, err, dt, filt = fu.result()
            feito[(cj, c)] = (rk, err, dt, filt)
            if amostra:
                print(f"  {cj} {c}: {dt:.0f} s, {rk[:3]} {err or ''}{' (filtrado)' if filt else ''}", flush=True)
            if i % 10 == 0 or i == len(futs):
                with open(arq + ".tmp", "wb") as f:
                    pickle.dump(feito, f)
                os.replace(arq + ".tmp", arq)
                print(f"{metodo}: {i}/{len(futs)}", flush=True)


def relatorio() -> int:
    us = {"RCAEval-C": R.unidade_c(8), "Market": R.unidade_m(8)}
    res = {}
    for m in ("microrank", "tracerca"):
        with open(os.path.join(SAIDA, f"{m}.pkl"), "rb") as f:
            res[m] = pickle.load(f)
    rng = np.random.default_rng(2026102001)
    labs = (("microrank", "MicroRank"), ("tracerca", "TraceRCA"))
    out = ["# MicroRank e TraceRCA oficiais nos mesmos casos com rastros (pós-hoc, fora do protocolo)", "",
           "`comparadores_rastros.py`. RCAEval 1.8.0; spans do caso e horário da injeção; semente 0; no máximo "
           f"{TEMPO_MAX} s por caso. Ranking vazio conta como erro. O nosso método: 1º instante de falha, ordem "
           "completa (como na Tabela de comparação com a literatura).", "",
           "## AC@1 / AC@3 / Avg@5 por caso, no nível de serviço", "",
           "| conjunto | casos | nosso | BARO | N-Sigma | MicroRank | TraceRCA | vazios MicroRank | vazios TraceRCA |",
           "|---|---|---|---|---|---|---|---|---|"]
    novas, subconj, falhas, tempos, filtrados, sem_filtro, sem_span = [], [], [], {}, {}, [], {}
    for nome, u in us.items():
        norm = R.cal_original(u)["norm"]
        primeiro: dict[str, dict] = {}
        for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
            if x["periodo"] == "falha" and x["esp"] and x["caso"] not in primeiro:
                primeiro[x["caso"]] = x
        rks = {"nosso": {c: E2.ordem_completa(x["f"], norm.get(x["grupo"], {})) for c, x in primeiro.items()}}
        for b in ("BARO", "N-Sigma"):
            rks[b] = {c: (u["baro"].get(c) or {}).get(b, []) for c in primeiro}
        for m, lab in labs:
            rks[lab] = {c: res[m].get((nome, c), ([], "ausente", 0.0, False))[0] for c in primeiro}
            for c in primeiro:
                rk, err, dt, filt = res[m].get((nome, c), ([], "ausente", 0.0, False))
                g = c.split("/")[0] if nome == "RCAEval-C" else "Market"
                tempos.setdefault((lab, g), []).append(dt)
                filtrados[(lab, g)] = filtrados.get((lab, g), 0) + int(filt)
                if not rk:
                    falhas.append((lab, g, err or "ranking vazio"))
        esp = {c: x["esp"] for c, x in primeiro.items()}
        for c in esp:
            g = c.split("/")[0] if nome == "RCAEval-C" else "Market"
            n, falta = sem_span.get(g, (0, []))
            sem_span[g] = (n + 1, falta + ([f"{c} ({esp[c]})"] if esp[c] not in _com_span(nome, c) else []))

        def acs(rk: dict[str, list[str]]) -> str:
            a = {k: np.mean([esp[c] in rk[c][:k] for c in esp]) for k in range(1, 6)}
            return f"{a[1]:.3f} / {a[3]:.3f} / {np.mean(list(a.values())):.3f}"
        vaz = {lab: sum(1 for c in esp if not rks[lab][c]) for _, lab in labs}
        out.append(f"| {nome} | {len(esp)} | {acs(rks['nosso'])} | {acs(rks['BARO'])} | {acs(rks['N-Sigma'])} | "
                   f"{acs(rks['MicroRank'])} | {acs(rks['TraceRCA'])} | {vaz['MicroRank']} | {vaz['TraceRCA']} |")
        a1 = {lab: {c: float(rks[lab][c][:1] == [esp[c]]) for c in esp} for lab in rks}
        for _, lab in labs:
            d, p = R._perm_ac(a1["nosso"], a1[lab], rng)
            novas.append({"base": nome, "b": lab, "delta": d, "p": p})
            ok = [c for c in esp if rks[lab][c]]
            if ok:
                ac_s = {q: {k: np.mean([esp[c] in rks[q][c][:k] for c in ok]) for k in (1, 3)} for q in ("nosso", lab)}
                ds, ps_ = R._perm_ac({c: a1["nosso"][c] for c in ok}, {c: a1[lab][c] for c in ok}, rng)
                subconj.append({"base": nome, "b": lab, "n": len(ok), "de": len(esp), "ac": ac_s, "delta": ds,
                                "p": ps_})
            nf = [c for c in esp if not res[dict((v, k) for k, v in labs)[lab]].get((nome, c), ([], None, 0.0, False))[3]]
            sem_filtro.append(f"| {nome} | {lab} | {len(nf)} de {len(esp)} | "
                              f"{np.mean([a1['nosso'][c] for c in nf]):.3f} / {np.mean([a1[lab][c] for c in nf]):.3f} |")
    r3 = (R.ler("resultados") or {}).get("R3", [])
    # 3 contra o N-Sigma (`resultado-extras-revisao.md`) e 6 contra o CIRCA e o RCD (`resultado-outros-comparadores.md`)
    fixos = [0.0050, 0.4280, 0.0592] + [0.0001] * 6
    ps = [c["p"] for c in r3] + fixos + [c["p"] for c in novas]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    out += ["", f"## Permutação pareada em AC@1 (10.000; Holm sobre {len(ps)} = R3 + 3 do N-Sigma + 6 do CIRCA e "
            f"do RCD + {len(novas)})", "", "| conjunto | comparação | Δ AC@1 | p | p Holm |", "|---|---|---|---|---|"]
    for k, c in enumerate(novas):
        out.append(f"| {c['base']} | nosso − {c['b']} | {c['delta']:+.3f} | {c['p']:.4f} | "
                   f"{holm[len(r3) + len(fixos) + k]:.4f} |")
    out += ["", "Holm sobre todas, nas comparações anteriores (p bruto → p Holm):", ""]
    rot = [f"R3 {c['base']} {c['medida']}: {c['a']} − {c['b']}" for c in r3] + \
        [f"N-Sigma {b}" for b in ("A", "RCAEval-C", "Market")] + \
        [f"{b} {m}" for b in ("A", "RCAEval-C", "Market") for m in ("CIRCA", "RCD")]
    out += [f"- {r}: {ps[i]:.4f} → {holm[i]:.4f}" for i, r in enumerate(rot)]
    hs, mx = [0.0] * len(subconj), 0.0
    for r, i in enumerate(sorted(range(len(subconj)), key=lambda i: subconj[i]["p"])):
        mx = max(mx, min(1.0, (len(subconj) - r) * subconj[i]["p"]))
        hs[i] = mx
    out += ["", f"## Só os casos em que o método terminou (o nosso, nos mesmos casos; Holm sobre estas {len(subconj)})",
            "", "| conjunto | método | casos | AC@1 nosso / método | AC@3 nosso / método | Δ AC@1 | p | p Holm |",
            "|---|---|---|---|---|---|---|---|"]
    for c, h in zip(subconj, hs, strict=True):
        a = c["ac"]
        out.append(f"| {c['base']} | {c['b']} | {c['n']} de {c['de']} | {a['nosso'][1]:.3f} / {a[c['b']][1]:.3f} | "
                   f"{a['nosso'][3]:.3f} / {a[c['b']][3]:.3f} | {c['delta']:+.3f} | {c['p']:.4f} | {h:.4f} |")
    out += ["", "## Sem os casos filtrados (sensibilidade)", "", "| conjunto | método | casos | AC@1 nosso / método |",
            "|---|---|---|---|"] + sem_filtro
    out += ["", "## Falhas e tempo por suíte", "", "| método | suíte | falhas | filtrados | casos | tempo mediano (s) | tempo máximo (s) |",
            "|---|---|---|---|---|---|---|"]
    for (lab, g), ts in sorted(tempos.items()):
        nf = sum(1 for la, gg, _ in falhas if la == lab and gg == g)
        out.append(f"| {lab} | {g} | {nf} | {filtrados.get((lab, g), 0)} | {len(ts)} | {np.median(ts):.0f} | "
                   f"{max(ts):.0f} |")
    out += ["", "## Casos em que o serviço da causa não tem nenhum span na entrada", "",
            "Nesses casos nenhum método de rastros pode pôr a causa no ranking.", "",
            "| suíte | casos | sem span da causa | casos sem span (serviço) |", "|---|---|---|---|"]
    for g, (n, falta) in sorted(sem_span.items()):
        out.append(f"| {g} | {n} | {len(falta)} | {', '.join(falta) or '—'} |")
    motivos: dict[tuple[str, str], int] = {}
    for lab, _, e in falhas:
        motivos[(lab, e)] = motivos.get((lab, e), 0) + 1
    out += ["", "## Motivos das falhas", ""]
    out += [f"- {lab}: {e} ({n}×)" for (lab, e), n in sorted(motivos.items())] or ["- nenhuma"]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-comparadores-rastros.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rodar", choices=("microrank", "tracerca"))
    ap.add_argument("--relatorio", action="store_true")
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--amostra", type=int)
    a = ap.parse_args()
    if a.rodar:
        rodar(a.rodar, a.jobs, a.amostra)
    if a.relatorio:
        return relatorio()
    return 0


if __name__ == "__main__":
    sys.exit(main())
