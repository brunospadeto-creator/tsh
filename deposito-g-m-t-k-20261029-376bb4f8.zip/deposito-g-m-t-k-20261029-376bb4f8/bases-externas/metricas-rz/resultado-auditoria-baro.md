# Auditoria do BARO e do N-Sigma oficiais (pós-hoc, fora do protocolo)

`auditoria_baro.py` (`ANALISE-QUALIDADE.md` §10.1 item 2). RCAEval 1.8.0, sem alteração. AC@k por caso, serviço. Variantes: `artigo` = entrada do `emenda2.py` (colunas renomeadas); `simples` = mesmo arquivo cru (sem linhas de `time` vazio); `completo` = `metrics.csv` cru (RE2/RE3). Ranking vazio (exceção) conta como erro, como no artigo.

735 casos (RE1-OB 125, RE1-SS 125, RE1-TT 125, RE2-OB 90, RE2-SS 90, RE2-TT 90, RE3-OB 30, RE3-SS 30, RE3-TT 30).

## AC@1 / AC@3 / Avg@5 por suíte

| suíte | variante | BARO | N-Sigma | exceções BARO | exceções N-Sigma |
|---|---|---|---|---|---|
| RE1-OB | artigo | 0.720 / 0.912 / 0.878 | 0.728 / 0.904 / 0.882 | 0 | 0 |
| RE1-OB | simples | 0.720 / 0.912 / 0.878 | 0.728 / 0.904 / 0.882 | 0 | 0 |
| RE1-SS | artigo | 0.184 / 0.600 / 0.557 | 0.600 / 0.912 / 0.866 | 0 | 0 |
| RE1-SS | simples | 0.184 / 0.600 / 0.557 | 0.600 / 0.912 / 0.866 | 0 | 0 |
| RE1-TT | artigo | 0.136 / 0.296 / 0.277 | 0.520 / 0.728 / 0.690 | 0 | 0 |
| RE1-TT | simples | 0.136 / 0.296 / 0.277 | 0.520 / 0.728 / 0.690 | 0 | 0 |
| RE2-OB | artigo | 0.178 / 0.922 / 0.773 | 0.800 / 0.956 / 0.938 | 0 | 0 |
| RE2-OB | simples | 0.178 / 0.922 / 0.773 | 0.800 / 0.956 / 0.938 | 0 | 0 |
| RE2-OB | completo | 0.211 / 0.444 / 0.458 | 0.600 / 0.911 / 0.853 | 0 | 0 |
| RE2-SS | artigo | 0.156 / 0.911 / 0.762 | 0.778 / 0.956 / 0.918 | 0 | 0 |
| RE2-SS | simples | 0.156 / 0.911 / 0.762 | 0.778 / 0.956 / 0.918 | 0 | 0 |
| RE2-SS | completo | 0.389 / 0.567 / 0.589 | 0.589 / 0.933 / 0.851 | 0 | 0 |
| RE2-TT | artigo | 0.589 / 0.744 / 0.738 | 0.600 / 0.744 / 0.727 | 0 | 0 |
| RE2-TT | simples | 0.589 / 0.744 / 0.738 | 0.600 / 0.744 / 0.727 | 0 | 0 |
| RE2-TT | completo | 0.311 / 0.367 / 0.373 | 0.344 / 0.589 / 0.562 | 0 | 0 |
| RE3-OB | artigo | 0.100 / 0.900 / 0.733 | 0.900 / 0.967 / 0.940 | 0 | 0 |
| RE3-OB | simples | 0.100 / 0.900 / 0.733 | 0.900 / 0.967 / 0.940 | 0 | 0 |
| RE3-OB | completo | 0.200 / 0.467 / 0.480 | 0.833 / 0.933 / 0.920 | 0 | 0 |
| RE3-SS | artigo | 0.167 / 0.867 / 0.713 | 0.400 / 0.833 / 0.720 | 0 | 0 |
| RE3-SS | simples | 0.167 / 0.867 / 0.713 | 0.400 / 0.833 / 0.720 | 0 | 0 |
| RE3-SS | completo | 0.100 / 0.233 / 0.247 | 0.100 / 0.333 / 0.327 | 0 | 0 |
| RE3-TT | artigo | 0.767 / 0.867 / 0.847 | 0.833 / 0.900 / 0.887 | 0 | 0 |
| RE3-TT | simples | 0.767 / 0.867 / 0.847 | 0.833 / 0.900 / 0.887 | 0 | 0 |
| RE3-TT | completo | 0.700 / 0.800 / 0.773 | 0.267 / 0.900 / 0.760 | 0 | 0 |

Publicado para o BARO no RE2-TT (Tabela 6 do RCAEval): AC@1 0.67, AC@3 0.82, Avg@5 0.8 (90 casos aqui).

## Conjuntos do artigo (AC@1 do BARO / N-Sigma)

| conjunto | variante | casos | BARO | N-Sigma |
|---|---|---|---|---|
| RCAEval inédito (A) | artigo | 480 | 0.298 | 0.631 |
| RCAEval inédito (A) | simples | 480 | 0.298 | 0.631 |
| RCAEval inédito (A) | completo | 114 | 0.325 | 0.474 |
| RCAEval com rastros (C) | artigo | 240 | 0.396 | 0.742 |
| RCAEval com rastros (C) | simples | 240 | 0.396 | 0.742 |
| RCAEval com rastros (C) | completo | 240 | 0.308 | 0.492 |

## Exceções por tipo

| variante | método | exceção | casos |
|---|---|---|---|
| — | — | nenhuma | 0 |

## Diagnóstico adicional (19/10, mesma sessão; trechos rodados à parte com as funções deste script)

**Coluna que o BARO põe em 1º** (variante `simples`, padrão do RCAEval):

| suíte | coluna mais frequente em 1º | casos | erros com o gabarito em 2º ou 3º |
|---|---|---|---|
| RE2-OB | `redis_diskio` | 69 de 90 | 67 de 74 |
| RE2-SS | `session-db_diskio` | 71 de 90 | 65 de 76 |
| RE1-SS | colunas de nó (`…-9100_node-memory-active-bytes`) e `rabbitmq`, espalhadas | — | 36 de 102 |
| RE1-TT | colunas `container-memory-*` de vários serviços, espalhadas | — | 14 de 108 |

Leitura: no RE2-OB e no RE2-SS, o máximo com sinal do BARO é dominado por uma série de disco do banco de dados,
presente em todos os casos. Isso explica o AC@1 baixo com o AC@3 alto (0,178 × 0,922 no RE2-OB). No RE1, colunas
de nó e de infraestrutura tomam o 1º lugar.

**`dk_select_useful=True`** (opção oficial que filtra colunas), AC@1 / AC@3 / Avg@5:

| suíte | AC@1 / AC@3 / Avg@5 | rankings vazios |
|---|---|---|
| RE1-OB | 0.208 / 0.208 / 0.208 | 15 |
| RE1-SS | 0.000 / 0.000 / 0.000 | 125 |
| RE1-TT | 0.000 / 0.000 / 0.000 | 125 |
| RE2-OB | 0.222 / 0.222 / 0.222 | 0 |
| RE2-SS | 0.289 / 0.300 / 0.298 | 0 |
| RE2-TT | 0.467 / 0.556 / 0.533 | 1 |
| RE3-OB | 0.500 / 0.500 / 0.500 | 15 |
| RE3-SS | 0.767 / 0.833 / 0.820 | 2 |
| RE3-TT | 0.900 / 0.900 / 0.900 | 0 |

A opção não reproduz o valor publicado e piora o BARO. O filtro da opção (`_cpu` e `_mem` com desvio > 1, e
`lat50`) não casa com os nomes das colunas do RE1-SS e do RE1-TT (`…_container-memory-rss` etc.), e o ranking
fica vazio.

## Conclusão da auditoria

- **Nenhuma** exceção em 735 casos × 2 métodos × até 3 variantes. O `except` silencioso não afetou o artigo.
- A renomeação de colunas é inofensiva: `artigo` = `simples` em todas as suítes.
- O `metrics.csv` completo e o `dk_select_useful` pioram o BARO. A entrada usada no artigo, igual ao padrão do
  pacote, é a que mais se aproxima do valor publicado no RE2-TT (0,589 × 0,67).
- A diferença restante continua sem explicação. A hipótese concreta é a sensibilidade do máximo com sinal a uma
  série ruidosa do banco de dados (tabela acima). Uma versão diferente dos dados ou do código usada no artigo
  original não pode ser descartada.
