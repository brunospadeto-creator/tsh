# Resultado consolidado para o artigo — `g-m∨t|mf` e `g-m∨t∨k|mfk` (18/10/2026)

**Fontes:**
- protocolo `PROTOCOLO-COMPLETO.md`: pré-registro e emendas 1–3, cada uma commitada antes de rodar;
- resultados `resultado-confirmatorio-A.md`, `resultado-descritivo-C.md`, `resultado-emenda2.md` e
  `resultado-robustez.md`;
- TeaStore em `experimento-falhas/teastore/stage3-online/resultados/protocolo-metricas-rz/`.

**Bases:** TeaStore, RCAEval e OpenRCA Market. O Eadro SN ficou fora (decisão de 18/10).

## 1. Métodos

| nome | detecção (portão) | localização (ranking) | fontes |
|---|---|---|---|
| **`g-m∨t\|mf`** | métricas (τ pela baseline, FP 0,05) **ou** traces (`d9-b+c@0.01`, λ e q pela baseline) | `m-rzf`: desvio robusto por métrica, normalizado pela baseline por família, com reserva pela família | métricas + traces |
| **`g-m∨t∨k\|mfk`** (novo) | idem **ou** evento K8s de sintoma | `m-rzf` com o serviço K8s promovido ao 1º lugar | métricas + traces + eventos K8s |

Nenhum limiar é igual entre as bases: todos saem da baseline de cada sistema. A única constante de política é a
meta de falso positivo.

## 2. Confirmatórios (leitura fixada antes de rodar: F1@1 ≥ 0,6, F1@2 ≥ 0,7, alarme ≤ 20%)

| parte | dados (nunca vistos pelo método) | método | F1@1 [IC 95%] | F1@2 | alarme | leitura |
|---|---|---|---|---|---|---|
| A | RCAEval RE1-OB/SS/TT, RE2-SS, RE3-SS (480 casos; só métricas) | `g-m∨t\|mf` (= `g-m\|mf`) | 0.614 [0.572–0.654] | 0.704 | 6.6% | ✅ confirma |
| B′ | TeaStore, 17 cenários gravados | `g-m∨t\|mf` | 0.601 [0.374–0.800] | 0.656 | 15.3% | ❌ não confirma |
| H-k2 | TeaStore, os mesmos 17 | **`g-m∨t∨k\|mfk`** | **0.710** [0.489–0.904] | **0.765** | 15.3% | ✅ confirma |
| H-k1 | TeaStore, 41 cenários (pareado) | K8s melhora? | ΔF1@1 **+0.093** [+0.023; +0.187] | — | — | ✅ confirma |

## 3. Comparação com a literatura (AC@1 por caso, serviço; código oficial do RCAEval 1.8.0)

| base | BARO | N-Sigma | **nosso** (1º instante, 120 s de falha) | d9 = d9-k (traces) |
|---|---|---|---|---|
| RCAEval inédito (474) | 0.295 | 0.631 | **0.709** | — |
| RCAEval com traces (240) | 0.404 | 0.754 | **0.783** | 0.354 |
| Market (77) | 0.221 | 0.506 | **0.649** | 0.260 |
| TeaStore B′ (17) | **0.882** | **0.882** | 0.765 (com K8s) | — |
| TeaStore definitiva (24) | 0.833 | **0.875** | 0.625 (com K8s) | — |

O BARO e o N-Sigma recebem o horário da injeção e todo o pós-falha. No RE2-TT, o BARO deu AC@1 0.589 contra 0.67
publicados; o arquivo de métricas pode ser outro.

**Ranking controlado,** com o mesmo portão e o escore do BARO no lugar do `m-rzf`, F1@1:
- RCAEval inédito: 0.284 contra 0.614;
- RCAEval com traces: 0.435 contra 0.688;
- Market: 0.211 contra 0.428;
- TeaStore definitiva: 0.210 contra 0.524.

## 4. Tabela unificada (F1@1 com portão / alarme / AC@1 sabendo)

| modelo | RCAEval inédito (480) | RCAEval com traces (240) | Market (77) | TeaStore B′ (17) | TeaStore definitiva (24) |
|---|---|---|---|---|---|
| **g-m∨t∨k\|mfk** | = g-m∨t (sem K8s) | = g-m∨t | = g-m∨t | **0.710** / 15% / 76% | 0.605 / 7% / 62% |
| **g-m∨t\|mf** | **0.614** / 7% / 70% | **0.688** / 15% / 73% | **0.428** / 17% / 60% | 0.601 / 15% / 65% | 0.524 / 7% / 54% |
| d9-k+a | — | 0.348 / 9% / 38% | 0.166 / 0% / 21% | **0.959** / 1% / 96% | **0.979** / 1% / 98% |
| d9-k | — | 0.308 / 8% / 38% | 0.154 / 0% / 21% | 0.921 / 1% / 96% | 0.887 / 1% / 98% |
| v-cons-b | — | 0.305 / 8% / 37% | 0.152 / 0% / 27% | 0.885 / 1% / 93% | 0.887 / 1% / 98% |
| d2c-r | — | 0.005 / 0% / 11% | 0.017 / 0% / 18% | 0.752 / 0% / 73% | 0.782 / 0% / 77% |

Nas bases abertas, d9-k = d9 e d9-k+a = d9+a, porque não há eventos K8s.

## 5. Robustez (emenda 3; critério registrado: falhar em R1, R3 ou R4 → "não robusta")

| conclusão | R1 baseline (500) | R2 bootstrap P(meta) | R3 permutação (Holm) | R4 placebo | R5 grade | R6 deixa-um-fora | veredito |
|---|---|---|---|---|---|---|---|
| **K-RC**: nosso > d9 e d9+a no RCAEval com traces | 100% | — | p 0,001 | — | 100% | 0 inversões | ✅ **robusta** |
| **K-M**: nosso > d9 no Market | 100% | — | p 0,001 | — | 100% | 0 inversões | ✅ **robusta** |
| nosso > BARO em AC@1 (RCAEval inédito, RCAEval com traces, Market) | — | — | p 0,001 nas três | — | — | — | ✅ **robusta** |
| **K-A**: meta no RCAEval inédito | 86,8% | 55% | — | — | 89% | 10 inversões | ⚠️ **não robusta** (fica no limiar) |
| **K-B**: meta em B′ com K8s | 79,8% | 70% | — | — | 78% | — | ⚠️ **não robusta** |
| **K-k1**: K8s melhora | 100% | — | p 0,130 (não sig.) | ✅ real +0.093 contra placebo −0.106 (p 0,0001) | 100% | inverte sem os cenários g | ⚠️ **não robusta** por R3 |
| TeaStore: d9-k+a > nosso com K8s | — | — | p 0,001 | — | — | — | ✅ robusta (perdemos) |
| TeaStore: BARO > nosso com K8s (AC@1) | — | — | p 0,0495 | — | — | — | ✅ (limítrofe) |
| todos acima do acaso | — | — | — | — | — | — | ✅ em tudo (R8, acima do percentil 99) |
| queda dev → holdout no RCAEval com traces | — | — | — | — | — | — | ⚠️ percentil 96,4 (R7): sinal de ajuste ao dev |

## 6. O que o artigo pode afirmar

1. **Contribuição sólida:** a localização por métricas normalizadas pela baseline (`m-rzf`) supera o BARO e o
   N-Sigma oficiais em AC@1 nas três bases abertas, e supera os métodos de traces no RCAEval e no Market. Isso é
   robusto a baseline, constantes, permutação e acaso.
2. **Eventos K8s ajudam,** com ressalva: no TeaStore, a promoção do serviço com sintoma confirmou H-k1 e H-k2, e o
   placebo mostra que o ganho não vem de embaralhar o ranking. Mas com 41 cenários a permutação não é
   significativa (p = 0,13), e o ganho se concentra nos cenários de memória e OOM, os únicos com evento K8s. A
   afirmação correta é: melhora quando o sintoma existe, com evidência moderada.
3. **A meta absoluta de 0,6** foi atingida em A e em B′ com K8s, mas fica no limiar e não é robusta à escolha da
   baseline. O número não deve ser vendido como garantia.
4. **Limites:**
   - no TeaStore, a d9-k+a (traces + K8s) e o BARO localizam melhor;
   - o alarme fica em 15–17% quando o portão de traces entra;
   - o método é fraco no Train Ticket e em falhas de rede (perda de pacote, atraso);
   - o método foi desenhado no RCAEval, e há sinal de ajuste ao dev (R7);
   - o adaptador do TeaStore foi corrigido depois da 1ª rodada na definitiva.
