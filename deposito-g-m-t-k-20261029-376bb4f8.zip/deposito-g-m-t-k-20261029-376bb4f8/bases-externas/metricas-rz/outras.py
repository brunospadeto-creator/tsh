#!/usr/bin/env python3
"""`g-m∨t|mf` (iteração 5 do `PROTOCOLO.md`) **sem mudança** no Eadro SN e no OpenRCA Market (teste de 10 min/base).

O método é o mesmo código do RCAEval (`ciclo.escores(..., familia=True)`, `ciclo.normalizadores`, `ciclo.tau_gate`,
`ciclo.ranking_rzl`, `ciclo._u`). Muda só o adaptador de cada base:

- **Métricas → colunas `<serviço>_<família>`.** A família é o nome da métrica na base, sem escolha manual:
  - Eadro: `metrics/<serviço>.csv` de cada bloco (1 s; cpu_usage_*, memory_*, rx/tx_bytes). Relógio das métricas
    + 8 h = relógio dos spans (mesmo deslocamento que o adaptador aplica às falhas; conferido nos blocos).
  - Market: `metric_container.csv` (por pod → serviço pelo `servico()` do adaptador; família = `kpi_name`) e
    `metric_service.csv` (família = `<grpc|http>:<kpi>`). 60 s. `metric_runtime` (JVM) e `metric_mesh` (istio)
    ficam fora: não existem para todos os serviços.
- **Baseline (sem gabarito):** o trecho que já é a baseline do v-cons-b em cada base (Eadro: 1º bloco "no fault",
  24 min; Market: 30 min por cloudbed), em janelas como as dos instantes (`calib.janelas_normais`). Dela saem o λ
  e o q do portão de traces (`calib.calibrar`), o normalizador `N` por família e o τ do `g-m`.
- **Instantes:** os registros do `../d9a/` (mesmos instantes da d9, d9+a, d9-k, v-cons-b, d2c-r).
  Referência das métricas = a mesma regra do RCAEval: falha → o pré-falha do caso; normal → `[t − 720, t − 120)`.

Uso: python outras.py --base eadro|openrca-market [--jobs 24]
"""
from __future__ import annotations

import argparse
import datetime
import glob
import json
import os
import pickle
import sys
import time
import warnings
from collections import Counter, defaultdict
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
sys.path[:0] = [RAIZ, os.path.join(RAIZ, "baseline-dinamica"), AQUI]

from comum import DADOS_ORIGEM, DADOS_SAIDA, execucao, metodos as M  # noqa: E402

import calib  # noqa: E402  (depois do `comum`, que põe a raiz do repositório no path)
import ciclo as CI  # noqa: E402

CACHE = os.path.join(DADOS_SAIDA, "metricas-rz")
NOMES = {"eadro": "Eadro SN", "openrca-market": "OpenRCA Market"}
FPS = (0.05, 0.01)
DESLOC_EADRO = 8 * 3600
_G: dict[str, Any] = {}   # eventos da baseline para os processos filhos (fork)


def _ad(base: str) -> Any:
    return execucao._modulo(os.path.join(RAIZ, base, "adaptar.py"))


def _ts(t: str) -> float:
    return datetime.datetime.fromisoformat(t).replace(tzinfo=datetime.UTC).timestamp()


# ---------------------------------------------------------------- baseline: janelas, portão de traces

def _baselines(base: str) -> dict[str, dict[str, Any]]:
    """`{grupo: entrada do plano}` do trecho de baseline do v-cons-b."""
    plano = _ad(base).casos()
    out = {}
    for k, v in plano.items():
        if v.get("baseline"):
            out[v.get("sis") or v.get("cb")] = {"id": k, **v}
    return {g: v for g, v in out.items() if base != "eadro" or g == "SN"}


def _eventos_baseline(base: str, b: dict[str, Any]) -> tuple[list[Any], dict[str, Any]]:
    ad = _ad(base)
    if base == "eadro":
        ev = ad.ler_eventos(b["spans"], b["sis"], b["ini"], b["fim"])
        ev = [e for e in ev if b["ini"] <= int(e.start_us) < b["fim"]]
        return ev, ad.SISTEMAS[b["sis"]]
    return ad.ler_eventos(b["id"]), ad.SISTEMA


def _medir(i: int) -> dict[str, Any]:
    from comum import rapido  # noqa: PLC0415
    rapido.ativar()
    rapido.limpar()
    return calib.medir(_G["janelas"][i], _G["sis"], M.PORTAO_D9)


def baseline_traces(base: str, jobs: int) -> dict[str, dict[str, Any]]:
    """`{grupo: {"t": [instantes], "janelas": [medidas]}}` (cache em disco)."""
    destino = os.path.join(CACHE, f"{base}-baseline-traces.json")
    if os.path.exists(destino):
        with open(destino) as f:
            return json.load(f)
    from multiprocessing import get_context  # noqa: PLC0415
    out = {}
    for g, b in _baselines(base).items():
        t0 = time.monotonic()
        ev, sistema = _eventos_baseline(base, b)
        sis = M.cfg_sistema(sistema)
        jan = list(calib.janelas_normais(ev, sistema["entry_services"]))
        _G.update(janelas=jan, sis=sis)
        with get_context("fork").Pool(min(jobs, len(jan))) as p:
            med = p.map(_medir, range(len(jan)))
        ts = [j.abertura_incidente.replace(tzinfo=datetime.UTC).timestamp() for j in jan]
        out[g] = {"t": ts, "janelas": med}
        print(f"baseline {g}: {len(jan)} janelas em {time.monotonic() - t0:.0f}s", flush=True)
    os.makedirs(CACHE, exist_ok=True)
    with open(destino + ".tmp", "w") as f:
        json.dump(out, f, default=str)
    os.replace(destino + ".tmp", destino)
    return out


# ---------------------------------------------------------------- métricas → (tempo, valores, colunas)

def _wide(partes: list[tuple[str, str, pd.Series]]) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """`[(serviço, família, série indexada por tempo)]` → matriz; coluna = `<serviço>_f<i>` (família codificada sem
    `_`, para o `rsplit("_", 1)` do `ciclo.escores` funcionar com qualquer nome de métrica)."""
    fams = sorted({f for _, f, _ in partes})
    cod = {f: f"f{i}" for i, f in enumerate(fams)}
    df = pd.concat([s.rename(i) for i, (_, _, s) in enumerate(partes)], axis=1).sort_index()
    cols = [f"{svc}_{cod[f]}" for svc, f, _ in partes]
    return df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), cols


def series_eadro(pasta_bloco: str) -> tuple[np.ndarray, np.ndarray, list[str]]:
    partes = []
    for arq in sorted(glob.glob(os.path.join(pasta_bloco, "metrics", "*.csv"))):
        df = pd.read_csv(arq)
        df = df.groupby("timestamp").mean()
        df.index = df.index + DESLOC_EADRO
        svc = _ad("eadro").servico("SN", os.path.basename(arq)[:-4])
        partes += [(svc, c, pd.to_numeric(df[c], errors="coerce")) for c in df.columns]
    return _wide(partes)


def series_market(cb: str, dia: str) -> tuple[np.ndarray, np.ndarray, list[str]]:
    destino = os.path.join(CACHE, f"market-{cb}-{dia}.pkl")
    if os.path.exists(destino):
        with open(destino, "rb") as f:
            return pickle.load(f)
    ad = _ad("openrca-market")
    pasta = os.path.join(DADOS_ORIGEM, "OpenRCA", "dataset", "Market", cb, "telemetry", dia, "metric")
    partes = []
    c = pd.read_csv(os.path.join(pasta, "metric_container.csv"))
    c = c.pivot_table(index="timestamp", columns=["cmdb_id", "kpi_name"], values="value", aggfunc="mean")
    for (pod, kpi), s in c.items():
        partes.append((ad.servico(pod.split(".", 1)[-1]), kpi, s))
    sv = pd.read_csv(os.path.join(pasta, "metric_service.csv"))
    sv = sv.groupby(["service", "timestamp"]).mean(numeric_only=True)
    for nome, d in sv.groupby(level=0):
        svc, proto = nome.rsplit("-", 1)
        d = d.droplevel(0)
        partes += [(ad.servico(svc), f"{proto}:{k}", d[k]) for k in ("rr", "sr", "mrt", "count")]
    out = _wide(partes)
    os.makedirs(CACHE, exist_ok=True)
    with open(destino + ".tmp", "wb") as f:
        pickle.dump(out, f)
    os.replace(destino + ".tmp", destino)
    return out


def _fonte(base: str, v: dict[str, Any]) -> tuple[str, Any]:
    """Chave e leitor da série de um caso do plano."""
    if base == "eadro":
        pasta = os.path.dirname(v["spans"])
        return pasta, lambda: series_eadro(pasta)
    return f"{v['cb']}/{v['dia']}", lambda: series_market(v["cb"], v["dia"])


def _escore(item: tuple[float, tuple[float, float]]) -> dict[str, dict[str, float]]:
    warnings.simplefilter("ignore", RuntimeWarning)
    tempo, val, cols = _G["serie"]
    return CI.escores(tempo, val, cols, item[0], item[1], familia=True)


def escores_todos(base: str, linhas: list[dict[str, Any]],
                  bt: dict[str, dict[str, Any]], jobs: int = 24) -> dict[tuple[str, str], dict[str, dict[str, float]]]:
    """Escores `m-rzf` (guarda por família) dos instantes dos casos e das janelas da baseline (cache em disco)."""
    destino = os.path.join(CACHE, f"{base}-escores-familia.pkl")
    if os.path.exists(destino):
        with open(destino, "rb") as f:
            return pickle.load(f)
    plano = _ad(base).casos()
    us = 1_000_000 if base == "eadro" else 1
    pedidos: dict[str, tuple[Any, list[tuple[tuple[str, str], float, tuple[float, float]]]]] = {}
    for x in linhas:
        v = plano[x["caso"]]
        chave, leitor = _fonte(base, v)
        t = _ts(x["t"])
        ref = (v["pre"][0] / us, v["pre"][1] / us) if x["periodo"] == "falha" else \
            (t - CI.JANELA - CI.REF, t - CI.JANELA)
        pedidos.setdefault(chave, (leitor, []))[1].append(((x["caso"], x["t"]), t, ref))
    for g, b in _baselines(base).items():
        chave, leitor = _fonte(base, plano[b["id"]])
        for t in bt[g]["t"]:
            pedidos.setdefault(chave, (leitor, []))[1].append(((f"baseline/{g}", str(t)), t,
                                                               (t - CI.JANELA - CI.REF, t - CI.JANELA)))
    out = {}
    from multiprocessing import get_context  # noqa: PLC0415
    for chave, (leitor, itens) in pedidos.items():
        _G["serie"] = leitor()
        with get_context("fork").Pool(jobs) as p:
            res = p.map(_escore, [(t, ref) for _, t, ref in itens], chunksize=4)
        out.update({k: r for (k, _, _), r in zip(itens, res, strict=True)})
        print(f"métricas {chave}: {len(itens)} instantes", flush=True)
    with open(destino + ".tmp", "wb") as f:
        pickle.dump(out, f)
    os.replace(destino + ".tmp", destino)
    return out


# ---------------------------------------------------------------- decisões e tabela

MODOS = ("d9", "d9+a", "d9-b+c@0.01", "m-rzf", "g-m|mf", "g-m∨t|mf", "g-m∧t|mf")


def analisar(base: str, jobs: int) -> str:
    warnings.simplefilter("ignore", RuntimeWarning)
    D = CI._d9a()  # noqa: N806
    D.METODOS = MODOS
    linhas = D.carregar(base)
    bt = baseline_traces(base, jobs)
    cals = {fp: {g: calib.calibrar(b["janelas"], fp) for g, b in bt.items()} for fp in FPS}
    es = escores_todos(base, linhas, bt, jobs)
    pseudo = [{"periodo": "normal", "na_baseline": True, "grupo": g, "caso": f"baseline/{g}", "t": str(t)}
              for g, b in bt.items() for t in b["t"]]
    norm = CI.normalizadores(pseudo, es)
    tau = CI.tau_gate(pseudo, es, norm)
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in MODOS}
    for x in linhas:
        g = x["grupo"]
        d1 = CI.BD.decisoes(x, cals[0.01][g], None, Counter())
        d0 = D.decisoes(x)
        e = es.get((x["caso"], x["t"]), {})
        rk = CI.ranking_rzl(e, norm.get(g, {}))
        gm = max(CI._u(e, norm.get(g, {})).values(), default=0.0) >= tau[g]
        gt = d1["d9-b+c"]["dec"]
        ds = {"d9": d0["d9"], "d9+a": d0["d9+a"], "d9-b+c@0.01": d1["d9-b+c"],
              "m-rzf": {"dec": bool(rk), "rk": rk, "f": rk},
              "g-m|mf": {"dec": gm and bool(rk), "rk": rk if gm else [], "f": rk},
              "g-m∨t|mf": {"dec": gm or gt, "rk": rk if (gm or gt) else [], "f": rk},
              "g-m∧t|mf": {"dec": gm and gt, "rk": rk if (gm and gt) else [], "f": rk}}
        esp = x["gabarito"]
        for m, d in ds.items():
            c = pc[m][x["caso"]]
            if x["periodo"] == "normal":
                c["nn"] += 1
                c["al"] += d["dec"]
            elif esp:
                c["ne"] += 1
                c["dec"] += d["dec"]
                for k in (1, 2):
                    c[f"tp{k}"] += d["dec"] and esp in d["rk"][:k]
                    c[f"o{k}"] += esp in d["f"][:k]
    casos = sorted({x["caso"] for x in linhas})
    out = [f"# `g-m∨t|mf` sem mudança — {NOMES[base]} (teste de 10 min, exploratório)", "",
           "`outras.py` / `PROTOCOLO.md` §Generalização. Mesmo código do RCAEval; só o adaptador de métricas é da base. "
           "Todos os instantes dos registros do `../d9a/` (fora a sombra). Sem K8s: d9 = d9-k.", "",
           "| grupo | janelas da baseline | λ (FP 0,01) | q d2c-b (FP 0,01) | famílias com N | τ do g-m |",
           "|---|---|---|---|---|---|"]
    out += [f"| {g} | {cals[0.01][g]['n_janelas']} | {cals[0.01][g]['lambda']:.3f} | "
            f"{cals[0.01][g]['q_d2cb']:.2e} | {sum(1 for v in norm.get(g, {}).values() if v > 0)} | {tau[g]:.3f} |"
            for g in sorted(bt)]
    out += ["", *D.tabela(pc, casos), ""]
    for a, b in (("g-m∨t|mf", "d9"), ("g-m∨t|mf", "d9-b+c@0.01"), ("g-m|mf", "d9")):
        d, lo, hi = D.diferenca(pc, casos, a, b)
        out.append(f"- ΔF1@1 {a} − {b} = {d:+.3f} [IC 95% {lo:+.3f} a {hi:+.3f}]")
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, f"resultado-{base}.md"), "w") as f:
        f.write(texto)
    return texto


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", choices=tuple(NOMES), required=True)
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    print(analisar(args.base, args.jobs))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
