#!/usr/bin/env python3
"""Custo de execução do método por instante (análise adicional, pedida pelos revisores simulados; fora do protocolo).

Mede, num único processo e sem paralelismo, o tempo de cada decisão do HMR depois que os dados do instante já estão
na memória (a leitura dos arquivos fica de fora, porque em operação as séries chegam do coletor):

- **parte de métricas** (Escore de Desvio por Família, normalização pela baseline, Portão de Métricas e ordenação):
  `ciclo.escores(..., familia=True)` + `emenda2.ordem_completa`, em todos os instantes de uma amostra estratificada
  de casos do RCAEval inédito (por suíte) e do RCAEval com rastros;
- **parte de rastros** (Portão de Rastros: contraste da sessão e, quando ele se abstém, os testes da composição das
  chamadas): `d5.medir` + `d9.contexto` + `d2cr.decidir`, a mesma sequência do `pre-teste/extrair.py`, numa amostra
  de casos do RCAEval com rastros.

Registra também o número de colunas, de famílias e de rastros por janela, a memória máxima do processo e o
processador. Uso: `custo.py [--n 4] [--n-rastros 4]` → `resultado-custo.md`.
"""
from __future__ import annotations

import argparse
import os
import platform
import random
import resource
import statistics
import subprocess
import sys
import time
import warnings
from collections import defaultdict

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ_BE = os.path.dirname(AQUI)
sys.path[:0] = [AQUI, RAIZ_BE, os.path.dirname(RAIZ_BE)]

import confirmatorio_a as CA  # noqa: E402
import emenda2 as E2  # noqa: E402
import outras as O  # noqa: E402

CI = O.CI
MAX_INST = 12   # instantes medidos por caso na parte de rastros (o tempo por instante não depende de quantos)


def _cpu() -> str:
    try:
        for linha in subprocess.run(["lscpu"], capture_output=True, text=True).stdout.splitlines():
            if linha.startswith("Model name"):
                return linha.split(":", 1)[1].strip()
    except Exception:  # noqa: BLE001
        pass
    return platform.processor() or "desconhecido"


def _quantis(v: list[float]) -> str:
    a = np.array(v) * 1000
    return f"{np.median(a):.1f} | {np.percentile(a, 95):.1f} | {a.max():.1f}"


def metricas_a(n: int) -> list[str]:
    cs = CA.casos()
    teste = CA.sorteio_teste(cs)
    rnd = random.Random(20261024)
    linhas = []
    for s in CA.SUITES:
        lista = sorted(c for c in cs[s] if f"{s}/{c}" not in teste)
        tempos, ncol, nfam = [], [], []
        for c in rnd.sample(lista, min(n, len(lista))):
            tempo, val, cols, inj = CA.ler(s, c)
            ini = float(tempo[0])
            ncol.append(len(cols))
            nfam.append(len({col.rsplit("_", 1)[1] for col in cols}))
            for periodo, t in CA.instantes(tempo, inj):
                ref = (max(ini, inj - CI.REF), inj) if periodo == "falha" else (max(ini, t - CI.JANELA - CI.REF),
                                                                                  t - CI.JANELA)
                t0 = time.perf_counter()
                f = CI.escores(tempo, val, cols, t, ref, familia=True)
                E2.ordem_completa(f, {})
                tempos.append(time.perf_counter() - t0)
        linhas.append(f"| RCAEval inédito, {s} | {len(tempos)} | {statistics.median(ncol):.0f} | "
                      f"{statistics.median(nfam):.0f} | {_quantis(tempos)} |")
    return linhas


def metricas_c(n: int) -> list[str]:
    import ciclo  # noqa: PLC0415
    casos = sorted(ciclo.casos_rcaeval() if hasattr(ciclo, "casos_rcaeval") else [])
    if not casos:
        u = __import__("robustez").unidade_c(4)
        casos = sorted({x["caso"] for x in u["inst"]})
    rnd = random.Random(20261024)
    grupos = defaultdict(list)
    for c in casos:
        grupos[c.split("/")[0]].append(c)
    tempos, ncol, nfam = [], [], []
    for g in sorted(grupos):
        for c in rnd.sample(grupos[g], min(n, len(grupos[g]))):
            df, inj = CI._serie(c)
            tempo, val, cols = df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns)
            ncol.append(len(cols))
            nfam.append(len({col.rsplit("_", 1)[1] for col in cols}))
            ini = float(tempo[0])
            for k in range(1, 9):
                t = inj + 60 * k
                ref = (max(ini, inj - CI.REF), inj)
                t0 = time.perf_counter()
                f = CI.escores(tempo, val, cols, t, ref, familia=True)
                E2.ordem_completa(f, {})
                tempos.append(time.perf_counter() - t0)
    return [f"| RCAEval com rastros (RE2, RE3) | {len(tempos)} | {statistics.median(ncol):.0f} | "
            f"{statistics.median(nfam):.0f} | {_quantis(tempos)} |"]


def rastros(n: int) -> list[str]:
    from comum import execucao, instantes as I, metodos as M, rapido  # noqa: PLC0415
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    from src.application.stage3.abordagens import d5_portao as d5  # noqa: PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    from src.application.stage3.abordagens import referencia  # noqa: PLC0415
    mod = execucao._modulo(os.path.join(RAIZ_BE, "rcaeval", "adaptar.py"))
    ids = sorted(mod.listar())
    rnd = random.Random(20261024)
    grupos = defaultdict(list)
    for i in ids:
        grupos[i.split("/")[0]].append(i)
    amostra = [c for g in sorted(grupos) for c in rnd.sample(grupos[g], min(n, len(grupos[g])))]
    tempos, ntr = [], []
    for cid in amostra:
        caso = mod.carregar(cid)
        if caso is None:
            continue
        sis = M.cfg_sistema(caso.sistema)
        cfg9 = d9._cfg({**sis, **M.PORTAO_D9})
        rapido.ativar()
        for k, (_periodo, _t, ent, nt) in enumerate(I.entradas(caso, I.REF)):
            if k >= MAX_INST:
                break
            rapido.limpar()
            t0 = time.perf_counter()
            raiz = d5._entradas(ent, cfg9)
            ev_ref = d5._eventos_ref(ent, cfg9)
            inc = referencia.estatisticas(ent.traces, servicos_raiz=raiz)
            ref = referencia.estatisticas(ev_ref, servicos_raiz=raiz)
            d5.medir(inc, ref, cfg9)
            d9.contexto(list(ent.traces), ev_ref, ref, cfg9)
            try:
                d2cr.decidir(ent, {}, {**sis, "q": 1.0})
            except Exception:  # noqa: BLE001
                pass
            tempos.append(time.perf_counter() - t0)
            ntr.append(nt)
    return [f"| RCAEval com rastros (RE2, RE3), {len(amostra)} casos | {len(tempos)} | "
            f"{statistics.median(ntr):.0f} (máx. {max(ntr)}) | {_quantis(tempos)} |"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=4, help="casos por suíte na parte de métricas")
    ap.add_argument("--n-rastros", type=int, default=4, help="casos por suíte na parte de rastros")
    a = ap.parse_args()
    warnings.simplefilter("ignore")
    t0 = time.time()
    m_a = metricas_a(a.n)
    print("métricas A:", *m_a, sep="\n", flush=True)
    m_c = metricas_c(a.n)
    print("métricas C:", *m_c, sep="\n", flush=True)
    r = rastros(a.n_rastros)
    print("rastros:", *r, sep="\n", flush=True)
    mem = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    out = ["# Custo de execução do método por instante (análise adicional, fora do protocolo)", "",
           f"`custo.py --n {a.n} --n-rastros {a.n_rastros}`. Um processo, sem paralelismo; processador: {_cpu()}; "
           f"Python {platform.python_version()}. Tempo de cada decisão com os dados do instante já na memória (a "
           "leitura dos arquivos fica de fora). Memória máxima do processo durante toda a medição: "
           f"{mem:.0f} MB. Duração total: {time.time() - t0:.0f} s.", "",
           "## Parte de métricas (escore por família, normalização, Portão de Métricas e ordenação)", "",
           "| conjunto | instantes | colunas (mediana) | famílias (mediana) | ms por instante: mediana \\| p95 \\| máx. |",
           "|---|---|---|---|---|", *m_a, *m_c, "",
           "## Parte de rastros (Portão de Rastros: contraste da sessão e testes da composição)", "",
           "| conjunto | instantes | rastros por janela (mediana) | ms por instante: mediana \\| p95 \\| máx. |",
           "|---|---|---|---|", *r, "",
           "Complexidade por instante: na parte de métricas, mediana e quartis de cada coluna na janela e na "
           "referência, ou O(C · n log n) para C colunas e n amostras, mais O(C) para as famílias e a ordenação; na "
           "parte de rastros, linear no número de spans da janela e da referência, mais um teste por atividade e por "
           "relação de chamada."]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-custo.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
