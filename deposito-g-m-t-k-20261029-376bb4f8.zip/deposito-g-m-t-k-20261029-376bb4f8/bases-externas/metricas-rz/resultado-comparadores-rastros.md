# MicroRank e TraceRCA oficiais nos mesmos casos com rastros (pós-hoc, fora do protocolo)

`comparadores_rastros.py`. RCAEval 1.8.0; spans do caso e horário da injeção; semente 0; no máximo 900 s por caso. Ranking vazio conta como erro. O nosso método: 1º instante de falha, ordem completa (como na Tabela de comparação com a literatura).

## AC@1 / AC@3 / Avg@5 por caso, no nível de serviço

| conjunto | casos | nosso | BARO | N-Sigma | MicroRank | TraceRCA | vazios MicroRank | vazios TraceRCA |
|---|---|---|---|---|---|---|---|---|
| RCAEval-C | 239 | 0.782 / 0.950 / 0.916 | 0.406 / 0.858 / 0.776 | 0.753 / 0.883 / 0.864 | 0.146 / 0.402 / 0.347 | 0.381 / 0.665 / 0.640 | 0 | 0 |
| Market | 77 | 0.649 / 0.883 / 0.857 | 0.221 / 0.636 / 0.579 | 0.506 / 0.714 / 0.678 | 0.117 / 0.260 / 0.262 | 0.195 / 0.545 / 0.491 | 0 | 0 |

## Permutação pareada em AC@1 (10.000; Holm sobre 25 = R3 + 3 do N-Sigma + 6 do CIRCA e do RCD + 4)

| conjunto | comparação | Δ AC@1 | p | p Holm |
|---|---|---|---|---|
| RCAEval-C | nosso − MicroRank | +0.636 | 0.0001 | 0.0025 |
| RCAEval-C | nosso − TraceRCA | +0.402 | 0.0001 | 0.0025 |
| Market | nosso − MicroRank | +0.532 | 0.0001 | 0.0025 |
| Market | nosso − TraceRCA | +0.455 | 0.0001 | 0.0025 |

Holm sobre todas, nas comparações anteriores (p bruto → p Holm):

- R3 A F1@1: g-m∨t|mf − m-rz|g-m: 0.0001 → 0.0025
- R3 A F1@1: g-m∨t|mf − cpu-max|g-m: 0.0001 → 0.0025
- R3 A AC@1 por caso: g-m∨t|mf (1º instante) − BARO oficial: 0.0001 → 0.0025
- R3 RCAEval-C F1@1: g-m∨t|mf − d9 (= d9-k): 0.0001 → 0.0025
- R3 RCAEval-C F1@1: g-m∨t|mf − d9+a (= d9-k+a): 0.0001 → 0.0025
- R3 RCAEval-C AC@1 por caso: g-m∨t|mf (1º instante) − BARO oficial: 0.0001 → 0.0025
- R3 Market F1@1: g-m∨t|mf − d9 (= d9-k): 0.0001 → 0.0025
- R3 Market AC@1 por caso: g-m∨t|mf (1º instante) − BARO oficial: 0.0001 → 0.0025
- R3 TeaStore F1@1: g-m∨t∨k|mfk − g-m∨t|mf: 0.1222 → 0.2444
- R3 TeaStore F1@1: g-m∨t∨k|mfk − d9-k+a: 0.0001 → 0.0025
- R3 TeaStore AC@1 por caso: g-m∨t∨k|mfk (1º instante) − BARO oficial: 0.0165 → 0.0825
- R3 TeaStore F1@1: d9-k − d9: 0.0343 → 0.1372
- N-Sigma A: 0.0050 → 0.0300
- N-Sigma RCAEval-C: 0.4280 → 0.4280
- N-Sigma Market: 0.0592 → 0.1776
- A CIRCA: 0.0001 → 0.0025
- A RCD: 0.0001 → 0.0025
- RCAEval-C CIRCA: 0.0001 → 0.0025
- RCAEval-C RCD: 0.0001 → 0.0025
- Market CIRCA: 0.0001 → 0.0025
- Market RCD: 0.0001 → 0.0025

## Só os casos em que o método terminou (o nosso, nos mesmos casos; Holm sobre estas 4)

| conjunto | método | casos | AC@1 nosso / método | AC@3 nosso / método | Δ AC@1 | p | p Holm |
|---|---|---|---|---|---|---|---|
| RCAEval-C | MicroRank | 239 de 239 | 0.782 / 0.146 | 0.950 / 0.402 | +0.636 | 0.0001 | 0.0004 |
| RCAEval-C | TraceRCA | 239 de 239 | 0.782 / 0.381 | 0.950 / 0.665 | +0.402 | 0.0001 | 0.0004 |
| Market | MicroRank | 77 de 77 | 0.649 / 0.117 | 0.883 / 0.260 | +0.532 | 0.0001 | 0.0004 |
| Market | TraceRCA | 77 de 77 | 0.649 / 0.195 | 0.883 / 0.545 | +0.455 | 0.0001 | 0.0004 |

## Sem os casos filtrados (sensibilidade)

| conjunto | método | casos | AC@1 nosso / método |
|---|---|---|---|
| RCAEval-C | MicroRank | 190 de 239 | 0.789 / 0.058 |
| RCAEval-C | TraceRCA | 190 de 239 | 0.789 / 0.305 |
| Market | MicroRank | 74 de 77 | 0.649 / 0.108 |
| Market | TraceRCA | 74 de 77 | 0.649 / 0.189 |

## Falhas e tempo por suíte

| método | suíte | falhas | filtrados | casos | tempo mediano (s) | tempo máximo (s) |
|---|---|---|---|---|---|---|
| MicroRank | Market | 0 | 3 | 77 | 59 | 93 |
| MicroRank | RE2-OB | 0 | 0 | 89 | 295 | 385 |
| MicroRank | RE2-TT | 0 | 17 | 90 | 194 | 355 |
| MicroRank | RE3-OB | 0 | 2 | 30 | 62 | 81 |
| MicroRank | RE3-TT | 0 | 30 | 30 | 41 | 55 |
| TraceRCA | Market | 0 | 3 | 77 | 2 | 21 |
| TraceRCA | RE2-OB | 0 | 0 | 89 | 5 | 65 |
| TraceRCA | RE2-TT | 0 | 17 | 90 | 13 | 34 |
| TraceRCA | RE3-OB | 0 | 2 | 30 | 2 | 24 |
| TraceRCA | RE3-TT | 0 | 30 | 30 | 6 | 23 |

## Casos em que o serviço da causa não tem nenhum span na entrada

Nesses casos nenhum método de rastros pode pôr a causa no ranking.

| suíte | casos | sem span da causa | casos sem span (serviço) |
|---|---|---|---|
| Market | 77 | 0 | — |
| RE2-OB | 89 | 0 | — |
| RE2-TT | 90 | 0 | — |
| RE3-OB | 30 | 12 | RE3-OB/adservice_f3/1 (adservice), RE3-OB/adservice_f3/2 (adservice), RE3-OB/adservice_f3/3 (adservice), RE3-OB/adservice_f4/1 (adservice), RE3-OB/adservice_f4/2 (adservice), RE3-OB/adservice_f4/3 (adservice), RE3-OB/adservice_f5/1 (adservice), RE3-OB/adservice_f5/2 (adservice), RE3-OB/adservice_f5/3 (adservice), RE3-OB/cartservice_f1/1 (cartservice), RE3-OB/cartservice_f1/2 (cartservice), RE3-OB/cartservice_f1/3 (cartservice) |
| RE3-TT | 30 | 0 | — |

## Motivos das falhas

- nenhuma
