#!/usr/bin/env python3
"""Parte A do `PROTOCOLO-COMPLETO.md`: `g-m∨t|mf` no RCAEval inédito, só métricas (RE1-OB/SS/TT, RE2-SS, RE3-SS).

Só código de entrada: leitura, instantes, sorteio da baseline e dos casos de teste. As regras de decisão e de
ranking são as do `ciclo.py` congelado (`escores(familia=True)`, `normalizadores`, `tau_gate`, `ranking_rzl`, `_u`).
Sem traces, o canal `t` nunca abre e `g-m∨t|mf` = `g-m|mf` (§2).

- `--teste`: os 15 casos da rodada de teste (§5). Imprime só as checagens, **sem F1**.
- sem opção: rodada oficial, sem os 15 casos de teste → `resultado-confirmatorio-A.md`.

Os casos de teste saem de tudo na rodada oficial: da baseline e da medida. A baseline é sorteada entre os demais.
Uso: python confirmatorio_a.py [--teste] [--jobs 24]
"""
from __future__ import annotations

import argparse
import glob
import os
import random
import sys
import warnings
from collections import Counter, defaultdict
from typing import Any

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import ciclo as CI  # noqa: E402

from comum import DADOS_ORIGEM  # noqa: E402

ORIGEM = os.path.join(DADOS_ORIGEM, "RCAEval")
SUITES = ("RE1-OB", "RE1-SS", "RE1-TT", "RE2-SS", "RE3-SS")
INICIO_NORMAL, PASSO, TETO_FALHA = 270, 60, 600
MIN_JANELAS_BASE, MIN_CASOS_BASE = 20, 5
MODOS = ("g-m∨t|mf", "m-rzf", "m-rz|g-m", "cpu-max|g-m")


def casos() -> dict[str, list[str]]:
    return {s: sorted(os.path.relpath(p, os.path.join(ORIGEM, s, s)).rstrip("/")
                      for p in glob.glob(os.path.join(ORIGEM, s, s, "*", "*", "")))
            for s in SUITES}


def gabarito(caso: str) -> tuple[str, str]:
    svc, tipo = caso.split("/")[0].rsplit("_", 1)
    return svc, tipo


def sorteio_teste(cs: dict[str, list[str]]) -> set[str]:
    rnd = random.Random("20261019-teste")
    return {f"{s}/{c}" for s in SUITES for c in rnd.sample(cs[s], 3)}


def ler(suite: str, caso: str) -> tuple[np.ndarray, np.ndarray, list[str], float]:
    pasta = os.path.join(ORIGEM, suite, suite, caso)
    arq = os.path.join(pasta, "data.csv")
    if not os.path.exists(arq):
        arq = os.path.join(pasta, "simple_metrics.csv")
    df = pd.read_csv(arq).set_index("time").sort_index()
    df = df[[c for c in df.columns if "_" in str(c)]].apply(pd.to_numeric, errors="coerce")
    with open(os.path.join(pasta, "inject_time.txt")) as f:
        inj = float(f.read().strip())
    return df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), [str(c) for c in df.columns], inj


def instantes(tempo: np.ndarray, inj: float) -> list[tuple[str, float]]:
    ini, fim = float(tempo[0]), float(tempo[-1])
    out, t = [], ini + INICIO_NORMAL
    while t <= inj:
        out.append(("normal", t))
        t += PASSO
    t = inj + 120
    while t <= min(fim, inj + TETO_FALHA):
        out.append(("falha", t))
        t += PASSO
    return out


def rodar_caso(job: tuple[str, str]) -> dict[str, Any]:
    """Escores `m-rzf` (guarda por família) e `m-rz` (guarda antiga) de cada instante do caso."""
    warnings.simplefilter("ignore", RuntimeWarning)
    suite, caso = job
    tempo, val, cols, inj = ler(suite, caso)
    ini = float(tempo[0])
    out = []
    for periodo, t in instantes(tempo, inj):
        ref = (max(ini, inj - CI.REF), inj) if periodo == "falha" else (max(ini, t - CI.JANELA - CI.REF), t - CI.JANELA)
        out.append({"periodo": periodo, "t": t,
                    "f": CI.escores(tempo, val, cols, t, ref, familia=True),
                    "z": CI.escores(tempo, val, cols, t, ref, familia=False)})
    svcs = {c.rsplit("_", 1)[0] for c in cols}
    fin = float(np.isfinite(val).mean()) if val.size else 0.0
    return {"suite": suite, "caso": caso, "inst": out, "svcs": svcs, "finito": fin}


def baseline(res: dict[str, dict[str, Any]], suite: str, excluir: set[str]) -> set[str]:
    """Casos sorteados (`20261019-<suíte>`) na ordem, até ≥ 20 janelas normais e ≥ 5 casos."""
    cs = sorted(c for c in res if res[c]["suite"] == suite and c not in excluir)
    random.Random(f"20261019-{suite}").shuffle(cs)
    escolhidos, n = [], 0
    for c in cs:
        escolhidos.append(c)
        n += sum(1 for x in res[c]["inst"] if x["periodo"] == "normal")
        if n >= MIN_JANELAS_BASE and len(escolhidos) >= MIN_CASOS_BASE:
            break
    return set(escolhidos)


def calibrar(res: dict[str, dict[str, Any]], base: dict[str, set[str]]) -> tuple[dict, dict, dict[str, int]]:
    pseudo, es = [], {}
    for s, cs in base.items():
        for c in cs:
            for x in res[c]["inst"]:
                if x["periodo"] == "normal":
                    pseudo.append({"periodo": "normal", "na_baseline": True, "grupo": s, "caso": c, "t": x["t"]})
                    es[(c, x["t"])] = x["f"]
    norm = CI.normalizadores(pseudo, es)
    tau = CI.tau_gate(pseudo, es, norm)
    return norm, tau, Counter(p["grupo"] for p in pseudo)


def _cpu(z: dict[str, dict[str, float]]) -> list[str]:
    return CI.ordenar({s: f["cpu"] for s, f in z.items() if "cpu" in f})


def por_caso(res: dict[str, dict[str, Any]], base: dict[str, set[str]], norm: dict, tau: dict
             ) -> dict[str, dict[str, Counter]]:
    pc: dict[str, dict[str, Counter]] = {m: defaultdict(Counter) for m in MODOS}
    na_base = set().union(*base.values())
    for c, r in res.items():
        s = r["suite"]
        esp = gabarito(c.split("/", 1)[1])[0]
        for x in r["inst"]:
            if x["periodo"] == "normal" and c in na_base:
                continue
            rk = CI.ranking_rzl(x["f"], norm.get(s, {}))
            gm = max(CI._u(x["f"], norm.get(s, {})).values(), default=0.0) >= tau[s]
            rz, rc = CI.ranking_rz(x["z"]), _cpu(x["f"])
            ds = {"g-m∨t|mf": (gm and bool(rk), rk), "m-rzf": (bool(rk), rk),
                  "m-rz|g-m": (gm and bool(rz), rz), "cpu-max|g-m": (gm and bool(rc), rc)}
            for m, (dec, lst) in ds.items():
                k = pc[m][c]
                if x["periodo"] == "normal":
                    k["nn"] += 1
                    k["al"] += dec
                else:
                    k["ne"] += 1
                    k["dec"] += dec
                    for j in (1, 2):
                        k[f"tp{j}"] += dec and esp in lst[:j]
                        k[f"o{j}"] += esp in lst[:j]
    return pc


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--teste", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    cs = casos()
    teste = sorteio_teste(cs)
    if args.teste:
        jobs = sorted(tuple(c.split("/", 1)) for c in teste)
    else:
        jobs = [(s, c) for s in SUITES for c in cs[s] if f"{s}/{c}" not in teste]
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(args.jobs) as ex:
        res = {f"{r['suite']}/{r['caso']}": r for r in ex.map(rodar_caso, jobs, chunksize=2)}
    if args.teste:   # checagens da rodada de teste (§5): sem F1
        base = {s: baseline(res, s, set()) for s in SUITES}
        norm, tau, nj = calibrar(res, base)
        print("| caso | normais | falha | serviços | gabarito nas colunas | fração finita | escores vazios |")
        print("|---|---|---|---|---|---|---|")
        for c, r in sorted(res.items()):
            esp = gabarito(r["caso"])[0]
            p = Counter(x["periodo"] for x in r["inst"])
            vaz = sum(1 for x in r["inst"] if not x["f"])
            print(f"| {c} | {p['normal']} | {p['falha']} | {len(r['svcs'])} | {'sim' if esp in r['svcs'] else '**NÃO**'} "
                  f"| {r['finito']:.3f} | {vaz} |")
        print("\nbaseline do teste (só 3 casos por suíte, não é a oficial):",
              {s: (len(base[s]), nj[s], round(tau[s], 3)) for s in SUITES})
        return 0
    base = {s: baseline(res, s, set()) for s in SUITES}
    norm, tau, nj = calibrar(res, base)
    pc = por_caso(res, base, norm, tau)
    D = CI._d9a()  # noqa: N806
    D.METODOS = MODOS
    todos = sorted(res)
    out = ["# Parte A — RCAEval inédito, só métricas (`PROTOCOLO-COMPLETO.md`, confirmatório)", "",
           f"{len(todos)} casos (os 15 da rodada de teste fora). Sem traces: `g-m∨t|mf` = `g-m|mf`. Meta (§6): F1@1 ≥ "
           "0,6 **e** F1@2 ≥ 0,7 **e** alarme ≤ 20% no resultado primário.", "",
           "| suíte | casos | casos na baseline | janelas da baseline | famílias com N | τ |", "|---|---|---|---|---|---|"]
    out += [f"| {s} | {sum(1 for c in todos if c.startswith(s + '/'))} | {len(base[s])} | {nj[s]} | "
            f"{sum(1 for v in norm.get(s, {}).values() if v > 0)} | {tau[s]:.3f} |" for s in SUITES]
    out += ["", "## Resultado primário (todas as suítes)", "", *D.tabela(pc, todos), ""]
    m = D.f1([pc["g-m∨t|mf"][c] for c in todos])
    m2 = D.f1([pc["g-m∨t|mf"][c] for c in todos], 2)
    al = D.taxa([pc["g-m∨t|mf"][c] for c in todos], "al", "nn")
    ok = m >= 0.6 and m2 >= 0.7 and al <= 0.20
    out.append(f"**Leitura fixada:** F1@1 {m:.3f} (≥ 0,6: {'sim' if m >= 0.6 else 'não'}), F1@2 {m2:.3f} (≥ 0,7: "
               f"{'sim' if m2 >= 0.7 else 'não'}), alarme {al:.1%} (≤ 20%: {'sim' if al <= 0.2 else 'não'}) → "
               f"**{'CONFIRMA' if ok else 'NÃO CONFIRMA'}**.")
    out.append("")
    for b in ("m-rz|g-m", "cpu-max|g-m"):
        d, lo, hi = D.diferenca(pc, todos, "g-m∨t|mf", b)
        sa, sb, p = D.mcnemar(pc["g-m∨t|mf"], pc[b])
        out.append(f"- ΔF1@1 g-m∨t|mf − {b} = {d:+.3f} [IC 95% {lo:+.3f} a {hi:+.3f}]; McNemar: só g-m∨t|mf {sa}, "
                   f"só {b} {sb}, p = {p:.3f}")
    out += ["", "## Secundários (descritivos)", ""]
    grupos = [(f"suíte {s}", lambda c, s=s: c.startswith(s + "/")) for s in SUITES]
    grupos += [(f"sistema {k}", lambda c, k=k: c.split("/")[0].endswith("-" + k)) for k in ("OB", "SS", "TT")]
    tipos = sorted({gabarito(c.split("/", 1)[1])[1] for c in todos})
    grupos += [(f"tipo {t}", lambda c, t=t: gabarito(c.split("/", 1)[1])[1] == t) for t in tipos]
    for rot, fn in grupos:
        sub = [c for c in todos if fn(c)]
        out += [f"### {rot} ({len(sub)} casos)", "", *D.tabela(pc, sub), ""]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-confirmatorio-A.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
