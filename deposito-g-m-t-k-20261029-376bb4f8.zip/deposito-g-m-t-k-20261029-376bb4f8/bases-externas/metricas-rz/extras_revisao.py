#!/usr/bin/env python3
"""Análises adicionais pedidas na revisão (pós-hoc, fora do protocolo).

Usa as unidades e as calibrações registradas do `robustez.py` (checkpoints em `DADOS_SAIDA/metricas-rz/robustez/`),
sem recalibrar nada:

- **item 3, escada do escore** (RCAEval inédito e com rastros, mesmo portão e mesmos instantes):
  E0 Escore BARO na Janela (máximo com sinal das amostras, IQR 0 → 1, como o BARO oficial);
  E1 + valor absoluto; E2 + mediana da janela no lugar do máximo das amostras; E3 + reserva por família
  (= z do Escore de Desvio por Família, sem log nem baseline); E4 + log e normalização pela baseline (= método);
- **item 4, permutação contra o N-Sigma** em AC@1 por caso (1º instante, ordem completa), nos três conjuntos
  públicos, com Holm sobre as 12 comparações do R3 + estas 3;
- **item 5, F1 médio por caso** ao lado do F1 somado por instantes.

Saída: `resultado-extras-revisao.md`. Uso: python extras_revisao.py [--jobs 16]
"""
from __future__ import annotations

import argparse
import math
import os
import sys
import warnings
from collections import Counter, defaultdict
from typing import Any

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import robustez as R  # noqa: E402

CA, CI, E2 = R.CA, R.CI, R.E2
DEGRAUS = ("E0 BARO na Janela", "E1 + valor absoluto", "E2 + mediana da janela", "E3 + reserva por família",
           "E4 + log e baseline (método)")


def _ordem(por: dict[str, float]) -> list[str]:
    return [s for s, _ in sorted(por.items(), key=lambda kv: (-kv[1], kv[0]))]


def _degraus(tempo: np.ndarray, val: np.ndarray, cols: list[str], t: float, ref: tuple[float, float]
             ) -> dict[str, list[str]]:
    """E0–E2 a partir da série; E3/E4 vêm de `x["f"]` (já na unidade)."""
    a, b = np.searchsorted(tempo, t - CI.JANELA, "right"), np.searchsorted(tempo, t, "right")
    r0, r1 = np.searchsorted(tempo, ref[0], "left"), np.searchsorted(tempo, ref[1], "left")
    jan, rf = val[a:b], val[r0:r1]
    if len(jan) == 0 or len(rf) == 0:
        return {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        med = np.nanmedian(rf, axis=0)
        iqr = np.nanpercentile(rf, 75, axis=0) - np.nanpercentile(rf, 25, axis=0)
        iqr = np.where(iqr > 0, iqr, 1.0)
        zs = {"E0 BARO na Janela": np.nanmax((jan - med) / iqr, axis=0),
              "E1 + valor absoluto": np.nanmax(np.abs(jan - med) / iqr, axis=0),
              "E2 + mediana da janela": np.abs(np.nanmedian(jan, axis=0) - med) / iqr}
    out = {}
    for nome, z in zs.items():
        por: dict[str, float] = {}
        for c, v in zip(cols, z, strict=True):
            if np.isfinite(v):
                s = E2.servico_col(c)
                por[s] = max(por.get(s, -np.inf), float(v))
        out[nome] = _ordem(por)
    return out


def _job_a(job: tuple[str, str, list[float]]) -> tuple[str, dict[float, dict[str, list[str]]]]:
    suite, caso, ts = job
    tempo, val, cols, inj = CA.ler(suite, caso)
    ini = float(tempo[0])
    out = {}
    for periodo, t in CA.instantes(tempo, inj):
        if t in ts:
            ref = (max(ini, inj - CI.REF), inj) if periodo == "falha" else (max(ini, t - CI.JANELA - CI.REF),
                                                                              t - CI.JANELA)
            out[t] = _degraus(tempo, val, cols, t, ref)
    return f"{suite}/{caso}", out


def _job_c(job: tuple[str, list[tuple[str, str]]]) -> tuple[str, dict[str, dict[str, list[str]]]]:
    caso, its = job
    df, inj = CI._serie(caso)
    tempo, val, cols = df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), list(df.columns)
    out = {}
    for periodo, ts in its:
        t = R.O._ts(ts)
        ref = (inj - CI.REF, inj) if periodo == "falha" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        out[ts] = _degraus(tempo, val, cols, t, ref)
    return caso, out


def escada(u: dict, cal: dict, extra: dict[str, dict[Any, dict[str, list[str]]]]) -> dict[str, dict[str, Counter]]:
    pc: dict[str, dict[str, Counter]] = {d: defaultdict(Counter) for d in DEGRAUS}
    for x in u["inst"]:
        if x["periodo"] == "normal" and x["caso"] in cal["excluir"]:
            continue
        g = x["grupo"]
        n = cal["norm"].get(g, {})
        gm = max(CI._u(x["f"], n).values(), default=0.0) >= cal["tau"][g]
        gt = R.gate_t(x, cal["calt"][g]) if (u["tem_traces"] and cal["calt"] is not None) else False
        dec = gm or gt
        rks = dict(extra.get(x["caso"], {}).get(x["t"], {}))
        rks["E3 + reserva por família"] = _ordem({s: max(f.values()) for s, f in x["f"].items() if f})
        rks["E4 + log e baseline (método)"] = E2.ordem_completa(x["f"], n)
        for d in DEGRAUS:
            lst = rks.get(d, [])
            k = pc[d][x["caso"]]
            if x["periodo"] == "normal":
                k["nn"] += 1
                k["al"] += dec
            elif x["esp"]:
                k["ne"] += 1
                k["dec"] += dec
                k["tp1"] += dec and lst[:1] == [x["esp"]]
                k["tp2"] += dec and x["esp"] in lst[:2]
                k["o1"] += lst[:1] == [x["esp"]]
    return pc


def f1_caso(c: Counter, k: int = 1) -> float:
    tp, fp, fn = c[f"tp{k}"], c["dec"] - c[f"tp{k}"] + c["al"], c["ne"] - c[f"tp{k}"]
    return 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else math.nan


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    args = ap.parse_args()
    warnings.simplefilter("ignore", RuntimeWarning)
    us = {"A": R.unidade_a(args.jobs), "RCAEval-C": R.unidade_c(args.jobs), "Market": R.unidade_m(args.jobs),
          "TeaStore": R.unidade_t()}
    cals = {n: R.cal_original(u) for n, u in us.items()}
    pcs = {n: R.avaliar_orig(u, cals[n]) for n, u in us.items()}
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    ts_a: dict[str, list[float]] = defaultdict(list)
    for x in us["A"]["inst"]:
        ts_a[x["caso"]].append(x["t"])
    por_c: dict[str, list] = defaultdict(list)
    for x in us["RCAEval-C"]["inst"]:
        por_c[x["caso"]].append((x["periodo"], x["t"]))
    with ProcessPoolExecutor(args.jobs) as ex:
        ext_a = dict(ex.map(_job_a, [(*c.split("/", 1), ts) for c, ts in ts_a.items()], chunksize=2))
        ext_c = dict(ex.map(_job_c, list(por_c.items()), chunksize=2))
    out = ["# Análises adicionais da revisão (pós-hoc, fora do protocolo)", "",
           "`extras_revisao.py` (`ANALISE-QUALIDADE.md` §10.1 itens 3–5). Unidades e calibrações registradas do "
           "`robustez.py` (sem a cópia `multi-source-data`).", "",
           "## Item 3 — escada do escore (mesmo portão, mesmos instantes)", "",
           "| base | degrau | F1@1 | F1@2 | Top-1 condicionado |", "|---|---|---|---|---|"]
    for nome, ext in (("A", ext_a), ("RCAEval-C", ext_c)):
        pc = escada(us[nome], cals[nome], ext)
        for d in DEGRAUS:
            cs = list(pc[d].values())
            o1 = np.mean([c["o1"] / c["ne"] for c in cs if c["ne"]])
            out.append(f"| {nome} | {d} | {R.f1(cs):.3f} | {R.f1(cs, 2):.3f} | {o1:.1%} |")
    rng = np.random.default_rng(2026101904)
    novas = []
    for nome in ("A", "RCAEval-C", "Market"):
        u = us[nome]
        nos, _ = R.ac1_casos(u, cals[nome]["norm"])
        primeiro = {}
        for x in sorted(u["inst"], key=lambda y: (y["caso"], str(y["t"]))):
            if x["periodo"] == "falha" and x["esp"] and x["caso"] not in primeiro:
                primeiro[x["caso"]] = x
        ns = {c: float(((u["baro"].get(c) or {}).get("N-Sigma", []))[:1] == [x["esp"]]) for c, x in primeiro.items()}
        d, p = R._perm_ac(nos, ns, rng)
        novas.append({"base": nome, "medida": "AC@1 por caso", "a": "g-m∨t|mf (1º instante)", "b": "N-Sigma oficial",
                      "delta": d, "p": p, "n": len(ns), "ac_nos": float(np.mean(list(nos.values()))),
                      "ac_ns": float(np.mean(list(ns.values())))})
    r3 = (R.ler("resultados") or {}).get("R3", [])
    todas = [*r3, *novas]
    ps = [c["p"] for c in todas]
    ordem = sorted(range(len(ps)), key=lambda i: ps[i])
    holm, mx = [0.0] * len(ps), 0.0
    for r, i in enumerate(ordem):
        mx = max(mx, min(1.0, (len(ps) - r) * ps[i]))
        holm[i] = mx
    out += ["", f"## Item 4 — permutação contra o N-Sigma (10.000; Holm sobre {len(todas)} = R3 + 3)", "",
            "| base | casos | AC@1 nosso | AC@1 N-Sigma | Δ | p | p Holm |", "|---|---|---|---|---|---|---|"]
    for c, h in zip(todas, holm, strict=True):
        if c in novas:
            out.append(f"| {c['base']} | {c['n']} | {c['ac_nos']:.3f} | {c['ac_ns']:.3f} | {c['delta']:+.3f} | "
                       f"{c['p']:.4f} | {h:.4f} |")
    out += ["", "Holm das 12 do R3 recalculado sobre as 15:", "", "| base | medida | a | b | Δ | p | p Holm (15) |",
            "|---|---|---|---|---|---|---|"]
    out += [f"| {c['base']} | {c['medida']} | {c['a']} | {c['b']} | {c['delta']:+.3f} | {c['p']:.4f} | {h:.4f} |"
            for c, h in zip(todas, holm, strict=True) if c not in novas]
    out += ["", "## Item 5 — F1@1 somado por instantes × médio por caso", "",
            "| base | modo | casos | F1@1 somado | F1@1 médio por caso | mediana por caso |", "|---|---|---|---|---|---|"]
    for nome, modo in (("A", "g-m∨t|mf"), ("RCAEval-C", "g-m∨t|mf"), ("Market", "g-m∨t|mf"),
                       ("TeaStore", "g-m∨t|mf"), ("TeaStore", "g-m∨t∨k|mfk")):
        # o F1 somado inclui os casos só com instantes normais (os trechos normais do Market), como nos outros
        # relatórios; a média por caso fica nos casos com instantes com causa
        cs = [c for c in pcs[nome][modo].values() if c["ne"]]
        v = [f1_caso(c) for c in cs]
        v = [x for x in v if not math.isnan(x)]
        out.append(f"| {nome} | {modo} | {len(cs)} | {R.f1(list(pcs[nome][modo].values())):.3f} | {np.mean(v):.3f} | "
                   f"{np.median(v):.3f} |")
    texto = "\n".join(out) + "\n"
    with open(os.path.join(AQUI, "resultado-extras-revisao.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    sys.exit(main())
