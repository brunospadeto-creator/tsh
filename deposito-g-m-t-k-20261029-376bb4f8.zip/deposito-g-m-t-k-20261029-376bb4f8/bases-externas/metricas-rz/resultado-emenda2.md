# Emenda 2 — BARO/N-Sigma oficiais, AC@k, BARO-janela e sensibilidade (RCAEval e Market)

`PROTOCOLO-COMPLETO.md` emenda 2. Tudo descritivo (as metas de A e B′ já foram lidas). AC@k por caso em nível de serviço; `g-m∨t|mf` no 1º instante de falha (só os primeiros 120 s), BARO/N-Sigma com todo o pós-injeção e o horário da injeção (oráculo).

## A — RCAEval inédito, só métricas (480 casos; sem traces: `g-m∨t` = `g-m`)

### Por caso (AC@k, serviço)

| método | casos | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|
| BARO (oficial) | 474 | 0.295 | 0.673 | 0.611 |
| N-Sigma (oficial) | 474 | 0.631 | 0.865 | 0.824 |
| g-m∨t|mf — 1º instante | 474 | 0.709 | 0.903 | 0.870 |
| g-m∨t|mf — último instante | 474 | 0.677 | 0.895 | 0.855 |

### Por instante

| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|---|
| g-m∨t|mf | 474 | 0.614 [0.572–0.654] | 0.704 | 6.6% | 36.3% | 69.8% | 89.5% |
| g-m∨t|BARO-janela | 474 | 0.284 [0.251–0.322] | 0.570 | 6.6% | 36.3% | 37.8% | 81.7% |
| g-m∨t|mf @FP0,01 | 474 | 0.446 [0.395–0.496] | 0.516 | 1.8% | 61.8% | 69.8% | 89.5% |
| g-m∨t|mf @FP0,10 | 474 | 0.599 [0.560–0.637] | 0.692 | 13.1% | 32.5% | 69.8% | 89.5% |

#### sistema OB (122 casos), por instante

| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|---|
| g-m∨t|mf | 119 | 0.637 [0.562–0.707] | 0.720 | 6.9% | 25.0% | 55.4% | 73.4% |
| g-m∨t|BARO-janela | 119 | 0.204 [0.141–0.271] | 0.577 | 6.9% | 25.0% | 28.1% | 90.9% |

#### sistema SS (236 casos), por instante

| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|---|
| g-m∨t|mf | 234 | 0.715 [0.663–0.765] | 0.822 | 5.6% | 21.4% | 82.6% | 97.3% |
| g-m∨t|BARO-janela | 234 | 0.333 [0.285–0.381] | 0.656 | 5.6% | 21.4% | 41.0% | 87.7% |

#### sistema TT (122 casos), por instante

| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|---|
| g-m∨t|mf | 121 | 0.283 [0.200–0.370] | 0.333 | 7.9% | 77.7% | 59.3% | 90.3% |
| g-m∨t|BARO-janela | 121 | 0.255 [0.176–0.342] | 0.307 | 7.9% | 77.7% | 41.3% | 61.2% |

## C — RCAEval com traces (240 casos; descritivo)

**Validação do BARO oficial no RE2-TT:** AC@1 0.589 / AC@3 0.744 / Avg@5 0.738 (90 casos), publicado (Tabela 6 do RCAEval) 0.67 / 0.82 / 0.80.

### Por caso (AC@k, serviço)

| método | casos | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|
| BARO (oficial) | 239 | 0.406 | 0.858 | 0.776 |
| N-Sigma (oficial) | 239 | 0.753 | 0.883 | 0.864 |
| g-m∨t|mf — 1º instante | 239 | 0.782 | 0.950 | 0.916 |
| g-m∨t|mf — último instante | 239 | 0.649 | 0.845 | 0.814 |
| d9 (= d9-k) forçado — 1º instante | 239 | 0.356 | 0.544 | 0.500 |

### Por instante

| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|---|
| g-m∨t|mf | 239 | 0.687 [0.640–0.732] | 0.826 | 15.4% | 3.2% | 72.6% | 91.4% |
| g-m∨t|BARO-janela | 239 | 0.437 [0.391–0.483] | 0.705 | 15.4% | 3.2% | 46.0% | 83.2% |
| g-m|mf | 239 | 0.632 [0.572–0.685] | 0.775 | 5.8% | 23.3% | 72.6% | 91.4% |
| g-m|BARO-janela | 239 | 0.440 [0.389–0.491] | 0.682 | 5.8% | 23.3% | 46.0% | 83.2% |
| g-m∨t|mf @FP0,01 | 239 | 0.679 [0.630–0.724] | 0.819 | 11.7% | 7.0% | 72.6% | 91.4% |
| g-m∨t|mf @FP0,10 | 239 | 0.675 [0.631–0.718] | 0.811 | 20.9% | 2.5% | 72.6% | 91.4% |

## C — OpenRCA Market (77 casos; descritivo)

### Por caso (AC@k, serviço)

| método | casos | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|
| BARO (oficial) | 77 | 0.221 | 0.636 | 0.579 |
| N-Sigma (oficial) | 77 | 0.506 | 0.714 | 0.678 |
| g-m∨t|mf — 1º instante | 77 | 0.649 | 0.883 | 0.857 |
| g-m∨t|mf — último instante | 77 | 0.558 | 0.740 | 0.743 |
| d9 (= d9-k) forçado — 1º instante | 77 | 0.260 | 0.597 | 0.494 |

### Por instante

| modo | casos | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |
|---|---|---|---|---|---|---|---|
| g-m∨t|mf | 77 | 0.428 [0.330–0.527] | 0.602 | 16.5% | 39.7% | 59.7% | 82.8% |
| g-m∨t|BARO-janela | 77 | 0.211 [0.149–0.282] | 0.482 | 16.5% | 39.7% | 30.4% | 80.0% |
| g-m|mf | 77 | 0.304 [0.199–0.405] | 0.477 | 12.4% | 60.5% | 59.7% | 82.8% |
| g-m|BARO-janela | 77 | 0.160 [0.095–0.229] | 0.373 | 12.4% | 60.5% | 30.4% | 80.0% |
| g-m∨t|mf @FP0,01 | 77 | 0.298 [0.212–0.383] | 0.449 | 15.7% | 58.3% | 59.7% | 82.8% |
| g-m∨t|mf @FP0,10 | 77 | 0.436 [0.336–0.537] | 0.618 | 16.5% | 37.3% | 59.7% | 82.8% |

