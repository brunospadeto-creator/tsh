# Plano — d9-k, v-cons-b e d2c-r em três bases públicas de RCA

Criado em 17/10/2026 (ARQ). Objetivo: medir **como os três métodos vencedores do Stage 3 generalizam** fora do
TeaStore, com comparação entre eles e com a d9 (referência), em bases reconhecidas na academia. Bases escolhidas e
validadas em `bases-baixadas.md` e `session.md` §42.84 em diante.

## 0. Regras

1. **Nenhum código existente muda.** `src/` (inclusive `d9k_portao_grafo_k8s.py`, `vconsb_consenso.py`,
   `d2cr_nulo_rolante.py`, `d9_portao_grafo.py`) e os scripts de `experimento-falhas/` são só **importados**.
   Todo código novo fica em `bases-externas/`.
2. **Mesmos parâmetros do TeaStore, sem ajuste por base.** Janela de 120 s; passo de 60 s; referência da sessão de
   150 s (`ref_seg`); d6 do v-cons-b com o `q` do fp 0,20; pesos, desempates e faixas de confiança do v-cons-b
   congelados (§42.72). Só entra **configuração de sistema** (serviço de entrada, regex da operação de entrada,
   serviços sem span próprio, mapa componente → serviço), declarada antes de rodar.
3. **Protocolo antes do resultado.** Cada base tem um `PROTOCOLO.md` commitado **antes** de rodar: casos, períodos,
   exclusões, desvios e leitura. Mudança depois de ver número = protocolo novo, declarado.
4. **Dados fora do git.** As bases ficam em `/mnt/gpu-disk/veritas/novo-artigo/datasets/` (só leitura). Insumos
   convertidos e registros brutos em `/mnt/gpu-disk/datasets/bases-externas/<base>/` (fora do git); só o
   `resultado.md`, o `inventario.json` e os registros comprimidos pequenos entram no repositório.
5. **Desvios declarados.** Toda diferença em relação ao TeaStore (falta de K8s, falta de status, referência curta)
   vai para o `PROTOCOLO.md` da base e para o `resultado.md`.

## 1. Estrutura

```
bases-externas/
├── PLANO.md                  este plano
├── comum/                    biblioteca compartilhada (só leitura de src/; sem decisão por base)
│   ├── jaeger.py             spans de qualquer formato → dict no formato do Jaeger (/api/traces)
│   ├── instantes.py          períodos normal/falha → instantes de 60 s → EntradaIncidente
│   ├── metodos.py            chama d9-k, v-cons-b (n = 5 e disparo único), d2c-r e d9 (+ decisão forçada)
│   └── metricas.py           F1@k com portão, alarme, abstenção, sabendo top-k, AC@k/Avg@5, IC bootstrap, McNemar
├── rcaeval/                  RCAEval RE2/RE3 (OB, TT) — código de análise independente
│   ├── PROTOCOLO.md
│   ├── adaptar.py            caso → traces Jaeger + períodos + gabarito
│   ├── baseline.py           artefatos do v-cons-b (a0-b, d6) por sistema
│   ├── rodar.py              registros por instante (jsonl.gz)
│   └── analisar.py           resultado.md
├── openrca-market/           OpenRCA Market (cloudbed-1/2) — mesma divisão de arquivos
└── eadro/                    Eadro (TT, SN) — mesma divisão de arquivos
```

`comum/` só existe para que as três bases meçam **do mesmo jeito**; nada nele conhece uma base. Cada pasta de base
tem o seu adaptador, o seu protocolo e a sua análise, e roda sozinha.

## 2. Como os métodos são chamados (igual ao avaliador do TeaStore)

| item | regra |
|---|---|
| insumo | `processo.eventos_de_traces_brutos(traces_jaeger, entry_services, entry_operation_regex)` → `EntradaIncidente(traces=janela, traces_lookback=passado, eventos_k8s=[], metricas={}, config_sistema=…)` |
| instantes normais | a cada 60 s dentro do normal, a partir de 150 s do início (precisa de referência); lookback = passado real |
| instantes de falha ("estável") | a cada 60 s a partir de injeção + 120 s (janela inteira dentro da falha) até o fim da falha (teto de 10 min); lookback = os 150 s **antes da injeção**, deslocados (pré-falha deslocado, como no avaliador unificado) |
| d9-k | `d9k_portao_grafo_k8s.decidir`; sem eventos K8s (nenhuma base tem) |
| v-cons-b | `vconsb_consenso.ConsensoVConsB` (n = 5, histórico por período) e `votar(..., n_persistencia=1)` (disparo único); artefatos por `vconsb_consenso.preparar_baseline` sobre a baseline da base |
| d2c-r | `d2cr_nulo_rolante.decidir` |
| d9 (referência) | `d9_portao_grafo.decidir` com o portão da d9 (`PORTAO_D9`) |
| decisão forçada | a mesma do TeaStore (permissiva) para o "sabendo que é falha" |
| D0.4 | instante com < 30 traces na janela fica fora (para todos os métodos) |

## 3. Medidas (as mesmas da coleta definitiva, mais as do RCAEval)

- **com portão:** F1@1, F1@2, F1@3; alarme nos normais; abstenção nas falhas;
- **sabendo que é falha:** top-1, top-2, top-3 (média por caso);
- **comparáveis com a literatura:** AC@1, AC@3 e Avg@5 por caso (1º instante de falha decidido; e média nos
  instantes), para comparar com os baselines publicados do RCAEval (TraceRCA, BARO, CIRCA…);
- IC 95% por bootstrap de caso (2000 reamostragens, semente fixa); McNemar exato pareado (d9-k × d9; v-cons-b ×
  d9-k; d2c-r × d9-k);
- separado por sistema (OB, TT, SN, cloudbed) e por tipo de falha.

**Leitura fixada antes (por base):** a d9-k generaliza se F1@1 ≥ d9 e alarme ≤ 2%; o v-cons-b, se top-3 sabendo
≥ 80% e top-1 sabendo ≥ d9; a d2c-r, se F1@1 ≥ d9 e alarme ≤ 2% (mesmo critério da d9-k, por ser a candidata a
complemento). **Pergunta transversal:** a complementaridade d9-k × d2c-r vista no TeaStore (§42.82) se repete?
Só descritiva; a combinação das duas não é avaliada aqui.

## 4. Planos por base

### 4.1 RCAEval RE2/RE3 — OB e TT (241 casos)

| item | regra |
|---|---|
| casos | RE2-OB 91, RE2-TT 90, RE3-OB 30, RE3-TT 30 (`traces.csv`); SS fora (sem traces) |
| gabarito | serviço do nome da pasta (`<serviço>_<falha>/<n>`), com o alias OB `frontend` → `frontendservice` (como em `replay/rcaeval.py`) |
| normal / falha | normal = `[início, injeção)` (12 min; RE3-TT 15 min); falha = `[injeção, fim]` (12 min) |
| baseline do v-cons-b | **por sistema, sem o próprio caso**: o normal dos outros casos do mesmo sistema e suíte (amostra fixa de 10 casos, semente fixa), para não calibrar no mesmo normal que mede o alarme |
| config de sistema | OB: entrada `frontendservice`, operação `^frontend` (a do `replay/rcaeval.py`); TT: entrada `ts-ui-dashboard`, operação HTTP — **confirmar nos dados antes do protocolo** |
| desvios | sem K8s; **TT sem `statusCode`** (o portão decide só por latência); a0-b sem `url.path` |
| exclusões | caso com < 2 min depois da injeção (ex.: `RE2-OB/checkoutservice_cpu/2`, 0,6 min) — contar antes e fixar no protocolo |
| custo estimado | adaptador ~2 h; baseline ~1 h; execução ~2–3 h (16 processos); análise ~30 min |

### 4.2 OpenRCA Market — cloudbed-1 e cloudbed-2 (148 falhas)

| item | regra |
|---|---|
| casos | `record.csv` de cada cloudbed; **só falhas em pod/serviço**; falhas em nó entram num grupo à parte (sem gabarito de serviço) |
| gabarito | componente do `record.csv` → serviço (`adservice-1` → `adservice`); mapa declarado no protocolo |
| normal / falha | falha = `[t, t + D)`, D da documentação do OpenRCA (**confirmar**; até lá, teto de 10 min); normal = trechos a ≥ 30 min de qualquer falha registrada |
| baseline do v-cons-b | por cloudbed e por dia: o maior trecho normal antes da 1ª falha do dia (≥ 9 min) |
| config de sistema | entrada `frontend`, operação HTTP do `operation_name` — **confirmar nos dados** |
| desvios | sem K8s; rótulos com críticas publicadas (declarar) |
| custo estimado | adaptador ~3 h (volume grande: 73 GB); baseline ~1 h; execução ~3–4 h; análise ~30 min |

### 4.3 Eadro — TT e SN (117 falhas)

| item | regra |
|---|---|
| casos | `TT.fault-*.json` (81 falhas de 600 s) e `SN.fault-*.json` (36 de 120 s) |
| gabarito | serviço do campo `name` (`dockercomposemanifests_ts-auth-service_1` → `ts-auth-service`) |
| baseline do v-cons-b | blocos **"no fault"** (TT 2 × ~2 h 15; SN 3 × ~24 min) |
| instantes normais | dentro dos blocos "no fault" (sessão normal de verdade, com lookback real) |
| instantes de falha | como no §2; SN com falhas de 120 s → 1 instante útil por falha |
| **desvio da referência** | a folga entre falhas é de ~115 s (TT) e ~34 s (SN): o lookback de 150 s cai na recuperação da falha anterior. **Principal:** como está (150 s, declarado contaminado). **Sensibilidade:** `ref_seg` = 100 s no TT. SN reportado à parte |
| config de sistema | TT entrada `ts-ui-dashboard`; SN entrada `nginx-web-server` — **confirmar nos dados** |
| custo estimado | adaptador ~2 h (extrair os `.tar.xz` "no fault"); execução ~1–2 h; análise ~30 min |

## 5. Etapas e ordem

| # | etapa | entrega | estimativa |
|---|---|---|---|
| 1 | Estrutura de pastas e este plano | `bases-externas/` | ✅ feito |
| 2 | `comum/` + testes pequenos (conversão Jaeger, instantes, métricas) | `comum/*.py`, `comum/tests/` | ~3 h |
| 3 | Fumaça: 1 caso de cada base passando pelos quatro métodos | log da fumaça | ~1 h |
| 4 | Conferências que faltam: entrada do TT/SN/Market, D do OpenRCA, casos truncados do RCAEval | anotadas nos protocolos | ~1 h |
| 5 | `PROTOCOLO.md` das três bases — **commit antes de rodar** | 3 protocolos | ~1 h |
| 6 | RCAEval: adaptar → baseline → rodar → analisar | `rcaeval/resultado.md` | ~5–6 h |
| 7 | OpenRCA Market: idem | `openrca-market/resultado.md` | ~7–8 h |
| 8 | Eadro: idem (principal + sensibilidade) | `eadro/resultado.md` | ~3–4 h |
| 9 | Tabela entre bases (TeaStore definitiva + três bases), registro no `session.md` | `bases-externas/RESULTADO.md` | ~1 h |

Total estimado: ~2–3 dias de trabalho offline, sem cluster. As execuções rodam com `nice` e em paralelo
(`ProcessPoolExecutor`), no mesmo venv do Stage 3 (com `pyarrow` para os parquet).

## 6. Riscos e decisões em aberto

| risco / decisão | tratamento |
|---|---|
| baseline do v-cons-b no RCAEval (normal de outros casos × do próprio caso) | proposto: outros casos do mesmo sistema; decidir antes do protocolo |
| volume do OpenRCA (73 GB) e do RCAEval-TT (~1 M spans por caso) | leitura por janela/colunas; registros comprimidos |
| d6 do v-cons-b com poucas janelas | o mínimo é 8 (`calibracao.MIN_JANELAS_CALIBRACAO`); caso abaixo disso → v-cons-b sem a d6, declarado |
| TT sem status de erro (RCAEval) | portão só por latência; declarado |
| Eadro com referência contaminada | principal + sensibilidade; SN à parte |
| nenhuma base tem K8s | a d9-k roda sem o canal K8s; leitura: quanto da d9-k vem só dos traces |

## 7. Código (17/10) e achados da verificação leve

Código escrito em `comum/` e nas três pastas; só importa `src/`. Verificação leve: tudo compila; 1 caso do RCAEval
(RE2-OB) e 2 do Eadro passaram pelos quatro métodos; o Market foi testado só numa amostra do CSV.

| base | achado | tratamento |
|---|---|---|
| RCAEval | entrada do TT: não há gateway nos traces; o gerador chama a API REST de cada `ts-*` | entrada = qualquer `ts-*` com operação HTTP (`^[A-Z]+ /`) |
| RCAEval | RE3-OB chama o frontend de `frontend` (o RE2-OB, `frontendservice`); `adservice` não aparece nos traces do RE3-OB | entrada com os dois nomes; casos de `adservice` ficam (os métodos não podem acertá-los — declarar) |
| RCAEval | 1 caso do RE2-OB com 192 s por caso só para d9-k/d2c-r/d9 | ~241 casos × ~4 min ÷ 8 processos ≈ 2 h, mais o v-cons-b |
| OpenRCA Market | só 118 dos 148 registros caem nos 2 dias de telemetria; 41 deles em nó | 77 falhas com serviço + 16 trechos normais |
| OpenRCA Market | `duration` em µs, `timestamp` em ms; status mistura `0`/`Ok`/`200` | convertidos; erro = fora de {0, Ok, 2xx, 3xx} |
| OpenRCA Market | na amostra, só ~4% dos traces passam no filtro de completude (raiz `frontend` `Recv.`); muitos fragmentos sem a raiz | medir depois do `--extrair`; se faltar tráfego (D0.4), decidir no protocolo |
| Eadro | os spans estão **8 h à frente** dos horários do JSON de falhas (UTC+8 gravado como UTC), em todos os blocos | `DESLOC_FALHAS_SEG = 8 h`, declarado |
| Eadro | o mesmo trace aparece em mais de um objeto do `spans.json` (spans repetidos viravam 2 raízes) | `comum.jaeger.de_linhas` deduplica por (trace, span) |
| Eadro | **TT com pouco tráfego:** ~14 traces completos por janela de 120 s, abaixo do mínimo de 30 da D0.4 → nenhum instante | decidir no protocolo: TT fora, ou D0.4 menor só ali (desvio) |
| Eadro | SN: falhas de 120 s → 1 instante de falha por caso | como previsto |

### Como rodar (da pasta de cada base, com o venv do Stage 3 + `pyarrow`)

| base | passos |
|---|---|
| RCAEval | `python adaptar.py` (conta casos e truncados) → `python baseline.py` → `python rodar.py --jobs 8` → `python analisar.py` |
| OpenRCA Market | `python adaptar.py --extrair` (uma passada por dia, ~5 GB) → `python baseline.py` → `python rodar.py --jobs 8` → `python analisar.py` |
| Eadro | `python adaptar.py --extrair` (blocos "no fault") → `python baseline.py` → `python rodar.py --jobs 8` [→ `--ref 100 --sistemas TT`] → `python analisar.py` |

Fumaça de qualquer base: `python rodar.py --limite 1`.

**Decisão do usuário (17/10):** o **Eadro TT sai** da avaliação (abaixo da D0.4: ~14 traces completos por janela de
120 s); a D0.4 fica igual em todas as bases. O Eadro fica só com o **SN** (36 falhas). Declarar como exclusão por
falta de tráfego.

## 8. Rodada de teste de ~5 min, avaliação e desempenho (17/10, noite)

Saída separada (`BASES_EXTERNAS_SAIDA=/mnt/gpu-disk/datasets/bases-externas-teste`); a oficial segue vazia.
**Desvio a declarar:** os números de 15 casos de teste (4 RCAEval + 2 TT, 4 Market, 4 Eadro) foram vistos antes da
rodada completa; nada foi ajustado por causa deles.

**Avaliação do processo**

| item | resultado |
|---|---|
| métodos | nenhum `falhou`; nenhum votante do v-cons-b falhou; d9-k = d9 sem K8s (esperado) |
| instantes | contagens certas (RCAEval: ~8 normais + 9 de falha; Market: 8–9; Eadro SN: 1 por falha) |
| tráfego | ≥ 95 traces por janela em todas as amostras (D0.4 folgada) |
| calibração da d6 | funciona; `q` alto no RCAEval/Market (0,10–0,50) é dos dados (o v-cons-b usa o ranking forçado da d6) |
| **problema — Eadro** | a 1ª falha de cada bloco **não tem referência** (o bloco começa 3 s antes): d9-k/d9 saem vazias. A leitura secundária "só a 1ª falha" do `eadro/PROTOCOLO.md` não funciona → emendar antes da rodada oficial |
| **corrigido — análise** | sem instantes normais, a leitura dizia "não generaliza"; agora diz "indeterminado" |

**Desempenho (otimizações exatas em `comum/rapido.py`, sem mexer em `src/`; registros comparados byte a byte)**

| caso | original | otimizado | ganho | registros |
|---|---|---|---|---|
| RE2-OB (4 instantes) | 76,4 s | 32,4 s | 2,4× | idênticos |
| RE3-TT (2 instantes) | 33,5 s | 7,6 s | 4,4× | idênticos |
| Market falha / normal | 23,7 / 15,6 s | 11,8 / 7,4 s | 2,0× / 2,1× | idênticos |
| Eadro SN | 2,2 s | 1,4 s | 1,6× | idênticos |
| baseline do v-cons-b (RE3-OB) | 38,7 s | 25,4 s | 1,5× | artefato idêntico |

Mais: baselines do RCAEval em paralelo por suíte; baseline do Eadro TT não é mais preparada; 24 processos por
padrão (pico medido de 2,6 GB por processo no RE2-TT).

Medidas completas (com v-cons-b, otimizado): RE2-TT 710 s por caso (1,14 M eventos), RE3-TT 58 s; baseline com
1 caso por suíte: RE2-TT 193 s, RE3-TT 78 s, RE2-OB 89 s, RE3-OB 25 s.

**Depois da avaliação (17/10):** emenda do Eadro decidida pelo usuário — as 4 primeiras falhas (uma por bloco) saem
por falta de referência; ficam 32 (`eadro/PROTOCOLO.md` §6). Corrigido também o intervalo dos blocos "no fault":
traziam spans antigos espalhados por dias (84 "trechos normais" no SN); agora o bloco = maior trecho contínuo de
minutos com ≥ 20% do pico → baseline de 24 min e 2 trechos normais de 15 min, e a baseline lê só esse trecho.
Tempo medido no SN completo (pasta de teste, resultados não lidos): baseline 61 s + execução 34 s com 24 processos.
