# Bases externas — protocolo, testes e resultados de d9-k, v-cons-b e d2c-r

Escrito em 18/10/2026 (ARQ), depois das duas rodadas e da revisão dos resultados. É a etapa 9 do `PLANO.md`
(tabela entre bases). Resultados por base: `rcaeval/resultado.md`, `openrca-market/resultado.md` e
`eadro/resultado.md`. Registro no `session.md` §42.85 e §42.86.

## 1. Objetivo

Os três métodos vencedores do Stage 3 (§42.84) foram escolhidos e confirmados no TeaStore. Aqui a pergunta é se eles
**generalizam** para outros sistemas, falhas e coletas. Para isso rodam em três bases públicas de RCA reconhecidas
na academia, sem nenhum ajuste, comparados entre si e com a **d9** (referência). As bases foram escolhidas em
`../bases-baixadas.md`: são de 2023–2025, têm traces com gabarito de serviço e trazem um trecho normal.

| base | origem | sistemas | por que entra |
|---|---|---|---|
| **RCAEval** RE2/RE3 | WWW 2025 (benchmark) | Online Boutique (OB), Train Ticket (TT) | traces + gabarito de serviço por caso; ~12 min normais antes de cada injeção |
| **OpenRCA** Market | ICLR 2025 | Online Boutique em 2 cloudbeds | 2 dias de telemetria contínua com 148 falhas registradas |
| **Eadro** | ICSE 2023 | Social Network (SN) | traces Jaeger + blocos "no fault" (= baseline) |

Ficaram fora (`../bases-baixadas.md`): Nezha, AnoMod, LEMMA-RCA, LO2, Cloud-OpsBench, TrainTicketTrace, RCAEval RE1 e
as suítes Sock Shop, que não têm traces, e Telecom/Bank. Também ficou fora o Eadro TT, com ~14 traces por janela,
abaixo da D0.4 (decisão do usuário, 17/10).

## 2. Regras do protocolo

Regras fixadas no `PLANO.md` §0, todas cumpridas:

1. **Nenhum código existente muda.** `src/` e `experimento-falhas/` só são importados; todo código novo fica em
   `bases-externas/`.
2. **Mesmos parâmetros do TeaStore, sem ajuste por base:**
   - janela de 120 s, passo de 60 s, referência da sessão (`ref_seg`) de 150 s;
   - lookback de 600 s e teto de falha de 600 s;
   - D0.4: um instante com menos de 30 traces na janela fica fora;
   - d6 com o `q` do fp 0,20, e pesos, desempates, n = 5 e faixas de confiança do v-cons-b congelados (§42.72).

   Só entra **configuração de sistema** (serviço e operação de entrada, definição de erro, mapa componente →
   serviço), declarada antes de rodar.
3. **Protocolo antes do resultado.** Cada base tem um `PROTOCOLO.md` commitado **antes** da execução. A única emenda
   (Eadro §6) foi decidida depois da rodada de teste e antes da rodada oficial.
4. **Dados fora do git.** As bases ficam em `/mnt/gpu-disk/veritas/novo-artigo/datasets/` (só leitura). Registros e
   artefatos ficam em `/mnt/gpu-disk/datasets/bases-externas/` (rodada 1) e `…/bases-externas-r2/` (rodada 2).
5. **Desvios declarados** no protocolo e no `resultado.md` de cada base.
6. **Leitura fixada antes**, igual nas três bases:
   - **d9-k** e **d2c-r** generalizam se F1@1 ≥ d9 **e** alarme ≤ 2%;
   - **v-cons-b** generaliza se top-3 sabendo ≥ 80% **e** top-1 sabendo ≥ d9.

## 3. Como os métodos são chamados

O código fica em `comum/`, compartilhado para que as três bases meçam do mesmo jeito; nada ali conhece uma base
específica.

| etapa | arquivo | o que faz |
|---|---|---|
| conversão | `comum/jaeger.py` | spans de qualquer formato → trace Jaeger (dedup por trace/span, `span.kind` inferido) → `processo.eventos_de_traces_brutos` |
| instantes | `comum/instantes.py` | **normais**: a cada 60 s, a partir de 150 s do início, com lookback real; **falha**: a cada 60 s a partir da injeção + 120 s (janela inteira dentro da falha) até o teto de 600 s, com lookback = pré-falha deslocado (como no avaliador unificado); D0.4 |
| métodos | `comum/metodos.py` | `d9k.decidir` (sem eventos K8s, que nenhuma base tem); `ConsensoVConsB` (n = 5, histórico por período) e `votar(n_persistencia=1)` (v-cons-b-1); `d2cr.decidir` (q = 1e-50); `d9.decidir` com o portão da d9; decisão forçada permissiva para o "sabendo" |
| baseline do v-cons-b | `*/baseline.py` | `vconsb.preparar_baseline` sobre o normal declarado de cada base (artefatos a0-b e d6) |
| execução | `comum/execucao.py`, `*/rodar.py` | um processo por caso (24 em paralelo), registros por instante em `jsonl.gz`, retomável |
| métricas | `comum/metricas.py`, `*/analisar.py` | ver §4 |
| aceleração | `comum/rapido.py` | caches **exatos** por substituição de atributo em tempo de execução (índice de filhos, memória da d9-k/d2c-r/d2/d6/referência); `BASES_EXTERNAS_RAPIDO=0` desliga |

## 4. Medidas

- **Com portão ("sem saber se é falha"):** F1@1/2/3, somando os instantes. Alarme num instante normal conta como
  FP; abstenção num instante de falha conta como FN. Também: **alarme** (decisões ÷ instantes normais) e
  **abstenção** (1 − decisões ÷ instantes de falha).
- **Sabendo que é falha:** top-1/2/3 do ranking forçado, média por caso.
- **Comparáveis com o RCAEval:** AC@1 e AC@3 por caso, no 1º instante de falha, e Avg@5. Os métodos devolvem
  top-3, então AC@4 = AC@5 = AC@3. Por isso o AC@k pode diferir do top-k, que é a média em todos os instantes.
- **Incerteza:** IC 95% por bootstrap de caso (2000 reamostragens, semente 20261017) e McNemar exato pareado por
  caso (acerto majoritário).

## 5. Protocolo por base

### 5.1 RCAEval RE2/RE3 (`rcaeval/PROTOCOLO.md`)

| item | regra |
|---|---|
| casos | 241 com traces: RE2-OB 91, RE2-TT 90, RE3-OB 30, RE3-TT 30. Gabarito = serviço do nome da pasta (alias OB `frontend` → `frontendservice`) |
| exclusão fixada | `RE2-OB/checkoutservice_cpu/2`: só 38 s depois da injeção (< 180 s), sem instante de falha. Entra só com os normais → **240 casos de falha** |
| períodos | normal = `[início, injeção)` (~12 min; RE3-TT ~15 min); falha = `[injeção, fim]`, teto de 600 s |
| sistema OB | entrada `frontendservice`/`frontend`, operação `^frontend$`; erro = `statusCode` gRPC ≠ 0 |
| sistema TT | não há gateway nos traces: entrada = qualquer `ts-*` com operação HTTP (`^[A-Z]+ /`). Sem `statusCode` → portão só por latência |
| baseline do v-cons-b | por suíte, o normal de 5 casos sorteados (semente `20261017-<suíte>`), encadeados no tempo; os instantes normais desses casos (`na_baseline`) **saem da medida de alarme** |
| gabarito invisível | RE3-OB `adservice`/`cartservice` (12 casos) não aparecem nos traces; ficam no principal e saem numa leitura secundária |

### 5.2 OpenRCA Market (`openrca-market/PROTOCOLO.md`)

| item | regra |
|---|---|
| casos | 118 dos 148 registros caem nos 2 dias de telemetria; 41 são em nó (sem serviço) e ficam fora → **77 falhas** em pod/serviço |
| gabarito | componente sem o sufixo de réplica (`recommendationservice2-0` → `recommendationservice`) |
| falha | `[t, t + 600 s)`, cortada na falha seguinte. A duração não é documentada (declarado); o pré-falha pode incluir o fim da falha anterior |
| normais | 16 trechos de 15 min a ≥ 30 min de qualquer falha; 5 caem depois do fim da telemetria → **11 trechos** (121 instantes) |
| sistema | entrada `frontend`, operação `hipstershop.Frontend/Recv.`; erro = status fora de {0, Ok, 2xx, 3xx}; `timestamp` em ms, `duration` em µs |
| baseline do v-cons-b | por cloudbed, um trecho de 30 min do 1º dia a ≥ 30 min de qualquer falha (não é caso normal) |
| ressalva | os rótulos do OpenRCA têm críticas publicadas (arXiv 2607.13548) |

### 5.3 Eadro SN (`eadro/PROTOCOLO.md`)

| item | regra |
|---|---|
| casos | 36 falhas (12 serviços × cpu_load / network_delay / network_loss), 120 s cada, em 4 blocos. Gabarito: `socialnetwork-<svc>-1` → `<svc>`; `nginx-thrift` → `nginx-web-server` |
| relógio | spans 8 h à frente do JSON de falhas (UTC+8 gravado como UTC) → +8 h nas falhas |
| emenda (§6) | a 1ª falha de cada bloco não tem referência (o bloco começa ~3 s antes) → sai → **32 falhas** |
| desvio declarado | as falhas vêm em sequência (~34 s de folga); a referência de 150 s cai na recuperação da falha anterior em **todas** as 32 |
| normais | blocos "no fault" = baseline literal. Bloco = maior trecho contínuo de minutos com ≥ 20% do pico. 1º bloco = baseline do v-cons-b (24 min); os outros 2 → trechos de 15 min (22 instantes) |
| sistema | entrada `nginx-web-server`, operação `^/`; erro = tag `error` ou `http.status_code` ≥ 500; spans repetidos entram uma vez |
| instantes | 1 instante de falha por caso (injeção + 120 s) |

## 6. Testes feitos

| # | teste | resultado |
|---|---|---|
| 1 | **Verificação leve** (`PLANO.md` §7): tudo compila; 1 caso RCAEval e 2 Eadro passam pelos quatro métodos | achados corrigidos antes do protocolo: entrada do TT, nome do frontend no RE3-OB, unidades do Market, relógio do Eadro, spans repetidos |
| 2 | **Rodada de teste de ~5 min** (15 casos, saída separada; `PLANO.md` §8) | nenhum método ou votante `falhou`; contagens de instantes certas; ≥ 95 traces por janela. Achou: 1ª falha do Eadro sem referência (→ emenda §6) e "não generaliza" sem instantes normais (→ "indeterminado") |
| 3 | **Igualdade da aceleração**: registros com `rapido` × código original, byte a byte | idênticos em RE2-OB (2,4×), RE3-TT (4,4×), Market (2,0–2,1×), Eadro (1,6×), baseline (1,5×) |
| 4 | **Baselines regeradas**: as preparadas antes (para adiantar suítes) × as do roteiro principal | idênticas |
| 5 | **Rodada 1** (oficial): 17/10 21:24 → 18/10 00:07 | 241 + 88 + 34 arquivos de registro; nenhum erro |
| 6 | **Validação da rodada 1**: falhas de método, motivos de abstenção, contagens | sem defeito. A d2c-r se abstém por `sem_diferenca_significativa` (propriedade do método com q = 1e-50) |
| 7 | **Rodada 2** do zero (`bases-externas-r2`): 23:29 → 02:28 | **idêntica byte a byte** à rodada 1 (registros, artefatos e `resultado.md`) |
| 8 | **Revisão de 18/10** (este documento) | §7 |

Custo da baseline do RE2-TT: ~2 h 03 por rodada (5 casos de ~1 M eventos). Cluster minikube parado antes das
rodadas.

## 7. Revisão dos resultados (18/10)

| item | achado | consequência |
|---|---|---|
| reprodutibilidade | rodada 1 = rodada 2 (`cmp` nos três `resultado.md`) | ✅ |
| RCAEval 241 → 240 | o caso sem falha é a exclusão fixada no protocolo (`checkoutservice_cpu/2`, 38 s) | ✅ coerente |
| Market 88 = 77 + 11 | 77 falhas e 11 trechos normais | ✅ coerente |
| **Eadro 32 → 31** | `SN.2022-04-17T190213…/f02`: `network_loss` **no próprio `nginx-web-server`** (a entrada). Só 19 eventos na janela de falha → abaixo da D0.4 → nenhum instante | declarado aqui. É a regra D0.4, igual para todos; não mexe na leitura |
| **afirmação errada no §42.85** | "v-cons-b tem o melhor top-3 em todas as bases" vale para RCAEval e Market, **não para o Eadro**: lá a d2c-r forçada tem top-3 39% e AC@3 0.387, contra 23% e 0.226 do v-cons-b | corrigido no §42.86 |
| exceções por suíte | RE2-TT: d9-k top-1 56% > v-cons-b 43% e F1@1 0.526 > 0.415. RE3-TT: AC@3 da d9-k 0.900 > v-cons-b 0.833 (mas top-3 72% < 85%). RE3-OB: d2c-r top-1 36% é o maior | o v-cons-b ganha no **top-3**, não no top-1 |
| critério da d9-k sem K8s | sem eventos K8s a d9-k é **idêntica** à d9, então "F1@1 ≥ d9" é sempre verdadeiro e a leitura vira só "alarme ≤ 2%" | o "generaliza" no Market é **empate**, não ganho |
| plano × protocolo | o `PLANO.md` §4.1 previa baseline de 10 casos "sem o próprio caso" e lookback de 150 s. O protocolo fixou 5 casos com `na_baseline` fora do alarme e lookback de 600 s (o do TeaStore) | decidido antes de rodar; protocolo vale |
| pendente | o protocolo do RCAEval prevê comparar AC@1/AC@3/Avg@5 com os baselines publicados (TraceRCA, BARO…). Não foi feito: os números publicados precisam ser conferidos na fonte, e o protocolo de janela é diferente | fica como próximo passo |

## 8. Tabela comparativa

TeaStore = coleta definitiva (24 cenários inéditos, `…/protocolo-coleta-definitiva/tabela-unica.md`, §42.80), a
única com eventos K8s. Bases abertas = rodada 1 (= rodada 2).

### 8.1 Completa

| base (casos de falha / instantes normais) | método | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 | top-3 | AC@1 | AC@3 | Avg@5 | leitura fixada |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **TeaStore** definitiva (24 / 120) | **d9-k** | **0.887** [0.777–0.970] | 0.887 | 0.8% | 17% | **98%** | 98% | 98% | — | — | — | ✅ confirma (§42.78) |
| | **v-cons-b** | **0.887** [0.780–0.962] | **0.905** | 0.8% | 17% | **98%** | **100%** | **100%** | — | — | — | ✅ confirma |
| | **d2c-r** | 0.866 [0.737–0.967] | 0.874 | **0.0%** | **2%** | 86% | 88% | 92% | — | — | — | não pré-registrada |
| | d9 (ref.) | 0.739 [0.563–0.880] | 0.739 | 0.8% | 25% | 90% | 90% | 90% | — | — | — | — |
| **RCAEval** RE2/RE3 (240 / 1834) | d9-k | **0.308** [0.254–0.364] | 0.385 | 8% | 21% | **38%** | 48% | 50% | 0.358 | 0.487 | 0.455 | ❌ alarme > 2% |
| | v-cons-b | 0.305 [0.250–0.359] | **0.446** | 8% | 21% | 37% | **54%** | **62%** | **0.371** | **0.613** | **0.548** | ❌ top-3 < 80% |
| | d2c-r | 0.000 [0.000–0.000] | 0.005 | **0%** | 94% | 11% | 20% | 29% | 0.046 | 0.283 | 0.213 | ❌ F1@1 < d9 |
| | d9 (ref.) | 0.308 [0.254–0.364] | 0.385 | 8% | 21% | 38% | 48% | 50% | 0.358 | 0.487 | 0.455 | — |
| **OpenRCA Market** (77 / 121) | d9-k | **0.154** [0.084–0.228] | 0.164 | **0%** | 81% | 22% | 31% | 42% | 0.260 | 0.545 | 0.455 | ✅ generaliza (empate com d9) |
| | v-cons-b | 0.152 [0.083–0.225] | **0.179** | **0%** | 81% | **27%** | **41%** | **53%** | **0.338** | **0.623** | **0.530** | ❌ top-3 < 80% |
| | d2c-r | 0.015 [0.000–0.039] | 0.020 | **0%** | 98% | 17% | 29% | 38% | 0.156 | 0.338 | 0.294 | ❌ F1@1 < d9 |
| | d9 (ref.) | 0.154 [0.084–0.228] | 0.164 | 0% | 81% | 22% | 31% | 42% | 0.260 | 0.545 | 0.455 | — |
| **Eadro SN** (31 / 22) | d9-k | 0.036 [0.000–0.115] | 0.036 | 5% | 23% | 3% | 3% | 3% | 0.032 | 0.032 | 0.032 | ❌ alarme > 2% |
| | v-cons-b | **0.071** [0.000–0.179] | **0.179** | 5% | 23% | 6% | 19% | 23% | 0.065 | 0.226 | 0.187 | ❌ top-3 < 80% |
| | d2c-r | 0.000 [0.000–0.000] | 0.000 | **0%** | 100% | **13%** | **29%** | **39%** | **0.129** | **0.387** | **0.316** | ❌ F1@1 < d9 |
| | d9 (ref.) | 0.036 [0.000–0.115] | 0.036 | 5% | 23% | 3% | 3% | 3% | 0.032 | 0.032 | 0.032 | — |

Negrito = melhor dos três métodos na base. AC@k/Avg@5 não foram medidos no TeaStore.

### 8.2 Resumo por método (F1@1 com portão / top-3 sabendo)

| método | TeaStore | RCAEval | Market | Eadro SN | leituras que passam |
|---|---|---|---|---|---|
| **d9-k** | 0.887 / 98% | 0.308 / 50% | 0.154 / 42% | 0.036 / 3% | Market (empate com d9) |
| **v-cons-b** | 0.887 / 100% | 0.305 / **62%** | 0.152 / **53%** | 0.071 / 23% | nenhuma (só RE3-TT: 85%) |
| **d2c-r** | 0.866 / 92% | 0.000 / 29% | 0.015 / 38% | 0.000 / **39%** | nenhuma |
| d9 (ref.) | 0.739 / 90% | 0.308 / 50% | 0.154 / 42% | 0.036 / 3% | — |

### 8.3 RCAEval por suíte (sabendo top-3: d9-k / v-cons-b / d2c-r)

| suíte | casos | d9-k | v-cons-b | d2c-r | alarme d9-k | F1@1 d9-k / v-cons-b |
|---|---|---|---|---|---|---|
| RE2-OB | 90 | 38% | **51%** | 41% | 1% | 0.187 / **0.269** |
| RE2-TT | 90 | 59% | **71%** | 11% | 18% | **0.526** / 0.415 |
| RE3-OB | 30 | 38% | **43%** | 36% | 0% | 0.082 / **0.098** |
| RE3-TT | 30 | 72% | **85%** | 40% | 9% | 0.162 / **0.259** |

Só gabaritos visíveis (sem os 12 casos invisíveis do RE3-OB): d9-k F1@1 0.325 / top-3 53%; v-cons-b 0.322 / 65%.

### 8.4 McNemar exato pareado

| base | v-cons-b × d9-k (top-3) | d9-k × d9 (F1@1) | d2c-r × d9-k (F1@1) |
|---|---|---|---|
| RCAEval | 36 × 2, p < 0,001 | 0 × 0, p = 1 | 0 × 64, p < 0,001 |
| Market | 14 × 3, p = 0,013 | 0 × 0, p = 1 | 0 × 9, p = 0,004 |
| Eadro SN | 6 × 0, p = 0,031 | 0 × 0, p = 1 | 0 × 1, p = 1 |

## 9. Leitura

1. **A vantagem da d9-k no TeaStore vem do canal K8s.** Sem eventos K8s (nenhuma base aberta tem), a d9-k é idêntica
   à d9 em todos os casos (McNemar 0 × 0). No TeaStore ela sobe a d9 de 0.739 para 0.887. Para o artigo: a
   contribuição da d9-k é **a evidência do orquestrador**, e as bases abertas não conseguem testá-la. **Confirmado
   no TeaStore pela ablação (§11.1):** sem K8s, a d9-k é idêntica à d9 em 240/240 instantes (F1@1 0.739).
2. **O v-cons-b é o melhor localizador nas bases com tráfego limpo.** Tem o maior top-3 e AC@3 no RCAEval e no
   Market, com ganho significativo sobre a d9-k nas três bases. Mas fica abaixo do critério de 80% (62% / 53% /
   23%); só o RE3-TT passa (85%). O ganho está no top-2/top-3, não no top-1 (no RE2-TT a d9-k é melhor no top-1).
3. **A d2c-r não decide fora do TeaStore.** Com q = 1e-50 ela se abstém em 94–100% dos instantes de falha. O ranking
   forçado existe: é o melhor no Eadro (top-3 39%) e no top-1 do RE3-OB (36%). Isso sugere que o problema é o
   limiar, fixado no TeaStore, e não a localização. Um limiar por base seria ajuste, proibido pelo protocolo.
4. **Os números absolutos caem muito fora do TeaStore** (F1@1 0.887 → 0.31 / 0.15 / 0.04). As causas declaradas:
   - sem K8s;
   - TT sem status de erro (portão só por latência; alarme de 18% no RE2-TT);
   - Market com 81% de abstenção (portão quase nunca abre) e rótulos criticados;
   - Eadro com referência contaminada pela falha anterior em todos os casos.
5. **Nenhum dos três generaliza pelo critério fixado**, exceto a d9-k no Market, por empate. O resultado vai ao
   artigo como está: limite de validade externa e motivação para o canal K8s.

## 10. Como reproduzir

Da pasta de cada base, com o venv do Stage 3 + `pyarrow`:

```
# RCAEval
python baseline.py && python rodar.py --jobs 24 && python analisar.py
# OpenRCA Market
python adaptar.py --extrair && python baseline.py && python rodar.py --jobs 24 && python analisar.py
# Eadro
python adaptar.py --extrair && python baseline.py && python rodar.py --jobs 24 && python analisar.py
```

`BASES_EXTERNAS_SAIDA=<pasta>` desvia a saída (rodada 2, teste) e grava `resultado-<pasta>.md`.
`BASES_EXTERNAS_RAPIDO=0` roda sem a aceleração (mesmos registros).

## 11. Ablação do K8s no TeaStore e teto do híbrido d9-k + d2c-r (18/10, exploratório)

### 11.1 d9-k e v-cons-b sem eventos K8s na coleta definitiva

Script: `experimento-falhas/teastore/stage3-online/replay/definitiva_sem_k8s.py`. A medida e os instantes são os
do `definitiva.py`, com uma única troca: nenhum evento K8s chega à entrada. Resultado completo em
`…/protocolo-coleta-definitiva/resultado-sem-k8s.md`; registros em `…/sem-k8s/`.

| método | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-3 |
|---|---|---|---|---|---|---|
| d9-k com K8s | **0.887** [0.777–0.970] | 0.887 | 0.8% | 17% | 98% | 98% |
| **d9-k sem K8s** | 0.739 [0.563–0.880] | 0.739 | 0.8% | 25% | 90% | 90% |
| v-cons-b com K8s | **0.887** [0.780–0.962] | 0.905 | 0.8% | 17% | 98% | **100%** |
| **v-cons-b sem K8s** | 0.749 [0.574–0.885] | 0.758 | 0.8% | 25% | 91% | 92% |
| d2c-r (não usa K8s) | 0.866 [0.737–0.967] | 0.874 | **0.0%** | **2%** | 86% | 92% |
| d9 (não usa K8s) | 0.739 [0.563–0.880] | 0.739 | 0.8% | 25% | 90% | 90% |

- **d9-k sem K8s = d9 instante a instante:** 240/240 instantes, com a mesma decisão, o mesmo 1º serviço e o mesmo
  ranking forçado top-3.
- **O K8s salva 4 cenários da d9-k**: h2-recommender-oom ×2 e g4-db-memory-limit ×2 (McNemar 4 × 0, p = 0,125).
- **Sem K8s, o d2c-r passa a ser o melhor dos três** no TeaStore (0.866 contra 0.749 e 0.739).

### 11.2 Por que o d2c-r vai mal nas bases abertas: depende do tipo de falha

Sabendo top-1 por tipo (`*/resultado.md`):

| tipo de falha | o que muda | d2c-r | d9-k (= d9) |
|---|---|---|---|
| RCAEval cpu / mem / disk / delay / socket / loss (180 casos) | latência | 1–7% | 29–67% |
| RCAEval f1–f5, falhas de código (RE3, 57 casos) | estrutura | 0–58% (f5 48%, f1 37%) | 15–63% (f5 15%, f1 32%) |
| Market packet loss | estrutura | **43%** | 24% |
| Eadro network_loss | estrutura | **27%** | 0% |
| Eadro cpu_load | latência | 0% | 12% |

A d9 vê **latência**; a d2c-r vê **estrutura**: sequências e erros, por testes de Fisher sobre contagens. A maior
parte do RCAEval é falha de recurso, que não muda a sequência de chamadas. Além disso, o q = 1e-50 do TeaStore
quase nunca é atingido fora dele (abstém em 94–100%).

### 11.3 Teto do híbrido (`bases-externas/teto_hibrido.py`)

Duas medidas, só com registros já gravados:
- **teto** = oráculo por instante, que fica com o que acertar (portão OU; no normal, alarme se qualquer um alarmar);
- **regra** = d9-k; se ela se abstiver e a d2c-r decidir, vale a d2c-r. Não tem parâmetro novo.

| base | casos | d9-k F1@1 / top-1 | d2c-r | v-cons-b | **teto** F1@1 / top-1 | **regra** F1@1 / alarme | só d9-k / só d2c-r / os dois / nenhum (top-1 sabendo, por caso) |
|---|---|---|---|---|---|---|---|
| TeaStore definitiva | 24 | 0.887 / 98% | 0.866 / 86% | 0.887 / 98% | **0.979** / 98% | **0.979 / 0.8%** | 3 / 0 / 21 / 0 |
| RCAEval | 240 | 0.308 / 38% | 0.000 / 11% | 0.305 / 37% | 0.307 / **43%** | 0.307 / 8.3% | 70 / 13 / 14 / 143 |
| OpenRCA Market | 77 | 0.154 / 22% | 0.015 / 17% | 0.152 / 27% | 0.154 / **32%** | 0.154 / 0.0% | 15 / 9 / 3 / 50 |
| Eadro SN | 31 | 0.036 / 3% | 0.000 / 13% | 0.071 / 6% | 0.036 / **16%** | 0.036 / 4.5% | 1 / 4 / 0 / 26 |

**Leitura:**
- **No TeaStore o ganho está na detecção.** A d2c-r decide exatamente onde o portão da d9-k fica fechado
  (recommender h6/g5). A regra simples sobe o F1@1 de 0.887 para **0.979** sem aumentar o alarme.
- **Nas bases abertas o ganho estaria só na localização** (+4 a +13 pp de top-1 no oráculo). Lá a d2c-r não decide,
  então a regra simples não muda nada. Aproveitar isso exigiria uma regra de escolha nova, com parâmetros.
- **Ressalva:** a regra foi escolhida depois de ver estes dados, que são o teste definitivo do TeaStore e as três
  bases abertas. É **exploratória**; confirmar exige protocolo pré-registrado e dados novos.

## 12. Híbrido d9+a / d9-k+a: pré-registro e mesma bateria dos modelos anteriores (18/10)

Pré-registro: `d9a/PROTOCOLO.md` (commit `47bd0a68`) e emenda §6 (`f26c55a3`: RCAEval limitado a 10 min, 28 casos
inéditos). Depois, a pedido do usuário, a **mesma bateria completa** dos modelos anteriores: TeaStore dev,
confirmatório e definitiva (`replay/hibrido_d9a.py`, mesma entrada do `paridade_solucoes`; d9 e d9-k refeitos =
números oficiais) e as três bases abertas inteiras (`d9a/resultado-<base>.md`).

- **d2c-a** = d2c-r com q = 1e-3 × min p_min das 2–3 janelas anteriores da sessão (exato).
- **d9+a** = d9, ou d2c-a quando a d9 abstém.
- **d9-k+a** = d9-k, ou d2c-a.

### Tabela única — F1@1 sem saber / alarme / sabendo top-1

| modelo | TeaStore dev (54) | TeaStore confirmatório (18) | TeaStore definitiva (24) | RCAEval (240) | Market (77) | Eadro SN (31) |
|---|---|---|---|---|---|---|
| d9-k | 0.710 / 0.4% / 76% | **0.590** / 0% / 61% | 0.887 / 0.8% / 98% | 0.308 / 8.3% / 38% ¹ | 0.154 / 0% / 21% ¹ | 0.036 / 4.5% / 3% ¹ |
| v-cons-b | 0.670 / 0.4% / 76% | 0.577 / 0% / 54% | 0.887 / 0.8% / 98% | 0.305 / 8% / 37% | 0.152 / 0% / **27%** | **0.071** / 5% / 6% |
| d2c-r ² | 0.467 / 0% / 47% | 0.263 / 0% / 26% | 0.782 / 0% / 77% | 0.005 / 0% / 11% | 0.017 / 0% / 18% | 0.000 / 0% / 13% |
| **d9-k+a** (híbrido, com K8s) | **0.749** / 0.4% / 76% | 0.571 / 0% / 61% | **0.979** / 0.8% / 98% | **0.348** / 8.9% / 38% ³ | **0.166** / 0% / 21% ³ | 0.035 / 4.5% / 3% ³ |
| **d9+a** (híbrido, sem K8s) | 0.674 / 0.4% / 70% | 0.553 / 0% / 61% | 0.896 / 0.8% / 90% | **0.348** / 8.9% / 38% | **0.166** / 0% / 21% | 0.035 / 4.5% / 3% |
| d2c-a | 0.457 / 0% / 47% | 0.263 / 0% / 26% | 0.767 / 0% / 77% | 0.142 / 0.6% / 11% | 0.071 / 0% / 18% | 0.000 / 0% / 13% |
| d9 (referência) | 0.631 / 0.4% / 70% | 0.472 / 0% / 61% | 0.739 / 0.8% / 90% | 0.308 / 8.3% / 38% | 0.154 / 0% / 21% | 0.036 / 4.5% / 3% |

¹ sem K8s nas bases abertas, d9-k = d9. ² d2c-r pela entrada do avaliador de paridade (a mesma do híbrido); no
avaliador unificado (§42.68) a definitiva dá 0.866 e o dev 0.445. ³ sem K8s, d9-k+a = d9+a.
Ganho do híbrido sobre o primário (McNemar, top-1 com portão): definitiva d9-k+a × d9-k 4 × 0 (p = 0,125), d9+a × d9
6 × 0 (p = 0,031); dev 3 × 0 (p = 0,25); RCAEval 202 inéditos d9+a × d9 11 × 0 (p = 0,001), ΔF1@1 +0.040 [+0.020;
+0.063].


**Leituras do pré-registro (RCAEval):**

| conjunto | d9+a × d9 | d2c-a × d2c-r |
|---|---|---|
| amostra da emenda (27 inéditos; `d9a/resultado-rcaeval-amostra27.md`) | ΔF1@1 +0.041 [−0.002; +0.104], alarme +1,3 pp → **não melhora** (IC cruza 0; poder baixo) | +0.172 [+0.008; +0.322], alarme 1,3% → **melhora** |
| 202 inéditos (desenho original §4.1, rodado depois para a bateria completa) | ΔF1@1 +0.040 [+0.020; +0.063], alarme 9,0% × 8,2% (+0,8 pp) → **melhora** | +0.128 [+0.074; +0.184], alarme 0,9% → **melhora** |

A leitura oficial da emenda é a dos 27; os 202 contêm os 27 e são reportados por transparência. O critério de
generalização original (F1@1 ≥ d9 e alarme ≤ 2%) não passa no RCAEval para nenhum modelo (o alarme da d9 já é 8%).

**Avaliação:**
1. **O híbrido é o melhor modelo em F1@1 em 4 de 6 conjuntos** (dev, definitiva, RCAEval, Market). Empata no Eadro e
   perde 0.019 para a d9-k no confirmatório (mas ganha em F1@2: 0.634 × 0.590).
2. **O ganho vem da detecção:** a d2c-a cobre a abstenção do primário (definitiva: 17% → 0%; RCAEval: 21% → 15%), com
   alarme igual no TeaStore e +0,6 pp no RCAEval. A localização ("sabendo") não muda, porque o forçado é o do
   primário.
3. **Sem K8s, o d9+a melhora a d9 em todos os conjuntos menos o Eadro:** +0.043 dev, +0.081 confirmatório, +0.157
   definitiva (p = 0,031), +0.040 RCAEval inéditos (p = 0,001), +0.012 Market.
4. **A d2c-a sozinha** tira a d2c-r do zero nas bases abertas, mas no TeaStore fica igual ou um pouco abaixo da
   d2c-r. O valor dela está em ser o **fallback** do híbrido.
5. **Ressalvas:** os conjuntos do TeaStore já tinham sido vistos (descritivo). A d2c-a e o híbrido nasceram do
   pré-teste. A única evidência fora da amostra são os casos inéditos do RCAEval. Com poucos cenários no TeaStore,
   só a definitiva sem K8s tem p < 0,05.

## 13. Decisão: Eadro SN fora das próximas rodadas (18/10/2026)

Decisão do usuário, depois da generalização do `g-m∨t|mf` (`metricas-rz/PROTOCOLO.md` §Generalização). O Eadro SN
teve o pior desempenho de todas as bases com todos os métodos:
- F1@1 de 0.036 a 0.071 com d9-k, v-cons-b e d2c-r;
- 0.277 com o `g-m∨t|mf`, com top-1 sabendo de 29%.

Ele sai das próximas rodadas. As bases ativas passam a ser **TeaStore, RCAEval e OpenRCA Market**. Os resultados já
medidos no Eadro ficam como estão, e nada é apagado.

## 14. `g-m∨t|mf` e `g-m∨t∨k|mfk`: protocolo completo, literatura e robustez (18/10/2026)

Detalhes em `metricas-rz/RESULTADO-ARTIGO.md` (protocolo em `metricas-rz/PROTOCOLO-COMPLETO.md`, emendas 1–3).

- **Confirmados:** A (RCAEval inédito, só métricas), H-k1 (K8s melhora) e H-k2 (meta com K8s nos 17 inéditos do
  TeaStore).
- **Não confirmado:** B′ sem K8s.
- **Robustos:** superioridade sobre a d9 e a d9+a no RCAEval com traces e no Market, e sobre o BARO e o N-Sigma em
  AC@1 nas bases abertas.
- **Não robustos:** a meta absoluta em A e em B′ (no limiar) e o ganho do K8s na permutação (p = 0,13).
