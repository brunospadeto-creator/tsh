# Pré-teste — limiares calculados pela baseline (d9-b, d2c-b, d9-b+c)

Escrito em 18/10/2026 (ARQ), **antes** de medir o desempenho. Pedido do usuário: nenhum valor fixo igual para todas
as bases; os limiares vêm da baseline de cada sistema e são recalculados para cada um. Métodos com **nomes novos**,
para não se misturarem às medidas anteriores (d9, d9-k, d2c-r, d2c-a, d9+a, d9-k+a ficam como estão). Nada de `src/`
muda (`calib.py` usa as funções do produto como utilitários).

Para calibrar, só foram vistos λ, q e quantas janelas abririam o portão no RCAEval. Nenhum F1 ou alarme foi visto.

## 1. Métodos

| nome | regra (detalhe em `calib.py`) |
|---|---|
| **d9-b** | portão: atividade passa se `escore_efeito ≥ λ·M_a`. `M_a` é o maior escore da atividade nas janelas normais da baseline; `λ` sai da validação cruzada deixando a janela de fora, de modo que ⌊FP_ALVO·n⌋ janelas da baseline abririam. Ranking `residuo_1`; forçado = o da d9 |
| **d2c-b** | `q = calibracao.quantil_q(p_min das janelas da baseline, FP_ALVO)`; decide e ranqueia com `d2cr.decidir(q)` |
| **d9-b+c** | d9-b; se abstiver, d2c-b. Forçado = o da d9 |
| d9-k-b (só TeaStore) | portão d9-b **ou** evento K8s de sintoma; ranking = o `ranking_base` da d9-k (residuo_1 → efeito da d5 → profundo) sobre o que passou na d9-b; se só o K8s abriu, o forçado da d9-k; serviço K8s no 1º lugar |
| d9-k-b+c (só TeaStore) | d9-k-b; se abstiver, d2c-b |

**Única constante de política:** `FP_ALVO = 0,05`, o padrão do `calibracao.py` do produto. Como sensibilidade
exploratória, também `0,01`.

Ficam fixos, por serem estruturais:
- janela de 120 s;
- referência de 150 s;
- passo de 60 s;
- D0.4 (mínimo de 30 traces);
- mínimo de eventos por atividade;
- peso 10 do erro no `escore_efeito`.

## 2. Baselines (sem gabarito)

| base | baseline | janelas |
|---|---|---|
| RCAEval | por suíte, os instantes normais dos 5 casos `na_baseline`, os mesmos da baseline do v-cons-b. Eles já saem da medida de alarme | 40 (RE3-TT 55) |
| TeaStore definitiva | coleção `32c273a6`, baseline de 90 min (`traces_baseline.json.gz`), em janelas como as dos instantes online | ~85 |

## 3. Pré-teste (≤ 10 min por base)

- **TeaStore definitiva:** 24 cenários, 240 instantes, mesma entrada do `hibrido_d9a.py`. Comparação com d9, d9-k,
  d9+a e d9-k+a (refeitos ou lidos).
- **RCAEval:** os 240 casos de falha, a partir dos registros do `d9a`, que guardam os efeitos, o grafo e o p_min por
  instante.
  - A d9-b é exata.
  - A d2c-b tem decisão exata pelo p_min.
  - O ranking da d2c-b é refeito exato com `d2cr.decidir(q)` nos instantes em que ela decide, até o limite de
    10 min. O que não couber fica com o ranking de q = 1 (aproximação declarada), e a fração exata é reportada.
- **Medidas:** as do `../d9a/` (F1@1/2 com portão, alarme, abstenção, sabendo top-1/2, IC por caso, McNemar).
- **Leitura:** pré-teste, descritivo. Os casos já foram vistos por outros métodos. Serve para decidir se vale um
  pré-registro e uma rodada completa.
