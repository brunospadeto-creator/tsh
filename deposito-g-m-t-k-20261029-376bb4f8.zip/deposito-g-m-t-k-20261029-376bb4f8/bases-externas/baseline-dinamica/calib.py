"""Limiares calculados pela baseline (`PROTOCOLO.md`): portão da d9 → **d9-b**, q da d2c-r → **d2c-b**.

Nomes novos de propósito: d9, d9-k, d2c-r, d2c-a, d9+a e d9-k+a ficam como foram medidos. Nada de `src/` muda; as
funções do produto são usadas como utilitários.

Única constante de política: `FP_ALVO` (fração das janelas normais da baseline que podem decidir), a mesma regra do
`calibracao.py` do produto ("limiar = meta de falso positivo medida em dado normal"). Nenhum gabarito entra.

- **d9-b** — escore por atividade `e = referencia.escore_efeito` (o mesmo da ordem da d9: max(razão, 1 + 10·Δerro)).
  Na baseline, `M_a` = maior `e` da atividade `a` nas janelas normais (cada uma contra os seus 150 s anteriores,
  como no instante online). Portão: abre se alguma atividade tem `e ≥ λ·M_a` (atividade ausente da baseline → `λ·M`
  com `M` = maior `e` de qualquer atividade). `λ` é escolhido por validação cruzada deixando a janela de fora:
  `λ_w = max_a e_a(w) / M_a(−w)`; com `k = ⌊FP_ALVO·n⌋`, `λ` fica logo acima do `(k+1)`-ésimo maior `λ_w` →
  exatamente `k` janelas da baseline abririam. Ranking = `d9.ranquear(passou, ctx, "residuo_1")`; forçado = o da d9.
- **d2c-b** — `q = calibracao.quantil_q(p_min das janelas da baseline, FP_ALVO)` (função do produto). Decide e
  ranqueia com `d2cr.decidir(q)` (exato).
- **d9-b+c** — d9-b; se abstiver, d2c-b. Forçado = o da d9. No TeaStore, **d9-k-b** = portão da d9-b OU evento K8s
  de sintoma (ranking = o `ranking_base` da d9-k sobre o que passou na d9-b, serviço K8s promovido ao 1º) e
  **d9-k-b+c** = d9-k-b; se abstiver, d2c-b.
"""
from __future__ import annotations

import math
from collections.abc import Iterable, Iterator
from typing import Any

from src.application.stage3.abordagens import calibracao, referencia

FP_ALVO = 0.05
JANELA, PASSO, LOOKBACK, MIN_TRACES = 120, 60, 600, 30


def janelas_normais(eventos: list[Any], entry_services: list[str]) -> Iterator[Any]:
    """Janelas da baseline como os instantes normais online: 120 s, passo 60 s, a partir de 120 + 150 s do início
    (passado na própria baseline), lookback = passado real; D0.4 (< 30 traces) fica fora."""
    import bisect  # noqa: PLC0415
    import datetime  # noqa: PLC0415

    from src.application.stage3.abordagens import processo  # noqa: PLC0415
    from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: PLC0415

    por_fim = sorted(eventos, key=lambda e: int(e.start_us) + int(e.duration_us))
    fins = [int(e.start_us) + int(e.duration_us) for e in por_fim]

    def entre(a: int, b: int) -> list[Any]:
        return processo.ordenar(por_fim[bisect.bisect_left(fins, a):bisect.bisect_right(fins, b)])

    def dt(us: int) -> datetime.datetime:
        return datetime.datetime.fromtimestamp(us / 1e6, datetime.UTC).replace(tzinfo=None)

    if not fins:
        return
    j, ini, fim = JANELA * 1_000_000, int(min(int(e.start_us) for e in eventos)), fins[-1]
    t = ini + j + 150 * 1_000_000
    while t <= fim:
        dentro = entre(t - j, t)
        if len({e.case_id for e in dentro}) >= MIN_TRACES:
            yield EntradaIncidente(incidente_id=f"baseline@{t}", janela=(dt(t - j), dt(t)), abertura_incidente=dt(t),
                                   traces=dentro, traces_lookback=entre(t - j - LOOKBACK * 1_000_000, t - j),
                                   metricas={}, eventos_k8s=[], config_sistema={"entry_services": entry_services})
        t += PASSO * 1_000_000


def medir(ent: Any, sis: dict[str, Any], portao_d9: dict[str, Any]) -> dict[str, Any]:
    """Efeitos da d9 (todas as atividades) e p_min da d2c-r permissiva de uma janela."""
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    from src.application.stage3.abordagens import d5_portao as d5  # noqa: PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415

    cfg9 = d9._cfg({**sis, **portao_d9})
    raiz = d5._entradas(ent, cfg9)
    ref = referencia.estatisticas(d5._eventos_ref(ent, cfg9), servicos_raiz=raiz)
    efeitos = d5.medir(referencia.estatisticas(ent.traces, servicos_raiz=raiz), ref, cfg9)["efeitos"]
    try:
        d = d2cr.decidir(ent, {}, {**sis, "q": 1.0})
        pm = (d.evidencias or {}).get("p_min_ajustado")
        pm = float(pm) if pm is not None else 1.0
    except Exception:  # noqa: BLE001
        pm = 1.0
    return {"efeitos": efeitos, "p_min": pm}


def _escores(efeitos: Iterable[dict[str, Any]]) -> dict[str, float]:
    out: dict[str, float] = {}
    for e in efeitos:
        a = str(e.get("atividade"))
        out[a] = max(out.get(a, 0.0), referencia.escore_efeito(e))
    return out


def calibrar(janelas: list[dict[str, Any]], fp_alvo: float = FP_ALVO) -> dict[str, Any]:
    """`janelas` = saídas de `medir` nas janelas da baseline → calibração da d9-b e da d2c-b."""
    es = [_escores(w["efeitos"]) for w in janelas]
    n = len(es)
    lambdas = []
    for i, w in enumerate(es):
        outros: dict[str, float] = {}
        for j, o in enumerate(es):
            if j != i:
                for a, v in o.items():
                    outros[a] = max(outros.get(a, 0.0), v)
        mg = max(outros.values(), default=0.0)
        lw = 0.0
        for a, v in w.items():
            ref = outros.get(a, mg)
            if ref > 0:
                lw = max(lw, v / ref)
        lambdas.append(lw)
    m: dict[str, float] = {}
    for w in es:
        for a, v in w.items():
            m[a] = max(m.get(a, 0.0), v)
    k = int(math.floor(fp_alvo * n + 1e-12))
    ordem = sorted(lambdas, reverse=True)
    lam = math.nextafter(ordem[k], math.inf) if k < n else 0.0
    q = calibracao.quantil_q([w["p_min"] for w in janelas], fp_alvo)
    return {"fp_alvo": fp_alvo, "n_janelas": n, "lambda": lam, "M": m, "M_global": max(m.values(), default=0.0),
            "q_d2cb": q, "k": k}


def passou_d9b(efeitos: list[dict[str, Any]], cal: dict[str, Any]) -> list[dict[str, Any]]:
    lam, m, mg = cal["lambda"], cal["M"], cal["M_global"]
    return [e for e in efeitos if referencia.escore_efeito(e) >= lam * m.get(str(e.get("atividade")), mg)]
