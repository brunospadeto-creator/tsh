"""Caso de uma base → instantes de 60 s → `EntradaIncidente`, com a mesma regra do avaliador do TeaStore.

- **normal:** um instante a cada `PASSO` s dentro de cada período normal, a partir de `JANELA + REF` s do início
  (precisa de passado na própria sessão); lookback = passado real.
- **falha ("estável"):** um instante a cada `PASSO` s a partir de `injeção + JANELA` (janela inteira dentro da
  falha) até o fim da falha, com teto de `TETO_FALHA` s; lookback = o período pré-falha, **deslocado** para terminar
  no início da janela (pré-falha deslocado do avaliador unificado).
- D0.4: instante com menos de `MIN_TRACES` traces na janela fica fora, para todos os métodos.
"""
from __future__ import annotations

import bisect
import copy
import datetime
from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any

from src.application.stage3.abordagens import processo
from src.application.stage3.abordagens.base import EntradaIncidente

JANELA = 120
PASSO = 60
REF = 150            # ref_seg dos métodos (d9-k, d9, d2c-r)
LOOKBACK = 600       # passado entregue ao método (ele corta o seu ref_seg dentro)
TETO_FALHA = 600
MIN_TRACES = 30


@dataclass
class Caso:
    """Uma unidade de avaliação. `falha`/`pre` em µs (epoch UTC); `normais` = períodos normais com passado real."""

    id: str
    base: str
    grupo: str                       # sistema/suíte, ex.: "RE2-OB"
    tipo: str                        # tipo de falha ("" para caso só normal)
    gabarito: str | None             # serviço causa (None = sem gabarito de serviço)
    eventos: list[Any]
    sistema: dict[str, Any]
    falha: tuple[int, int] | None = None
    pre: tuple[int, int] | None = None
    normais: list[tuple[int, int]] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)


def _dt(us: int) -> datetime.datetime:
    return datetime.datetime.fromtimestamp(us / 1e6, datetime.UTC).replace(tzinfo=None)


class Fatiador:
    """`processo.cortar_janela` (eventos que **terminam** na janela) por busca binária."""

    def __init__(self, eventos: list[Any]) -> None:
        self.por_fim = sorted(eventos, key=lambda e: int(e.start_us) + int(e.duration_us))
        self.fins = [int(e.start_us) + int(e.duration_us) for e in self.por_fim]

    def entre(self, ini_us: int, fim_us: int) -> list[Any]:
        a, b = bisect.bisect_left(self.fins, ini_us), bisect.bisect_right(self.fins, fim_us)
        return processo.ordenar(self.por_fim[a:b])


def _deslocar(eventos: list[Any], delta_us: int) -> list[Any]:
    """= `dataclasses.replace(e, start_us=…)` (cópia rasa, `attributes` compartilhado), sem passar pelo `__init__`."""
    saida = []
    for e in eventos:
        n = copy.copy(e)
        n.start_us = int(e.start_us) + delta_us
        saida.append(n)
    return saida


def entradas(caso: Caso, ref: int = REF) -> Iterator[tuple[str, datetime.datetime, EntradaIncidente, int]]:
    """`(período, t, entrada, n_traces)` em ordem de tempo dentro de cada período."""
    fat = Fatiador(caso.eventos)
    cfg_sis = {"entry_services": caso.sistema["entry_services"]}
    j, p = JANELA * 1_000_000, PASSO * 1_000_000

    def montar(t_us: int, lookback: list[Any]) -> tuple[EntradaIncidente, int]:
        dentro = fat.entre(t_us - j, t_us)
        n = len({e.case_id for e in dentro})
        ent = EntradaIncidente(incidente_id=f"{caso.id}@{t_us}", janela=(_dt(t_us - j), _dt(t_us)),
                               abertura_incidente=_dt(t_us), traces=dentro, traces_lookback=lookback, metricas={},
                               eventos_k8s=[], config_sistema=cfg_sis)
        return ent, n

    for ini, fim in caso.normais:
        t = ini + j + ref * 1_000_000
        while t <= fim:
            ent, n = montar(t, fat.entre(t - j - LOOKBACK * 1_000_000, t - j))
            if n >= MIN_TRACES:
                yield "normal", _dt(t), ent, n
            t += p
    if caso.falha and caso.pre:
        ini, fim = caso.falha
        pre = fat.entre(*caso.pre)
        t, ultimo = ini + j, min(fim, ini + TETO_FALHA * 1_000_000)
        while t <= ultimo:
            ent, n = montar(t, _deslocar(pre, (t - j) - caso.pre[1]))
            if n >= MIN_TRACES:
                yield "falha", _dt(t), ent, n
            t += p


def encadear(segmentos: list[list[Any]]) -> list[Any]:
    """Junta períodos normais de sessões diferentes num só, contíguo no tempo (para a baseline do v-cons-b).

    Sem isso, as janelas deslizantes da a0-b e da d6 percorreriam os dias vazios entre as sessões. Cada segmento é
    deslocado para começar onde o anterior termina; a ordem interna e as durações não mudam.
    """
    saida: list[Any] = []
    fim_anterior: int | None = None
    for seg in segmentos:
        if not seg:
            continue
        ini = min(int(e.start_us) for e in seg)
        delta = 0 if fim_anterior is None else fim_anterior - ini
        saida += _deslocar(seg, delta) if delta else list(seg)
        fim_anterior = max(int(e.start_us) + int(e.duration_us) for e in seg) + delta
    return processo.ordenar(saida)
