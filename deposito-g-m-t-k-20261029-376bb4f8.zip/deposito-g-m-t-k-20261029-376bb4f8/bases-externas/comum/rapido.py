"""Aceleração **exata** da avaliação, sem alterar `src/` (só neste processo, por substituição de atributos de módulo).

Perfil de 1 caso do RCAEval (RE2-OB, 2 instantes, 5 métodos, 97 s): `processo.filhos_de`/`duracao_propria`
(varredura O(n) por evento → O(n²) por trace) ~30 s; a d9-k calculada 2× por instante (sozinha e dentro do v-cons-b)
~23 s; a d2c-r refazendo o artefato rolante e as medidas da janela na decisão permissiva; a d6 do v-cons-b repetindo
as mesmas medidas da janela. As trocas abaixo devolvem exatamente o mesmo valor:

1. `filhos_de`/`duracao_propria`: índice pai → filhos por sequência (a mesma lista, reaproveitado enquanto for o
   mesmo objeto); mesma comparação de `parent_span_id` como texto, mesma ordenação.
2. `d9k.decidir`: memória por instante, chave = (entrada, configuração normalizada por `d9k._cfg`).
3. `d2cr.artefato_rolante`: memória por instante, chave sem o `q` (o `q` só é copiado para `calibracao`).
4. `d2.medidas_por_trace`: memória por instante, chave = identidade dos eventos de cada sequência (os chamadores
   só leem o resultado: `d2c.decidir`/`d2.decidir` iteram as chaves, `construir_artefato` copia para o artefato);
5. `d6.grafo_de_servicos` e `referencia.estatisticas`: memória por instante, chave = identidade dos eventos (+
   dependências / serviços raiz); devolvem cópia (conjuntos copiados; estatísticas em `deepcopy`).

`BASES_EXTERNAS_RAPIDO=0` desliga tudo (para o teste de igualdade). `limpar()` é chamado a cada instante.
"""
from __future__ import annotations

import copy
import json
import os
from collections import defaultdict
from typing import Any

from src.application.stage3.abordagens import d2_diferencial as d2
from src.application.stage3.abordagens import d6_residuo as d6
from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr
from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k
from src.application.stage3.abordagens import processo, referencia

LIGADO = os.environ.get("BASES_EXTERNAS_RAPIDO", "1") != "0"
_memo: dict[Any, Any] = {}
_ultimo_seq: list[Any] = [None, None]          # [sequência, índice]
_orig: dict[str, Any] = {}


def limpar() -> None:
    _memo.clear()
    _ultimo_seq[0] = _ultimo_seq[1] = None


def _indice(sequencia: Any) -> dict[str, list[Any]]:
    if _ultimo_seq[0] is not sequencia:
        idx: dict[str, list[Any]] = defaultdict(list)
        for c in sequencia:
            idx[str((getattr(c, "attributes", None) or {}).get("parent_span_id") or "")].append(c)
        _ultimo_seq[0], _ultimo_seq[1] = sequencia, idx
    return _ultimo_seq[1]


def _filhos_de(evento: Any, sequencia: Any) -> list[Any]:
    return processo.ordenar(_indice(sequencia).get(str(getattr(evento, "span_id", "")), []))


def _duracao_propria(evento: Any, sequencia: Any) -> int:
    total = int(getattr(evento, "duration_us", 0))
    soma = sum(int(getattr(f, "duration_us", 0)) for f in _indice(sequencia).get(str(getattr(evento, "span_id", "")), []))
    return max(0, total - soma)


def _chave_cfg(cfg: dict[str, Any]) -> str:
    return json.dumps(cfg, sort_keys=True, default=str)


def _d9k_decidir(entrada: Any, artefato: dict[str, Any], cfg: dict[str, Any]) -> Any:
    if artefato:
        return _orig["d9k"](entrada, artefato, cfg)
    chave = ("d9k", id(entrada), _chave_cfg(d9k._cfg(cfg)))
    if chave not in _memo:
        _memo[chave] = (entrada, _orig["d9k"](entrada, artefato, cfg))
    return _memo[chave][1]


def _artefato_rolante(entrada: Any, cfg: dict[str, Any]) -> dict[str, Any]:
    chave = ("d2cr", id(entrada), _chave_cfg({k: v for k, v in cfg.items() if k != "q"}))
    if chave not in _memo:
        _memo[chave] = (entrada, _orig["rolante"](entrada, cfg))
    art = copy.deepcopy(_memo[chave][1])
    if art:
        art["calibracao"]["q"] = float(cfg["q"])
    return art


def _medidas_por_trace(sequencias: list[list[Any]]) -> dict[str, Any]:
    chave = ("medidas", tuple(tuple(id(e) for e in s) for s in sequencias))
    if chave not in _memo:
        _memo[chave] = (sequencias, _orig["medidas"](sequencias))
    return _memo[chave][1]


def _grafo_de_servicos(eventos: list[Any], dependencias: dict[str, str]) -> dict[str, set[str]]:
    eventos = list(eventos)
    chave = ("grafo", tuple(id(e) for e in eventos), _chave_cfg(dependencias))
    if chave not in _memo:
        _memo[chave] = (eventos, _orig["grafo"](eventos, dependencias))
    return {k: set(v) for k, v in _memo[chave][1].items()}


def _estatisticas(eventos: Any, *, servicos_raiz: Any = None, min_eventos: int = 1) -> dict[str, Any]:
    eventos = list(eventos)
    chave = ("estat", tuple(id(e) for e in eventos), _chave_cfg([servicos_raiz, min_eventos]))
    if chave not in _memo:
        _memo[chave] = (eventos, _orig["estat"](eventos, servicos_raiz=servicos_raiz, min_eventos=min_eventos))
    return copy.deepcopy(_memo[chave][1])


def ativar(completo: bool = True) -> bool:
    """`completo=False` (preparo da baseline): só o índice de filhos (1), que não guarda nada entre chamadas."""
    if not LIGADO or _orig:
        return LIGADO
    if not completo:
        processo.filhos_de = _filhos_de
        processo.duracao_propria = _duracao_propria
        _orig["so_arvore"] = True
        return True
    _orig.update({"d9k": d9k.decidir, "rolante": d2cr.artefato_rolante, "medidas": d2.medidas_por_trace,
                  "grafo": d6.grafo_de_servicos, "estat": referencia.estatisticas})
    processo.filhos_de = _filhos_de
    processo.duracao_propria = _duracao_propria
    d9k.decidir = _d9k_decidir
    d2cr.artefato_rolante = _artefato_rolante
    d2.medidas_por_trace = _medidas_por_trace
    d6.grafo_de_servicos = _grafo_de_servicos
    referencia.estatisticas = _estatisticas
    return True
