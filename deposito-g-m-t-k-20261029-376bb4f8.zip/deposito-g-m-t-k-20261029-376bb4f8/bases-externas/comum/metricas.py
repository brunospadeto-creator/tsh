"""Métricas das bases externas: as da coleta definitiva do TeaStore + as do RCAEval (AC@k, Avg@5).

- com portão: F1@k somando contagens dos instantes (alarme no normal conta como erro; abstenção na falha, como
  perda) — mesma fórmula de `protocolo_rapido_analise.f1`;
- alarme = decisões em instantes normais / instantes normais; abstenção = 1 − decisões / instantes de falha;
- sabendo que é falha: top-k do ranking forçado, média por caso;
- AC@k (RCAEval): por caso, o gabarito no top-k do ranking forçado do **1º instante de falha**; Avg@5 = média de
  AC@1..AC@5 (os métodos devolvem top-3, então AC@4 = AC@5 = AC@3 — declarado);
- IC 95% por bootstrap de caso (2000, semente fixa); McNemar exato bilateral pareado por caso (acerto majoritário).
"""
from __future__ import annotations

import gzip
import json
import math
import random
from collections import Counter, defaultdict
from collections.abc import Callable, Iterable
from typing import Any

SEMENTE = 20261017
N_BOOT = 2000


def ler(caminhos: Iterable[str]) -> list[dict[str, Any]]:
    out = []
    for c in caminhos:
        with gzip.open(c, "rt") as f:
            out += [json.loads(x) for x in f if x.strip()]
    return out


def por_caso(linhas: list[dict[str, Any]]) -> dict[str, dict[str, dict[str, Any]]]:
    """`{método: {caso: contagens}}` (só casos com gabarito contam a parte de falha)."""
    acc: dict[str, dict[str, Counter]] = defaultdict(lambda: defaultdict(Counter))
    primeiro: dict[tuple[str, str], tuple[str, list[str]]] = {}
    meta: dict[str, dict[str, Any]] = {}
    for r in linhas:
        c = acc[r["metodo"]][r["caso"]]
        meta[r["caso"]] = {"grupo": r["grupo"], "tipo": r["tipo"], "gabarito": r["gabarito"]}
        dec = r["status"] == "decidiu" and bool(r["ranking"])
        if r["periodo"] == "normal":
            c["n_nor"] += 1
            c["alarme"] += dec
            continue
        esp = r["gabarito"]
        if not esp:
            continue
        c["n_est"] += 1
        c["dec"] += dec
        for k in (1, 2, 3):
            c[f"tp{k}"] += dec and esp in r["ranking"][:k]
            c[f"o{k}"] += esp in (r["forcado"] or [])[:k]
        chave = (r["metodo"], r["caso"])
        if chave not in primeiro or r["t"] < primeiro[chave][0]:
            primeiro[chave] = (r["t"], r["forcado"] or [])
    saida: dict[str, dict[str, dict[str, Any]]] = {}
    for m, casos in acc.items():
        saida[m] = {}
        for caso, c in casos.items():
            d = dict(c)
            d.update(meta[caso])
            if (m, caso) in primeiro:
                rk, esp = primeiro[(m, caso)][1], meta[caso]["gabarito"]
                d.update({f"ac{k}": float(esp in rk[:k]) for k in (1, 2, 3, 4, 5)})
            saida[m][caso] = d
    return saida


def f1(cs: list[dict[str, Any]], k: int = 1) -> float:
    tp = sum(c.get(f"tp{k}", 0) for c in cs)
    fp = sum(c.get("dec", 0) - c.get(f"tp{k}", 0) for c in cs) + sum(c.get("alarme", 0) for c in cs)
    fn = sum(c.get("n_est", 0) - c.get(f"tp{k}", 0) for c in cs)
    den = 2 * tp + fp + fn
    return 2 * tp / den if den else float("nan")


def taxa(cs: list[dict[str, Any]], num: str, den: str) -> float:
    d = sum(c.get(den, 0) for c in cs)
    return sum(c.get(num, 0) for c in cs) / d if d else float("nan")


def media_caso(chave: str, den: str | None = "n_est") -> Callable[[list[dict[str, Any]]], float]:
    def fn(cs: list[dict[str, Any]]) -> float:
        v = [c[chave] / c[den] if den else c[chave] for c in cs if chave in c and (not den or c.get(den))]
        return sum(v) / len(v) if v else float("nan")
    return fn


def avg5(cs: list[dict[str, Any]]) -> float:
    v = [sum(c[f"ac{k}"] for k in (1, 2, 3, 4, 5)) / 5 for c in cs if "ac1" in c]
    return sum(v) / len(v) if v else float("nan")


def bootstrap(cs: list[dict[str, Any]], fn: Callable[[list[dict[str, Any]]], float]) -> tuple[float, float]:
    if not cs:
        return float("nan"), float("nan")
    rnd = random.Random(SEMENTE)
    vals = sorted(fn([rnd.choice(cs) for _ in cs]) for _ in range(N_BOOT))
    vals = [v for v in vals if not math.isnan(v)] or [float("nan")]
    return vals[int(0.025 * len(vals))], vals[max(0, int(0.975 * len(vals)) - 1)]


def mcnemar(a: dict[str, dict[str, Any]], b: dict[str, dict[str, Any]], chave: str) -> tuple[int, int, float]:
    def maj(c: dict[str, Any]) -> bool:
        return c.get("n_est", 0) > 0 and c.get(chave, 0) / c["n_est"] > 0.5
    comuns = [c for c in a if c in b and a[c].get("n_est")]
    sa = sum(maj(a[c]) and not maj(b[c]) for c in comuns)
    sb = sum(maj(b[c]) and not maj(a[c]) for c in comuns)
    n = sa + sb
    p = min(1.0, 2 * sum(math.comb(n, i) for i in range(min(sa, sb) + 1)) / 2 ** n) if n else 1.0
    return sa, sb, p


def resumo(cs: list[dict[str, Any]]) -> dict[str, float]:
    return {"f1": f1(cs), "f2": f1(cs, 2), "f3": f1(cs, 3), "alarme": taxa(cs, "alarme", "n_nor"),
            "abst": 1 - taxa(cs, "dec", "n_est"), "o1": media_caso("o1")(cs), "o2": media_caso("o2")(cs),
            "o3": media_caso("o3")(cs), "ac1": media_caso("ac1", None)(cs), "ac3": media_caso("ac3", None)(cs),
            "avg5": avg5(cs), "n_casos": sum(1 for c in cs if c.get("n_est")), "n_nor": sum(c.get("n_nor", 0)
                                                                                          for c in cs)}


def _p(x: float) -> str:
    return "—" if math.isnan(x) else f"{x:.0%}"


def _f(x: float) -> str:
    return "—" if math.isnan(x) else f"{x:.3f}"


def tabela(pcs: dict[str, dict[str, dict[str, Any]]], metodos: Iterable[str],
           filtro: Callable[[dict[str, Any]], bool] = lambda c: True) -> list[str]:
    out = ["| método | casos | instantes normais | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 "
           "[IC 95%] | top-2 | top-3 | AC@1 | AC@3 | Avg@5 |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for m in metodos:
        cs = [c for c in (pcs.get(m) or {}).values() if filtro(c)]
        if not cs:
            continue
        r = resumo(cs)
        fi, oi = bootstrap(cs, f1), bootstrap(cs, media_caso("o1"))
        out.append(f"| {m} | {r['n_casos']} | {r['n_nor']} | {_f(r['f1'])} [{_f(fi[0])}–{_f(fi[1])}] | {_f(r['f2'])} | "
                   f"{_f(r['f3'])} | {_p(r['alarme'])} | {_p(r['abst'])} | {_p(r['o1'])} [{_p(oi[0])}–{_p(oi[1])}] | "
                   f"{_p(r['o2'])} | {_p(r['o3'])} | {_f(r['ac1'])} | {_f(r['ac3'])} | {_f(r['avg5'])} |")
    return out


def relatorio(titulo: str, linhas: list[dict[str, Any]], metodos: Iterable[str], notas: list[str]) -> str:
    metodos = list(metodos)
    pcs = por_caso(linhas)
    grupos = sorted({c["grupo"] for m in pcs.values() for c in m.values()})
    out = [f"# {titulo}", "", *notas, "", "## Todos", "", *tabela(pcs, metodos), ""]
    for g in grupos:
        out += [f"## {g}", "", *tabela(pcs, metodos, lambda c, g=g: c["grupo"] == g), ""]
    tipos = sorted({c["tipo"] for m in pcs.values() for c in m.values() if c.get("n_est")})
    out += ["## Sabendo top-1 por tipo de falha", "", "| tipo | casos | " + " | ".join(metodos) + " |",
            "|---|---|" + "---|" * len(metodos)]
    for t in tipos:
        cel = [_p(media_caso("o1")([c for c in (pcs.get(m) or {}).values() if c["tipo"] == t])) for m in metodos]
        n = sum(1 for c in (pcs.get(metodos[0]) or {}).values() if c["tipo"] == t and c.get("n_est"))
        out.append(f"| {t} | {n} | " + " | ".join(cel) + " |")
    out += ["", "## McNemar exato pareado (acerto majoritário por caso)", ""]
    for a, b, chave in (("d9-k", "d9", "tp1"), ("d2c-r", "d9", "tp1"), ("d2c-r", "d9-k", "tp1"),
                        ("v-cons-b", "d9-k", "o3")):
        if a in pcs and b in pcs:
            sa, sb, p = mcnemar(pcs[a], pcs[b], chave)
            out.append(f"- {a} × {b} ({chave}): só {a} {sa}, só {b} {sb}, p = {p:.3f}")
    out += ["", "## Leitura (fixada no PROTOCOLO.md)", ""]
    todos = {m: resumo(list((pcs.get(m) or {}).values())) for m in metodos if m in pcs}
    if "d9" in todos:
        r9 = todos["d9"]
        for m in ("d9-k", "d2c-r"):
            if m in todos:
                r = todos[m]
                if math.isnan(r["alarme"]) or math.isnan(r["f1"]) or math.isnan(r9["f1"]):
                    veredito = "**indeterminado** (sem instantes normais ou de falha suficientes)"
                else:
                    ok = r["f1"] >= r9["f1"] and r["alarme"] <= 0.02
                    veredito = "**generaliza**" if ok else "**não generaliza**"
                out.append(f"- {m}: F1@1 {_f(r['f1'])} × d9 {_f(r9['f1'])}; alarme {_p(r['alarme'])} → {veredito}")
        if "v-cons-b" in todos:
            r = todos["v-cons-b"]
            ok = r["o3"] >= 0.80 and r["o1"] >= r9["o1"]
            out.append(f"- v-cons-b: top-3 sabendo {_p(r['o3'])} (≥ 80%); top-1 {_p(r['o1'])} × d9 {_p(r9['o1'])} → "
                       + ("**generaliza**" if ok else "**não generaliza**"))
    return "\n".join(out) + "\n"
