"""Spans de qualquer base → traces no formato da API do Jaeger → `TraceEvent` do Stage 3.

O `build_event_log` do produto (por `processo.eventos_de_traces_brutos`) exige um span raiz `server` do serviço de
entrada, cuja operação case com a regex de entrada. Como as bases não trazem `span.kind` de forma uniforme, ele é
deduzido da árvore, como em `experimento-falhas/.../replay/rcaeval.py`: sem pai (ou pai de outro serviço) =
`server`; com filho de outro serviço = `client`; senão `internal`.
"""
from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from src.application.stage3.abordagens import processo


def _kind(span_id: str, pai: str | None, servico: str, servico_de: dict[str, str], com_filho_externo: set[str]) -> str:
    if pai is None or servico_de.get(pai) not in (None, servico):
        return "server"
    if span_id in com_filho_externo:
        return "client"
    return "internal"


def de_linhas(linhas: Iterable[tuple[str, str, str | None, str, str, int, int, bool]]) -> dict[str, dict[str, Any]]:
    """`(trace_id, span_id, pai, serviço, operação, início_us, duração_us, erro)` → `{trace_id: trace Jaeger}`."""
    # span repetido (mesmo trace e span) entra uma vez: o Eadro grava o mesmo trace em mais de um objeto do
    # `spans.json`, e a repetição viraria duas raízes (`multiplos_spans_de_entrada`)
    unicos: dict[tuple[str, str], tuple] = {}
    for x in linhas:
        unicos.setdefault((x[0], x[1]), x)
    linhas = list(unicos.values())
    servico_de = {sid: svc for _t, sid, _p, svc, *_ in linhas}
    com_filho_externo = {p for _t, _s, p, svc, *_ in linhas if p and servico_de.get(p) not in (None, svc)}
    traces: dict[str, dict[str, Any]] = {}
    for trace_id, sid, pai, svc, op, ini, dur, erro in linhas:
        pai = pai or None
        tr = traces.setdefault(trace_id, {"traceID": trace_id, "spans": [], "processes": {}})
        tr["processes"][svc] = {"serviceName": svc}
        tags = [{"key": "span.kind", "value": _kind(sid, pai, svc, servico_de, com_filho_externo)}]
        if erro:
            tags.append({"key": "error", "value": True})
        tr["spans"].append({"traceID": trace_id, "spanID": sid, "processID": svc, "operationName": op,
                            "startTime": int(ini), "duration": int(dur),
                            "references": [{"refType": "CHILD_OF", "spanID": pai}] if pai else [], "tags": tags})
    return traces


def normalizar_jaeger(traces: Iterable[dict[str, Any]], erro_de_tags: Any = None) -> dict[str, dict[str, Any]]:
    """Traces já no formato Jaeger (ex.: Eadro) → mesmas linhas de `de_linhas` (kind e erro refeitos)."""
    linhas = []
    for tr in traces:
        proc = tr.get("processes") or {}
        for s in tr.get("spans") or []:
            pai = next((str(r["spanID"]) for r in s.get("references") or [] if r.get("refType") == "CHILD_OF"), None)
            tags = {str(t.get("key")): t.get("value") for t in s.get("tags") or []}
            erro = bool(erro_de_tags(tags)) if erro_de_tags else bool(tags.get("error"))
            svc = str((proc.get(s.get("processID")) or {}).get("serviceName") or s.get("processID") or "")
            linhas.append((str(s["traceID"]), str(s["spanID"]), pai, svc, str(s.get("operationName") or ""),
                           int(s["startTime"]), int(s.get("duration") or 0), erro))
    return de_linhas(linhas)


def eventos(traces: dict[str, dict[str, Any]], sistema: dict[str, Any]) -> list[Any]:
    """Traces Jaeger → `TraceEvent` pelo mesmo filtro de completude do produto, ordenados."""
    return processo.ordenar(processo.eventos_de_traces_brutos(
        traces, sistema["entry_services"], sistema.get("entry_operation_regex") or r"^[A-Z]+ /"))
