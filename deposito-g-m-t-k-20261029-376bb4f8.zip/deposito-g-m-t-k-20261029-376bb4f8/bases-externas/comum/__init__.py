"""Biblioteca comum das bases externas (`bases-externas/PLANO.md` §1–§3).

Só importa `src/` (os métodos do Stage 3 ficam intocados). Nada aqui conhece uma base específica: cada base tem
o seu adaptador, que entrega `comum.instantes.Caso`.
"""
import os
import sys

RAIZ_BASES = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = os.path.dirname(RAIZ_BASES)
if REPO not in sys.path:
    sys.path.insert(0, REPO)

# Os padrões são os caminhos da máquina do autor; em outra máquina, `BASES_EXTERNAS_ORIGEM` aponta a pasta com
# `RCAEval/`, `OpenRCA/` e `Eadro/` (dados públicos) e `BASES_EXTERNAS_SAIDA` desvia registros e artefatos
# (ex.: rodada de teste, reprodução), sem tocar a saída oficial.
DADOS_ORIGEM = os.environ.get("BASES_EXTERNAS_ORIGEM", "/mnt/gpu-disk/veritas/novo-artigo/datasets")
DADOS_SAIDA = os.environ.get("BASES_EXTERNAS_SAIDA", "/mnt/gpu-disk/datasets/bases-externas")

# Pastas que não são casos: `multi-source-data` é a amostra que vem com o RCAEval, cópia de `checkoutservice_cpu/1`
# (mesmo `inject_time`). Fica fora da leitura; a divisão dev/holdout registrada continua a mesma (`ciclo.dividir`).
DUPLICADOS = frozenset({"RE2-OB/checkoutservice_cpu/multi-source-data"})


def nome_resultado() -> str:
    """`resultado.md` na saída oficial; `resultado-<pasta>.md` quando `BASES_EXTERNAS_SAIDA` aponta para outra
    (rodada 2, teste), para não sobrescrever o resultado oficial."""
    padrao = "/mnt/gpu-disk/datasets/bases-externas"
    return "resultado.md" if DADOS_SAIDA == padrao else f"resultado-{os.path.basename(DADOS_SAIDA)}.md"
