"""Os três métodos vencedores (d9-k, v-cons-b, d2c-r) e a referência (d9), como no avaliador do TeaStore.

Cada instante grava, por método: `status` e `ranking` (com portão) e `forcado` (decisão forçada, para o "sabendo
que é falha"). O v-cons-b sai em duas formas: `v-cons-b` (n = 5, histórico por período, `ConsensoVConsB`) e
`v-cons-b-1` (disparo único, n = 1, como o produto), exatamente como em `replay/paridade_solucoes.py`.
Os parâmetros são os congelados dos módulos; só entram as chaves de **sistema** (`entry_services`,
`dependencias_sem_span`) e, na sensibilidade do Eadro, `ref_seg`.
"""
from __future__ import annotations

import time
from typing import Any

from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr
from src.application.stage3.abordagens import d9_portao_grafo as d9
from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k
from src.application.stage3.abordagens import vconsb_consenso as vc

from . import instantes as I  # noqa: N812
from . import rapido

METODOS = ("d9-k", "v-cons-b", "v-cons-b-1", "d2c-r", "d9")
PORTAO_D9 = {"limiar": 1.5, "limiar_erro": 0.10, "limiar_dano_lat": None, "ref_seg": 150}   # = AF.PORTAO_D9
PERMISSIVO = dict(d9k.PERMISSIVO)
Q_D2CR, Q_PERMISSIVO = 1e-50, 1.0


def cfg_sistema(sistema: dict[str, Any], ref: int | None = None) -> dict[str, Any]:
    cfg = {"entry_services": list(sistema["entry_services"]),
           "dependencias_sem_span": dict(sistema.get("dependencias_sem_span") or {})}
    if ref is not None:
        cfg["ref_seg"] = ref
    return cfg


def cfg_vconsb(sistema: dict[str, Any], ref: int | None = None) -> dict[str, Any]:
    deps = dict(sistema.get("dependencias_sem_span") or {})
    k = {"dependencias_sem_span": deps, **({"ref_seg": ref} if ref is not None else {})}
    return {"entry_services": list(sistema["entry_services"]), "cfg_d9k": k, "cfg_a0b": {"dependencias_sem_span": deps},
            "cfg_d6": {"atenuacao": 1.0, "dependencias_sem_span": deps}}


def preparar_vconsb(eventos_normais: list[Any], sistema: dict[str, Any]) -> dict[str, Any]:
    """Artefatos do v-cons-b (a0-b e d6 com janelas de 120 s e fp 0,20) a partir do normal da base."""
    rapido.ativar(completo=False)
    t0 = time.monotonic()
    art = vc.preparar_baseline(eventos_normais, [], cfg_vconsb(sistema))
    art["_preparo"] = {"segundos": round(time.monotonic() - t0, 1), "n_eventos": len(eventos_normais),
                       "n_traces": len({e.case_id for e in eventos_normais})}
    return art


def _nomes(d: Any) -> list[str]:
    return [i.servico for i in d.ranking][:3]


def _seguro(fn: Any) -> Any:
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001 - um instante quebrado não derruba o caso
        return exc


def _linha_simples(mod: Any, entrada: Any, cfg: dict[str, Any], cfg_perm: dict[str, Any]) -> dict[str, Any]:
    d = _seguro(lambda: mod.decidir(entrada, {}, cfg))
    if isinstance(d, Exception):
        return {"status": "falhou", "motivo": f"{type(d).__name__}: {d}"[:200], "ranking": [], "forcado": []}
    rk = _nomes(d) if d.status == "decidiu" else []
    forcado = rk
    if not forcado:
        dp = _seguro(lambda: mod.decidir(entrada, {}, {**cfg, **cfg_perm}))
        forcado = _nomes(dp) if not isinstance(dp, Exception) else []
    return {"status": "decidiu" if rk else "absteve", "motivo": d.motivo_abstencao, "ranking": rk, "forcado": forcado}


def avaliar_caso(caso: I.Caso, artefato_vconsb: dict[str, Any] | None, ref: int | None = None) -> list[dict[str, Any]]:
    """Todos os instantes do caso, os quatro métodos (+ v-cons-b-1). Uma linha por (instante, método)."""
    sis = cfg_sistema(caso.sistema, ref)
    cfg_vc = cfg_vconsb(caso.sistema, ref)
    portao_d9 = {**PORTAO_D9, **({"ref_seg": ref} if ref is not None else {})}
    linhas: list[dict[str, Any]] = []
    consenso, periodo_atual = None, None
    rapido.ativar()
    for periodo, t, ent, n in I.entradas(caso, ref or I.REF):
        rapido.limpar()
        base = {"base": caso.base, "grupo": caso.grupo, "caso": caso.id, "tipo": caso.tipo,
                "gabarito": caso.gabarito, "periodo": periodo, "t": t.isoformat(), "n_traces": n,
                **{k: v for k, v in caso.extra.items() if isinstance(v, (str, int, float, bool))}}

        def gravar(metodo: str, linha: dict[str, Any], base: dict[str, Any] = base) -> None:
            linhas.append({**base, "metodo": metodo, **linha})

        # d9-k
        dk = _seguro(lambda: d9k.decidir(ent, {}, sis))
        if isinstance(dk, Exception):
            gravar("d9-k", {"status": "falhou", "motivo": f"{type(dk).__name__}: {dk}"[:200], "ranking": [],
                            "forcado": []})
        else:
            gravar("d9-k", {"status": dk.status, "motivo": dk.motivo_abstencao,
                            "ranking": _nomes(dk) if dk.status == "decidiu" else [],
                            "forcado": list(dk.evidencias.get("ranking_forcado") or [])[:3]})
        # v-cons-b (n = 5, um histórico por período) e disparo único
        if artefato_vconsb is not None:
            if periodo != periodo_atual:
                consenso, periodo_atual = vc.ConsensoVConsB(artefato_vconsb, cfg_vc), periodo
            dv = _seguro(lambda: consenso.decidir(ent))
            if isinstance(dv, Exception):
                gravar("v-cons-b", {"status": "falhou", "motivo": f"{type(dv).__name__}: {dv}"[:200],
                                    "ranking": [], "forcado": []})
            else:
                ev = dv.evidencias
                gravar("v-cons-b", {"status": dv.status, "motivo": dv.motivo_abstencao, "ranking": _nomes(dv),
                                    "forcado": list(ev.get("ranking_forcado") or [])[:3],
                                    "confianca": ev.get("confianca"), "falhas_votantes": ev.get("falhas")})
                brutos = {**(ev.get("votos") or {}), "a0-b": ev.get("a0b_bruto") or []}
                v1 = vc.votar(brutos, None, ev.get("k8s_sintoma"), {**vc._cfg(cfg_vc), "n_persistencia": 1})
                aberto = bool(ev.get("portao_d9k"))
                gravar("v-cons-b-1", {"status": "decidiu" if aberto and v1["ordem"] else "absteve",
                                      "motivo": None, "ranking": v1["ordem"][:3] if aberto else [],
                                      "forcado": v1["ordem"][:3]})
        # d2c-r e d9 (referência)
        gravar("d2c-r", _linha_simples(d2cr, ent, {**sis, "q": Q_D2CR}, {"q": Q_PERMISSIVO}))
        gravar("d9", _linha_simples(d9, ent, {**sis, **portao_d9}, PERMISSIVO))
    return linhas
