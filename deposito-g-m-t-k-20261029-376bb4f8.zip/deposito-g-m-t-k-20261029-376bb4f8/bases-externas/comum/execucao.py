"""Execução paralela comum: um processo por caso, registros `jsonl.gz` por caso (retomável).

O adaptador da base (caminho do arquivo `adaptar.py`, porque `openrca-market` não é nome de módulo) precisa expor `carregar(caso_id) -> Caso`; o artefato do v-cons-b vem de
`<saida>/artefatos/<grupo>.json` (gravado pelo `baseline.py` da base). Caso já gravado é pulado.
"""
from __future__ import annotations

import gzip
import importlib.util
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor
from typing import Any

from . import metodos


def caminho_artefato(saida: str, grupo: str) -> str:
    return os.path.join(saida, "artefatos", f"{grupo}.json")


def _modulo(caminho: str) -> Any:
    spec = importlib.util.spec_from_file_location(f"adaptar_{abs(hash(caminho))}", caminho)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _job(job: tuple[str, str, str, str, int | None]) -> str:
    modulo, caso_id, saida, subdir, ref = job
    destino = os.path.join(saida, subdir, f"{caso_id.replace('/', '__')}.jsonl.gz")
    if os.path.exists(destino):
        return f"{caso_id}: já feito"
    t0 = time.monotonic()
    try:
        caso = _modulo(modulo).carregar(caso_id)
    except Exception as exc:  # noqa: BLE001
        return f"{caso_id}: ERRO ao carregar — {type(exc).__name__}: {exc}"[:300]
    if caso is None:
        return f"{caso_id}: fora (sem dados utilizáveis)"
    art_path = caminho_artefato(saida, caso.grupo)
    artefato: dict[str, Any] | None = None
    if os.path.exists(art_path):
        with open(art_path) as f:
            artefato = json.load(f)
    linhas = metodos.avaliar_caso(caso, artefato, ref)
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("".join(json.dumps(x) + "\n" for x in linhas))
    os.replace(destino + ".tmp", destino)
    sem_vc = "" if artefato else " (sem artefato do v-cons-b)"
    return f"{caso_id}: {len(linhas)} linhas, {len(caso.eventos)} eventos, {time.monotonic() - t0:.0f}s{sem_vc}"


def rodar(modulo: str, ids: list[str], saida: str, jobs: int, subdir: str = "registros",
          ref: int | None = None) -> None:
    with ProcessPoolExecutor(jobs) as ex:
        for msg in ex.map(_job, [(modulo, c, saida, subdir, ref) for c in ids]):
            print(msg, flush=True)
