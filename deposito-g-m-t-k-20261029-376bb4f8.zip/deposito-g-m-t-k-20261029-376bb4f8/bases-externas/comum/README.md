# comum

Biblioteca compartilhada pelas três bases (ver `../PLANO.md` §1–§3): conversão de spans para o formato do Jaeger,
instantes e `EntradaIncidente`, chamada dos métodos (d9-k, v-cons-b, d2c-r, d9) e métricas. Só importa `src/`;
nenhuma regra específica de base fica aqui. Código escrito: `jaeger.py`, `instantes.py`, `metodos.py`, `metricas.py`, `execucao.py`.
