#!/usr/bin/env python3
"""Eadro (Train Ticket e Social Network) → `comum.instantes.Caso` (`../PLANO.md` §4.3).

- **Blocos com falha** (`data/<SIS>.<ini>D<fim>/spans.json` + `data/<SIS>.fault-<ini>D<fim>.json`): falhas em
  sequência (TT 600 s, SN 120 s), uma a cada ~715 s (TT) / ~154 s (SN). Cada falha é um caso: falha =
  `[start, start + duration]`; pré-falha = os `LOOKBACK` s antes de `start`, cortados no início do bloco — cai na
  recuperação da falha anterior (**desvio declarado**: `extra.pre_contaminado`).
- **Blocos "no fault"** (`no fault/*.tar.xz`, extraídos para `/mnt/gpu-disk/datasets/bases-externas/eadro/`) = a
  baseline do sistema: o 1º bloco (por data) vira o artefato do v-cons-b; os demais são cortados em trechos
  normais de `NORMAL_SEG` s (casos sem gabarito, para medir alarme com sessão normal de verdade).
- Gabarito: TT `dockercomposemanifests_ts-auth-service_1` → `ts-auth-service`; SN `socialnetwork-text-service-1` →
  `text-service` (`nginx-thrift` → `nginx-web-server`, o nome nos traces). Erro = tag `error` ou
  `http.status_code` ≥ 500.
- Entrada: TT — o gerador de carga chama cada serviço direto (raízes em vários `ts-*`, operações de método Java),
  então entrada = qualquer serviço do TT, operação qualquer; SN — `nginx-web-server`, operação `^/`.

Uso: python adaptar.py --extrair | --listar
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
import tarfile

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

from comum import DADOS_ORIGEM, DADOS_SAIDA, instantes, jaeger  # noqa: E402

RAIZ = os.path.join(DADOS_ORIGEM, "Eadro")
SAIDA = os.path.join(DADOS_SAIDA, "eadro")
NOFAULT = os.path.join(SAIDA, "no-fault")
PASTAS = {"TT": os.path.join(RAIZ, "TT_Dataset", "TT Dataset"), "SN": os.path.join(RAIZ, "SN_Dataset", "SN Dataset")}
NORMAL_SEG = 900
# Os spans estão 8 h à frente dos horários do JSON de falhas (UTC+8 gravado como UTC): medido em 4 blocos de cada
# sistema — nenhum span na janela das falhas, ~80–93% dos spans na janela + 8 h. Aplicado às falhas (declarado).
DESLOC_FALHAS_SEG = 8 * 3600
SERVICOS_TT = (
    "ts-assurance-service", "ts-auth-service", "ts-basic-service", "ts-cancel-service", "ts-config-service",
    "ts-contacts-service", "ts-food-map-service", "ts-food-service", "ts-inside-payment-service",
    "ts-notification-service", "ts-order-other-service", "ts-order-service", "ts-payment-service",
    "ts-preserve-service", "ts-price-service", "ts-route-plan-service", "ts-route-service", "ts-seat-service",
    "ts-security-service", "ts-station-service", "ts-ticketinfo-service", "ts-train-service",
    "ts-travel-plan-service", "ts-travel-service", "ts-travel2-service", "ts-user-service",
    "ts-verification-code-service")
SISTEMAS = {
    "TT": {"nome": "train-ticket-eadro", "entry_services": list(SERVICOS_TT), "entry_operation_regex": r".",
           "dependencias_sem_span": {}},
    "SN": {"nome": "social-network-eadro", "entry_services": ["nginx-web-server"], "entry_operation_regex": r"^/",
           "dependencias_sem_span": {}},
}
ALIAS_SN = {"nginx-thrift": "nginx-web-server"}


def servico(sis: str, nome: str) -> str:
    if sis == "TT":
        return re.sub(r"_\d+$", "", re.sub(r"^dockercomposemanifests_", "", nome))
    s = re.sub(r"-\d+$", "", re.sub(r"^socialnetwork-", "", nome))
    return ALIAS_SN.get(s, s)


def _erro(tags: dict) -> bool:
    if tags.get("error") in (True, "true", "True"):
        return True
    try:
        return int(tags.get("http.status_code") or 0) >= 500
    except (TypeError, ValueError):
        return False


def extrair() -> None:
    for sis, pasta in PASTAS.items():
        for tar in sorted(glob.glob(os.path.join(pasta, "no fault", "*.t*xz"))):
            with tarfile.open(tar) as t:
                membros = [m for m in t.getmembers() if m.name.endswith("spans.json")]
                for m in membros:
                    destino = os.path.join(NOFAULT, sis, m.name)
                    if not os.path.exists(destino):
                        t.extract(m, os.path.join(NOFAULT, sis), filter="data")
                        print(f"{sis}: {m.name}", flush=True)


def _blocos_falha(sis: str) -> list[tuple[str, str]]:
    """`[(pasta do bloco, json de falhas)]`."""
    saida = []
    for f in sorted(glob.glob(os.path.join(PASTAS[sis], "data", f"{sis}.fault-*.json"))):
        bloco = os.path.join(os.path.dirname(f), os.path.basename(f).replace(".fault-", ".").replace(".json", ""))
        if os.path.exists(os.path.join(bloco, "spans.json")):
            saida.append((bloco, f))
    return saida


def _blocos_normais(sis: str) -> list[str]:
    return sorted({os.path.dirname(p) for p in glob.glob(os.path.join(NOFAULT, sis, "*", "spans.json"))})


def _intervalo(spans_json: str) -> tuple[int, int]:
    """Início e fim (µs) da coleta do bloco: o maior trecho contínuo de minutos com ≥ 20% do pico de spans por
    minuto. Os `spans.json` "no fault" trazem spans antigos espalhados por dias (o mínimo/máximo e até os percentis
    1–99% esticam o bloco), e o nome do bloco está em outro fuso."""
    from collections import Counter  # noqa: PLC0415

    with open(spans_json) as f:
        d = json.load(f)
    por_min = Counter(int(s["startTime"]) // 60_000_000 for tr in d for s in tr["spans"])
    corte = 0.2 * max(por_min.values())
    densos = sorted(m for m, n in por_min.items() if n >= corte)
    melhor, atual = [densos[0], densos[0]], [densos[0], densos[0]]
    for m in densos[1:]:
        atual = [atual[0], m] if m - atual[1] <= 2 else [m, m]
        if atual[1] - atual[0] > melhor[1] - melhor[0]:
            melhor = list(atual)
    return melhor[0] * 60_000_000, (melhor[1] + 1) * 60_000_000


def casos() -> dict[str, dict]:
    caminho = os.path.join(SAIDA, "plano_de_casos.json")
    if os.path.exists(caminho):
        with open(caminho) as f:
            return json.load(f)
    plano: dict[str, dict] = {}
    for sis in SISTEMAS:
        for bloco, fjson in _blocos_falha(sis):
            with open(fjson) as f:
                d = json.load(f)
            nome_bloco = os.path.basename(bloco)
            for k, falha in enumerate(sorted(d["faults"], key=lambda x: x["start"])):
                ini = int((falha["start"] + DESLOC_FALHAS_SEG) * 1e6)
                if k == 0:   # emenda de 17/10: o bloco começa ~3 s antes da 1ª falha → sem referência na sessão
                    plano[f"{sis}/{nome_bloco}/f{k:02d}"] = {"sis": sis, "fora": "1ª falha do bloco, sem referência"}
                    continue
                plano[f"{sis}/{nome_bloco}/f{k:02d}"] = {
                    "sis": sis, "spans": os.path.join(bloco, "spans.json"), "tipo": falha["fault"],
                    "gabarito": servico(sis, falha["name"]), "falha": [ini, ini + int(falha["duration"] * 1e6)],
                    "pre": [max(int((d["start"] + DESLOC_FALHAS_SEG) * 1e6), ini - instantes.LOOKBACK * 1_000_000), ini],
                    "pre_contaminado": k > 0}
        normais = _blocos_normais(sis)
        for i, bloco in enumerate(normais):
            spans = os.path.join(bloco, "spans.json")
            ini, fim = _intervalo(spans)
            nome_bloco = os.path.basename(bloco)
            if i == 0:
                plano[f"{sis}/{nome_bloco}/baseline"] = {"sis": sis, "spans": spans, "baseline": True,
                                                         "ini": ini, "fim": fim}
                continue
            passo = NORMAL_SEG * 1_000_000
            for j, a in enumerate(range(ini, fim - passo + 1, passo)):
                plano[f"{sis}/{nome_bloco}/n{j:02d}"] = {"sis": sis, "spans": spans, "tipo": "", "gabarito": None,
                                                         "normais": [[a, a + passo]]}
    os.makedirs(SAIDA, exist_ok=True)
    with open(caminho, "w") as f:
        json.dump(plano, f, indent=1)
    return plano


def listar() -> list[str]:
    return sorted(c for c, v in casos().items() if not v.get("baseline") and "fora" not in v)


def ler_eventos(spans_json: str, sis: str, ini_us: int | None = None, fim_us: int | None = None) -> list:
    with open(spans_json) as f:
        d = json.load(f)
    if ini_us is not None:
        d = [tr for tr in d if any(ini_us <= int(s["startTime"]) < fim_us for s in tr["spans"])]
    return jaeger.eventos(jaeger.normalizar_jaeger(d, _erro), SISTEMAS[sis])


def carregar(caso_id: str) -> instantes.Caso | None:
    v = casos()[caso_id]
    sis = v["sis"]
    if v.get("falha"):
        ini, fim = v["pre"][0], v["falha"][1]
    else:
        ini, fim = v["normais"][0] if v.get("normais") else (v["ini"], v["fim"])
    eventos = ler_eventos(v["spans"], sis, ini, fim)
    if not eventos:
        return None
    caso = instantes.Caso(id=caso_id, base="eadro", grupo=sis, tipo=v.get("tipo") or "", gabarito=v.get("gabarito"),
                          eventos=eventos, sistema=SISTEMAS[sis],
                          extra={"pre_contaminado": bool(v.get("pre_contaminado"))})
    if v.get("falha"):
        caso.falha, caso.pre = tuple(v["falha"]), tuple(v["pre"])
    caso.normais = [tuple(x) for x in v.get("normais") or []]
    return caso


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--extrair", action="store_true")
    ap.add_argument("--listar", action="store_true")
    args = ap.parse_args()
    if args.extrair:
        extrair()
        cache = os.path.join(SAIDA, "plano_de_casos.json")
        if os.path.exists(cache):
            os.remove(cache)   # o plano depende dos blocos "no fault" extraídos
    plano = casos()
    for sis in SISTEMAS:
        vs = [v for v in plano.values() if v["sis"] == sis]
        print(f"{sis}: {sum('falha' in v for v in vs)} falhas ({sum('fora' in v for v in vs)} 1ªs fora), {sum('normais' in v for v in vs)} trechos normais, "
              f"{sum(bool(v.get('baseline')) for v in vs)} baseline")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
