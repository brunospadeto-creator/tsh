#!/usr/bin/env python3
"""Artefatos do v-cons-b no Eadro (`../PLANO.md` §4.3): por sistema, o 1º bloco "no fault" (a baseline da base).
Precisa do `adaptar.py --extrair`.

Uso: python baseline.py
"""
from __future__ import annotations

import json
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import execucao, metodos  # noqa: E402


def main() -> int:
    for caso_id, v in sorted(adaptar.casos().items()):
        if not v.get("baseline") or v["sis"] == "TT":   # TT fora (PLANO.md §7, decisão de 17/10)
            continue
        eventos = adaptar.ler_eventos(v["spans"], v["sis"], v["ini"], v["fim"])   # só o trecho denso do bloco
        art = metodos.preparar_vconsb(eventos, adaptar.SISTEMAS[v["sis"]])
        art["_preparo"].update({"bloco": caso_id})
        destino = execucao.caminho_artefato(adaptar.SAIDA, v["sis"])
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with open(destino, "w") as f:
            json.dump(art, f, default=str)
        cal = (art.get("d6") or {}).get("calibracao") or {}
        print(f"{v['sis']}: {len(eventos)} eventos; q(d6)={cal.get('q')} janelas={cal.get('n_janelas')} "
              f"a0-b={art['a0-b'].get('janelas')} ({art['_preparo']['segundos']}s)", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
