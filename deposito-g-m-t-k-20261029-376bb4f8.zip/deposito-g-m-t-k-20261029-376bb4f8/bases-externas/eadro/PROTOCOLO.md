# Protocolo — Eadro SN: d9-k, v-cons-b e d2c-r × d9

Escrito em 17/10/2026, **antes** de rodar qualquer método nesta base (só contagens e tráfego dos dados foram
vistos). Commitado antes da execução. Base do plano: `../PLANO.md` §0–§3, §4.3 e §7.

## 1. Casos

- **Social Network:** 36 falhas (12 serviços × 3 tipos: cpu_load, network_delay, network_loss), 120 s cada, em
  4 blocos; gabarito = serviço do contêiner (`socialnetwork-text-service-1` → `text-service`;
  `nginx-thrift` → `nginx-web-server`).
- **Train Ticket fora (decisão do usuário, 17/10):** ~14 traces completos por janela de 120 s, abaixo da D0.4
  (≥ 30), que fica igual em todas as bases.
- **Normais:** os blocos "no fault" do SN (3 × ~24 min): o 1º é a baseline do v-cons-b; os outros 2 viram trechos
  normais de 15 min.

## 2. Períodos, instantes e configuração

- **Relógio:** os spans estão 8 h à frente dos horários do JSON de falhas (UTC+8 gravado como UTC; medido em todos
  os blocos) → +8 h nas falhas.
- falha = `[start, start + 120 s]` → **1 instante de falha por caso** (injeção + 120 s);
- **desvio declarado:** as falhas vêm em sequência, com ~34 s de folga; a referência da sessão (150 s antes) e o
  lookback (até 600 s, cortado no início do bloco) caem na falha anterior, exceto na 1ª falha de cada bloco
  (`pre_contaminado`). Leitura secundária: só a 1ª falha de cada bloco (4 casos, sem contaminação; só descritiva);
- spans repetidos no `spans.json` entram uma vez (`comum/jaeger.py`);
- entrada `nginx-web-server`, operação `^/`; erro = tag `error` ou `http.status_code` ≥ 500; sem eventos K8s.

## 3. Baseline do v-cons-b

O 1º bloco "no fault" do SN (~24 min, `baseline.py`).

## 4. Métodos e medidas

Os mesmos do RCAEval (`comum/metodos.py`, `comum/metricas.py`). Sensibilidade com `ref_seg` = 100 s não se aplica
ao SN (a folga é de ~34 s); fica sem sensibilidade.

## 5. Leitura fixada antes

A mesma das outras bases (d9-k e d2c-r: F1@1 ≥ d9 e alarme ≤ 2%; v-cons-b: top-3 sabendo ≥ 80% e top-1 ≥ d9),
com a ressalva de que a referência contaminada pesa contra a d9-k e a d2c-r. Nada recalibrado.

## 6. Emenda de 17/10 (antes da rodada oficial; depois da rodada de teste de 4 casos)

A rodada de teste mostrou que a **1ª falha de cada bloco não tem referência**: o bloco começa ~3 s antes dela, então
d9-k e d9 saem vazias. Decisão do usuário: **as 4 primeiras falhas (uma por bloco) saem**; ficam **32 falhas**, todas
com referência contaminada pela falha anterior (declarado, §2). A leitura secundária "só a 1ª falha de cada bloco"
do §2 é **removida** (não é avaliável).
