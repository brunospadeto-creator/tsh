# Eadro (Train Ticket e Social Network; 117 falhas; baseline = blocos "no fault")

Código de análise independente desta base (ver `../PLANO.md` §4). Arquivos previstos: `PROTOCOLO.md` (commitado
antes de rodar), `adaptar.py`, `baseline.py`, `rodar.py`, `analisar.py` e `resultado.md`. Dados de origem em
`/mnt/gpu-disk/veritas/novo-artigo/datasets/` (só leitura); insumos e registros brutos em
`/mnt/gpu-disk/datasets/bases-externas/eadro/` (fora do git). Código escrito (ver `../PLANO.md` §7 para os achados e o passo a passo).
