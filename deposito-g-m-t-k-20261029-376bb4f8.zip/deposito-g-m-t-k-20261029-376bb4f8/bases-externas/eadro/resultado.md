# Eadro — principal, ref_seg 150 s (34 casos)

Eadro (Train Ticket e Social Network), parâmetros congelados do TeaStore, sem eventos K8s.
Baseline do v-cons-b = 1º bloco "no fault"; instantes normais = demais blocos "no fault" (trechos de 15 min).
**Desvio declarado:** as falhas vêm em sequência (folga ~115 s no TT, ~34 s no SN); a referência da sessão (150 s antes da falha) cai na recuperação da falha anterior. A 1ª falha de cada bloco sai (sem referência).
AC@4 = AC@5 = AC@3 (os métodos devolvem top-3).

## Todos

| método | casos | instantes normais | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| d9-k | 31 | 22 | 0.036 [0.000–0.115] | 0.036 | 0.036 | 5% | 23% | 3% [0%–10%] | 3% | 3% | 0.032 | 0.032 | 0.032 |
| v-cons-b | 31 | 22 | 0.071 [0.000–0.179] | 0.179 | 0.214 | 5% | 23% | 6% [0%–16%] | 19% | 23% | 0.065 | 0.226 | 0.187 |
| v-cons-b-1 | 31 | 22 | 0.071 [0.000–0.179] | 0.179 | 0.214 | 5% | 23% | 6% [0%–16%] | 19% | 23% | 0.065 | 0.226 | 0.187 |
| d2c-r | 31 | 22 | 0.000 [0.000–0.000] | 0.000 | 0.000 | 0% | 100% | 13% [3%–26%] | 29% | 39% | 0.129 | 0.387 | 0.316 |
| d9 | 31 | 22 | 0.036 [0.000–0.115] | 0.036 | 0.036 | 5% | 23% | 3% [0%–10%] | 3% | 3% | 0.032 | 0.032 | 0.032 |

## SN

| método | casos | instantes normais | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | top-3 | AC@1 | AC@3 | Avg@5 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| d9-k | 31 | 22 | 0.036 [0.000–0.115] | 0.036 | 0.036 | 5% | 23% | 3% [0%–10%] | 3% | 3% | 0.032 | 0.032 | 0.032 |
| v-cons-b | 31 | 22 | 0.071 [0.000–0.179] | 0.179 | 0.214 | 5% | 23% | 6% [0%–16%] | 19% | 23% | 0.065 | 0.226 | 0.187 |
| v-cons-b-1 | 31 | 22 | 0.071 [0.000–0.179] | 0.179 | 0.214 | 5% | 23% | 6% [0%–16%] | 19% | 23% | 0.065 | 0.226 | 0.187 |
| d2c-r | 31 | 22 | 0.000 [0.000–0.000] | 0.000 | 0.000 | 0% | 100% | 13% [3%–26%] | 29% | 39% | 0.129 | 0.387 | 0.316 |
| d9 | 31 | 22 | 0.036 [0.000–0.115] | 0.036 | 0.036 | 5% | 23% | 3% [0%–10%] | 3% | 3% | 0.032 | 0.032 | 0.032 |

## Sabendo top-1 por tipo de falha

| tipo | casos | d9-k | v-cons-b | v-cons-b-1 | d2c-r | d9 |
|---|---|---|---|---|---|---|
| cpu_load | 8 | 12% | 12% | 12% | 0% | 12% |
| network_delay | 12 | 0% | 8% | 8% | 8% | 0% |
| network_loss | 11 | 0% | 0% | 0% | 27% | 0% |

## McNemar exato pareado (acerto majoritário por caso)

- d9-k × d9 (tp1): só d9-k 0, só d9 0, p = 1.000
- d2c-r × d9 (tp1): só d2c-r 0, só d9 1, p = 1.000
- d2c-r × d9-k (tp1): só d2c-r 0, só d9-k 1, p = 1.000
- v-cons-b × d9-k (o3): só v-cons-b 6, só d9-k 0, p = 0.031

## Leitura (fixada no PROTOCOLO.md)

- d9-k: F1@1 0.036 × d9 0.036; alarme 5% → **não generaliza**
- d2c-r: F1@1 0.000 × d9 0.036; alarme 0% → **não generaliza**
- v-cons-b: top-3 sabendo 23% (≥ 80%); top-1 6% × d9 3% → **não generaliza**
