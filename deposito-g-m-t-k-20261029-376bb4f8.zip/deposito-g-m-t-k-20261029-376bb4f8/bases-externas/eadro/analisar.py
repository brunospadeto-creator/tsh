#!/usr/bin/env python3
"""Eadro: `resultado.md` (`../PLANO.md` §3–§4.3). Principal (`ref_seg` 150 s) e, se existir, a sensibilidade
(`registros-ref100/`). TT e SN saem separados; o SN tem a referência mais contaminada (folga de ~34 s).

Uso: python analisar.py
"""
from __future__ import annotations

import glob
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import metodos, metricas, nome_resultado  # noqa: E402

NOTAS = [
    "Eadro (Train Ticket e Social Network), parâmetros congelados do TeaStore, sem eventos K8s.",
    "Baseline do v-cons-b = 1º bloco \"no fault\"; instantes normais = demais blocos \"no fault\" (trechos de 15 min).",
    "**Desvio declarado:** as falhas vêm em sequência (folga ~115 s no TT, ~34 s no SN); a referência da sessão "
    "(150 s antes da falha) cai na recuperação da falha anterior. A 1ª falha de cada bloco sai (sem referência).",
    "AC@4 = AC@5 = AC@3 (os métodos devolvem top-3).",
]


def main() -> int:
    partes = []
    for subdir, rotulo in (("registros", "principal, ref_seg 150 s"), ("registros-ref100", "sensibilidade, ref_seg 100 s")):
        arqs = sorted(glob.glob(os.path.join(adaptar.SAIDA, subdir, "*.jsonl.gz")))
        if arqs:
            linhas = metricas.ler(arqs)
            partes.append(metricas.relatorio(f"Eadro — {rotulo} ({len(arqs)} casos)", linhas,
                                             metodos.METODOS, NOTAS if not partes else []))
    texto = "\n".join(partes) or "sem registros\n"
    with open(os.path.join(AQUI, nome_resultado()), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
