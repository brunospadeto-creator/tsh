#!/usr/bin/env python3
"""Eadro: d9-k, v-cons-b, d2c-r e d9 nas falhas e nos trechos normais (`../PLANO.md` §4.3). Retomável.

Principal: `ref_seg` = 150 s (o congelado), em `registros/`. Sensibilidade do desvio da referência: `--ref 100`,
só no TT, em `registros-ref100/`. Precisa do `adaptar.py --extrair` e do `baseline.py`.
Uso: python rodar.py [--jobs 24] [--sistemas TT,SN] [--ref 100] [--limite N]
"""
from __future__ import annotations

import argparse
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import execucao  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=24)
    ap.add_argument("--sistemas", default="SN")   # TT fora (PLANO.md §7, decisão de 17/10)
    ap.add_argument("--ref", type=int, help="ref_seg da sensibilidade (ex.: 100); padrão = o congelado (150)")
    ap.add_argument("--limite", type=int, help="só os N primeiros casos de cada sistema (fumaça)")
    args = ap.parse_args()
    ids = []
    for s in args.sistemas.split(","):
        do_sis = [i for i in adaptar.listar() if i.startswith(f"{s}/")]
        ids += do_sis[: args.limite] if args.limite else do_sis
    subdir = f"registros-ref{args.ref}" if args.ref else "registros"
    execucao.rodar(os.path.join(AQUI, "adaptar.py"), ids, adaptar.SAIDA, args.jobs, subdir, args.ref)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
