#!/usr/bin/env python3
"""Pré-teste das três propostas sem K8s, offline sobre as medidas do `extrair.py`.

Parâmetros fixados **antes** de ver qualquer número do pré-teste (iguais em todas as bases):

- histórico H(t) da própria sessão: instante normal → até 3 instantes normais anteriores do mesmo caso; instante de
  falha → até 3 janelas `sombra` do pré-falha. Instante **avaliável** se |H| ≥ 2. Todos os métodos são medidos só
  nos instantes avaliáveis (comparação justa);
- **d9** (referência, refeita): portão razão ≥ 1,5 ou Δerro ≥ 0,10; ranking `residuo_1`; forçado = permissivo;
- **d2c-r** (referência, refeita): decide sse p_min ≤ 1e-50; ranking = o do q = 1 (aproximação declarada);
- **1. d2c-a**: decide sse p_min(t) ≤ 1e-3 × min p_min(H); ranking/forçado = os da d2c-r;
- **2. d9-n**: atividade passa se razão ≥ max(1,2; 1,1 × maior razão dela em H) ou Δerro ≥ max(0,05; maior Δerro
  dela em H + 0,05); atividade fora de H usa 1,5 / 0,10. Ranking `residuo_1` sobre as que passaram; forçado = d9;
- **3. d9+r**: portão = d2c-a OU d9-n. Ranking: se a d2c-a abriu e (a d9-n fechou ou alguma atividade passou por
  erro) → ranking da d2c-r; senão → o da d9-n. Forçado: se vale a condição da d2c-a → forçado da d2c-r; senão → d9;
- **teto** (oráculo d9 ∪ d2c-r por instante), só de referência.

Sensibilidade (exploratória): margem da d2c-a ∈ {1e-1, 1e-6}.
**`d9+a*` é pós-hoc** (definida depois de ver o pré-teste): d9 original; se fechar, a d2c-a. Forçado = d9.
Uso: python analisar.py [--bases rcaeval,openrca-market,eadro]
"""
from __future__ import annotations

import argparse
import glob
import gzip
import json
import math
import os
import sys
from collections import Counter, defaultdict
from typing import Any

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI)]

from comum import DADOS_SAIDA  # noqa: E402
from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: E402

ENTRADA = os.path.join(DADOS_SAIDA, "pre-teste")
K_MIN, K_MAX = 2, 3


def _p(x: Any) -> float:
    return float(x) if x is not None else 1.0


def _ctx(c: dict[str, Any]) -> dict[str, Any]:
    return {"deps": c["deps"], "filhos": {k: set(v) for k, v in c["filhos"].items()}, "sumidos": c["sumidos"]}


def _rank9(passou: list[dict[str, Any]], ctx: dict[str, Any]) -> list[str]:
    return [lin["servico"] for lin in d9.ranquear(passou, ctx, "residuo_1")][:3] if passou else []


def _passa(e: dict[str, Any], r: float, d: float) -> bool:
    return float(e["ratio_mediana"]) >= r or float(e["delta_erro"]) >= d


def _hist(efeitos_h: list[list[dict[str, Any]]]) -> tuple[dict[str, float], dict[str, float]]:
    rmax: dict[str, float] = {}
    dmax: dict[str, float] = {}
    for efs in efeitos_h:
        for e in efs:
            a = str(e.get("atividade"))
            rmax[a] = max(rmax.get(a, 0.0), float(e["ratio_mediana"]))
            dmax[a] = max(dmax.get(a, -1.0), float(e["delta_erro"]))
    return rmax, dmax


def decisoes(x: dict[str, Any], hist: list[dict[str, Any]], margem: float = 1e-3) -> dict[str, dict[str, Any]]:
    ctx = _ctx(x["ctx"])
    efs = x["efeitos"]
    out: dict[str, dict[str, Any]] = {}
    # d9
    p9 = [e for e in efs if _passa(e, 1.5, 0.10)]
    f9 = _rank9([e for e in efs if _passa(e, 1.0, 0.0)], ctx)
    r9 = _rank9(p9, ctx)
    out["d9"] = {"dec": bool(r9), "rk": r9, "f": f9}
    # d2c-r
    d2 = x["d2cr"]
    rk2 = d2["ranking"] if d2["status"] != "falhou" else []
    pm = _p(d2.get("p_min")) if d2["status"] != "falhou" else 1.0
    out["d2c-r"] = {"dec": bool(rk2) and pm <= 1e-50, "rk": rk2 if pm <= 1e-50 else [], "f": rk2}
    # 1. d2c-a
    hmin = min(_p(h["d2cr"].get("p_min")) for h in hist)
    abre_a = bool(rk2) and pm <= margem * hmin
    out["d2c-a"] = {"dec": abre_a, "rk": rk2 if abre_a else [], "f": rk2}
    # 2. d9-n
    rmax, dmax = _hist([h["efeitos"] for h in hist])
    pn, por_erro = [], False
    for e in efs:
        a = str(e.get("atividade"))
        r_thr = max(1.2, 1.1 * rmax[a]) if a in rmax else 1.5
        d_thr = max(0.05, dmax[a] + 0.05) if a in dmax else 0.10
        if _passa(e, r_thr, d_thr):
            pn.append(e)
            por_erro |= float(e["delta_erro"]) >= d_thr
    rn = _rank9(pn, ctx)
    out["d9-n"] = {"dec": bool(rn), "rk": rn, "f": f9}
    # 3. d9+r
    if abre_a and (not rn or por_erro):
        out["d9+r"] = {"dec": True, "rk": rk2, "f": rk2}
    else:
        out["d9+r"] = {"dec": bool(rn), "rk": rn, "f": rk2 if (bool(rk2) and pm <= margem * hmin) else f9}
    # pós-hoc (exploratório, depois de ver o pré-teste): d9 original OU d2c-a, sem a d9-n
    if out["d9"]["dec"]:
        out["d9+a*"] = dict(out["d9"])
    else:
        out["d9+a*"] = {"dec": abre_a, "rk": rk2 if abre_a else [], "f": f9}
    return out


def carregar(base: str) -> list[dict[str, Any]]:
    linhas = []
    for arq in sorted(glob.glob(os.path.join(ENTRADA, base, "*.jsonl.gz"))):
        with gzip.open(arq, "rt") as f:
            linhas += [json.loads(x) for x in f if x.strip()]
    return linhas


def avaliar(linhas: list[dict[str, Any]], margem: float = 1e-3) -> tuple[list[tuple[dict, dict]], Counter]:
    por_caso: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for x in linhas:
        por_caso[x["caso"]].append(x)
    saida, cont = [], Counter()
    for caso, xs in por_caso.items():
        xs.sort(key=lambda x: x["t"])
        sombras = [x for x in xs if x["periodo"] == "sombra"]
        normais_vistos: list[dict[str, Any]] = []
        for x in xs:
            if x["periodo"] == "sombra":
                continue
            hist = (normais_vistos if x["periodo"] == "normal" else sombras)[-K_MAX:]
            if x["periodo"] == "normal":
                normais_vistos.append(x)
            cont[(x["periodo"], len(hist) >= K_MIN)] += 1
            if len(hist) < K_MIN or (x["periodo"] == "normal" and x.get("na_baseline")):
                continue
            saida.append((x, decisoes(x, hist, margem)))
    return saida, cont


METODOS = ("d9", "d2c-r", "d2c-a", "d9-n", "d9+r", "d9+a*", "teto")


def medir(aval: list[tuple[dict, dict]]) -> dict[str, dict[str, float]]:
    c: dict[str, Counter] = defaultdict(Counter)
    o: dict[str, dict[str, list]] = defaultdict(lambda: defaultdict(list))
    for x, ds in aval:
        ds = {**ds, "teto": None}
        esp = x["gabarito"]
        for m in METODOS:
            if m == "teto":
                a, b = ds["d9"], ds["d2c-r"]
                dec = a["dec"] or b["dec"]
                tp = (a["dec"] and a["rk"][:1] == [esp]) or (b["dec"] and b["rk"][:1] == [esp])
                o1 = a["f"][:1] == [esp] or b["f"][:1] == [esp]
                o3 = esp in a["f"][:3] or esp in b["f"][:3]
            else:
                d = ds[m]
                dec, tp, o1, o3 = d["dec"], d["dec"] and d["rk"][:1] == [esp], d["f"][:1] == [esp], esp in d["f"][:3]
            if x["periodo"] == "normal":
                c[m]["nn"] += 1
                c[m]["al"] += dec
            elif esp:
                c[m]["ne"] += 1
                c[m]["dec"] += dec
                c[m]["tp"] += tp
                o[m][x["caso"]].append((o1, o3))
    res = {}
    for m in METODOS:
        k = c[m]
        tp, fp, fn = k["tp"], k["dec"] - k["tp"] + k["al"], k["ne"] - k["tp"]
        casos = list(o[m].values())
        res[m] = {"f1": 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else math.nan,
                  "al": k["al"] / k["nn"] if k["nn"] else math.nan,
                  "abst": 1 - k["dec"] / k["ne"] if k["ne"] else math.nan,
                  "o1": sum(sum(a for a, _ in v) / len(v) for v in casos) / len(casos) if casos else math.nan,
                  "o3": sum(sum(b for _, b in v) / len(v) for v in casos) / len(casos) if casos else math.nan,
                  "casos": len(casos), "nn": k["nn"]}
    return res


def _f(x: float, pct: bool = False) -> str:
    return "—" if math.isnan(x) else (f"{x:.0%}" if pct else f"{x:.3f}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bases", default="rcaeval,openrca-market,eadro")
    args = ap.parse_args()
    out = ["# Pré-teste das propostas sem K8s (amostras ≤ 10 min por base)", "",
           "| base | método | casos | inst. normais | F1@1 | alarme | abstenção | sabendo top-1 | top-3 |",
           "|---|---|---|---|---|---|---|---|---|"]
    sens = ["", "## Sensibilidade da margem da d2c-a (exploratória)", "",
            "| base | margem | d2c-a F1@1 / alarme / abstenção | d9+r F1@1 / alarme / top-1 |", "|---|---|---|---|"]
    cob = ["", "## Instantes avaliáveis (|H| ≥ 2)", "", "| base | período | avaliáveis | sem histórico |", "|---|---|---|---|"]
    for base in args.bases.split(","):
        linhas = carregar(base)
        if not linhas:
            continue
        aval, cont = avaliar(linhas)
        r = medir(aval)
        for m in METODOS:
            v = r[m]
            out.append(f"| {base} | {m} | {v['casos']} | {v['nn']} | {_f(v['f1'])} | {_f(v['al'], True)} | "
                       f"{_f(v['abst'], True)} | {_f(v['o1'], True)} | {_f(v['o3'], True)} |")
        for per in ("normal", "falha"):
            cob.append(f"| {base} | {per} | {cont[(per, True)]} | {cont[(per, False)]} |")
        for mg in (1e-1, 1e-6):
            rs = medir(avaliar(linhas, mg)[0])
            a, h = rs["d2c-a"], rs["d9+r"]
            sens.append(f"| {base} | {mg:g} | {_f(a['f1'])} / {_f(a['al'], True)} / {_f(a['abst'], True)} | "
                        f"{_f(h['f1'])} / {_f(h['al'], True)} / {_f(h['o1'], True)} |")
    texto = "\n".join(out + cob + sens) + "\n"
    with open(os.path.join(AQUI, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
