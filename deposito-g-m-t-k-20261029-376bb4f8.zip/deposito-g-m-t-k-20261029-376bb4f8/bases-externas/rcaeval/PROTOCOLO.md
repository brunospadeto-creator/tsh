# Protocolo — RCAEval RE2/RE3 (OB, TT): d9-k, v-cons-b e d2c-r × d9

Escrito em 17/10/2026, **antes** de rodar qualquer método nesta base (só contagens de dados foram vistas).
Commitado antes da execução; mudança depois de ver número = protocolo novo, declarado. Base do plano:
`../PLANO.md` §0–§4.1 e §7.

## 1. Casos

| suíte | casos com traces | gabaritos (serviço × casos) |
|---|---|---|
| RE2-OB | 91 | checkout 19, currency 18, email 18, productcatalog 18, recommendation 18 |
| RE2-TT | 90 | ts-auth, ts-order, ts-route, ts-train, ts-travel (18 cada) |
| RE3-OB | 30 | adservice 9, cartservice 3, currency 3, email 15 |
| RE3-TT | 30 | ts-auth 15, ts-route 15 |

- Sock Shop (RE2-SS, RE3-SS) fora: sem traces. RE1 fora: só métricas.
- **Exclusão fixada:** `RE2-OB/checkoutservice_cpu/2` tem 39 s de dados depois da injeção (< 180 s) → sem instante de
  falha; entra só com os instantes normais.
- **Gabarito invisível:** no RE3-OB, `adservice` e `cartservice` (12 casos) não aparecem nos traces; nenhum método de
  traces pode acertá-los. Ficam no resultado principal e saem numa leitura secundária ("só gabaritos visíveis").

## 2. Períodos, instantes e configuração

- normal = `[início, injeção)` (~12 min; RE3-TT ~15 min); falha = `[injeção, fim]`, teto de 600 s;
- instantes a cada 60 s; janela 120 s; referência da sessão 150 s; falha a partir de injeção + 120 s; lookback da
  falha = os 600 s antes da injeção, deslocados (`comum/instantes.py`); D0.4: < 30 traces na janela fica fora;
- sistema OB: entrada `frontendservice`/`frontend`, operação `^frontend$`; erro = `statusCode` gRPC ≠ 0;
- sistema TT: entrada = qualquer `ts-*` com operação HTTP (`^[A-Z]+ /`); `statusCode` vazio → sem erro;
- sem eventos K8s (a base não tem); `dependencias_sem_span` vazio.

## 3. Baseline do v-cons-b

Por suíte, o normal de **5 casos sorteados** (semente `20261017-<suíte>`, `baseline.py`), encadeados no tempo. Os
instantes normais desses casos (`na_baseline`) **saem da medida de alarme** de todos os métodos.

## 4. Métodos e medidas

d9-k, v-cons-b (n = 5) e v-cons-b-1 (disparo único), d2c-r, d9 (referência), com os parâmetros congelados do
TeaStore (`comum/metodos.py`). Medidas de `comum/metricas.py`: F1@1/2/3 com portão, alarme, abstenção, sabendo
top-1/2/3, AC@1/AC@3/Avg@5 (1º instante de falha; AC@4 = AC@5 = AC@3), IC 95% por bootstrap de caso, McNemar.
Por suíte e no total.

## 5. Leitura fixada antes

- **d9-k generaliza** se F1@1 (total) ≥ d9 **e** alarme ≤ 2%.
- **d2c-r generaliza** se F1@1 (total) ≥ d9 **e** alarme ≤ 2%.
- **v-cons-b generaliza** se top-3 sabendo ≥ 80% **e** top-1 sabendo ≥ d9.
- Descritivo: complementaridade d9-k × d2c-r por tipo de falha; comparação de AC@1/AC@3/Avg@5 com os baselines
  publicados do RCAEval (mesma base, protocolo de janela diferente — declarar).
- Nada é recalibrado com estes casos; se a leitura falhar, é reportado como está.
