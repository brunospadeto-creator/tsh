#!/usr/bin/env python3
"""RCAEval: `resultado.md` a partir dos registros (`../PLANO.md` §3). Instantes normais dos casos usados na baseline
do v-cons-b ficam fora da medida de alarme (para todos os métodos, para manter o pareamento).

Uso: python analisar.py
"""
from __future__ import annotations

import glob
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import metodos, metricas, nome_resultado  # noqa: E402

INVISIVEIS = {"RE3-OB": {"adservice", "cartservice"}}
NOTAS = [
    "RCAEval RE2/RE3 (Online Boutique e Train Ticket), parâmetros congelados do TeaStore, sem eventos K8s.",
    "TT sem `statusCode` (portão só por latência). AC@k/Avg@5: ranking forçado do 1º instante de falha; os métodos "
    "devolvem top-3, então AC@4 = AC@5 = AC@3.",
    "Instantes normais dos casos usados na baseline do v-cons-b (`na_baseline`) fora da medida de alarme.",
]


def main() -> int:
    arqs = sorted(glob.glob(os.path.join(adaptar.SAIDA, "registros", "*.jsonl.gz")))
    linhas = [r for r in metricas.ler(arqs) if not (r["periodo"] == "normal" and r.get("na_baseline"))]
    texto = metricas.relatorio(f"RCAEval — d9-k, v-cons-b, d2c-r × d9 ({len(arqs)} casos)", linhas,
                               metodos.METODOS, NOTAS)
    # leitura secundária (PROTOCOLO.md §1): só gabaritos que aparecem nos traces (RE3-OB adservice/cartservice fora)
    visiveis = [r for r in linhas if r["gabarito"] not in INVISIVEIS.get(r["grupo"], set())]
    texto += "\n" + metricas.relatorio("Leitura secundária — só gabaritos visíveis nos traces", visiveis,
                                       metodos.METODOS, [f"Fora: {INVISIVEIS}."])
    with open(os.path.join(AQUI, nome_resultado()), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
