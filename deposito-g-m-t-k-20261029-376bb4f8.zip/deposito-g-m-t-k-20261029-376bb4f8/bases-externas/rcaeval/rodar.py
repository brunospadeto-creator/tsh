#!/usr/bin/env python3
"""RCAEval: d9-k, v-cons-b, d2c-r e d9 em todos os casos (`../PLANO.md` §4.1). Retomável.

Registros em `/mnt/gpu-disk/datasets/bases-externas/rcaeval/registros/<caso>.jsonl.gz`.
Uso: python rodar.py [--jobs 24] [--suites RE2-OB,…] [--limite N]
"""
from __future__ import annotations

import argparse
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

import adaptar  # noqa: E402

from comum import execucao  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=24)
    ap.add_argument("--suites", default=",".join(adaptar.SUITES))
    ap.add_argument("--limite", type=int, help="só os N primeiros casos de cada suíte (fumaça)")
    args = ap.parse_args()
    ids = []
    for s in args.suites.split(","):
        da_suite = [i for i in adaptar.listar() if i.startswith(f"{s}/")]
        ids += da_suite[: args.limite] if args.limite else da_suite
    execucao.rodar(os.path.join(AQUI, "adaptar.py"), ids, adaptar.SAIDA, args.jobs)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
