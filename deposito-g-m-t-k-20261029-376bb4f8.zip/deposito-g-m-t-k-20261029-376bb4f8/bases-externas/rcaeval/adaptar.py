#!/usr/bin/env python3
"""RCAEval RE2/RE3 (Online Boutique e Train Ticket) → `comum.instantes.Caso` (`../PLANO.md` §4.1).

Caso = `<suíte>/<serviço>_<falha>/<n>`, com `traces.csv` (`parentSpanID`, `statusCode`) e `inject_time.txt`
(segundos). Normal = `[início, injeção)`; falha = `[injeção, fim]`; pré-falha = os `LOOKBACK` s antes da injeção.
Sock Shop fica fora (sem traces). Configuração de sistema (declarada no PROTOCOLO.md):

- OB: entrada `frontendservice` (RE2) / `frontend` (RE3), operação `^frontend$`; erro = `statusCode` gRPC ≠ 0;
- TT: o gerador de carga chama a API REST de cada serviço direto (não há gateway nos traces), então a entrada é
  qualquer `ts-*` com operação HTTP (`^[A-Z]+ /`); `statusCode` vem vazio → sem erro (portão só por latência).

Uso: python adaptar.py --listar   (conta casos e casos truncados)
"""
from __future__ import annotations

import glob
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

from comum import DADOS_ORIGEM, DADOS_SAIDA, instantes, jaeger  # noqa: E402

RAIZ = os.path.join(DADOS_ORIGEM, "RCAEval")
SAIDA = os.path.join(DADOS_SAIDA, "rcaeval")
SUITES = ("RE2-OB", "RE2-TT", "RE3-OB", "RE3-TT")
SERVICOS_TT = (
    "ts-admin-basic-info-service", "ts-admin-travel-service", "ts-assurance-service", "ts-auth-service",
    "ts-basic-service", "ts-config-service", "ts-consign-price-service", "ts-consign-service", "ts-contacts-service",
    "ts-food-map-service", "ts-food-service", "ts-inside-payment-service", "ts-order-other-service", "ts-order-service",
    "ts-payment-service", "ts-preserve-other-service", "ts-preserve-service", "ts-price-service", "ts-route-service",
    "ts-seat-service", "ts-security-service", "ts-station-service", "ts-ticketinfo-service", "ts-train-service",
    "ts-travel-service", "ts-travel2-service", "ts-user-service")
SISTEMAS = {
    "OB": {"nome": "online-boutique", "entry_services": ["frontendservice", "frontend"],
           "entry_operation_regex": r"^frontend$", "dependencias_sem_span": {}},
    "TT": {"nome": "train-ticket", "entry_services": list(SERVICOS_TT), "entry_operation_regex": r"^[A-Z]+ /",
           "dependencias_sem_span": {}},
}
# Nome do serviço no gabarito × nos traces (o RE2-OB chama o frontend de `frontendservice`).
ALIAS = {"RE2-OB": {"frontend": "frontendservice"}}
MIN_POS_FALHA_SEG = 120 + 60     # caso com menos que isso depois da injeção não tem nenhum instante de falha


def listar() -> list[str]:
    """Ids `<suíte>/<serviço>_<falha>/<n>` dos casos com `traces.csv` não vazio."""
    ids = []
    for s in SUITES:
        for t in sorted(glob.glob(os.path.join(RAIZ, s, s, "*", "*", "traces.csv"))):
            if os.path.getsize(t) > 200:
                ids.append(f"{s}/{os.path.relpath(os.path.dirname(t), os.path.join(RAIZ, s, s))}")
    return ids


def _pasta(caso_id: str) -> str:
    suite, resto = caso_id.split("/", 1)
    return os.path.join(RAIZ, suite, suite, resto)


def gabarito(caso_id: str) -> tuple[str, str, str]:
    """`(suíte, serviço, tipo)` a partir de `<suíte>/<serviço>_<falha>[_k]/<n>`."""
    suite, pasta, _n = caso_id.split("/")
    servico, tipo = pasta.split("_", 1)
    return suite, ALIAS.get(suite, {}).get(servico, servico), tipo


def ler_traces(caso_id: str, colunas_extra: tuple[str, ...] = ()) -> tuple[list[tuple], int]:
    import pandas as pd

    pasta = _pasta(caso_id)
    df = pd.read_csv(os.path.join(pasta, "traces.csv"), low_memory=False,
                     usecols=["traceID", "spanID", "parentSpanID", "serviceName", "operationName", "startTime",
                              "duration", "statusCode", *colunas_extra])
    with open(os.path.join(pasta, "inject_time.txt")) as f:
        inj_us = int(float(f.read().strip()) * 1_000_000)
    status = pd.to_numeric(df["statusCode"], errors="coerce")
    erro = (status.notna() & (status != 0)).tolist()
    pais = [p if isinstance(p, str) and p else None for p in df["parentSpanID"]]
    linhas = list(zip(df["traceID"].astype(str), df["spanID"].astype(str), pais, df["serviceName"].astype(str),
                      df["operationName"].astype(str), df["startTime"].astype("int64"), df["duration"].astype("int64"),
                      erro, strict=True))
    return linhas, inj_us


def carregar(caso_id: str, so_normal: bool = False) -> instantes.Caso | None:
    suite, servico, tipo = gabarito(caso_id)
    sistema = SISTEMAS[suite.split("-")[1]]
    linhas, inj = ler_traces(caso_id)
    if so_normal:
        linhas = [x for x in linhas if x[5] < inj]
    eventos = jaeger.eventos(jaeger.de_linhas(linhas), sistema)
    if not eventos:
        return None
    ini = min(int(e.start_us) for e in eventos)
    fim = max(int(e.start_us) + int(e.duration_us) for e in eventos)
    caso = instantes.Caso(id=caso_id, base="rcaeval", grupo=suite, tipo=tipo, gabarito=servico, eventos=eventos,
                          sistema=sistema, normais=[(ini, inj)],
                          extra={"pos_falha_seg": round((fim - inj) / 1e6), "na_baseline": False})
    if not so_normal and fim - inj >= MIN_POS_FALHA_SEG * 1_000_000:
        caso.falha = (inj, fim)
        caso.pre = (inj - instantes.LOOKBACK * 1_000_000, inj)
    from baseline import casos_da_baseline  # noqa: PLC0415 - evita import circular no topo

    caso.extra["na_baseline"] = caso_id in casos_da_baseline(suite)
    return caso


def main() -> int:
    import pandas as pd

    ids = listar()
    print(f"{len(ids)} casos com traces:", {s: sum(i.startswith(s) for i in ids) for s in SUITES})
    curtos = []
    for i in ids:
        pasta = _pasta(i)
        with open(os.path.join(pasta, "inject_time.txt")) as f:
            inj = float(f.read().strip())
        ult = pd.read_csv(os.path.join(pasta, "traces.csv"), usecols=["startTime"])["startTime"].max() / 1e6
        if ult - inj < MIN_POS_FALHA_SEG:
            curtos.append((i, round(ult - inj)))
    print(f"casos com < {MIN_POS_FALHA_SEG} s depois da injeção (sem instante de falha): {len(curtos)}")
    for i, s in curtos:
        print(f"  {i}: {s} s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
