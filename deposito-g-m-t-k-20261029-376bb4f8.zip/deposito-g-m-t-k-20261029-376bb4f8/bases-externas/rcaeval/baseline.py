#!/usr/bin/env python3
"""Artefatos do v-cons-b no RCAEval (`../PLANO.md` §4.1): por suíte, o normal de `N` casos sorteados.

O RCAEval não tem coleta normal separada; cada caso tem ~12 min normais antes da injeção. A baseline de cada suíte
junta o normal de `N` casos sorteados com semente fixa (`casos_da_baseline`), encadeados no tempo
(`instantes.encadear`). Os instantes normais desses casos ficam marcados (`na_baseline`) e a análise os tira da
medida de alarme, para não calibrar e medir no mesmo normal.

Uso: python baseline.py [--suites RE2-OB,RE2-TT,…] [--n 5]
"""
from __future__ import annotations

import argparse
import functools
import json
import os
import random
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.dirname(AQUI), AQUI]

from comum import execucao, instantes, metodos  # noqa: E402

SEMENTE = 20261017
N_PADRAO = 5


@functools.cache
def casos_da_baseline(suite: str, n: int = N_PADRAO) -> frozenset[str]:
    import adaptar  # noqa: PLC0415

    ids = sorted(i for i in adaptar.listar() if i.startswith(f"{suite}/"))
    return frozenset(random.Random(f"{SEMENTE}-{suite}").sample(ids, min(n, len(ids))))


def preparar(suite: str, n: int) -> str:
    import adaptar  # noqa: PLC0415

    segmentos = []
    for caso_id in sorted(casos_da_baseline(suite, n)):
        caso = adaptar.carregar(caso_id, so_normal=True)
        if caso:
            segmentos.append(caso.eventos)
            print(f"  {caso_id}: {len(caso.eventos)} eventos normais", flush=True)
    eventos = instantes.encadear(segmentos)
    art = metodos.preparar_vconsb(eventos, adaptar.SISTEMAS[suite.split("-")[1]])
    art["_preparo"].update({"casos": sorted(casos_da_baseline(suite, n)), "semente": SEMENTE})
    destino = execucao.caminho_artefato(adaptar.SAIDA, suite)
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    with open(destino, "w") as f:
        json.dump(art, f, default=str)
    cal = (art.get("d6") or {}).get("calibracao") or {}
    return f"{suite}: q(d6)={cal.get('q')} janelas={cal.get('n_janelas')} a0-b={art['a0-b'].get('janelas')} " \
           f"({art['_preparo']['segundos']}s)"


def main() -> int:
    import adaptar  # noqa: PLC0415

    ap = argparse.ArgumentParser()
    ap.add_argument("--suites", default=",".join(adaptar.SUITES))
    ap.add_argument("--n", type=int, default=N_PADRAO)
    args = ap.parse_args()
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415

    suites = args.suites.split(",")
    with ProcessPoolExecutor(len(suites)) as ex:   # uma suíte por processo
        for msg in ex.map(preparar, suites, [args.n] * len(suites)):
            print(msg, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
