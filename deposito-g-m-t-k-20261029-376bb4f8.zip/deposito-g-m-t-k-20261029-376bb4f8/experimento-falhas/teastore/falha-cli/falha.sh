#!/usr/bin/env bash
# Aplica/retrai falhas no TeaStore (formato release-tags + registry).
# Coleta orientada por período/duração e janela de pacote (em segundos).
#
# Falhas de código (f1,f2,f3,f7,f8,f9,f10): release própria (exp-v1.0.0-fN).
# Falhas "só infra/config" (f4,f5,f6,f11,f12,f13,f14): config-override sobre a
# imagem baseline (exp-v1.0.0/34b37f7) via kubectl patch no deployment — sem
# commit nem release própria.
#
# Uso:
#   falha.sh list
#   falha.sh status <f1|f1-latency>
#   falha.sh apply <f1|f1-latency>   [-t SEG] [-w SEG] [--no-stresser] [--drain] [--rollback]
#   falha.sh all                     [-t SEG] [-w SEG] [--no-stresser] [--drain]
#   falha.sh baseline                [-t SEG] [-w SEG] [--no-stresser] [--drain]
#   falha.sh rollback <f1|f1-latency>
#   falha.sh restaurar
#
# Opções de coleta (por comando):
#   -t, --time SEG    Período de coleta em segundos (padrão: 600)
#   -w, --window SEG  Tamanho da janela/pacote em segundos (padrão: 60)
#   --drain           Registra a falha/coleção no Veritas E executa o drain.
#                     (default: apenas coleta, sem registro/drain)
#   --no-stresser     Desliga o stresser k8s durante a coleta
set -euo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SELF_DIR}/../lib.sh"

FALHAS_DIR="${FALHAS_DIR:-$SELF_DIR/../falhas}"
RESULTADOS_DIR="${RESULTADOS_DIR:-$SELF_DIR/../resultados}"
COLLECT_TIME="${COLLECT_TIME:-600}"
PACKAGE_WINDOW="${PACKAGE_WINDOW:-60}"
NO_STRESSER=0
ROLLBACK_AFTER=0
DRAIN=0

_validate_falha() {
    local falha="$1"
    if [ "$(_falha_to_service "$falha")" = "unknown" ]; then
        echo "ERRO: falha desconhecida: '$falha' (use 'falha.sh list')" >&2
        return 1
    fi
}

_validate_positive_int() {
    local name="$1" value="$2"
    if ! [[ "$value" =~ ^[0-9]+$ ]] || [ "$value" -le 0 ]; then
        echo "ERRO: $name deve ser um inteiro positivo (recebido: '$value')" >&2
        return 1
    fi
}

# Parseia flags de coleta (por comando). Define COLLECT_TIME, PACKAGE_WINDOW,
# NO_STRESSER e ROLLBACK_AFTER no escopo global.
_parse_coleta_flags() {
    while [ $# -gt 0 ]; do
        case "$1" in
            -t|--time) COLLECT_TIME="$2"; shift 2 ;;
            -w|--window) PACKAGE_WINDOW="$2"; shift 2 ;;
            --no-stresser) NO_STRESSER=1; shift ;;
            --drain) DRAIN=1; shift ;;
            --rollback) ROLLBACK_AFTER=1; shift ;;
            *) echo "ERRO: opção desconhecida: $1" >&2; echo "Uso: $0 {apply <falha>|all|baseline} [-t SEG] [-w SEG] [--no-stresser] [--drain] [--rollback]" >&2; exit 1 ;;
        esac
    done
    _validate_positive_int "tempo de coleta (-t)" "$COLLECT_TIME"
    _validate_positive_int "janela/pacote (-w)" "$PACKAGE_WINDOW"
    if [ "$PACKAGE_WINDOW" -lt 10 ] || [ "$PACKAGE_WINDOW" -gt 60 ]; then
        echo "ERRO: janela/pacote (-w) deve estar entre 10 e 60 (API do Veritas)" >&2
        return 1
    fi
}

_coleta_metadata() {
    local falha="$1" image="$2"
    local start_iso
    start_iso=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    mkdir -p "$RESULTADOS_DIR"
    local file="$RESULTADOS_DIR/${falha}-coleta-$(date -u +%Y%m%dT%H%M%S).json"
    cat > "$file" <<EOF
{"falha": "${falha}", "collect_time_seconds": ${COLLECT_TIME}, "package_window_seconds": ${PACKAGE_WINDOW}, "window_start": "${start_iso}", "failure_id": "${LAST_FAILURE_ID:-}", "drained": ${DRAIN}, "image": "${image}"}
EOF
    echo "    Metadados da coleta: $file"
}

# Registra coleta/falha no Veritas e executa o drain (somente com --drain).
_registrar_e_drenar() {
    local falha="$1"
    if [ "$falha" = "baseline" ]; then
        registrar_baseline_veritas "$VERITAS_SYSTEM_ID" "$PACKAGE_WINDOW"
    else
        registrar_falha_veritas "$falha" "$VERITAS_SYSTEM_ID" "$PACKAGE_WINDOW"
    fi
    aguardar_failure_pending_drain "$VERITAS_SYSTEM_ID" "$LAST_FAILURE_ID" 300
    drain_falha_veritas "$VERITAS_SYSTEM_ID" "$LAST_FAILURE_ID"
    aguardar_drain_concluido "$VERITAS_SYSTEM_ID" "$LAST_FAILURE_ID" 300
}

list() {
    echo "Falhas conhecidas (release-tags p/ código; config-override p/ infra):"
    for dir in "$FALHAS_DIR"/*/; do
        [ -d "$dir" ] || continue
        local nome falha service release
        nome=$(basename "$dir")
        falha=$(echo "$nome" | sed 's/^[0-9]*-//' | tr '[:upper:]' '[:lower:]')
        service=$(_falha_to_service "$falha")
        if _is_infra_fault "$falha"; then
            release="config-override (baseline exp-v1.0.0)"
        else
            release=$(_falha_to_release "$falha")
        fi
        printf "  %-22s -> teastore-%-11s %s\n" "$falha" "$service" "$release"
    done
}

coletar() {
    local falha="$1" image
    local vfile="$RESULTADOS_DIR/${falha}-version.json"
    image=$(kubectl get deployment -n "$NAMESPACE" "teastore-$(_falha_to_service "$falha")" \
        -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null || echo "desconhecido")
    if [ "$DRAIN" -eq 1 ]; then
        criar_colecao "$VERITAS_SYSTEM_ID" "$falha" "$PACKAGE_WINDOW"
        gerar_version_json "$falha" "$vfile"
        ativar_version_context "$VERITAS_SYSTEM_ID" "$falha" "$vfile"
    fi
    echo "    Coletando por ${COLLECT_TIME}s (janela/pacote ${PACKAGE_WINDOW}s)..."
    if [ "$NO_STRESSER" -eq 0 ]; then
        stresser_on
    else
        echo "    Stresser desligado (--no-stresser)."
    fi
    aguardar "$COLLECT_TIME"
    stresser_off
    _coleta_metadata "$falha" "$image"
    if [ "$DRAIN" -eq 1 ]; then
        _registrar_e_drenar "$falha"
        desativar_version_context "$VERITAS_SYSTEM_ID"
    fi
}

apply() {
    local falha="$1"
    _validate_falha "$falha"
    shift
    _parse_coleta_flags "$@"
    echo "=== Aplicando falha '$falha' (coleta ${COLLECT_TIME}s, janela ${PACKAGE_WINDOW}s) ==="
    aplicar_falha_build "$falha"
    wait_for_teastore_ready "$falha"
    coletar "$falha"
    if [ "$ROLLBACK_AFTER" -eq 1 ]; then
        echo "    Rollback ao final (--rollback)..."
        rollback_falha_build "$falha"
    else
        echo "    Falha ainda aplicada. Para reverter: falha.sh rollback $falha"
    fi
}

baseline() {
    shift
    _parse_coleta_flags "$@"
    echo "=== Baseline (coleta ${COLLECT_TIME}s, janela ${PACKAGE_WINDOW}s) ==="
    restaurar_teastore
    coletar "baseline"
}

# Roda todas as falhas uma a uma. Cada falha termina com rollback (obrigatório
# para a próxima começar do baseline). Drain apenas com --drain.
all() {
    shift
    _parse_coleta_flags "$@"
    echo "=== Rodando todas as falhas (coleta ${COLLECT_TIME}s, janela ${PACKAGE_WINDOW}s, drain=${DRAIN}) ==="
    for dir in "$FALHAS_DIR"/*/; do
        [ -d "$dir" ] || continue
        local nome falha
        nome=$(basename "$dir")
        falha=$(echo "$nome" | sed 's/^[0-9]*-//' | tr '[:upper:]' '[:lower:]')
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  Falha: ${falha} (inicio $(date -u +%H:%M:%S))"
        echo "═══════════════════════════════════════════════════════════"
        aplicar_falha_build "$falha"
        wait_for_teastore_ready "$falha"
        coletar "$falha"
        rollback_falha_build "$falha"
        echo "  ${falha} concluida: $(date -u +%H:%M:%S)"
    done
}

rollback() {
    local falha="$1"
    _validate_falha "$falha"
    echo "=== Rollback da falha '$falha' ==="
    rollback_falha_build "$falha"
}

restaurar() {
    echo "=== Restaurando TeaStore ao baseline (exp-v1.0.0) ==="
    restaurar_teastore
}

status() {
    local falha="$1" service image
    _validate_falha "$falha"
    service=$(_falha_to_service "$falha")
    image=$(kubectl get deployment -n "$NAMESPACE" "teastore-${service}" \
        -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null || echo "deployment não encontrado")
    echo "teastore-${service}: ${image}"
}

case "${1:-}" in
    list) list ;;
    apply)
        [ $# -ge 2 ] || { echo "Uso: falha.sh apply <falha> [-t SEG] [-w SEG] [--no-stresser] [--rollback]"; exit 1; }
        apply "$2" "${@:3}"
        ;;
    baseline) baseline "$@" ;;
    all) all "$@" ;;
    rollback)
        [ $# -ge 2 ] || { echo "Uso: falha.sh rollback <falha>"; exit 1; }
        rollback "$2"
        ;;
    restaurar) restaurar ;;
    status)
        [ $# -ge 2 ] || { echo "Uso: falha.sh status <falha>"; exit 1; }
        status "$2"
        ;;
    *)
        echo "Uso: $0 {list|status <falha>|apply <falha> [-t SEG] [-w SEG] [--no-stresser] [--drain] [--rollback]|all [-t SEG] [-w SEG] [--no-stresser] [--drain]|baseline [-t SEG] [-w SEG] [--no-stresser] [--drain]|rollback <falha>|restaurar}"
        exit 1
        ;;
esac