#!/usr/bin/env bash
# Driver resumivel do hold-out 2 do Stage 3 (HOLDOUT-2.md). Mesma logica do run-holdout-lotes.sh:
# um lote e a unidade do pre-registro; se abortar, recomeca inteiro com a MESMA semente (ate 3 tentativas).
# Uso:  setsid nohup ./run-holdout2-lotes.sh > /dev/null 2>&1 &
#       LOTES="B1 B2" ./run-holdout2-lotes.sh     # subconjunto, na ordem dada
set -uo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$SELF_DIR/stage3-online/resultados/holdout2"
BASE_COLLECTION="$(cat "$SELF_DIR/resultados/baseline-collection.id")"
H="h1-image-cpu-throttle,h2-recommender-oom,h3-auth-jvm-heap,h4-db-cpu-throttle,h5-image-registry-misconfig,h6-recommender-down"
G="g1-auth-cpu-throttle,g2-persistence-down,g3-image-memory-limit,g4-db-memory-limit,g5-recommender-cpu-throttle,g6-persistence-jvm-heap"
# Parte B (versoes c, falhas novas) primeiro; parte A (completa o hold-out 1, mesmas sementes) depois.
declare -A FALHAS_DO=([B1]="$G" [B2]="$G" [B3]="$G" [A1]="$H" [A2]="$H")
declare -A SEED_DO=([B1]=20261021 [B2]=20261022 [B3]=20261023 [A1]=20261011 [A2]=20261012)
LOTES="${LOTES:-B1 B2 B3 A1 A2}"
RETRIES=3

[ "$BASE_COLLECTION" = "547ba505-60ac-4596-b950-395ff59b72b7" ] \
    || { echo "[driver] baseline $BASE_COLLECTION != 547ba505 do HOLDOUT-2.md -- parando"; exit 1; }
mkdir -p "$OUT"
echo "[driver] inicio $(date -u +%FT%TZ)  base=$BASE_COLLECTION  lotes=$LOTES" | tee -a "$OUT/driver.log"

for lote in $LOTES; do
    falhas="${FALHAS_DO[$lote]:-}"; seed="${SEED_DO[$lote]:-}"
    [ -n "$falhas" ] || { echo "[driver] lote desconhecido: $lote" | tee -a "$OUT/driver.log"; exit 1; }
    mark="$OUT/$lote.done"
    if [ -f "$mark" ]; then
        echo "[driver] lote $lote ja concluido, pulando" | tee -a "$OUT/driver.log"
        continue
    fi
    attempt=0
    while [ ! -f "$mark" ]; do
        attempt=$((attempt+1))
        if [ "$attempt" -gt "$RETRIES" ]; then
            echo "[driver] lote $lote esgotou $RETRIES tentativas -- parando" | tee -a "$OUT/driver.log"
            exit 1
        fi
        echo "[driver] lote $lote tentativa $attempt seed=$seed $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
        if "$SELF_DIR/coleta-lote-stage3.sh" -c "$BASE_COLLECTION" -f "$falhas" --seed "$seed" \
                >> "$OUT/$lote.log" 2>&1; then
            grep -oE 'lote do Stage 3: +[0-9]{8}T[0-9]{6}Z' "$OUT/$lote.log" | tail -1 | awk '{print $NF}' > "$OUT/$lote.run"
            touch "$mark"
            echo "[driver] lote $lote concluido $(date -u +%FT%TZ) run=$(cat "$OUT/$lote.run")" | tee -a "$OUT/driver.log"
        else
            echo "[driver] lote $lote tentativa $attempt falhou $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
            sleep 120
        fi
    done
done
echo "[driver] hold-out 2 completo $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
