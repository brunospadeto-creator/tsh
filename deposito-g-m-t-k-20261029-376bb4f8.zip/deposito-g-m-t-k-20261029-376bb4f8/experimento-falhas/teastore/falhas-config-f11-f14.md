# Falhas de Configuração F11–F14 (TeaStore)

> **Modelo**: falhas "só infra/config". NÃO alteram código-fonte da aplicação.
> Usam a **imagem e commit baseline** (`exp-v1.0.0`, `34b37f7`) e materializam o
> bug por **override de config no deployment K8s** (resources/env/probe/ConfigMap),
> via `falha-cli/falha.sh` + `_apply_infra_config`/`_revert_infra_config` em `lib.sh`.
> Assim `app_commit` permanece o do baseline — simulando mudança de infra no mundo
> real sem vazar a falha pelo commit (foco em detectar pelo EFEITO observável).

**Sistema**: teastore (id `f530cda3-e337-4c63-a7dc-d57c8722afef`)
**Coleção**: `fe1bb003-f5bc-4b52-8f53-479065e26cd4`
**Marcador de classe** (para o Stage 2): `F11`…`F14`

---

## F11 — Limit de memória apertado (OOMKill / RestartLoop)

### Conceito
Um `resources.limits.memory` bem abaixo do consumo real do serviço faz o kernel
matar o container por **OOM** (Out Of Memory) assim que o cgroup estoura. O
kubelet reinicia o container em loop (`CrashLoopBackOff`/restarts), degradando o
serviço e os dependentes.

### Mundo real
Causa clássica de incidente: definir limit de memória sem conhecer o working set
do processo (ex.: limit de 128Mi num pod que consome 1Gi), ou esquecer de atualizar
o limit após um aumento natural de uso. Resultado: restart cíclico, instabilidade,
SLA violado por erros/latência.

### Onde aplicar
`teastore-persistence` — consome ~900MB–1050MB (`memoria_usage_mb` no baseline).

### Implementação (config-override)
```bash
kubectl patch deployment teastore-persistence -n teastore --type=strategic -p \
  '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-persistence","resources":{"limits":{"memory":"96Mi"}}}]}}}}'
```

### Efeito observável (sinais detectáveis)
| Canal | Assinatura |
|-------|-----------|
| `memoria_usage_mb` | colapso para ~0 e restarts (ou picos antes do kill) |
| restart count do pod | sobe (CrashLoopBackOff) |
| `latencia_pura_ms` | picos/erros nos dependentes de persistence |
| logs | erros de conexão/OOM nos dependentes (webui) |

### Por que é novo
F5 limita a **heap da JVM** (`_JAVA_OPTIONS -Xmx`); F11 limita o **cgroup do pod**
no k8s — mecanismo distinto, pura config de orchestrator.

---

## F12 — CPU limit raso → throttling de cgroup

### Conceito
Um `resources.limits.cpu` muito abaixo do que a carga do stresser exige faz o
cgroup **throttle** a execução do processo (ele é pausado periodicamente para
obedecer a quota). Não crashea, mas a latência dispara e o throughput cai.

### Mundo real
Limitar CPU sem conhecer a pegada real do serviço (ou um limit que não escala com
o tráfego). O processo fica "engasgado"; a app continua up mas responde muito
lentamente — um dos enganos mais comuns de tuning de `resources` em produção.

### Onde aplicar
`teastore-webui` (hot path do tráfego), com o stresser ligado.

### Implementação (config-override)
```bash
kubectl patch deployment teastore-webui -n teastore --type=strategic -p \
  '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-webui","resources":{"limits":{"cpu":"150m"}}}]}}}}'
```

### Efeito observável (sinais detectáveis)
| Canal | Assinatura |
|-------|-----------|
| `cpu_throttled` | **dispara** (métrica canônica coletada pelo cgroup-exporter) |
| `cpu_usage` | achatado no teto da quota (≤150m) |
| `latencia_pura_ms` | sobe muito com carga |
| logs | mais lentos (mas volume normal) |

### Por que é novo
F10 limita **threads no código** (ThreadPoolExecutor); F12 limita a **quota CPU
do cgroup** no k8s — outro mecanismo, e diretamente medível por `cpu_throttled`.

---

## F13 — Probe de readiness/liveness com endpoint errado

### Conceito
Um `readinessProbe` (ou `livenessProbe`) apontando para um caminho que não
responde, ou com `periodSeconds`/`failureThreshold` agressivos, faz o kubelet
marcar o pod como **NotReady**. O **Service remove o pod do balanceamento** →
requisições que passariam por ele retornam 503/timeout.

### Mundo real
Erro frequente: adicionar/adjust probe após deploy sem validar o endpoint de
health (ex.: `/health` que a app não expõe, ou probe que só fica OK depois de
vários segundos de startup), derrubando o tráfego de um serviço perfeitamente
"up" internamente.

### Onde aplicar
`teastore-auth` (ou webui) — caminho obrigatório no fluxo.

### Implementação (config-override)
```bash
kubectl patch deployment teastore-auth -n teastore --type=strategic -p \
  '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-auth","readinessProbe":{"httpGet":{"path":"/healthz","port":8080},"periodSeconds":1,"failureThreshold":1}}]}}}}'
```

### Efeito observável (sinais detectáveis)
| Canal | Assinatura |
|-------|-----------|
| pod status | `NotReady` / `0/1 Running` |
| `latencia_pura_ms` | 503/timeout no caminho via auth |
| logs | erro HTTP 503/connection-refused nos consumidores |
| volume de requisições | queda (requests rejeitados) até o balanceador |

### Por que é novo
Nenhuma falha atual F1–F10 mexe em **probe/health check** — dimensão totalmente nova.

---

## F14 — Explosão de logs (nível DEBUG / log-bomb)

### Conceito
Forçar o serviço a logar em volume muito maior que o normal (
DEBUG/TRACE, ou mount de `log4j2.xml` verbose), saturando I/O de disco e o
coletor. Sinal claro de "logs explicam": `logs_volume`/`total_log_count` e
`fs_writes_bytes` disparam.

### Mundo real
Subir nível de log para DEBUG em produção "só para ver o que tá acontecendo" e
esquecer de reverter — causa sobrecarga de disco, custo, e degradação por
contenção de I/O. Também acontece com libs que logam em excesso.

### Onde aplicar
`teastore-webui` ou `teastore-persistence` (maior volume de ação).

### Implementação (config-override)
Depende do mecanismo do app (TeaStore usa Log4j2). Duas vias:
1. Montar um **ConfigMap** com `log4j2.xml` em nível DEBUG sobre
   `WEB-INF/classes` do webui (padrão volume mount idêntico ao F4).
2. Ou via `_JAVA_OPTIONS` se a app honra `-Dlog.level=DEBUG`.

```bash
# via ConfigMap + volumeMount (mesmo scaffold do F4)
kubectl create configmap falha-log-debug -n teastore --from-file=log4j2.xml=/tmp/log4j-debug.xml
kubectl patch deployment teastore-webui -n teastore --type=strategic -p \
  '{"spec":{"template":{"spec":{"volumes":[{"name":"logconf","configMap":{"name":"falha-log-debug"}}],"containers":[{"name":"teastore-webui","volumeMounts":[{"name":"logconf","mountPath":"/usr/local/tomcat/webapps/ROOT/WEB-INF/classes/log4j2.xml","subPath":"log4j2.xml"}]}]}}}}'
```

> **Caveat**: precisa confirmar ao vivo qual caminho `log4j2.xml` e se
> `-Dlog.level` funciona — única das 4 que tem dependência de detalhe do app.

### Efeito observável (sinais detectáveis)
| Canal | Assinatura |
|-------|-----------|
| `total_log_count`/`logs_volume` | **sobe em ordens de magnitude** |
| `fs_writes_bytes` | dispara (I/O de escrita de log) |
| `cpu_usage` | aquecido (formatação dos logs) |

### Por que é novo
Nenhuma falha atual ataca o **volume de logs** — e o Stage 1 semântico
(`text_for_embedding_current`) usa `Logs volume`/`Top log patterns`, então essa
teria sinal direto e forte.

---

## Tabela-resumo

| F | Técnica | Alvo | Mecanismo (override) | Observável-chave |
|---|---------|------|----------------------|------------------|
| F11 | limit memória (OOM) | persistence | `resources.limits.memory` | `memoria_usage_mb`↓ / restarts |
| F12 | limit CPU (throttle) | webui | `resources.limits.cpu` | `cpu_throttled`↑ |
| F13 | probe errada (health) | auth/webui | `readinessProbe` | pod `NotReady`, 503 |
| F14 | log-bomb (DEBUG) | webui/persistence | ConfigMap `log4j2.xml` | `logs_volume`/`fs_writes_bytes`↑ |

Todas apontam para imagem baseline (`app_commit=34b37f7`); a classe da falha é
carregada pela **config descrita no version-context do deployment**, não pelo commit.
