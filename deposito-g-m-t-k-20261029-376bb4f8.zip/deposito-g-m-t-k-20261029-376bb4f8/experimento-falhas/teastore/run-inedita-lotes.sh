#!/usr/bin/env bash
# Driver resumivel da coleta inedita (PROTOCOLO-COLETA-INEDITA.md). Mesma logica do run-holdout-lotes.sh:
# um lote e a unidade do pre-registro; se abortar, recomeca inteiro com a MESMA semente (ate 3 tentativas).
# Uso:  setsid nohup ./run-inedita-lotes.sh > /dev/null 2>&1 &
#       LOTES="C1 C2" ./run-inedita-lotes.sh     # subconjunto, na ordem dada
set -uo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$SELF_DIR/stage3-online/resultados/inedita"
BASE_COLLECTION="$(cat "$SELF_DIR/resultados/baseline-collection.id")"
H="h1-image-cpu-throttle,h2-recommender-oom,h3-auth-jvm-heap,h4-db-cpu-throttle,h5-image-registry-misconfig,h6-recommender-down"
G="g1-auth-cpu-throttle,g2-persistence-down,g3-image-memory-limit,g4-db-memory-limit,g5-recommender-cpu-throttle,g6-persistence-jvm-heap"
# C1-C2: h; C3-C4: g. Sementes novas (PROTOCOLO-COLETA-INEDITA.md §2).
declare -A FALHAS_DO=([C1]="$H" [C2]="$H" [C3]="$G" [C4]="$G")
declare -A SEED_DO=([C1]=20261031 [C2]=20261032 [C3]=20261033 [C4]=20261034)
LOTES="${LOTES:-C1 C2 C3 C4}"
RETRIES=3

[ "$BASE_COLLECTION" = "547ba505-60ac-4596-b950-395ff59b72b7" ] \
    || { echo "[driver] baseline $BASE_COLLECTION != 547ba505 do protocolo -- parando"; exit 1; }
mkdir -p "$OUT"
echo "[driver] inicio $(date -u +%FT%TZ)  base=$BASE_COLLECTION  lotes=$LOTES" | tee -a "$OUT/driver.log"

for lote in $LOTES; do
    falhas="${FALHAS_DO[$lote]:-}"; seed="${SEED_DO[$lote]:-}"
    [ -n "$falhas" ] || { echo "[driver] lote desconhecido: $lote" | tee -a "$OUT/driver.log"; exit 1; }
    mark="$OUT/$lote.done"
    if [ -f "$mark" ]; then
        echo "[driver] lote $lote ja concluido, pulando" | tee -a "$OUT/driver.log"
        continue
    fi
    attempt=0
    while [ ! -f "$mark" ]; do
        attempt=$((attempt+1))
        if [ "$attempt" -gt "$RETRIES" ]; then
            echo "[driver] lote $lote esgotou $RETRIES tentativas -- parando" | tee -a "$OUT/driver.log"
            exit 1
        fi
        echo "[driver] lote $lote tentativa $attempt seed=$seed $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
        if "$SELF_DIR/coleta-lote-stage3.sh" -c "$BASE_COLLECTION" -f "$falhas" --seed "$seed" \
                >> "$OUT/$lote.log" 2>&1; then
            grep -oE 'lote do Stage 3: +[0-9]{8}T[0-9]{6}Z' "$OUT/$lote.log" | tail -1 | awk '{print $NF}' > "$OUT/$lote.run"
            touch "$mark"
            echo "[driver] lote $lote concluido $(date -u +%FT%TZ) run=$(cat "$OUT/$lote.run")" | tee -a "$OUT/driver.log"
        else
            echo "[driver] lote $lote tentativa $attempt falhou $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
            sleep 120
        fi
    done
done
echo "[driver] coleta inedita completa $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
