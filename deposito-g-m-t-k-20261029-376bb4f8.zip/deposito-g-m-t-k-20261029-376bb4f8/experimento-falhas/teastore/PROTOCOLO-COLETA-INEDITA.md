# Protocolo da coleta inédita — d9-k e v-cons-b em h × 2 + g × 2

Registrado em 2026-10-15 (ARQ), **antes** de coletar. Decisão do usuário: `session.md` §42.75 (coleta completa
primeiro). Objetivo: o número de teste das soluções definitivas (§42.72) em cenários que **ninguém leu**.

## 1. Código e harness (nada muda depois de ver o resultado)

- **Métodos avaliados**: `d9k_portao_grafo_k8s.py` (d9-k-v1, hash `dbe86983757e`) e `vconsb_consenso.py`
  (v-cons-b-v1, `a51c15168f22`), congelados em `congelamento.json` (`modos`), commit `99cb91e0`; referência: d9.
- **Harness, imagem e `stage3_config`**: os do hold-out 2 (13/10; job-runner `sha256:87372597…`, pacotes
  contínuos, `exp-v1.1.0`, carga 10–20 usuários). A avaliação é **offline por instante** (como §42.66–§42.74), então
  a coleta não depende dos modos rodarem online; não se reconstrói a imagem (evita mudar o insumo coletado).
- **Baseline**: coleção normal `547ba505` (a mesma de h e g); artefatos da a0-b e da d6 já preparados.

## 2. Lotes

| lote | falhas | semente |
|---|---|---|
| C1 | h1–h6 | 20261031 |
| C2 | h1–h6 | 20261032 |
| C3 | g1–g6 | 20261033 |
| C4 | g1–g6 | 20261034 |

Sementes nunca usadas (h: 20261011/12; g: 20261021–23 já usadas). Driver `run-inedita-lotes.sh` (cópia do
`run-holdout2-lotes.sh`; lote abortado recomeça inteiro com a mesma semente, até 3 tentativas). ~8 h por lote.
Cenário que não passa no verificador da falha não é coletado (fica registrado à parte).

## 3. Medida

`replay/confirmatorio.py` com os 4 runs novos: instantes de 60 s no normal e no estável, janela 120 s, referência
pré-falha deslocada nos estáveis, K8s só de sintoma (Fase 0), < 30 traces fora (D0.4). Modos: d9-k, v-cons-b
(n = 5 avaliado e disparo único) e d9. F1@1/2/3 com portão, alarme, top-1/2/3 sabendo que é falha; IC 95% por
bootstrap de cenário; por grupo h e g. McNemar pareado d9-k × d9 e v-cons-b × d9-k (acerto majoritário).

## 4. Leitura fixada antes

- **d9-k confirma** se F1@1 (todos) ≥ F1@1 da d9 e alarme ≤ 2%.
- **v-cons-b confirma** como lista de investigação se top-3 sabendo que é falha ≥ 80% e ≥ top-3 da d9-k.
- Qualquer resultado é reportado como está; nada é recalibrado com estes cenários. Se um lote não fechar em 3
  tentativas, o resultado sai com os lotes completos e a ausência declarada.
