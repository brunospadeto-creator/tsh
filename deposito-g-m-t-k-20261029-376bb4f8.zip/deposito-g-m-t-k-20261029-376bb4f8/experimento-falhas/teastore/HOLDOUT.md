# Hold-out do Stage 3 — pré-registro (2026-10-03, antes de qualquer coleta)

Este arquivo é commitado **antes** da primeira coleta de hold-out. Nada aqui muda depois de ver resultado; uma
mudança, se vier, é um pré-registro novo e invalida o anterior como evidência.

## O que se mede

Generalização da localização dos cinco modos (`a0-v1`, `d1-v1`, `d2-v3`, `d3-v1`, `d4-v1`), congelados por modo
em `stage3-online/congelamento.json` (commit do congelamento: `ee28ccea`). É o número **P5-generalização** do
`plano-revisao-generalizacao-stage3.md`: falhas e alvos que **não participaram de nenhuma decisão** — nem das
regras da a0 (escolhidas nos 38 casos de calibração), nem dos limiares de d1–d4 (só dado normal).

## Falhas (todas por override de configuração, sobre a imagem base `exp-v1.1.0`)

| id | alvo | causa injetada | por que é hold-out |
|---|---|---|---|
| `h1-image-cpu-throttle` | image | `limits.cpu=120m` | alvo nunca usado |
| `h2-recommender-oom` | recommender | `limits.memory=128Mi` | alvo nunca usado |
| `h3-auth-jvm-heap` | auth | `_JAVA_OPTIONS -Xmx40m` | auth só teve F13 (probe) |
| `h4-db-cpu-throttle` | db | `limits.cpu=110m` (banco lento) | alvo nunca usado |
| `h5-image-registry-misconfig` | image | `REGISTRY_HOST=registry-inexistente` | tipo novo (descoberta mal configurada) |
| `h6-recommender-down` | recommender | `replicas=0` | tipo novo (dependência indisponível) |

Gabarito: `teastore-<alvo>`. Implementação: `lib.sh` (`_falha_to_service`, `_apply_infra_config`) e
`stage3-online/verificar_falha.py` (só a causa, nunca o efeito).

## Protocolo

1. Baseline normal **longa** (`BASELINE_TIME=5400`, 90 min) numa coleção nova, com `stage3_config.modos =
   {"escolhidos": ["a0","d1","d2","d3","d4"], "principal": "a0"}`; artefatos d1–d4 preparados dela.
2. Três lotes de hold-out (`coleta-lote-stage3.sh -c <coleção> -f h1,…,h6`), ordem embaralhada por lote,
   = 18 cenários. Warmup medido e verificador só de causa, como no lote de 02/10.
3. Pré-voo exige: os cinco modos = congelados, job-runner no digest congelado, `stage3_config` congelada.

## O que se reporta (e só isto)

- Por modo, **separado**: Top-1, Top-3, MRR, cobertura (respondeu/total), com IC de Wilson; sobre todos os
  cenários coletados, e à parte os descartados pelo verificador.
- Hipótese pré-registrada H1 (vinda do diagnóstico dos 38 casos, `diagnostico-38-consolidado-20261003.md`):
  "nos cenários em que a a0 erra o Top-1, algum d_k acerta em ao menos metade". Reportada como confirmada ou
  não; **não** autoriza fusão por si só.
- Limitações previstas, declaradas antes: o `db` não emite spans próprios (aparece como span cliente do
  persistence), então d1–d4 não têm como nomear `teastore-db` em `h4`; em `h6` o recommender some dos traces.

## O que não se faz

Ajustar regra, parâmetro, limiar ou lista de falhas olhando o hold-out; trocar o gabarito; descartar cenário
por efeito (só por causa, pelo verificador). O RCAEval (`replay/rcaeval.py`) abre só depois deste relatório.

## Sistema externo — RCAEval RE2 (Online Boutique), protocolo fixado antes de abrir o lacre

- Script: `stage3-online/replay/rcaeval_modos.py` (os cinco modos, separados). Roda **só depois** do relatório
  do hold-out do TeaStore.
- Janela do incidente = `[injeção, injeção + 120 s]`, a mesma para os cinco modos. Motivo, decidido sem ver
  resultado: cada caso tem ~12 min de normal; com a janela até o fim do caso (~12 min) os d_k não teriam
  nenhuma janela normal para calibrar. Com 120 s e meio passo, ~11 janelas.
- Normal = traces que começam antes da injeção; a0 com `localization_mode=anomalias`; configuração só de
  sistema (entrada `frontendservice`, operação `^frontend$`).
- Reporta-se por modo: Top-1, Top-3, MRR, cobertura, com IC de Wilson, mais o corte por tipo de falha.
