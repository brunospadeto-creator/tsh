# Protocolo confirmatório — d9-k e v-cons-b nas coletas não usadas

Registrado em 2026-10-14 (ARQ), **antes** de rodar. Decisão: `session.md` §42.72 (d9-k e v-cons-b são as soluções
definitivas, código em `d9k_portao_grafo_k8s.py` e `vconsb_consenso.py`, paridade 100% com a avaliação).
Objetivo: o primeiro número das duas soluções fora dos 54 cenários já lidos. **Nada é ajustado**: pesos, n,
limiares e desempates são os do código congelado no commit `d7318c35`.

## 1. Base (21 cenários, nenhum lido por d9-k/v-cons-b/d9/a0-b/d6 nas escolhas)

| run | coleção normal | cenários | observação |
|---|---|---|---|
| `20261002T013953Z` | `2032361d` | f1, f3, f4, f6, f7, f8, f9, f10, f11, f14 | lote de reprodutibilidade da a0 (calibração da a0, não destes modos); baseline própria |
| `20260926T190446Z` | `d7cd3536` | f7, f9, f13 | ensaio G |
| `20260926T134559Z`, `…135052Z`, `…135501Z` | `d7cd3536` | f1 | avulsos, estável curto (3 pacotes) |
| `20261001T231714Z` | `2032361d` | f1 | avulso |
| `20261004T061011Z` | `547ba505` | f1 | avulso |
| `20261004T074140Z`, `20261012T023725Z` | `547ba505` | h2 | lotes h em que o incidente não abriu (só este cenário com traces) |
| `20261011T220351Z` | `547ba505` | h1 | idem |

Cenários sem `referencia.json` (`20260925T…`) ou sem traces ficam fora (não há como montar o normal).

## 2. Medida

Mesma entrada do avaliador unificado e de `replay/paridade_solucoes.py`: instantes a cada 60 s no normal e no
estável, janela de 120 s, referência pré-falha deslocada nos estáveis, eventos K8s só de sintoma a partir do normal
(Fase 0), instante com < 30 traces fora (D0.4). Artefatos da a0-b e da d6 (d2c ao fp 0,20) da coleção normal do
run (para `2032361d`, a a0-b é preparada agora, da baseline `coleta-20261001T221019Z`, sem olhar falha).
Modos: **d9-k**, **v-cons-b** e a **d9** (pai, referência). Métricas da §3 do `PROTOCOLO-RAPIDO.md`: F1@1/2/3 com
portão, alarme no normal, top-1/2/3 sabendo que é falha (média por cenário); IC 95% por bootstrap de cenário.

## 3. Leitura fixada antes

- **Confirma a d9-k** se F1@1 (todos) ≥ F1@1 da d9 e alarme ≤ 2%.
- **Confirma o v-cons-b** se top-3 sabendo que é falha ≥ 80% (o observado foi 90%; tolerância de 10 p.p.) e
  top-1 sabendo ≥ d9.
- Abaixo disso: declarar a queda no artigo como estimativa fora da amostra; nada é recalibrado com estes cenários.
- n = 21 é pequeno e quase todo f (17 f + 4 h, nenhum g): resultado descritivo, sem teste de hipótese principal.
