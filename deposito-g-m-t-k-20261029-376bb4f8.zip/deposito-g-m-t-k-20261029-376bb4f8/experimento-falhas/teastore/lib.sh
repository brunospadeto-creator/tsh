#!/usr/bin/env bash
# shellcheck disable=SC2317
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
NAMESPACE="${NAMESPACE:-teastore}"
MONITOR_NS="${MONITOR_NS:-monitor}"
STRESS_NS="${STRESS_NS:-stress}"
VERITAS_SYSTEM_ID="${VERITAS_SYSTEM_ID:-f530cda3-e337-4c63-a7dc-d57c8722afef}"
COLLECT_TIME="${COLLECT_TIME:-600}"
# Carga de referência do lote. Fica aqui, e não só no manifesto, porque o
# stresser perde o estado quando o pod reinicia: o toggle `active` vive na memória do processo e a
# config precisa ser re-assegurada, não só declarada uma vez.
STRESSER_MIN_USERS="${STRESSER_MIN_USERS:-10}"
STRESSER_PEAK_USERS="${STRESSER_PEAK_USERS:-20}"
STRESSER_WAVE_PERIOD="${STRESSER_WAVE_PERIOD:-60}"
# Release base do experimento (Etapa D item 5): a imagem de todo serviço saudável, a base
# de rollback e o prefixo das releases de falha (`$EXP_BASE-fN`). Um lugar só -- com o valor fixo em 10
# pontos, o ensaio da Etapa G aplicou `exp-v1.0.0-f1` e o rollback devolveu o webui à v1.0.0.
# `exp-v1.1.0` = conector Apache + sem tracer legado (spans `client` completos); `exp-v1.0.0` reproduz as
# coleções antigas.
EXP_BASE="${EXP_BASE:-exp-v1.1.0}"
# O gerador de version.json (scripts/generate_version_json.sh) lê estes dois.
export BASELINE_RELEASE_TAG="${BASELINE_RELEASE_TAG:-$EXP_BASE}"
export RELEASE_PREFIX="${RELEASE_PREFIX:-$EXP_BASE}"
PF_PIDS=()
ACTIVE_COLLECTION_ID=""
ACTIVE_VERSION_CENARIO=""
VERSION_SCRIPT="$SCRIPT_DIR/scripts/generate_version_json.sh"

# ── helpers ──────────────────────────────────────────────────────────

wait_for_pods() {
    local ns="$1"
    local timeout="${2:-120}"
    echo "    Aguardando pods em $ns ficarem Ready (timeout ${timeout}s)..."
    local elapsed=0
    while [ $elapsed -lt "$timeout" ]; do
        local not_ready
        # `Terminating` e o residuo do pod ANTIGO, nao o pod novo que interessa.
        # Ignorar e correto em qualquer rollout, mas NAO foi a causa do abort de
        # 2026-09-30: naquela hora m06/m07 estavam NotReady ha 19 dias e o pod do
        # recommender ficava Terminating para sempre porque o kubelet morto nao
        # confirmava a morte (sem deletionTimestamp, DisruptionTarget=True). A causa
        # real foi o no, nao este gate. Se a coleta abortar assim de novo, cheque
        # `kubectl get nodes` antes de culpar esta linha.
        not_ready=$(kubectl get pods -n "$ns" --no-headers 2>/dev/null | \
            grep -v 'stresser' | grep -v 'Terminating' | awk '{print $3}' | grep -cv 'Running\|Completed' || true)
        if [ "$not_ready" -eq 0 ]; then
            echo "    Todos os pods em $ns estao Ready."
            return 0
        fi
        printf "."
        sleep 3
        elapsed=$((elapsed + 3))
    done
    echo ""
    echo "    ERRO: timeout aguardando pods em $ns"
    kubectl get pods -n "$ns"
    return 1
}

wait_for_teastore_ready() {
    local falha="${1:-}"
    if _is_infra_fault "$falha"; then
        echo "    Falha infra (${falha}): readiness/resources quebrados por design —"
        echo "    aguardando 20s p/ o estado de falha estabilizar e seguindo (sem exigir Ready)."
        sleep 20
        kubectl get pods -n "$NAMESPACE" 2>/dev/null | grep 'teastore' || true
        return 0
    fi
    wait_for_pods "$NAMESPACE" 120
}

cleanup_terminating_pods() {
    local ns="${1:-$NAMESPACE}"
    local pods
    pods=$(kubectl get pods -n "$ns" --field-selector=status.phase!=Running -o name 2>/dev/null | grep -v 'Completed' || true)
    if [ -n "$pods" ]; then
        echo "    Limpando pods Terminating em $ns..."
        echo "$pods" | xargs -r kubectl delete -n "$ns" --force --grace-period=0 2>/dev/null || true
        sleep 3
    fi
}

wait_for_generatedb() {
    local timeout="${1:-180}"
    local pod url answer
    url="http://localhost:8080/tools.descartes.teastore.persistence/rest/generatedb/finished"
    pod=$(kubectl get pod -n "$NAMESPACE" -l run=teastore-persistence -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    if [ -z "$pod" ]; then
        pod=$(kubectl get pod -n "$NAMESPACE" -l app=teastore -o name 2>/dev/null | grep 'persistence' | head -1)
    fi
    if [ -z "$pod" ]; then
        echo "    AVISO: nenhum pod da persistence encontrado para checar o generatedb"
        return 1
    fi
    # O banco é efêmero (emptyDir): o pod da persistence regenera do zero a cada boot. Enquanto ele
    # regenera, o pod fica Ready e o webui responde HTTP 200 -- com o catálogo vazio. Sem esta espera,
    # o lote coleta contra um TeaStore de pé e sem dados, e a baseline sai com o catálogo zerado
    # A rota devolve `true`/`false` em texto puro, não JSON.
    echo "    Aguardando generatedb/finished=true em $pod (timeout ${timeout}s)..."
    # Prazo pelo relógio: cada volta leva 5 s de espera + até 30 s de `kubectl exec`, então somar um valor
    # fixo por volta errava o timeout (somava 15 s dormindo 5 -- "180 s" viravam ~1 min).
    local prazo=$((SECONDS + timeout))
    while [ "$SECONDS" -lt "$prazo" ]; do
        answer=$(timeout 30 kubectl exec -n "$NAMESPACE" "$pod" -c teastore-persistence -- \
            wget -qO- --timeout=10 --tries=1 "$url" 2>/dev/null | tr -d '[:space:]' || true)
        if [ "$answer" = "true" ]; then
            echo "    generatedb/finished=true (banco populado)."
            return 0
        fi
        printf "."
        sleep 5
    done
    echo ""
    echo "    AVISO: generatedb/finished não virou true em ${timeout}s -- o catálogo pode estar vazio."
    return 1
}

wait_for_teastore_webui() {
    local timeout="${1:-180}"
    local pod
    pod=$(kubectl get pod -n "$NAMESPACE" -l run=teastore-webui -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    if [ -z "$pod" ]; then
        pod=$(kubectl get pod -n "$NAMESPACE" -l app=teastore -o name 2>/dev/null | grep 'webui' | head -1)
        [ -z "$pod" ] && { echo "    AVISO: nenhum pod encontrado para health check"; return 1; }
    fi
    local url="http://localhost:8080/tools.descartes.teastore.webui/category?category=2&page=1"
    local attempt
    # `timeout` no kubectl exec: o wget --timeout=5 sozinho não basta -- com o webui aceitando a conexão e
    # sem responder o exec ficava preso para sempre. Uma remediação: o webui que sobe antes
    # das dependências fica com requisições presas; um rollout restart dele resolve.
    for attempt in 1 2; do
        echo "    Aguardando TeaStore WebUI responder via $pod (timeout ${timeout}s, tentativa ${attempt})..."
        local elapsed=0
        while [ $elapsed -lt "$timeout" ]; do
            timeout 30 kubectl exec -n "$NAMESPACE" "$pod" -c teastore-webui -- \
                wget -qO- --timeout=20 "$url" >/dev/null 2>&1 && \
                { echo "    TeaStore WebUI respondendo."; return 0; }
            printf "."
            sleep 5
            elapsed=$((elapsed + 35))
        done
        echo ""
        [ "$attempt" = 2 ] && break
        echo "    WebUI sem resposta: rollout restart do webui (remediação)"
        kubectl rollout restart -n "$NAMESPACE" deployment/teastore-webui >/dev/null 2>&1 || true
        kubectl rollout status -n "$NAMESPACE" deployment/teastore-webui --timeout=300s >/dev/null 2>&1 || true
        pod=$(kubectl get pod -n "$NAMESPACE" -l run=teastore-webui --sort-by=.metadata.creationTimestamp \
              -o jsonpath='{.items[-1:].metadata.name}' 2>/dev/null)
    done
    echo "    AVISO: TeaStore WebUI nao respondeu apos ${timeout}s (2 tentativas)"
    return 1
}

# ── Regime estável antes de abrir a janela ────────────────────────────────
# O run.sh aplica a falha (deploy) e SÓ ENTÃO abre a janela de coleta. O deploy
# recria os pods, e o boot da JVM/Tomcat leva ~12-15 min para assentar: medido em
# 28/09, a latência do webui cai de 12.418 ms para ~220 ms dentro da janela.
# A baseline é coletada em warm state e as falhas em cold start, então referência
# e janela medem estados diferentes — foi assim que 11 das 14 janelas de 25/09
# ficaram contaminadas (razão de 3x a 180x entre o primeiro e o último minuto).
#
# Um `sleep` fixo é um palpite, e foi por isso que o WARMUP_TIME ficou em 0: o
# piso default era curto demais para o boot real, então desligá-lo "não
# contestava" nada. Aqui o regime é MEDIDO na mesma métrica que a evidência
# grava (latencia_pura_ms server-side do Tomcat, a query do sistema), e a janela
# só abre quando ela estabiliza. Piso e teto evitam sair cedo numa rampa lenta e
# esperar para sempre numa plataforma instável.

# Query do webui com janela de 1 min (a evidência usa 5 min): resolução maior
# para achar o platô rápido. O ruído da onda de 60 s do stresser é tratado no
# agregado, não aqui — ver aguardar_regime_webui.
_PROM_WEBUI_MS_QUERY='sum(rate(catalina_globalrequestprocessor_processingtime{namespace="teastore",pod=~"teastore-webui.*",name=~".*http-nio.*"}[1m])) / (sum(rate(catalina_globalrequestprocessor_requestcount{namespace="teastore",pod=~"teastore-webui.*",name=~".*http-nio.*"}[1m])) > 0)'

# POST em vez de GET na URL: a query tem {}, > e " e URL-encoding em bash é
# frágil. Sem port-forward de propósito — em 28/09 o do Prometheus caiu no meio
# da sessão e o warmup não pode depender disso.
_prom_webui_ms() {
    timeout 30 kubectl -n "${PROM_NS:-observability}" exec deploy/prometheus -c prometheus -- \
        wget -qO- -T 12 --post-data="query=$_PROM_WEBUI_MS_QUERY" \
        http://localhost:9090/api/v1/query 2>/dev/null \
    | python3 -c "
import json, sys
try:
    r = json.load(sys.stdin).get('data', {}).get('result') or []
    print('%.3f' % float(r[0]['value'][1]) if r else '')
except Exception:
    print('')
" 2>/dev/null
}

# Mediana dos últimos N valores de uma lista separada por espaço.
_mediana() {
    printf '%s\n' $1 | sort -g | awk '{v[NR]=$1} END{
        if (NR==0) { print ""; exit }
        if (NR%2) print v[(NR+1)/2]; else printf "%.3f\n", (v[NR/2]+v[NR/2+1])/2
    }'
}

# Resultado da última chamada, para quem precisa registrar (coleta-lote-stage3.sh/run-stage3-online.sh):
# REGIME_STATUS = estavel | teto | sem_leitura; REGIME_SEG = segundos esperados; REGIME_MS = última mediana.
# Com o 4º argumento, grava também um JSON com esses campos e o histórico de leituras.
REGIME_STATUS=""
REGIME_SEG=0
REGIME_MS=""

_regime_registrar() {  # status decorrido mediana hist arquivo piso teto tol
    REGIME_STATUS="$1"; REGIME_SEG="$2"; REGIME_MS="$3"
    [ -n "$5" ] || return 0
    python3 - "$@" <<'PYREG' || echo "    AVISO: não gravei o resultado do warmup em $5"
import datetime, json, sys
status, seg, med, hist, out, piso, teto, tol = sys.argv[1:9]
json.dump({
    "status": status, "segundos": int(seg), "mediana_ms": float(med) if med else None,
    "leituras_ms": [float(x) for x in hist.split()],
    "piso_s": int(piso), "teto_s": int(teto), "tol_pct": float(tol),
    "fim": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
}, open(out, "w"), indent=2)
PYREG
}

aguardar_regime_webui() {
    local piso="${1:-600}" teto="${2:-1800}" tol="${3:-5}" out="${4:-}"
    local inicio decorrido atual hist ultimos6 med_atual med_anterior estaveis
    inicio=$(date +%s)
    hist=""
    med_atual=""
    estaveis=0
    echo "    Aguardando regime do webui (piso ${piso}s, tol ${tol}%, medias de 3 min, teto ${teto}s)..."
    while :; do
        sleep 60
        decorrido=$(( $(date +%s) - inicio ))
        atual=$(_prom_webui_ms)
        if [ -z "$atual" ]; then
            echo "      ${decorrido}s  (sem leitura de latencia; seguindo)"
            if [ "$decorrido" -ge "$piso" ] && [ -z "$hist" ]; then
                echo "    AVISO: nenhuma leitura de latencia em ${decorrido}s -- regime NAO medido."
                _regime_registrar sem_leitura "$decorrido" "" "" "$out" "$piso" "$teto" "$tol"
                return 0
            fi
            if [ "$decorrido" -ge "$teto" ]; then
                echo "    AVISO: teto de ${teto}s atingido com leituras falhando."
                _regime_registrar teto "$decorrido" "$med_atual" "$hist" "$out" "$piso" "$teto" "$tol"
                return 0
            fi
            continue
        fi
        hist="${hist} ${atual}"
        # Compara a mediana dos 3 últimos minutos com a dos 3 anteriores. Mediana
        # e não amostra: a onda do stresser (WAVE_PERIOD=60s) faz o valor de 1 min
        # oscilar ±15% mesmo em regime -- medido em 28/09 no piloto, com 32,3 /
        # 32,6 / 31,5 / 36,2 / 32,4 / 27,7 / 33,5 ms depois de assentado. Com
        # janela de 1 min e tol 3% o critério nunca fechava e só o teto de 1800 s
        # salvava; a mediana de 3 min absorve a onda e ainda separa a rampa, que
        # cai de 124 ms para ~28 ms (−77%, muito acima de qualquer tolerância).
        ultimos6=$(printf '%s\n' $hist | tail -6 | tr '\n' ' ')
        if [ "$(printf '%s\n' $hist | wc -l)" -lt 6 ]; then
            echo "      ${decorrido}s  latencia=${atual}ms  (coletando medicoes)"
            continue
        fi
        med_atual=$(_mediana "$(printf '%s\n' $ultimos6 | tail -3 | tr '\n' ' ')")
        med_anterior=$(_mediana "$(printf '%s\n' $ultimos6 | head -3 | tr '\n' ' ')")
        # `med_anterior > 0` evita divisão por zero quando não há tráfego.
        if awk -v a="$med_anterior" -v b="$med_atual" -v t="$tol" \
               'BEGIN{ exit !(a>0 && ((b-a)/a*100 < t && (a-b)/a*100 < t)) }'; then
            estaveis=$(( estaveis + 1 ))
        else
            estaveis=0
        fi
        echo "      ${decorrido}s  latencia=${atual}ms  mediana 3min: ${med_anterior} -> ${med_atual}ms  estaveis=${estaveis}/2"
        if [ "$decorrido" -ge "$piso" ] && [ "$estaveis" -ge 2 ]; then
            echo "    Regime estavel em ${decorrido}s (mediana ${med_atual}ms). Abrindo janela."
            _regime_registrar estavel "$decorrido" "$med_atual" "$hist" "$out" "$piso" "$teto" "$tol"
            return 0
        fi
        if [ "$decorrido" -ge "$teto" ]; then
            echo "    AVISO: teto de ${teto}s atingido sem estabilizar (mediana ${med_atual}ms)."
            echo "    Abrindo janela assim mesmo — a contaminacao pode sobrar nesta coleta."
            _regime_registrar teto "$decorrido" "$med_atual" "$hist" "$out" "$piso" "$teto" "$tol"
            return 0
        fi
    done
}

pf() {
    local label="$1" local_port="$2" remote_port="$3" ns="$4"
    local pod
    pod=$(kubectl get pod -n "$ns" -l "$label" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    if [ -z "$pod" ]; then
        echo "    ERRO: pod label=$label ns=$ns nao encontrado"
        return 1
    fi
    nohup kubectl port-forward -n "$ns" "pod/$pod" "${local_port}:${remote_port}" >/dev/null 2>&1 &
    PF_PIDS+=($!)
}

pf_svc() {
    local svc="$1" local_port="$2" remote_port="$3" ns="$4"
    nohup kubectl port-forward -n "$ns" "svc/$svc" "${local_port}:${remote_port}" >/dev/null 2>&1 &
    PF_PIDS+=($!)
}

setup_prometheus_pf() {
    local local_port="${1:-9090}"
    local ns="${MONITOR_NS:-monitor}"
    local pod
    pod=$(kubectl get pod -n "$ns" -l app=prometheus -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    if [ -z "$pod" ]; then
        echo "    ERRO: pod prometheus nao encontrado em $ns"
        return 1
    fi
    fuser -k "${local_port}/tcp" 2>/dev/null || true
    sleep 1
    pf "app=prometheus" "$local_port" "9090" "$ns"
    sleep 2
    echo "    Prometheus port-forward: localhost:$local_port"
}

kill_port_forwards() {
    for pid in "${PF_PIDS[@]}"; do
        kill "$pid" 2>/dev/null || true
    done
    PF_PIDS=()
}

build_image() {
    local tag="$1" dockerfile="$2" context="$3"
    echo "    Build: $tag"
    docker build -q -t "$tag" -f "$dockerfile" "$context" 2>&1 | tail -1
    echo "    Load: $tag no Minikube..."
    local tarfile="/tmp/${tag}.tar"
    docker save -o "$tarfile" "$tag" 2>/dev/null
    minikube image load "$tarfile" 2>&1 | tail -1 || true
    rm -f "$tarfile"
}

# ── Build from source (new pipeline: release tags → registry) ────────

TEASTORE_CONFIG_REPO="${TEASTORE_CONFIG_REPO:-http://localhost:3000/descartesresearch/teastore-config.git}"
TEASTORE_APP_REPO="${TEASTORE_APP_REPO:-http://localhost:3000/descartesresearch/TeaStore.git}"
# Token do Gitea: NUNCA versionar. Exporte TEASTORE_GITEA_TOKEN antes de rodar os scripts que o usam.
TEASTORE_GITEA_TOKEN="${TEASTORE_GITEA_TOKEN:-}"

# Registry: push pelo host (port-forward 5000) e pull pelos nós (NodePort 30500).
# O registry é agnóstico de hostname: repositórios são por path relativo.
REGISTRY_PUSH_HOST="${REGISTRY_PUSH_HOST:-localhost:5000}"
REGISTRY_PULL_HOST="${REGISTRY_PULL_HOST:-127.0.0.1:30500}"
REGISTRY_PREFIX="${REGISTRY_PREFIX:-descartesresearch}"

# Ensure the config repo (patches + Dockerfiles) is cloned locally.
# /tmp is wiped on host reboot, so this must be self-healing.
_ensure_config_repo() {
    local cfg_dir="${TEATRE_STORE_CONFIG_DIR:-/tmp/teastore-config}"
    if [ -d "$cfg_dir/.git" ]; then
        cd "$cfg_dir"
        git fetch origin >/dev/null 2>&1 || true
        git reset --hard origin/main >/dev/null 2>&1 || true
        return 0
    fi
    echo "    Clonando teastore-config (patches)..."
    rm -rf "$cfg_dir"
    git clone -q "$TEASTORE_CONFIG_REPO" "$cfg_dir" || {
        echo "    ERRO: falha ao clonar $TEASTORE_CONFIG_REPO"
        return 1
    }
}

# Clone/fetch TeaStore app repo (com tags de release) — self-healing.
_ensure_app_repo() {
    local work_dir="${1:-/tmp/teastore-release}"
    if [ -d "$work_dir/.git" ]; then
        cd "$work_dir"
        git remote set-url origin "$TEASTORE_APP_REPO" 2>/dev/null || true
        git fetch origin --tags --prune >/dev/null 2>&1 || true
    else
        echo "    Clonando TeaStore ($TEASTORE_APP_REPO)..."
        rm -rf "$work_dir"
        git clone -q "$TEASTORE_APP_REPO" "$work_dir" || {
            echo "    ERRO: falha ao clonar $TEASTORE_APP_REPO"
            return 1
        }
        cd "$work_dir"
        git fetch origin --tags --prune >/dev/null 2>&1 || true
    fi
}

# Map failure name to affected service
_falha_to_service() {
    local falha="$1"
    local n
    if [ "$falha" = "baseline" ]; then
        echo "webui"
        return
    fi
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    case "$n" in
        f1|f2|f4|f5|f12|f14) echo "webui" ;;
        f3|f6|f7|f8|f10|f11) echo "persistence" ;;
        f9) echo "registry" ;;
        f13) echo "auth" ;;
        # hold-out (HOLDOUT.md, registrado antes da coleta): alvos que nenhuma calibração usou
        h1|h5) echo "image" ;;
        h2|h6) echo "recommender" ;;
        h3) echo "auth" ;;
        h4) echo "db" ;;
        # hold-out 2 (HOLDOUT-2.md, registrado antes da coleta): pares alvo × tipo fora do desenvolvimento
        g1) echo "auth" ;;
        g2|g6) echo "persistence" ;;
        g3) echo "image" ;;
        g4) echo "db" ;;
        g5) echo "recommender" ;;
        *) echo "unknown" ;;
    esac
}

# Map failure name → release tag (baseline → $EXP_BASE; fN-* → $EXP_BASE-fN)
_falha_to_release() {
    local falha="$1"
    if [ "$falha" = "baseline" ]; then
        echo "$EXP_BASE"
        return
    fi
    local n
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    [ -n "$n" ] && echo "${EXP_BASE}-${n}" || echo "$EXP_BASE"
}

# Ref da imagem no registry (host de push ou pull)
_registry_image() {
    local service="$1" release="$2" host="$3"
    echo "${host}/${REGISTRY_PREFIX}/teastore-${service}:${release}"
}

# Half-check se uma tag já existe no registry
_registry_has_tag() {
    local service="$1" release="$2"
    curl -sf "http://${REGISTRY_PUSH_HOST}/v2/${REGISTRY_PREFIX}/teastore-${service}/tags/list" 2>/dev/null \
        | python3 -c "import json,sys; tags=json.load(sys.stdin).get('tags',[]); print('1' if '$release' in tags else '0')" 2>/dev/null || echo "0"
}

# Falhas "só infra": não alteram o código-fonte da aplicação (nem commit nem
# imagem própria). O bug é materializado por override de config no deployment
# K8s (env/ConfigMap/resources/probe) SOBRE a imagem baseline — simulando mudança
# de infra no mundo real, onde app_commit permanece o do baseline (34b37f7).
#   f4 (invalid-path): ConfigMap montado no path do catálogo de imagens
#   f5 (jvm-heap)    : env _JAVA_OPTIONS com heap máximo reduzido (webui)
#   f6 (db-connect)  : env DB_HOST apontando p/ host inexistente (persistence)
#   f11 (mem-oom)    : limits.memory baixo p/ persistence (OOMKill/restart loop)
#   f12 (cpu-throttle): limits.cpu raso p/ webui (throttling de cgroup)
#   f13 (bad-probe)  : readinessProbe p/ endpoint inexistente no auth (NotReady)
#   f14 (log-bomb)   : ConfigMap log4j2.xml DEBUG montado no webui (volume de logs)
_is_infra_fault() {
    local falha="$1"
    local n
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    case "$n" in
        f4|f5|f6|f11|f12|f13|f14|h1|h2|h3|h4|h5|h6|g1|g2|g3|g4|g5|g6) return 0 ;;
        *) return 1 ;;
    esac
}

# JSON strategic-merge p/ override de resources (f11/f12) ou probe (f13)
_infra_resources_patch() {
    local falha="$1"
    local n
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    case "$n" in
        f11)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-persistence","resources":{"limits":{"memory":"96Mi"}}}]}}}}'
            ;;
        f12)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-webui","resources":{"limits":{"cpu":"150m"}}}]}}}}'
            ;;
        f13)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-auth","readinessProbe":{"httpGet":{"path":"/healthz","port":8080},"initialDelaySeconds":0,"periodSeconds":1,"failureThreshold":1,"timeoutSeconds":1}}]}}}}'
            ;;
        h1)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-image","resources":{"limits":{"cpu":"120m"}}}]}}}}'
            ;;
        h2)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-recommender","resources":{"limits":{"memory":"128Mi"}}}]}}}}'
            ;;
        h4)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-db","resources":{"limits":{"cpu":"110m"}}}]}}}}'
            ;;
        g1)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-auth","resources":{"limits":{"cpu":"100m"}}}]}}}}'
            ;;
        g3)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-image","resources":{"limits":{"memory":"128Mi"}}}]}}}}'
            ;;
        g4)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-db","resources":{"limits":{"memory":"96Mi"}}}]}}}}'
            ;;
        g5)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-recommender","resources":{"limits":{"cpu":"100m"}}}]}}}}'
            ;;
        *) echo '{}' ;;
    esac
}

# JSON strategic-merge p/ o override de env de uma falha infra (por nome)
_infra_env_patch() {
    local falha="$1"
    local n
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    case "$n" in
        f5)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-webui","env":[{"name":"_JAVA_OPTIONS","value":"-Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.rmi.port=1099 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Djava.rmi.server.hostname=127.0.0.1 -Xms16m -Xmx64m -javaagent:/otel/opentelemetry-javaagent.jar"}]}]}}}}'
            ;;
        f6)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-persistence","env":[{"name":"DB_HOST","value":"db-host-inexistente"}]}]}}}}'
            ;;
        h3)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-auth","env":[{"name":"_JAVA_OPTIONS","value":"-Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.rmi.port=1099 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Djava.rmi.server.hostname=127.0.0.1 -Xms16m -Xmx40m -javaagent:/otel/opentelemetry-javaagent.jar"}]}]}}}}'
            ;;
        h5)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-image","env":[{"name":"REGISTRY_HOST","value":"registry-inexistente"}]}]}}}}'
            ;;
        g6)
            echo '{"spec":{"template":{"spec":{"containers":[{"name":"teastore-persistence","env":[{"name":"_JAVA_OPTIONS","value":"-Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.rmi.port=1099 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Djava.rmi.server.hostname=127.0.0.1 -Xms16m -Xmx48m -javaagent:/otel/opentelemetry-javaagent.jar"}]}]}}}}'
            ;;
        *) echo '{}' ;;
    esac
}

# Aplica a falha infra via override de config no deployment K8s (sem trocar
# imagem/commit). Pré-requisito: o deployment do serviço já aponta p/ baseline.
_apply_infra_config() {
    local falha="$1"
    local n
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    echo "=== Aplicando config-override da falha infra $falha (imagem baseline) ==="
    case "$n" in
        f5|f6|h3|h5|g6)
            local service
            service=$(_falha_to_service "$falha")
            local envpatch
            envpatch=$(_infra_env_patch "$falha")
            kubectl patch deployment "teastore-${service}" -n "$NAMESPACE" \
                --type=strategic -p "$envpatch" 2>/dev/null || return 1
            echo "    Override env aplicado a teastore-${service}."
            ;;
        h6)
            kubectl scale deployment teastore-recommender -n "$NAMESPACE" --replicas=0 2>/dev/null || return 1
            echo "    teastore-recommender escalado para 0 réplicas (dependência indisponível)."
            ;;
        g2)
            kubectl scale deployment teastore-persistence -n "$NAMESPACE" --replicas=0 2>/dev/null || return 1
            echo "    teastore-persistence escalado para 0 réplicas (dependência indisponível)."
            ;;
        f11|f12|f13|h1|h2|h4|g1|g3|g4|g5)
            local service
            service=$(_falha_to_service "$falha")
            local respatch
            respatch=$(_infra_resources_patch "$falha")
            kubectl patch deployment "teastore-${service}" -n "$NAMESPACE" \
                --type=strategic -p "$respatch" 2>/dev/null || return 1
            echo "    Override resources/probe aplicado a teastore-${service}."
            ;;
        f4)
            kubectl create configmap falha-invalid-path -n "$NAMESPACE" \
                --from-literal=catalogo="" 2>/dev/null \
                || kubectl patch configmap falha-invalid-path -n "$NAMESPACE" \
                    -p '{"data":{"catalogo":""}}' 2>/dev/null || true
            kubectl patch deployment teastore-webui -n "$NAMESPACE" --type=strategic \
                -p '{"spec":{"template":{"spec":{"volumes":[{"name":"catalogo-invalido","configMap":{"name":"falha-invalid-path"}}],"containers":[{"name":"teastore-webui","volumeMounts":[{"name":"catalogo-invalido","mountPath":"/opt/teastore/imagens/catalogo"}]}]}}}}' 2>/dev/null || return 1
            echo "    ConfigMap falha-invalid-path montado em /opt/teastore/imagens/catalogo (webui)."
            ;;
        f14)
            kubectl create configmap falha-log-debug -n "$NAMESPACE" \
                --from-literal=log4j2.xml='<?xml version="1.0" encoding="UTF-8"?><Configuration status="WARN"><Appenders><Console name="Console"><PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/></Console></Appenders><Loggers><Root level="DEBUG"><AppenderRef ref="Console"/></Root></Loggers></Configuration>' 2>/dev/null \
                || kubectl patch configmap falha-log-debug -n "$NAMESPACE" \
                    -p '{"data":{"log4j2.xml":"<Configuration status=\"WARN\"><Appenders><Console name=\"Console\"><PatternLayout pattern=\"%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n\"/></Appenders></Loggers><Root level=\"DEBUG\"/></Configuration>"}}' 2>/dev/null || true
            kubectl patch deployment teastore-webui -n "$NAMESPACE" --type=strategic \
                -p '{"spec":{"template":{"spec":{"volumes":[{"name":"logconf","configMap":{"name":"falha-log-debug"}}],"containers":[{"name":"teastore-webui","volumeMounts":[{"name":"logconf","mountPath":"/usr/local/tomcat/webapps/ROOT/WEB-INF/classes/log4j2.xml","subPath":"log4j2.xml"}]}]}}}}' 2>/dev/null || return 1
            echo "    ConfigMap falha-log-debug (log4j2 DEBUG) montado no webui."
            ;;
        *)
            echo "    ERRO: falha $falha não tem config-override definido." >&2
            return 1
            ;;
    esac
    local service
    service=$(_falha_to_service "$falha")
    kubectl rollout status -n "$NAMESPACE" "deployment/teastore-${service}" \
        --watch --timeout=180s 2>/dev/null || true
    echo "    Config-override aplicado a teastore-${service}."
}

# Reverte o override de config de uma falha infra: recria o deployment do
# serviço a partir do manifest base (zera env/volumes/resources/probes) e
# reaponta p/ baseline.
_revert_infra_config() {
    local falha="$1"
    local n service
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    service=$(_falha_to_service "$falha")
    echo "=== Revertendo config-override da falha infra $falha (teastore-${service}) ==="
    if [ "$n" = "f4" ]; then
        kubectl delete configmap -n "$NAMESPACE" falha-invalid-path 2>/dev/null || true
    fi
    if [ "$n" = "f14" ]; then
        kubectl delete configmap -n "$NAMESPACE" falha-log-debug 2>/dev/null || true
    fi
    kubectl delete deployment -n "$NAMESPACE" "teastore-${service}" 2>/dev/null || true
    # Só o serviço da falha volta ao manifesto base (seletor `run=`). O apply da base INTEIRA reimplantava os 7
    # serviços, inclusive o teastore-db, cujo banco é efêmero: o próximo cenário começava com o banco
    # regenerando -- persistence com 67% de 5xx e webui sem responder antes da F14 e da F7, recommender fora do
    # registry antes da F10 e da F1 no lote de calibração 20260926T203024Z.
    kubectl apply -f "$SCRIPT_DIR/teastore-base.yaml" -l "run=teastore-${service}" 2>/dev/null || true
    _deploy_image "$service" "$(_registry_image "$service" "$EXP_BASE" "$REGISTRY_PULL_HOST")"
    if ! wait_for_generatedb 180; then
        regenerar_banco_teastore && wait_for_generatedb 300 \
            || echo "    AVISO: banco do TeaStore sem generatedb/finished=true depois do rollback de $falha."
    fi
    echo "    Config-override revertido para baseline (só teastore-${service})."
}

# Garante port-forward do registry no host (push)
_ensure_registry_pf() {
    if curl -sf "http://${REGISTRY_PUSH_HOST}/v2/" >/dev/null 2>&1; then
        return 0
    fi
    if ! pgrep -f "port-forward.*registry.*5000:5000" >/dev/null 2>&1; then
        echo "    Abrindo port-forward do registry (${REGISTRY_PUSH_HOST})..."
        setsid nohup kubectl port-forward -n registry svc/registry 5000:5000 >/tmp/registry-pf.log 2>&1 &
        disown -a
    fi
    local i
    for i in $(seq 1 15); do
        curl -sf "http://${REGISTRY_PUSH_HOST}/v2/" >/dev/null 2>&1 && return 0
        sleep 2
    done
    return 1
}

# Build de release a partir da tag git + push no registry
_release_build_n_push() {
    local service="$1" release="$2"
    local work_dir="${TEATRE_STORE_SRC_DIR:-/tmp/teastore-release}"
    local push_tag pull_tag
    push_tag=$(_registry_image "$service" "$release" "$REGISTRY_PUSH_HOST")
    pull_tag=$(_registry_image "$service" "$release" "$REGISTRY_PULL_HOST")

    _ensure_app_repo "$work_dir" || return 1
    cd "$work_dir"
    if ! git rev-parse -q --verify "refs/tags/${release}" >/dev/null; then
        echo "    ERRO: tag ${release} não existe no repo TeaStore"
        return 1
    fi
    echo "    Checkout da release ${release} (commit $(git rev-parse --short "${release}^{commit}"))..."
    git checkout -q "$release"

    echo "    Building WAR: services/tools.descartes.teastore.${service}"
    mvn package -DskipTests -pl "services/tools.descartes.teastore.${service}" -am -q 2>&1 | tail -3

    echo "    Build: $push_tag (service=$service)"
    docker build -q -t "$push_tag" \
        -f "$work_dir/utilities/tools.descartes.teastore.docker.all/Dockerfile" \
        "$work_dir/services/tools.descartes.teastore.${service}" 2>&1 | tail -3

    echo "    Publicando no registry: $push_tag"
    docker push "$push_tag"
    printf '%s' "$pull_tag"
}

# Deploy: aponta o deployment para a imagem do registry (pipeline de release)
_deploy_image() {
    local service="$1" image="$2"
    echo "    Atualizando deployment teastore-${service} -> ${image}"
    kubectl set image -n "$NAMESPACE" \
        "deployment/teastore-${service}" \
        "teastore-${service}=${image}" 2>/dev/null
    kubectl patch deployment "teastore-${service}" -n "$NAMESPACE" \
        -p "{\"spec\":{\"template\":{\"spec\":{\"containers\":[{\"name\":\"teastore-${service}\",\"imagePullPolicy\":\"Always\"}]}}}}" 2>/dev/null || true
    echo "    Aguardando rollout..."
    kubectl rollout status -n "$NAMESPACE" "deployment/teastore-${service}" --watch --timeout=180s 2>/dev/null || true
}

# Apply failure: falhas de código via release (build → push → deploy image);
# falhas "só infra" (f4/f5/f6) via override de config sobre a imagem baseline
# (sem commit próprio nem release distinta).
aplicar_falha_build() {
    local falha="$1"
    local service
    service=$(_falha_to_service "$falha")

    if [ "$service" = "unknown" ]; then
        echo "    ERRO: serviço desconhecido para falha $falha"
        return 1
    fi

    if _is_infra_fault "$falha"; then
        local pull_tag
        pull_tag=$(_registry_image "$service" "$EXP_BASE" "$REGISTRY_PULL_HOST")
        echo "=== Aplicando falha infra $falha (imagem baseline ${pull_tag}, sem release própria) ==="
        _deploy_image "$service" "$pull_tag"
        _apply_infra_config "$falha"
        echo "=== Falha infra $falha aplicada (config-override sobre baseline) ==="
        return 0
    fi

    local release push_tag pull_tag
    release=$(_falha_to_release "$falha")
    push_tag=$(_registry_image "$service" "$release" "$REGISTRY_PUSH_HOST")
    pull_tag=$(_registry_image "$service" "$release" "$REGISTRY_PULL_HOST")

    echo "=== Aplicando falha $falha (release=$release, serviço=$service) ==="

    # Pipeline: garantir release publicada no registry
    _ensure_registry_pf || { echo "    ERRO: registry inacessível em ${REGISTRY_PUSH_HOST}"; return 1; }
    if [ "$(_registry_has_tag "$service" "$release")" = "1" ]; then
        echo "    Release ${release} já publicada no registry."
    else
        echo "    Release ${release} não publicada — build + push a partir da tag git..."
        _release_build_n_push "$service" "$release" || return 1
    fi

    # Deploy: aponta para a imagem do registry (pull via NodePort)
    _deploy_image "$service" "$pull_tag"

    echo "=== Falha $falha aplicada (${pull_tag}) ==="
}

# Rollback: falhas infra revertem override de config para baseline;
# falhas de código restauram a baseline ($EXP_BASE) do registry.
rollback_falha_build() {
    local falha="$1"
    local service
    service=$(_falha_to_service "$falha")

    if _is_infra_fault "$falha"; then
        _revert_infra_config "$falha"
        return 0
    fi

    echo "=== Rollback: restaurando baseline (${EXP_BASE}) para teastore-${service} ==="

    # Deploy usa a imagem baseline já publicada no registry (release anterior)
    _deploy_image "$service" "$(_registry_image "$service" "$EXP_BASE" "$REGISTRY_PULL_HOST")"

    echo "=== Baseline restaurado ==="
}

# ── Stresser ─────────────────────────────────────────────────────────

_stresser_set_active() {
    local want_active="$1" label="$2"
    local users
    users=$(kubectl exec -n "$STRESS_NS" deploy/stresser -- python3 -c "
import urllib.request, json
d = json.loads(urllib.request.urlopen('http://localhost:8000/status').read())
if d['active'] != ${want_active}:
    urllib.request.urlopen('http://localhost:8000/toggle', data=b'').read()
    d = json.loads(urllib.request.urlopen('http://localhost:8000/status').read())
print(d['active_users'])
" 2>/dev/null)
    echo "    ${label} com ${users} usuarios."
}

stresser_on() {
    echo "    Ligando stresser..."
    # O app do stresser não lê MIN_USERS/PEAK_USERS/WAVE_PERIOD do ambiente (WAVE_PERIOD=600 fixo no
    # código) e volta ao padrão quando o pod reinicia: a carga da baseline só é garantida pelo /config.
    kubectl exec -n "$STRESS_NS" deploy/stresser -- python3 -c "
import json, urllib.request
body = json.dumps({'min_users': $STRESSER_MIN_USERS, 'peak_users': $STRESSER_PEAK_USERS,
                   'wave_period': $STRESSER_WAVE_PERIOD}).encode()
req = urllib.request.Request('http://localhost:8000/config', data=body, method='POST',
                             headers={'Content-Type': 'application/json'})
print('    Config do stresser:', urllib.request.urlopen(req).read().decode())
" || echo "    AVISO: não consegui aplicar a config do stresser."
    _stresser_set_active "True" "Stresser ativo"
}

stresser_off() {
    echo "    Desligando stresser..."
    _stresser_set_active "False" "Stresser desligado"
}

# Regenera o banco pelo próprio TeaStore (mesmos tamanhos da geração inicial: 5 categorias, 100 produtos por
# categoria, 100 usuários, até 5 pedidos por usuário). É o conserto já usado nas coletas anteriores.
regenerar_banco_teastore() {
    local pod
    pod=$(kubectl get pod -n "$NAMESPACE" -l run=teastore-persistence -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    [ -n "$pod" ] || { echo "    AVISO: pod da persistence não encontrado para regenerar o banco"; return 1; }
    echo "    Regenerando o banco do TeaStore (generatedb) em $pod..."
    timeout 60 kubectl exec -n "$NAMESPACE" "$pod" -c teastore-persistence -- wget -qO- --timeout=30 --tries=1 \
        "http://localhost:8080/tools.descartes.teastore.persistence/rest/generatedb?categories=5&products=100&users=100&orders=5" \
        >/dev/null 2>&1
}

# Garante que o deployment do stresser existe. A CARGA (10-20 usuários, onda de 60 s) não é
# garantida aqui: o app do stresser ignora MIN_USERS/PEAK_USERS/WAVE_PERIOD do ambiente (WAVE_PERIOD=600 fixo
# no código), então corrigir o env só reiniciava o pod -- e o reinício devolvia a onda aos 600 s. Quem
# garante a carga é `stresser_on`, que aplica a config por `POST /config` a cada ligação.
_ensure_stresser_config() {
    if ! kubectl get deployment -n "$STRESS_NS" stresser &>/dev/null; then
        kubectl apply -f "$PROJECT_DIR/k8s/stress/stresser.yaml" 2>/dev/null || return 1
        kubectl rollout status -n "$STRESS_NS" deployment/stresser --timeout=180s >/dev/null 2>&1 || true
    fi
    return 0
}

# ── TeaStore base ────────────────────────────────────────────────────

restaurar_teastore() {
    echo "    Restaurando TeaStore ao estado base (release ${EXP_BASE})..."
    # Remover possiveis artifacts de falhas anteriores
    kubectl delete deployment -n "$NAMESPACE" teastore-registry-mock 2>/dev/null || true
    kubectl delete configmap -n "$NAMESPACE" falha-invalid-path 2>/dev/null || true
    # Deletar deployments q podem ter sidecars para garantir limpeza total
    for dep in teastore-webui teastore-auth teastore-persistence; do
        kubectl delete deployment -n "$NAMESPACE" "$dep" 2>/dev/null || true
    done
    # Limpar pods stuck em Terminating
    cleanup_terminating_pods "$NAMESPACE"
    # Aplicar base (recria os deployments deletados)
    kubectl apply -f "$SCRIPT_DIR/teastore-base.yaml" 2>/dev/null
    # Garantir registry com replica 1
    kubectl scale -n "$NAMESPACE" deployment/teastore-registry --replicas=1 2>/dev/null || true
    # Redirecionar todos os deployments para a imagem baseline publicada no registry
    _ensure_registry_pf >/dev/null 2>&1 || true
    # registry PRIMEIRO: se ele reinicia por último, sobe com a lista vazia e o webui fica preso até todos se
    # registrarem de novo (travou a 1ª tentativa da recoleta)
    for dep in teastore-registry teastore-db teastore-persistence teastore-auth teastore-image \
               teastore-recommender teastore-webui; do
        local service="${dep#teastore-}"
        local img
        img=$(_registry_image "$service" "$EXP_BASE" "$REGISTRY_PULL_HOST")
        _deploy_image "$service" "$img" 2>/dev/null || true
    done
    # Garantir que o stresser existe no namespace stress
    if ! kubectl get deployment -n "$STRESS_NS" stresser &>/dev/null; then
        kubectl apply -f "$PROJECT_DIR/k8s/stress/stresser.yaml" 2>/dev/null
    fi
    _ensure_stresser_config >/dev/null 2>&1 || echo "    AVISO: não consegui normalizar a config do stresser."
    wait_for_teastore_ready
    # só depois de o banco efêmero estar populado o webui tem o que servir. A ordem importa --
    # checar o webui antes deixaria passar um catálogo vazio com HTTP 200.
    if ! wait_for_generatedb 180; then
        # Geração interrompida (o banco efêmero recriado no boot e a persistence trocada no meio):
        # a flag fica em 0, a persistence nova não regenera sozinha, e image/recommender nunca se registram.
        regenerar_banco_teastore && wait_for_generatedb 300 \
            || echo "    AVISO: banco do TeaStore sem generatedb/finished=true -- o ambiente não está saudável."
    fi
    wait_for_teastore_webui 300
    echo "    TeaStore restaurado."
}

# ── Veritas ──────────────────────────────────────────────────────────

_veritas_api() {
    local method="$1" path="$2" data="$3"
    curl -s -X "$method" \
        -H "Content-Type: application/json" \
        -H "Accept: application/json" \
        -H "X-API-Key: change-me" \
        ${data:+-d "$data"} \
        "http://localhost:8000${path}" || {
        echo "ERRO: _veritas_api falhou (method=$method path=$path)"
        return 1
    }
}

registrar_falha_veritas() {
    local falha_nome="$1" system_id="$2"
    local package_window="${3:-}"
    local now_epoch end_epoch
    now_epoch=$(date -u +%s)
    end_epoch=$((now_epoch))
    local start_epoch=$((end_epoch - COLLECT_TIME))
    local window_start window_end
    window_start=$(date -u -d "@${start_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    window_end=$(date -u -d "@${end_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    local body
    if [ -n "$package_window" ]; then
        body=$(cat <<EOF
{"name": "${falha_nome}", "description": "Falha ${falha_nome} no TeaStore", "window_start": "${window_start}", "window_end": "${window_end}", "package_window_seconds": ${package_window}}
EOF
)
    else
        body=$(cat <<EOF
{"name": "${falha_nome}", "description": "Falha ${falha_nome} no TeaStore", "window_start": "${window_start}", "window_end": "${window_end}"}
EOF
)
    fi
    echo "    Registrando falha $falha_nome no Veritas (janela: ${window_start} -> ${window_end}, package_window_seconds: ${package_window:-default})..."
    _veritas_api "POST" "/systems/${system_id}/failures" "$body"
    echo ""
}

registrar_baseline_veritas() {
    local system_id="$1"
    local package_window="${2:-}"
    local now_epoch end_epoch
    now_epoch=$(date -u +%s)
    end_epoch=$((now_epoch))
    local start_epoch=$((end_epoch - COLLECT_TIME))
    local window_start window_end
    window_start=$(date -u -d "@${start_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    window_end=$(date -u -d "@${end_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    local body
    if [ -n "$package_window" ]; then
        body=$(cat <<EOF
{"name": "baseline", "description": "Coleta baseline sem falhas", "window_start": "${window_start}", "window_end": "${window_end}", "is_baseline": true, "package_window_seconds": ${package_window}}
EOF
)
    else
        body=$(cat <<EOF
{"name": "baseline", "description": "Coleta baseline sem falhas", "window_start": "${window_start}", "window_end": "${window_end}", "is_baseline": true}
EOF
)
    fi
    echo "    Registrando baseline no Veritas (janela: ${window_start} -> ${window_end}, package_window_seconds: ${package_window:-default})..."
    _veritas_api "POST" "/systems/${system_id}/failures" "$body"
    echo ""
}

treinar_modelo() {
    local system_id="$1"
    local collection_id="${2:-}"
    if [ -z "$collection_id" ]; then
        echo "    ERRO: collection_id da coleta (baseline) é obrigatório para o treinamento."
        return 1
    fi
    echo "    Iniciando treinamento do modelo (collection_id=${collection_id})..."
    _veritas_api "POST" "/systems/${system_id}/train" "{\"collection_id\": \"${collection_id}\"}"
    echo ""
    echo "    Acompanhe: http://localhost:8000/systems/${system_id}/train/status"
}

# ── Collections ──────────────────────────────────────────────────────

criar_colecao() {
    local system_id="$1"
    local nome="$2"
    local package_window="${3:-60}"
    local body
    local post_window="$package_window"
    if [ "$package_window" -lt 10 ]; then
        post_window=10
    fi
    body=$(cat <<EOF
{"name": "${nome}", "package_window_seconds": ${post_window}}
EOF
)
    echo "    Criando colecao '${nome}'..."
    local resp
    resp=$(_veritas_api "POST" "/systems/${system_id}/collections" "$body")
    ACTIVE_COLLECTION_ID=$(echo "$resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('collection_id',''))" 2>/dev/null || true)
    if [ -z "$ACTIVE_COLLECTION_ID" ]; then
        echo "    ERRO: falha ao criar colecao. Resposta: $resp"
        return 1
    fi
    if [ "$package_window" -lt 10 ]; then
        echo "    PATCH package_window_seconds=${package_window} (workaround <10s)..."
        _veritas_api "PATCH" "/systems/${system_id}/collections/${ACTIVE_COLLECTION_ID}" "{\"package_window_seconds\": ${package_window}}" > /dev/null || true
    fi
    echo "    Colecao criada: $ACTIVE_COLLECTION_ID"
}

# ── Version Context ──────────────────────────────────────────────────

ativar_version_context() {
    local system_id="$1"
    local cenario="$2"
    local version_json_file="$3"
    local data
    data=$(cat "$version_json_file")
    ACTIVE_VERSION_CENARIO="$cenario"
    echo "    Ativando version-context '${cenario}'..."
    _veritas_api "PUT" "/systems/${system_id}/version-contexts/${cenario}?activate=true" "$data" > /dev/null
    echo "    Version-context '${cenario}' ativado."
}

desativar_version_context() {
    local system_id="$1"
    if [ -n "$ACTIVE_VERSION_CENARIO" ]; then
        echo "    Desativando version-context '${ACTIVE_VERSION_CENARIO}'..."
        _veritas_api "POST" "/systems/${system_id}/version-contexts/deactivate" '{}' > /dev/null || true
        ACTIVE_VERSION_CENARIO=""
    fi
}

# ── Falha com collection_id ─────────────────────────────────────────

registrar_falha_veritas() {
    local falha_nome="$1" system_id="$2"
    local package_window="${3:-}"
    local now_epoch end_epoch
    now_epoch=$(date -u +%s)
    end_epoch=$((now_epoch))
    local start_epoch=$((end_epoch - COLLECT_TIME))
    local window_start window_end
    window_start=$(date -u -d "@${start_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    window_end=$(date -u -d "@${end_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    local body
    local pw="${package_window:-60}"
    body=$(cat <<EOF
{"name": "${falha_nome}", "description": "Falha ${falha_nome} no TeaStore", "window_start": "${window_start}", "window_end": "${window_end}", "package_window_seconds": ${pw}, "collection_id": "${ACTIVE_COLLECTION_ID}"}
EOF
)
    echo "    Registrando falha $falha_nome no Veritas (janela: ${window_start} -> ${window_end}, pw=${pw}, collection=${ACTIVE_COLLECTION_ID})..."
    local resp
    resp=$(_veritas_api "POST" "/systems/${system_id}/failures" "$body")
    LAST_FAILURE_ID=$(echo "$resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('failure_id',''))" 2>/dev/null || true)
    if [ -z "$LAST_FAILURE_ID" ]; then
        echo "    ERRO: falha ao obter failure_id da resposta: $resp"
        return 1
    fi
    echo "    failure_id=${LAST_FAILURE_ID}"
    echo ""
}

registrar_baseline_veritas() {
    local system_id="$1"
    local package_window="${2:-}"
    local now_epoch end_epoch
    now_epoch=$(date -u +%s)
    end_epoch=$((now_epoch))
    local start_epoch=$((end_epoch - COLLECT_TIME))
    local window_start window_end
    window_start=$(date -u -d "@${start_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    window_end=$(date -u -d "@${end_epoch}" +%Y-%m-%dT%H:%M:%S)+00:00
    local body
    local pw="${package_window:-60}"
    body=$(cat <<EOF
{"name": "baseline", "description": "Coleta baseline sem falhas", "window_start": "${window_start}", "window_end": "${window_end}", "is_baseline": true, "package_window_seconds": ${pw}, "collection_id": "${ACTIVE_COLLECTION_ID}"}
EOF
)
    echo "    Registrando baseline no Veritas (janela: ${window_start} -> ${window_end}, pw=${pw}, collection=${ACTIVE_COLLECTION_ID})..."
    local resp
    resp=$(_veritas_api "POST" "/systems/${system_id}/failures" "$body")
    LAST_FAILURE_ID=$(echo "$resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('failure_id',''))" 2>/dev/null || true)
    if [ -z "$LAST_FAILURE_ID" ]; then
        echo "    ERRO: falha ao obter failure_id da resposta: $resp"
        return 1
    fi
    echo "    failure_id=${LAST_FAILURE_ID}"
    echo ""
    aguardar_baseline_drain "$system_id" "${BASELINE_DRAIN_TIMEOUT:-300}"
}

aguardar_baseline_drain() {
    local system_id="$1"
    local timeout="${2:-120}"
    echo "    Aguardando baseline atingir status pending_drain (timeout ${timeout}s)..."
    local elapsed=0
    while [ $elapsed -lt "$timeout" ]; do
        local status
        status=$(curl -sf -H "X-API-Key: change-me" \
            "http://localhost:8000/systems/${system_id}/failures" 2>/dev/null \
            | python3 -c "
import json,sys
failures=json.load(sys.stdin)
baselines=[f for f in failures if f.get('is_baseline')]
if baselines: print(baselines[-1].get('status','unknown'))
else: print('none')
" 2>/dev/null || echo "error")
        if [ "$status" = "pending_drain" ] || [ "$status" = "draining" ] || [ "$status" = "completed" ]; then
            echo "    Baseline status: $status"
            return 0
        fi
        printf "."
        sleep 3
        elapsed=$((elapsed + 3))
    done
    echo ""
    echo "    AVISO: baseline nao atingiu pending_drain apos ${timeout}s (status=$status)"
}

aguardar_failure_pending_drain() {
    local system_id="$1"
    local failure_id="$2"
    local timeout="${3:-300}"
    echo "    Aguardando failure=${failure_id} atingir pending_drain (timeout ${timeout}s)..."
    local elapsed=0
    while [ $elapsed -lt "$timeout" ]; do
        local status
        status=$(curl -sf -H "X-API-Key: change-me" \
            "http://localhost:8000/systems/${system_id}/failures/${failure_id}" 2>/dev/null \
            | python3 -c "import json,sys; d=json.load(sys.stdin); f=d.get('failure',d); print(f.get('status','unknown'))" 2>/dev/null || echo "error")
        if [ "$status" = "pending_drain" ] || [ "$status" = "draining" ] || [ "$status" = "completed" ]; then
            echo "    Failure status: $status"
            return 0
        fi
        if [ "$status" = "failed" ]; then
            echo "    AVISO: failure entrou em status=failed"
            return 1
        fi
        printf "."
        sleep 3
        elapsed=$((elapsed + 3))
    done
    echo ""
    echo "    AVISO: failure nao atingiu pending_drain apos ${timeout}s (status=$status)"
    return 1
}

drain_falha_veritas() {
    local system_id="$1"
    local failure_id="$2"
    echo "    Disparando drain para failure=${failure_id}..."
    _veritas_api "POST" "/systems/${system_id}/failures/${failure_id}/drain" '{}'
    echo ""
}

# Persistir a janela em disco.
#
# A evidência (failure + evidence_packages) só existe no Postgres do cluster.
# Um reboot/recreate do minikube apaga tudo, e com isso some a única forma de
# auditar a coleta — foi o que aconteceu com o piloto f1/f5/f10 de 28/09: os
# metadados (version.json) sobreviveram no git, mas as janelas sumiram e o
# piloto virou irrecuperável. Por isso o dump é para $RESULTADOS/evidencia/,
# que é versionável e sobrevive ao cluster.
exportar_evidencia() {
    local system_id="$1"
    local failure_id="$2"
    local nome="${3:-${failure_id:0:8}}"
    local out_dir="$RESULTADOS/evidencia"
    local out_file="$out_dir/${nome}-${failure_id}.json"

    mkdir -p "$out_dir"
    if curl -sf -H "X-API-Key: change-me" \
        "http://localhost:8000/systems/${system_id}/failures/${failure_id}" \
        -o "$out_file" 2>/dev/null && [ -s "$out_file" ]; then
        # Guarda uma contagem junto para dar para auditar sem abrir o JSON.
        local n
        n=$(python3 -c "
import json,sys
d=json.load(open('$out_file'))
p=d.get('evidence_packages') or []
print(len(p))
" 2>/dev/null || echo 0)
        echo "    Evidencia exportada: ${out_file} (${n} pacotes)"
    else
        echo "    AVISO: nao foi possivel exportar evidencia de ${failure_id}"
        rm -f "$out_file"
        return 1
    fi
}

aguardar_drain_concluido() {
    local system_id="$1"
    local failure_id="$2"
    local timeout="${3:-1500}"
    echo "    Aguardando drain completar para failure=${failure_id} (timeout ${timeout}s)..."
    local elapsed=0
    while [ $elapsed -lt "$timeout" ]; do
        local status evidence_count
        status=$(curl -sf -H "X-API-Key: change-me" \
            "http://localhost:8000/systems/${system_id}/failures/${failure_id}" 2>/dev/null \
            | python3 -c "import json,sys; d=json.load(sys.stdin); f=d.get('failure',d); print(f.get('status','unknown'))" 2>/dev/null || echo "error")
        evidence_count=$(curl -sf -H "X-API-Key: change-me" \
            "http://localhost:8000/systems/${system_id}/failures/${failure_id}" 2>/dev/null \
            | python3 -c "import json,sys; d=json.load(sys.stdin); f=d.get('failure',d); print(f.get('evidence_count',0))" 2>/dev/null || echo "0")
        if [ "$status" = "completed" ]; then
            echo "    Drain concluido (status=completed, evidence_count=${evidence_count})."
            return 0
        fi
        if [ "$status" = "failed" ] || [ "$status" = "invalid" ]; then
            echo "    AVISO: failure terminou em status=$status"
            return 1
        fi
        printf "."
        sleep 5
        elapsed=$((elapsed + 5))
    done
    echo ""
    echo "    AVISO: drain nao completou apos ${timeout}s (status=$status)"
    return 1
}

# ── Version JSON ─────────────────────────────────────────────────────

# Version.json para falhas "só infra": app_commit = baseline (34b37f7), sem
# release própria; a variação é descrita como override de config no deployment.
_gerar_version_json_infra() {
    local falha="$1" output_file="$2"
    local n service desc
    n=$(echo "$falha" | grep -oE '^[fhg][0-9]+' | head -1 || true)
    service=$(_falha_to_service "$falha")
    case "$n" in
        f5) desc="Override de config no deployment teastore-webui (env _JAVA_OPTIONS com -Xms16m -Xmx64m) sobre imagem baseline; sem mudança de código-fonte." ;;
        f6) desc="Override de config no deployment teastore-persistence (env DB_HOST -> host inexistente) sobre imagem baseline; sem mudança de código-fonte." ;;
        f4) desc="Override de config no deployment teastore-webui (ConfigMap falha-invalid-path montado em /opt/teastore/imagens/catalogo) sobre imagem baseline; sem mudança de código-fonte." ;;
        f11) desc="Override de config no deployment teastore-persistence (resources.limits.memory=96Mi) sobre imagem baseline; OOMKill/restart em loop; sem mudança de código-fonte." ;;
        f12) desc="Override de config no deployment teastore-webui (resources.limits.cpu=150m) sobre imagem baseline; throttling de cgroup; sem mudança de código-fonte." ;;
        f13) desc="Override de config no deployment teastore-auth (readinessProbe em /healthz inexistente) sobre imagem baseline; pod NotReady; sem mudança de código-fonte." ;;
        h1) desc="HOLD-OUT: teastore-image com resources.limits.cpu=120m (throttling) sobre imagem baseline." ;;
        h2) desc="HOLD-OUT: teastore-recommender com resources.limits.memory=128Mi (OOM) sobre imagem baseline." ;;
        h3) desc="HOLD-OUT: teastore-auth com _JAVA_OPTIONS -Xmx40m (heap reduzido) sobre imagem baseline." ;;
        h4) desc="HOLD-OUT: teastore-db com resources.limits.cpu=110m (banco lento) sobre imagem baseline." ;;
        h5) desc="HOLD-OUT: teastore-image com REGISTRY_HOST=registry-inexistente (descoberta mal configurada)." ;;
        h6) desc="HOLD-OUT: teastore-recommender escalado para 0 réplicas (dependência indisponível)." ;;
        g1) desc="HOLD-OUT 2: teastore-auth com resources.limits.cpu=100m (throttling) sobre imagem baseline." ;;
        g2) desc="HOLD-OUT 2: teastore-persistence escalado para 0 réplicas (dependência indisponível)." ;;
        g3) desc="HOLD-OUT 2: teastore-image com resources.limits.memory=128Mi sobre imagem baseline." ;;
        g4) desc="HOLD-OUT 2: teastore-db com resources.limits.memory=96Mi sobre imagem baseline." ;;
        g5) desc="HOLD-OUT 2: teastore-recommender com resources.limits.cpu=100m (throttling) sobre imagem baseline." ;;
        g6) desc="HOLD-OUT 2: teastore-persistence com _JAVA_OPTIONS -Xmx48m (heap reduzido) sobre imagem baseline." ;;
        f14) desc="Override de config no deployment teastore-webui (ConfigMap falha-log-debug com log4j2 DEBUG) sobre imagem baseline; explosão de logs; sem mudança de código-fonte." ;;
        *) desc="Override de config no deployment; sem mudança de código-fonte." ;;
    esac
    local baseline_full baseline_short
    # Commit da release base pela tag no Gitea (fonte de verdade); o arquivo TEASTORE_COMMIT é a base antiga.
    baseline_full=$(git ls-remote --tags "$TEASTORE_APP_REPO" "refs/tags/${EXP_BASE}^{}" 2>/dev/null | cut -f1)
    [ -n "$baseline_full" ] || baseline_full=$(git ls-remote --tags "$TEASTORE_APP_REPO" "refs/tags/${EXP_BASE}" 2>/dev/null | cut -f1)
    [ -n "$baseline_full" ] || baseline_full=$(cat "$SCRIPT_DIR/../TEASTORE_COMMIT" 2>/dev/null || echo "34b37f7e7be433ce72d5f9455e66922a13116749")
    baseline_short="${baseline_full:0:7}"
    cat > "$output_file" <<EOF
{
  "configuracao": {
    "status": "CONFIGURACOES_ALTERADAS",
    "ambiente": "k8s",
    "falha": "$falha",
    "motivo": "$desc",
    "arquivos_alterados": [{"arquivo": "k8s/deployment/teastore-${service}/override-config", "diff": "$desc"}]
  },
  "aplicacao": {
    "nome": "teastore",
    "repo_url": "https://localhost:3000/descartesresearch/TeaStore",
    "release_tag": "${EXP_BASE}",
    "app_commit_version": "$baseline_short",
    "dt_commit_version": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  },
  "config": {
    "repo_url": "k8s deployment manifest (teastore-base.yaml + override)",
    "config_commit_version": "$(basename "$SCRIPT_DIR")/teastore-base.yaml"
  }
}
EOF
}

gerar_version_json() {
    local falha="$1" output_file="$2"
    if _is_infra_fault "$falha"; then
        echo "    Gerando version.json INFRA (commit baseline, config-deploy) para ${falha}..."
        _gerar_version_json_infra "$falha" "$output_file"
        echo "    Version.json: $output_file"
        return 0
    fi
    _ensure_config_repo
    echo "    Gerando version.json para ${falha}..."
    FALHA="$falha" bash "$VERSION_SCRIPT" --falha "$falha" > "$output_file"
    echo "    Version.json: $output_file"
}

aguardar() {
    local segundos="$1"
    echo "    Aguardando ${segundos}s de coleta..."
    for i in $(seq 1 "$segundos"); do
        if [ $((i % 60)) -eq 0 ]; then
            echo "    ... $i s decorridos"
        fi
        sleep 1
    done
    echo "    Coleta finalizada."
}
