#!/usr/bin/env bash
# Coleta completa do lote do Stage 3 num comando só:
#
#   FASE 0  pré-voo       -- nós Ready, pods sem resíduo, observabilidade de pé (Prometheus com alvos,
#                            Jaeger com serviços), API, Gitea, registry e releases das falhas de código.
#                            Qualquer reprovação aborta ANTES de mexer no cluster.
#   FASE 1  aquecimento   -- restaura o TeaStore à release base, liga a carga e espera o regime MEDIDO do
#                            webui (aguardar_regime_webui), não um sleep. O boot da JVM leva 12-15 min,
#                            e foi ele que contaminou 11 das 14 janelas de 25/09.
#   FASE 2  baseline      -- health_gate com carga (bloqueante), janela da baseline numa coleção nova
#                            (protocolo de manutencao/baseline_25m.sh: 25 min, pacotes de 3 s), backup dos
#                            traces e, LOGO EM SEGUIDA, "Calcular Baseline" + "Coletar Traces de Baseline".
#                            Tem de ser logo: o Badger apaga traces com mais de 6 h, e o run.sh calculava a
#                            baseline de traces só depois das 14 falhas (~8 h depois da janela).
#   FASE 3  falhas        -- stage3-online/run-stage3-online.sh nas 14 falhas, embaralhadas. Por cenário:
#                            health_gate → warmup medido → referência → implanta a falha →
#                            verificar_falha.py (falha no pod que roda, só ela, estado esperado, webui no
#                            ar) → warmup medido sob a falha → verifica de novo → 3 pacotes + incidente +
#                            Stage 3 + dumps de traces → rollback. Cenário que não passa na verificação não
#                            é coletado (marker FALHA_NAO_VERIFICADA).
#
# Uso:
#   ./coleta-lote-stage3.sh                       # tudo, ~9-11 h
#   ./coleta-lote-stage3.sh --ensaio -f f1-latency   # ensaio com uma falha (~1h30 com baseline)
#   ./coleta-lote-stage3.sh -c <collection_id>    # reusa uma baseline já calculada: pula FASES 1 e 2
#   ./coleta-lote-stage3.sh --so-preflight        # só a FASE 0
#
# Opções:
#   -f, --falhas LISTA     subconjunto (vírgulas, nomes completos: f1-latency,f6-db-connectivity)
#   -c, --colecao ID       reusa a coleção (baseline métricas + traces completa); pula FASES 1 e 2
#   --seed N               semente do embaralhamento (padrão: aleatória, gravada no manifest)
#   --so-preflight         roda só a FASE 0
#   --ensaio               aceita congelamento com propósito PENDENTE; o lote sai marcado ENSAIO
#                          (não vale como teste nem calibração, só valida o protocolo)
#   -h, --help
#
# Congelamento (stage3-online/congelamento.json): o pré-voo exige src/ do HEAD igual ao congelado e sem
# mudanças pendentes, job-runner rodando o digest congelado, stage3_config do sistema igual à congelada e
# o propósito do lote decidido (teste|recalibracao). O registro é copiado para o lote.
#
# Variáveis (padrões = protocolo dos lotes de calibração 20260926T203024Z/20260927T051757Z):
#   WARMUP_INICIAL=600 WARMUP_INICIAL_MAX=1800  aquecimento do cluster (FASE 1)
#   BASELINE_TIME=1500 PACKAGE_WINDOW=3          janela da baseline e dos pacotes
#   WARMUP_FALHA=300 WARMUP_FALHA_MAX=1200       warmup medido pós-implantação (piso/teto)
#   REF_WARMUP=300 REF_WINDOW=300 COLETA=300     warmup pré-referência, referência, coleta do incidente
#   VERIFY_TIMEOUT=300 STAGE3_TIMEOUT=900
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
S3_DIR="$SCRIPT_DIR/stage3-online"

WARMUP_INICIAL="${WARMUP_INICIAL:-600}"
WARMUP_INICIAL_MAX="${WARMUP_INICIAL_MAX:-1800}"
BASELINE_TIME="${BASELINE_TIME:-1500}"
PACKAGE_WINDOW="${PACKAGE_WINDOW:-3}"
WARMUP_FALHA="${WARMUP_FALHA:-300}"
WARMUP_FALHA_MAX="${WARMUP_FALHA_MAX:-1200}"
REF_WARMUP="${REF_WARMUP:-300}"
REF_WINDOW="${REF_WINDOW:-300}"
COLETA="${COLETA:-300}"
VERIFY_TIMEOUT="${VERIFY_TIMEOUT:-300}"
STAGE3_TIMEOUT="${STAGE3_TIMEOUT:-900}"
TODAS="f1-latency,f2-jvm-memory,f3-sql-degradation,f4-invalid-path,f5-jvm-heap,f6-db-connectivity,f7-pool-contention,f8-missing-table,f9-incompat-version,f10-cpu-contention,f11-memory-limit,f12-cpu-throttle,f13-bad-probe,f14-log-bomb"
FALHAS="$TODAS"
COLECAO=""
SEED=""
SO_PREFLIGHT=0
ENSAIO=0

while [ $# -gt 0 ]; do
    case "$1" in
        -f|--falhas) FALHAS="$2"; shift 2 ;;
        -c|--colecao) COLECAO="$2"; shift 2 ;;
        --seed) SEED="$2"; shift 2 ;;
        --so-preflight) SO_PREFLIGHT=1; shift ;;
        --ensaio) ENSAIO=1; shift ;;
        -h|--help) sed -n '2,/^set -euo/p' "$0" | sed '$d'; exit 0 ;;
        *) echo "Opção desconhecida: $1 (use -h)" >&2; exit 1 ;;
    esac
done

# Os helpers de version.json (lib.sh) leem estes dois.
VERSION_DIR="$SCRIPT_DIR/../version/teastore-k8s"
TEASTORE_CONFIG_REPO="${TEASTORE_CONFIG_REPO:-http://localhost:3000/descartesresearch/teastore-config.git}"
source "$SCRIPT_DIR/lib.sh"

TS="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$S3_DIR/resultados/coleta-$TS"
mkdir -p "$OUT"
exec > >(tee -a "$OUT/coleta.log") 2>&1

fase() { echo ""; echo "################ $(date -u +%FT%TZ)  $* ################"; }
abortar() { echo ""; echo "ABORTADO: $*"; echo "$*" > "$OUT/ABORTADO"; exit 1; }

cleanup() {
    local rc=$?
    stresser_off 2>/dev/null || true
    desativar_version_context "$VERITAS_SYSTEM_ID" 2>/dev/null || true
    kill_port_forwards 2>/dev/null || true
    echo ">>> coleta-lote-stage3 terminou (exit=$rc). Log e artefatos: $OUT"
}
trap cleanup EXIT

echo ">>> coleta-lote-stage3 $TS  falhas=$FALHAS  colecao=${COLECAO:-nova}"
echo ">>> código: $(git -C "$REPO_ROOT" rev-parse --short HEAD)$( [ -n "$(git -C "$REPO_ROOT" status --porcelain -- src)" ] && echo ' (src/ com mudanças não commitadas)')"

# ═════════════════════════════ FASE 0: pré-voo ═════════════════════════════
fase "FASE 0: pré-voo"
problemas=()
ok() { echo "    [OK] $*"; }
ruim() { echo "    [FALHOU] $*"; problemas+=("$*"); }
warn() { echo "    [AVISO] $*"; }
# stage3_config como o sistema esta gravado, em JSON cru (sem passar pelo dataclass)
cfg_bruto() {
    curl -s -m 10 -H "X-API-Key: change-me" "http://localhost:8000/systems/$VERITAS_SYSTEM_ID" \
        | python3 -c "import json,sys; d=json.load(sys.stdin); print(json.dumps((d.get('system') or d).get('stage3_config') or {}))" 2>/dev/null
}

nr=$(kubectl get nodes --no-headers 2>/dev/null | awk '$2!="Ready"{print $1"="$2}' | tr '\n' ' ')
nn=$(kubectl get nodes --no-headers 2>/dev/null | wc -l)
[ "$nn" -gt 0 ] && [ -z "$nr" ] && ok "nós: $nn/$nn Ready" || ruim "nós fora de Ready: ${nr:-nenhum nó listado}"

for ns_dep in monitor/web monitor/job-runner monitor/postgres observability/prometheus observability/jaeger \
              observability/loki stress/stresser registry/registry; do
    ns="${ns_dep%/*}"; dep="${ns_dep#*/}"
    pronto=$(kubectl get deploy -n "$ns" "$dep" -o jsonpath='{.status.readyReplicas}/{.spec.replicas}' 2>/dev/null || echo "?/?")
    [ "${pronto%/*}" = "${pronto#*/}" ] && [ "${pronto%/*}" != "" ] && ok "$ns_dep $pronto" || ruim "$ns_dep não está pronto ($pronto)"
done

residuo=$(kubectl get pods -n "$NAMESPACE" --no-headers 2>/dev/null | awk '$3!="Running"{print $1"="$3}' | tr '\n' ' ')
[ -z "$residuo" ] && ok "teastore: nenhum pod fora de Running" || ruim "teastore com pods fora de Running: $residuo"
residuo=$(kubectl get pods -n "$STRESS_NS" --no-headers 2>/dev/null | awk '$3!="Running"{print $1"="$3}' | tr '\n' ' ')
[ -z "$residuo" ] && ok "stress: nenhum pod fora de Running" || ruim "stress com pods fora de Running: $residuo"

alvos=$(timeout 30 kubectl -n "${PROM_NS:-observability}" exec deploy/prometheus -c prometheus -- \
    wget -qO- -T 12 'http://localhost:9090/api/v1/targets?state=active' 2>/dev/null | python3 -c "
import json, sys
t = json.load(sys.stdin)['data']['activeTargets']
for pool in ('kubernetes-cadvisor-sd', 'teastore-jmx-exporter', 'kubernetes-stressers'):
    up = sum(1 for x in t if x['scrapePool'] == pool and x['health'] == 'up')
    tot = sum(1 for x in t if x['scrapePool'] == pool)
    print(f'{pool}={up}/{tot}')
" 2>/dev/null || echo "erro")
for a in $alvos; do
    up="${a#*=}"; up="${up%/*}"
    [ "$a" != "erro" ] && [ "${up:-0}" -gt 0 ] && ok "Prometheus $a" || ruim "Prometheus sem alvo up: $a"
done

pf_svc web 8000 8000 "$MONITOR_NS"; pf_svc gitea 3000 3000 gitea; pf_svc jaeger 16686 16686 observability
sleep 3
curl -sf -m 5 -o /dev/null http://localhost:8000/health && ok "API do MISETE" || ruim "API do MISETE inacessível"
curl -s -m 5 -o /dev/null http://localhost:3000/ && ok "Gitea" || ruim "Gitea inacessível"
svcs=$(curl -sf -m 10 http://localhost:16686/api/services 2>/dev/null | python3 -c "import json,sys; print(' '.join(sorted(json.load(sys.stdin)['data'] or [])))" 2>/dev/null || true)
[[ " $svcs " == *" teastore-webui "* ]] && ok "Jaeger: $svcs" || ruim "Jaeger sem teastore-webui (serviços: ${svcs:-nenhum})"

if [ -z "${TEASTORE_GITEA_TOKEN:-${GITEA_TOKEN:-}}" ] && [ -r "$HOME/.config/misete/gitea-token" ]; then
    export TEASTORE_GITEA_TOKEN="$(cat "$HOME/.config/misete/gitea-token")"
fi
[ -n "${TEASTORE_GITEA_TOKEN:-${GITEA_TOKEN:-}}" ] && ok "token do Gitea" || ruim "token do Gitea ausente (~/.config/misete/gitea-token)"

if _ensure_registry_pf; then
    ok "registry (push) em $REGISTRY_PUSH_HOST"
    for f in $(echo "$FALHAS" | tr ',' ' '); do
        _is_infra_fault "$f" && continue
        svc=$(_falha_to_service "$f"); rel=$(_falha_to_release "$f")
        if [ "$(_registry_has_tag "$svc" "$rel")" = "1" ]; then ok "release $svc:$rel publicada"
        else echo "    [AVISO] release $svc:$rel não publicada -- será construída na hora (mvn + docker)"; fi
    done
    for svc in registry db persistence auth image recommender webui; do
        [ "$(_registry_has_tag "$svc" "$EXP_BASE")" = "1" ] || ruim "imagem base $svc:$EXP_BASE ausente no registry"
    done
else
    ruim "registry inacessível em $REGISTRY_PUSH_HOST"
fi

for f in $(echo "$FALHAS" | tr ',' ' '); do
    [ "$(_falha_to_service "$f")" != "unknown" ] || ruim "falha desconhecida: $f"
done

# Congelamento: o lote só é auditável se o que roda é o que está registrado.
CONG="$S3_DIR/congelamento.json"
if [ ! -r "$CONG" ]; then
    ruim "congelamento ausente ($CONG)"
else
    cong() { python3 -c "import json,sys; d=json.load(open('$CONG')); print(eval(sys.argv[1], {}, {'d': d}))" "$1"; }
    # Congelamento por modo (decisao do usuario 2026-10-02T23:23:03Z, item 3.8). Antes era
    # `HEAD:src` inteiro; agora confere so os arquivos de decisao dos MODOS ESCOLHIDOS, para que
    # D1-D4 possam ser escritas na main sem invalidar a A0. A infraestrutura compartilhada segue
    # coberta por codigo.src_tree e por job_runner.digest, conferidos logo abaixo.
    # `modos.escolhidos` e lido do JSON cru do stage3_config — de proposito, sem passar pelo
    # dataclass Stage3Config, para nao editar config.py (arquivo da A0).
    cfg_modos=$(cfg_bruto | python3 -c "
import json,sys
d=json.load(sys.stdin)
m=(d.get('modos') or {}) if isinstance(d,dict) else {}
esc=m.get('escolhidos') or ['a0']
print(' '.join(esc) if isinstance(esc,list) else ' '.join(esc.split(',')))
" 2>/dev/null)
    [ -n "$cfg_modos" ] || cfg_modos="a0"          # padrao: quem usa o sistema hoje nao muda nada
    ok "modos escolhidos: $cfg_modos"
    # Pelo código de saída do verificador. A versão anterior fazia `sed 's/^/  /' | grep -q '^ruim'`,
    # e a indentação impedia o `^ruim` de casar: o pré-voo aprovava sempre (corrigido em 2026-10-03).
    # shellcheck disable=SC2086
    if verif=$(python3 "$S3_DIR/congelamento_modos.py" --verificar $cfg_modos 2>&1); then
        ok "modo(s) escolhido(s) = congelado(s)"
    else
        ruim "modo(s) escolhido(s) divergem do congelado ou tem mudanca nao commitada"
    fi
    echo "$verif" | sed 's/^/      /'
    # Todo modo escolhido que não seja a a0 roda por jobs próprios (stage3_abordagem) e tem artefato
    # de baseline (prepare_abordagens_baseline): sem os kinds no job-runner, ficariam pendentes para
    # sempre. A a0 sai daqui porque roda pelo job legado `stage3_diagnosis`.
    outros_modos=$(echo "$cfg_modos" | tr ' ' '\n' | grep -vxE 'a0' | tr '\n' ' ')
    if [ -n "$outros_modos" ]; then
        kinds=$(kubectl -n "$MONITOR_NS" get deploy job-runner -o jsonpath='{.spec.template.spec.containers[0].command}{.spec.template.spec.containers[0].args}' 2>/dev/null)
        for k in stage3_abordagem prepare_abordagens_baseline; do
            [[ "$kinds" == *"$k"* ]] && ok "job-runner aceita $k" || ruim "job-runner sem $k em --allowed-kinds"
        done
    fi
    tree_ok=$(cong "d['codigo']['src_tree']"); tree_now=$(git -C "$REPO_ROOT" rev-parse HEAD:src)
    [ "$tree_now" = "$tree_ok" ] && ok "arvore src/ do HEAD = congelada (${tree_ok:0:12})" \
        || warn "arvore src/ do HEAD ($tree_now) != congelada ($tree_ok) -- ok se so D1-D4 ou specs mudaram"
    dig_ok=$(cong "d['job_runner']['digest']")
    dig_now=$(kubectl -n "$MONITOR_NS" get pods -l app=job-runner -o jsonpath='{range .items[*]}{.status.containerStatuses[0].imageID}{"\n"}{end}' 2>/dev/null | sed 's/.*@//' | sort -u | tr '\n' ' ')
    [ "$dig_now" = "$dig_ok " ] && ok "job-runner no digest congelado (${dig_ok:7:12})" \
        || ruim "job-runner roda '${dig_now}', congelado '$dig_ok'"
    cfg_now=$(curl -s -m 10 -H "X-API-Key: change-me" "http://localhost:8000/systems/$VERITAS_SYSTEM_ID" \
        | python3 -c "import json,sys; d=json.load(sys.stdin); print(json.dumps((d.get('system') or d).get('stage3_config'), sort_keys=True))" 2>/dev/null || echo "?")
    cfg_ok=$(python3 -c "import json; print(json.dumps(json.load(open('$CONG'))['stage3_config']['gravada_no_banco'], sort_keys=True))")
    [ "$cfg_now" = "$cfg_ok" ] && ok "stage3_config do sistema = congelada" \
        || ruim "stage3_config do sistema difere da congelada: $cfg_now"
    proposito=$(cong "d['proposito']")
    case "$proposito" in
        teste|recalibracao) ok "propósito do lote: $proposito" ;;
        *) if [ "$ENSAIO" = "1" ]; then echo "    [AVISO] propósito '$proposito' -- seguindo como ENSAIO"
           else ruim "propósito do lote '$proposito' (decida teste|recalibracao em congelamento.json, ou use --ensaio)"; fi ;;
    esac
    if [ -z "$COLECAO" ]; then
        bs_ok=$(cong "d['protocolo']['baseline_s']"); pk_ok=$(cong "d['protocolo']['pacote_s']")
        [ "$BASELINE_TIME" = "$bs_ok" ] && [ "$PACKAGE_WINDOW" = "$pk_ok" ] \
            && ok "baseline ${BASELINE_TIME}s / pacotes ${PACKAGE_WINDOW}s = congelados" \
            || ruim "baseline ${BASELINE_TIME}s / pacotes ${PACKAGE_WINDOW}s != congelados (${bs_ok}s / ${pk_ok}s)"
    fi
    cp "$CONG" "$OUT/congelamento.json"
    [ "$ENSAIO" = "1" ] && echo "ensaio: valida o protocolo, não vale como teste nem calibração" > "$OUT/ENSAIO"
fi

if [ "${#problemas[@]}" -gt 0 ]; then
    printf '%s\n' "${problemas[@]}" > "$OUT/preflight_reprovado.txt"
    abortar "pré-voo reprovado (${#problemas[@]} problema(s)) -- nada foi alterado no cluster"
fi
echo "    Pré-voo aprovado."
[ "$SO_PREFLIGHT" = "1" ] && exit 0

# Artefato de baseline de CADA modo escolhido que tenha um, a partir dos traces normais da coleção,
# LOGO depois dos traces da baseline (expiram do Jaeger em 6 h). Inclui a calibração normal × normal.
# Idempotente: com -c, só prepara o que ainda não está "pronto".
# `a0` fica de fora: ela roda pelo job legado (`stage3_diagnosis`) e NÃO tem artefato de baseline —
# exigi-la aqui travaria o poll para sempre. Todo o resto dos escolhidos (d1-d4c, d5-d9, d9-k, v-cons-b)
# tem `preparar_baseline` e vira artefato (é o mesmo conjunto que `execute_prepare_abordagens_baseline`
# prepara: `implementados = [m for m in modos if m in registro.MODOS]`).
preparar_modos() {
    local S3_URL="/systems/$VERITAS_SYSTEM_ID/collections/$COLECAO" modos_d prontos=""
    modos_d=$(echo "$cfg_modos" | tr ' ' '\n' | grep -vxE 'a0' | tr '\n' ' ')
    [ -n "$modos_d" ] || return 0
    _falta() {
        _veritas_api GET "$S3_URL/abordagens_baseline/status" "" > "$OUT/abordagens_baseline_status.json" 2>/dev/null
        python3 -c "
import json
v=json.load(open('$OUT/abordagens_baseline_status.json'))
st={m['modo']: m['status'] for m in v.get('modos', [])}
falta=[m for m in '$modos_d'.split() if st.get(m) != 'pronto']
print('ok' if not falta else ' '.join(falta))" 2>/dev/null
    }
    prontos=$(_falta)
    if [ "$prontos" = "ok" ]; then echo "    baseline dos modos já pronta ($modos_d)"; return 0; fi
    echo "    Preparar baseline dos modos ($modos_d)..."
    _veritas_api POST "$S3_URL/abordagens_baseline" "" >/dev/null
    for _ in $(seq 1 "${ABORDAGENS_TIMEOUT_POLLS:-1440}"); do   # 1440 × 10 s = 4 h
        prontos=$(_falta)
        [ "$prontos" = "ok" ] && break
        sleep 10
    done
    [ "$prontos" = "ok" ] || abortar "baseline dos modos não ficou pronta (faltando: $prontos; ver abordagens_baseline_status.json)"
    echo "    baseline dos modos: pronta ($modos_d)"
}

if [ -z "$COLECAO" ]; then
    # ═════════════════════════ FASE 1: aquecimento do cluster ═════════════════════════
    fase "FASE 1: restaurar TeaStore (${EXP_BASE}) e aquecer o cluster"
    restaurar_teastore
    stresser_on
    aguardar_regime_webui "$WARMUP_INICIAL" "$WARMUP_INICIAL_MAX" "${WARMUP_TOL:-5}" "$OUT/warmup_inicial.json"
    [ "$REGIME_STATUS" = "estavel" ] || abortar "aquecimento inicial terminou como '$REGIME_STATUS' -- baseline em cima de rampa não serve"

    # ═════════════════════════ FASE 2: baseline ═════════════════════════
    fase "FASE 2: baseline (${BASELINE_TIME}s, pacotes de ${PACKAGE_WINDOW}s)"
    echo "    health_gate com carga (bloqueante na baseline)..."
    python3 "$S3_DIR/health_gate.py" --out "$OUT/health_pre_baseline.json" --timeout 300 --jaeger http://localhost:16686 \
        || abortar "TeaStore não está saudável antes da baseline (ver health_pre_baseline.json)"

    criar_colecao "$VERITAS_SYSTEM_ID" "coleta-$TS-baseline-${BASELINE_TIME}s-${PACKAGE_WINDOW}s" "$PACKAGE_WINDOW" \
        || abortar "coleção não foi criada"
    COLECAO="$ACTIVE_COLLECTION_ID"
    echo "$COLECAO" > "$OUT/collection.id"
    # `resultados/baseline-collection.id` só é gravado no FIM da FASE 2 (depois de preparar_modos): um
    # driver que reusa esse id com `-c` não pode herdar uma coleção cuja baseline abortou pela metade.
    gerar_version_json "baseline" "$OUT/baseline-version.json"
    ativar_version_context "$VERITAS_SYSTEM_ID" "baseline" "$OUT/baseline-version.json"

    WS_EPOCH=$(date -u +%s)
    echo "    $(date -u +%FT%TZ) janela da baseline começa"
    aguardar "$BASELINE_TIME"
    WS="$(date -u -d "@$WS_EPOCH" +%Y-%m-%dT%H:%M:%S)+00:00"
    WE="$(date -u -d "@$((WS_EPOCH + BASELINE_TIME))" +%Y-%m-%dT%H:%M:%S)+00:00"
    body="{\"name\": \"baseline\", \"description\": \"coleta-lote-stage3 $TS: baseline ${BASELINE_TIME} s, stresser ${STRESSER_MIN_USERS}-${STRESSER_PEAK_USERS} onda ${STRESSER_WAVE_PERIOD} s, aquecimento medido ${REGIME_SEG} s\", \"window_start\": \"$WS\", \"window_end\": \"$WE\", \"is_baseline\": true, \"package_window_seconds\": $PACKAGE_WINDOW, \"collection_id\": \"$COLECAO\"}"
    resp=$(_veritas_api POST "/systems/$VERITAS_SYSTEM_ID/failures" "$body")
    FID=$(echo "$resp" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('failure_id') or d.get('failure',{}).get('failure_id',''))" 2>/dev/null || true)
    [ -n "$FID" ] || abortar "baseline não registrada: $resp"
    echo "$FID" > "$OUT/baseline-failure.id"
    echo "    baseline registrada: failure $FID ($WS -> $WE)"
    stresser_off
    desativar_version_context "$VERITAS_SYSTEM_ID"

    echo "    Backup dos traces da janela (TTL de 6 h no Jaeger)..."
    PYTHONPATH="$REPO_ROOT" python3 "$S3_DIR/dump_traces.py" http://localhost:16686 "$WS" "$WE" "$OUT/traces_baseline.json" 2000 \
        && gzip -f "$OUT/traces_baseline.json" \
        || abortar "backup dos traces da baseline falhou -- sem ele a avaliação offline (artefatos a0-b/d6) não roda"

    echo "    Esperando os pacotes da baseline (pending_drain)..."
    st=""
    for _ in $(seq 1 180); do
        st=$(_veritas_api GET "/systems/$VERITAS_SYSTEM_ID/failures/$FID" "" \
            | python3 -c "import json,sys; d=json.load(sys.stdin); f=d.get('failure',d); print(f.get('status'))" 2>/dev/null || true)
        case "$st" in pending_drain|completed|failed|error) break ;; esac
        sleep 10
    done
    case "$st" in pending_drain|completed) echo "    baseline: $st" ;; *) abortar "pacotes da baseline não ficaram prontos (status=$st)" ;; esac

    S3_URL="/systems/$VERITAS_SYSTEM_ID/collections/$COLECAO"
    _s3_wait() {
        local s=""
        for _ in $(seq 1 "${S3_WAIT_POLLS:-$(( 180 * (BASELINE_TIME + 1499) / 1500 ))}"); do
            s=$(_veritas_api GET "$S3_URL/baseline/status" "" | python3 -c "import json,sys; print(json.load(sys.stdin).get('$1'))" 2>/dev/null)
            case "$s" in completed|failed|error) break ;; esac
            sleep 10
        done
        echo "$s"
    }
    echo "    Calcular Baseline (métricas)..."
    _veritas_api POST "$S3_URL/baseline" "" >/dev/null
    s=$(_s3_wait status); echo "    status=$s"
    [ "$s" = "completed" ] || abortar "Calcular Baseline terminou como '$s'"
    echo "    Coletar Traces de Baseline (modelos de processo)..."
    _veritas_api POST "$S3_URL/trace_baseline" "" >/dev/null
    s=$(_s3_wait trace_status); echo "    trace_status=$s"
    _veritas_api GET "$S3_URL/baseline/status" "" > "$OUT/baseline_status.json" || true
    [ "$s" = "completed" ] || abortar "Coletar Traces de Baseline terminou como '$s' (ver baseline_status.json)"

    preparar_modos
    echo "$COLECAO" > "$SCRIPT_DIR/resultados/baseline-collection.id"
    echo "    baseline completa: $COLECAO"
else
    fase "FASES 1 e 2 puladas: reusando a coleção $COLECAO"
    echo "$COLECAO" > "$OUT/collection.id"
    preparar_modos
fi

# ═════════════════════════ FASE 3: falhas ═════════════════════════
fase "FASE 3: falhas ($FALHAS)"
kill_port_forwards 2>/dev/null || true   # o run-stage3-online.sh abre os dele
antes=$(ls -1 "$S3_DIR/resultados" | sort)
s3_args=(-c "$COLECAO" -f "$FALHAS" --coleta "$COLETA" --ref-window "$REF_WINDOW"
         --warmup "$WARMUP_FALHA" --warmup-max "$WARMUP_FALHA_MAX" --ref-warmup "$REF_WARMUP"
         --verify-timeout "$VERIFY_TIMEOUT" --stage3-timeout "$STAGE3_TIMEOUT")
if [ -n "$SEED" ]; then s3_args+=(--shuffle "$SEED"); else s3_args+=(--shuffle); fi
echo "    run-stage3-online.sh ${s3_args[*]}"
rc=0
bash "$S3_DIR/run-stage3-online.sh" "${s3_args[@]}" || rc=$?
lote=$(comm -13 <(echo "$antes") <(ls -1 "$S3_DIR/resultados" | sort) | grep -E '^[0-9]{8}T[0-9]{6}Z$' | tail -1 || true)
if [ -n "$lote" ]; then
    ln -sfn "../$lote" "$OUT/lote" && echo "$lote" > "$OUT/lote.id"
    cp "$OUT/congelamento.json" "$S3_DIR/resultados/$lote/congelamento.json"
    [ -f "$OUT/ENSAIO" ] && cp "$OUT/ENSAIO" "$S3_DIR/resultados/$lote/ENSAIO"
fi

fase "FIM"
echo "    coleção (baseline): $COLECAO"
echo "    lote do Stage 3:    ${lote:-não identificado} (exit=$rc)"
[ -n "$lote" ] && [ -f "$S3_DIR/resultados/$lote/resumo_verificacao.txt" ] && cat "$S3_DIR/resultados/$lote/resumo_verificacao.txt"
echo "    Para refazer falhas com esta mesma baseline (já calculada e gravada no banco):"
echo "      ./coleta-lote-stage3.sh -c $COLECAO -f <lista>"
exit "$rc"
