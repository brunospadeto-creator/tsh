#!/usr/bin/env bash
set -euo pipefail
echo "F1-LATENCY: Iniciando stress --cpu 1 para simular latencia alta..."
stress --cpu 1