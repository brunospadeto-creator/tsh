#!/usr/bin/env bash
set -euo pipefail
echo "F2-MEMORY: Iniciando stress --vm 2 --vm-bytes 256M para pressao no heap JVM..."
stress --vm 2 --vm-bytes 256M