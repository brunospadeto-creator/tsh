#!/usr/bin/env bash
set -euo pipefail
echo "F10-CPU: Iniciando stress --cpu 2 para contencao de CPU..."
stress --cpu 2