# Protocolo da coleta definitiva — d9-k e v-cons-b em h × 2 + g × 2, sobre baseline nova

Registrado em 2026-10-15 (ARQ), **antes** de coletar; completado no mesmo dia, ainda sem nenhum dado coletado
(`resultados/definitiva/` não existia). Substitui o `PROTOCOLO-COLETA-INEDITA.md`: o cluster foi reconstruído do
zero e a imagem e o `stage3_config` mudaram no mesmo dia, então a baseline `547ba505` da coleta inédita deixou de
ser utilizável com `-c` e uma **baseline nova** é coletada aqui (registro em `session.md` §42.76). Este é o número
de teste das soluções definitivas (§42.72) em cenários que **ninguém leu**.

## 0. Congelamento desta coleta

- **código** `b186704a`, **src_tree** `3b8fa5b27b27…` (o mesmo `src/` dos commits seguintes, que só mexem no
  harness e neste protocolo), **job-runner** `sha256:470f86dd…` (imagens rebuildadas e publicadas hoje; md5 dos
  arquivos de decisão no pod = repo).
- **harness**: `coleta-lote-stage3.sh` e `run-definitiva-lotes.sh` no commit que registra esta versão do
  protocolo; análise `replay/definitiva.py` escrita no mesmo commit, antes de qualquer dado.
- **`stage3_config`** do sistema: `modos.escolhidos = [a0, d9-k, v-cons-b]`, `principal = a0` (o pré-voo
  exige que o banco seja **igual** ao `gravada_no_banco` do congelamento).
- **baseline de 90 min** (`protocolo.baseline_s = 5400`, pacotes de 3 s): a mesma duração da `547ba505`, a baseline dos
  B1–B3 e do lote 3 (desenvolvimento), do hold-out e da paridade produto × avaliação (§42.74). Assim o insumo dos
  artefatos (d6, a0-b, calibração normal × normal) tem o tamanho daquele em que os métodos foram escolhidos, e a
  única variável nova é a sessão de baseline. (O confirmatório, §42.73, misturou `2032361d` e `d7cd3536`, de
  25 min, com a `547ba505`.) O driver lê a duração do congelamento e o pré-voo reprova se
  `BASELINE_TIME`/`PACKAGE_WINDOW` divergirem.
- **propósito** `teste`: nada no método muda depois de ver o resultado.
- **diferenças de harness em relação à coleta inédita**:
  1. `preparar_modos()` prepara **todo escolhido que não seja a a0** (antes só `d[1-4]c?`; com
     `[a0,d9-k,v-cons-b]` retornava cedo e a baseline sairia sem os artefatos da a0-b e da d6).
  2. O pré-voo confere `stage3_abordagem`/`prepare_abordagens_baseline` no job-runner para qualquer escolhido
     além da a0.
  3. `resultados/baseline-collection.id` só é gravado **no fim** da FASE 2 (baseline, traces e artefatos
     prontos). Antes era gravado ao criar a coleção, e um C1 abortado no meio da FASE 2 seria retomado com `-c`
     em cima de uma baseline incompleta.
  4. O backup dos traces da baseline (`traces_baseline.json.gz`) é **obrigatório**: se falhar, a FASE 2 aborta
     (antes era só um aviso, e é ele o insumo da avaliação offline, §4).
  5. Driver novo `run-definitiva-lotes.sh`: o primeiro lote roda **sem `-c`** (FASE 1 + FASE 2); os demais
     reusam a baseline que ele criou. O id "anterior" é fixado em `definitiva/baseline_anterior.id` na primeira
     execução, então o driver pode ser reiniciado sem criar uma segunda baseline.

## 1. Métodos avaliados (nada muda depois de ver o resultado)

- **d9-k** (`d9k_portao_grafo_k8s.py`, d9-k-v1, hash `dbe86983757e`): solução primária — é o número do artigo.
- **v-cons-b** (`vconsb_consenso.py`, v-cons-b-v1, `a51c15168f22`): lista de investigação (top-3). Leitura
  principal na variante n = 5 avaliada (`v-cons-b-prod`); o disparo único do produto (`v-cons-b-1`) é reportado
  ao lado.
- **Referência**: d9 (só offline; não está em `escolhidos`).
- Avaliação **offline por instante** (como §42.66–§42.74). a0, d9-k e v-cons-b também rodam online
  (`escolhidos`), então o pacote de auditoria de cada incidente registra a decisão de produção; o número do
  artigo é o offline.

## 2. Coleta

- **FASE 1** aquecimento medido do webui (`aguardar_regime_webui` 600–1800 s, ~19 min) — o boot da JVM
  contamina a janela se a baseline começar na rampa.
- **FASE 2** baseline de **5400 s** com pacotes de **3 s** + backup dos traces + "Calcular Baseline" + "Coletar
  Traces de Baseline" **logo em seguida** (o Badger apaga traces em 6 h) + artefatos dos modos escolhidos
  (~2 h 10 no total).
- **FASE 3** cenários, sementes nunca usadas:

| lote | falhas | semente | baseline |
|---|---|---|---|
| C1 | h1–h6 | 20261031 | a que C1 cria (roda sem `-c`) |
| C2 | h1–h6 | 20261032 | reusa (`-c`) |
| C3 | g1–g6 | 20261033 | reusa (`-c`) |
| C4 | g1–g6 | 20261034 | reusa (`-c`) |

(h: 20261011/12; g: 20261021–23 já usadas — ver `PROTOCOLO-COLETA-INEDITA.md`.) Cada lote ≈ 7 h 30–8 h 30
(`holdout2/driver.log`); o conjunto ≈ **34–36 h** de cluster. Disparo:
`setsid nohup ./run-definitiva-lotes.sh > /dev/null 2>&1 &`; acompanhamento a cada 30 min com uma linha (lote,
cenário, minutos restantes).

### 2.1 Desvios de execução (registrados durante a coleta, antes de qualquer cenário)

- **15/10 18:23** — o driver foi parado (decisão do usuário) com o C1 ainda na FASE 2, no preparo dos artefatos,
  antes de qualquer cenário. Motivo: o Jaeger (1 CPU, ~10 h sob carga) lia ~13 min por minuto de janela.
- **15/10 18:57** — o job `prepare_abordagens_baseline` da coleção `32c273a6` morreu em 4 timeouts do Jaeger.
  Como os traces da baseline expiram do Jaeger a partir das 19:26, os artefatos da d9-k e da v-cons-b foram
  instalados pelo **backup** (`instalar_artefatos_backup.py`): a mesma função do job
  (`execute_prepare_abordagens_baseline`) com `traces_baseline.json.gz` como provedor de traces normais — o
  caminho usado na `547ba505` em 12/10. A paridade com o artefato offline do §4 continua obrigatória.
- **15/10 ~20:05** — Jaeger com 4 CPU, 12 Gi e `GOMEMLIMIT` 10 GiB (`k8s/jaeger.yaml`), reiniciado. Só
  infraestrutura de consulta: o conteúdo dos traces não muda; método, medida e leitura também não.
- O C1 recomeça com `-c 32c273a6` (driver religado, `definitiva/baseline.id` gravado à mão porque o harness
  só o grava ao fim da FASE 2): FASE 1 e FASE 2 não se repetem; cada cenário tem o aquecimento próprio.
- **16/10 ~12:57Z** — a máquina foi desligada no meio do C2 (tentativa 1; h5, h3, h4, h1 completos, h2 cortado
  no aquecimento antes da injeção, h6 não iniciado). Run parcial `20261016T075241Z` fora da análise, não apagado.
  O cluster foi religado com `minikube start` (não reconstruído: mesmos nós, imagens, digest `470f86dd`,
  coleção `32c273a6` no banco, TeaStore na configuração base); a baseline continua válida (§3). Pré-voo de
  15:16Z aprovado sem `ruim`. O C2 recomeça inteiro com a semente 20261032 como **tentativa 2** pelo §3 (o
  driver relançado conta de 1 de novo; o limite de 3 vale somando as tentativas registradas aqui). O Jaeger
  segue como no C1 (4 CPU/12 Gi, fixado em `m02`, sem nó exclusivo), para C2–C4 iguais ao C1.

## 3. Regras de parada e exclusão (fixadas antes)

- **Coleta completa** (decisão do usuário, §42.75): os 4 lotes; não há corte para só C1.
- O lote é a unidade: abortou, recomeça inteiro com a mesma semente, até 3 tentativas. Lote que não fechar em 3
  tentativas fica **ausente**, declarado; o resultado com lote ausente é **parcial** e não vale como confirmação
  (o `definitiva.py` imprime isso).
- C1 abortado antes do fim da FASE 2 recomeça **sem `-c`** (baseline nova do zero). C1 abortado na FASE 3
  recomeça com `-c` na baseline que ele criou.
- Cenário que não passa no verificador da falha não é coletado (fica em `FALHA_NAO_VERIFICADA`, reportado à
  parte). Cenário sem referência, pacotes ou `traces_full_scenario.json` sai da análise e é listado no inventário.
- Se o cluster cair no meio de C2–C4 de modo que a baseline nova deixe de valer (cluster reconstruído, imagem
  trocada), a coleta **para**: os lotes concluídos são o resultado parcial; nada é misturado com outra baseline.

## 4. Preparo offline (depois da FASE 2; não depende dos resultados)

1. `traces_baseline.json.gz` da coleta do C1 (`resultados/coleta-<ts>/`) é copiado para
   `/mnt/gpu-disk/backups-misete/baseline-90m-<ts>/` e a coleção entra em `BACKUPS`
   (`replay/preparar_baseline_abordagens.py`; até lá `backup_de()` acha o arquivo pela `collection.id`).
2. Artefatos offline da coleção nova, com o mesmo comando usado na `547ba505`:
   - a0-b: `replay/a0b_insumos.py <coleção8>`;
   - d6 (= d2c, janela 120 s): `replay/preparar_baseline_abordagens.py --colecoes <coleção8> --modos d2c
     --janela-seg 120 --sufixo -w120`;
   - para a tabela única do §7: os mesmos para d1, d1c, d2, d4, d4c (`-w120`) e d3 por `fp_alvo` (grade
     0,025/0,05/0,10/0,20).
   - d9 e d9-k não têm artefato de coleção (referência pré-falha do próprio cenário).
3. **Paridade** produto × offline, como na §42.74: `q` da d6 e nº de janelas da a0-b do artefato do produto
   (`abordagens_baseline`) = do artefato offline. Divergência → registrar e usar o offline (o avaliado), sem
   olhar resultado de cenário.

## 5. Medida

`replay/definitiva.py` (runs lidos de `resultados/definitiva/C*.run`), saída em
`resultados/protocolo-coleta-definitiva/`. Mesma medida do confirmatório (`paridade_solucoes.rodar_caso`):

- instantes a cada 60 s nos períodos **normal** e **estável** (pacotes contínuos do harness), janela de 120 s,
  referência pré-falha deslocada nos instantes do estável;
- K8s só de sintoma (Fase 0); instantes com ≥ 30 traces fora da janela descartados (D0.4);
- modos: `d9-k-prod`, `v-cons-b-prod` (n = 5 avaliado), `v-cons-b-1` (disparo único) e `d9`;
- métricas por modo: **F1@1/2/3 com portão** (contagens somadas sobre os instantes; o normal entra como alarme),
  **alarme** = decisões em instantes normais / instantes normais, **abstenção** = 1 − decisões / instantes do
  estável, **top-1/2/3 sabendo que é falha** (média por cenário);
- IC 95% por bootstrap de cenário (2000 reamostragens, semente fixa) para F1@1, top-1 e top-3;
- separado em **todos**, **h** e **g**;
- McNemar exato bilateral sobre acerto majoritário por cenário (> 50% dos instantes do estável): d9-k × d9 em
  top-1 com portão; v-cons-b × d9-k em top-3 sabendo.

## 6. Leitura fixada antes

- **d9-k confirma** se F1@1 (todos, 24 cenários) ≥ F1@1 da d9 **e** alarme ≤ 2%.
- **v-cons-b confirma** como lista de investigação se top-3 sabendo que é falha ≥ 80% **e** top-1 sabendo ≥ d9 —
  o mesmo critério do `PROTOCOLO-CONFIRMATORIO.md` §3 (o "≥ top-3 da d9-k" da versão anterior deste protocolo
  vira métrica secundária, reportada ao lado).
- **Relação com o confirmatório**: o v-cons-b **não** confirmou lá (top-3 74%); a d9-k confirmou. Os dois testes
  são reportados lado a lado, cada um com sua leitura; **não** se somam amostras nem se escolhe o melhor dos dois.
  Um terceiro teste do v-cons-b não está previsto.
- Qualquer resultado é reportado como está; **nada é recalibrado** com estes cenários.

## 7. Relação com o que já existe (contraste argumental do artigo)

- desenvolvimento: 54 cenários (F1–F14 × 2, h do lote 3, ensaio h1 e **g1–g6 × 3 dos lotes B1–B3**) — d9-k e
  v-cons-b foram escolhidos olhando estes; o número deles aqui é otimista e não serve de teste.
- confirmatório: 18 cenários com dado (15 f, 3 h; sobras de coletas antigas sobre `2032361d`, `d7cd3536` e
  `547ba505`) — §42.73, `PROTOCOLO-CONFIRMATORIO.md`. Nenhum g.
- **definitivo: 24 cenários (h × 2 + g × 2) sobre baseline nova** — este protocolo. Primeiro teste com dado
  coletado **depois** do congelamento dos métodos, balanceado em h e g. As famílias h e g já apareceram no
  desenvolvimento (g nos B1–B3, h no lote 3): é uma **replicação com instâncias novas** (sementes, sessão de
  baseline e cluster novos), não um teste em tipos de falha inéditos.

*Correção de procedência (2026-10-15, depois do disparo às 16:53Z, antes de qualquer resultado):* este §7 e a
justificativa da baseline no §0 diziam que o confirmatório tinha 18 cenários h e g sobre a `547ba505`; os g dos
B1–B3 são de desenvolvimento e o confirmatório usou três baselines. Não altera método, medida nem leitura.

A baseline nova também dá uma **linha de base reproduzível**: com os artefatos recalculados nela (§4), todos os
modos (a0, d1–d9, d9-k, v-cons-b) são reavaliados offline sobre a mesma base, para a tabela única ordenada por
F1@1 (§42.67) sobre dado de teste — secundária, fora da leitura do §6.
