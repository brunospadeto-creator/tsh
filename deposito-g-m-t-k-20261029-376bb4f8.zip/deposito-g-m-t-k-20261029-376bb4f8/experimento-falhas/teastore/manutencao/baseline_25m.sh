#!/usr/bin/env bash
# Baseline de 25 min numa coleção nova: stresser 10-20 usuários, onda de 60 s (o mesmo
# das F1-F14 da coleção 0300e685), aquecimento de 10 min fora da janela, janela de 25 min, pacotes de 3 s.
# Logo depois da janela: backup dos traces do Jaeger (TTL de 6 h), "Calcular Baseline" e "Coletar Traces
# de Baseline" (modelos de processo). O drain não é pedido (o cálculo usa os pacotes parciais).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
WARMUP_TIME="${WARMUP_TIME:-600}"
BASELINE_TIME="${BASELINE_TIME:-1500}"
PACKAGE_WINDOW="${PACKAGE_WINDOW:-3}"
COLLECTION_NAME="${COLLECTION_NAME:-teastore-baseline-25m-onda60-3s}"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="${OUT:-/mnt/gpu-disk/backups-misete/baseline-25m-$TS}"
PY="${PY:-$HOME/.venvs/monitor-replay/bin/python}"
RESULTADOS="$SCRIPT_DIR/resultados"
VERSION_DIR="$SCRIPT_DIR/../version/teastore-k8s"
TEASTORE_CONFIG_REPO="${TEASTORE_CONFIG_REPO:-http://localhost:3000/descartesresearch/teastore-config.git}"
source "$SCRIPT_DIR/lib.sh"
mkdir -p "$OUT" "$RESULTADOS"

_pf_ensure() {  # nome svc porta ns url
    curl -s -m 3 -o /dev/null "$5" && return 0
    pf_svc "$2" "$3" "$3" "$4"
    for _ in $(seq 1 20); do curl -s -m 2 -o /dev/null "$5" && return 0; sleep 1; done
    echo "ERRO: $1 inacessível em $5"; exit 1
}
_pf_ensure "API do MISETE" web 8000 "$MONITOR_NS" http://localhost:8000/health
_pf_ensure "Gitea" gitea 3000 gitea http://localhost:3000/
_pf_ensure "Jaeger" jaeger 16686 observability http://localhost:16686/api/services
if [ -z "${TEASTORE_GITEA_TOKEN:-${GITEA_TOKEN:-}}" ] && [ -r "$HOME/.config/misete/gitea-token" ]; then
    export TEASTORE_GITEA_TOKEN="$(cat "$HOME/.config/misete/gitea-token")"
fi

cleanup() {
    stresser_off 2>/dev/null || true
    desativar_version_context "$VERITAS_SYSTEM_ID" 2>/dev/null || true
}
trap cleanup EXIT

echo "=== $(date -u +%FT%TZ) baseline 25 min: coleção nova '$COLLECTION_NAME' ==="
wait_for_teastore_webui 300
criar_colecao "$VERITAS_SYSTEM_ID" "$COLLECTION_NAME" "$PACKAGE_WINDOW"
COL="$ACTIVE_COLLECTION_ID"
echo "$COL" > "$OUT/collection.id"

vfile="$OUT/baseline-version.json"
gerar_version_json "baseline" "$vfile"
ativar_version_context "$VERITAS_SYSTEM_ID" "baseline" "$vfile"

kubectl exec -n "$STRESS_NS" deploy/stresser -- python3 -c "
import json, urllib.request
req = urllib.request.Request('http://localhost:8000/config', method='POST', headers={'Content-Type': 'application/json'},
    data=json.dumps({'min_users': 10, 'peak_users': 20, 'wave_period': 60}).encode())
print('    stresser /config:', urllib.request.urlopen(req).read().decode())"
stresser_on

echo "    $(date -u +%FT%TZ) aquecimento de ${WARMUP_TIME}s (fora da janela)"
sleep "$WARMUP_TIME"
WS_EPOCH=$(date -u +%s)
echo "    $(date -u +%FT%TZ) janela da baseline começa"
aguardar "$BASELINE_TIME"
WE_EPOCH=$((WS_EPOCH + BASELINE_TIME))
WS="$(date -u -d "@$WS_EPOCH" +%Y-%m-%dT%H:%M:%S)+00:00"
WE="$(date -u -d "@$WE_EPOCH" +%Y-%m-%dT%H:%M:%S)+00:00"

body="{\"name\": \"baseline\", \"description\": \"Baseline 25 min, stresser 10-20 onda 60 s, aquecimento ${WARMUP_TIME} s\", \"window_start\": \"$WS\", \"window_end\": \"$WE\", \"is_baseline\": true, \"package_window_seconds\": $PACKAGE_WINDOW, \"collection_id\": \"$COL\"}"
echo "    Registrando baseline ($WS -> $WE) na coleção $COL"
resp=$(_veritas_api POST "/systems/$VERITAS_SYSTEM_ID/failures" "$body")
echo "    $resp"
FID=$(echo "$resp" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('failure_id') or d.get('failure',{}).get('failure_id',''))")
echo "$FID" > "$OUT/failure.id"
stresser_off
desativar_version_context "$VERITAS_SYSTEM_ID"

echo "    $(date -u +%FT%TZ) backup dos traces da janela"
PYTHONPATH="$REPO_ROOT" "$PY" "$SCRIPT_DIR/stage3-online/dump_traces.py" \
    http://localhost:16686 "$WS" "$WE" "$OUT/traces_baseline.json" 2000
gzip -f "$OUT/traces_baseline.json"
ls -la "$OUT"

echo "    $(date -u +%FT%TZ) esperando os pacotes parciais (status pending_drain)"
st=""
for _ in $(seq 1 180); do
    st=$(_veritas_api GET "/systems/$VERITAS_SYSTEM_ID/failures/$FID" "" \
        | python3 -c "import json,sys; d=json.load(sys.stdin); f=d.get('failure',d); print(f.get('status'), f.get('validation_status'))" 2>/dev/null || true)
    case "$st" in pending_drain*|completed*|failed*|error*) break ;; esac
    sleep 10
done
echo "    failure $FID: $st"

S3_URL="/systems/$VERITAS_SYSTEM_ID/collections/$COL"
_s3_wait() {
    local s=""
    for _ in $(seq 1 180); do
        s=$(_veritas_api GET "$S3_URL/baseline/status" "" | python3 -c "import json,sys; print(json.load(sys.stdin).get('$1'))" 2>/dev/null)
        case "$s" in completed|failed|error) break ;; esac
        sleep 10
    done
    echo "    $1=$s"
}
echo "    $(date -u +%FT%TZ) Calcular Baseline"
_veritas_api POST "$S3_URL/baseline" "" >/dev/null && _s3_wait status
echo "    $(date -u +%FT%TZ) Coletar Traces de Baseline (modelos de processo)"
_veritas_api POST "$S3_URL/trace_baseline" "" >/dev/null && _s3_wait trace_status
_veritas_api GET "$S3_URL/baseline/status" "" | tee "$OUT/baseline_status.json"; echo
echo "=== $(date -u +%FT%TZ) FIM ==="
