#!/bin/bash
# generate_version_json.sh — Generate version.json for TeaStore k8s experiments
#
# Usage:
#   ./generate_version_json.sh [--falha F1|F2|...|baseline] [--gitea-url http://...] [--output-dir ...]
#
# Reads:
#   - TEASTORE_COMMIT (file in same directory)
#   - Gitea API for commit metadata
#   - kubectl for image digests
#   - teastore-config repo for config commit
#
# Outputs:
#   - version.json to stdout or --output-dir

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FALHA="${FALHA:-baseline}"
GITEA_URL="${GITEA_URL:-http://localhost:3000}"
GITEA_ORG="${GITEA_ORG:-descartesresearch}"
GITEA_REPO="${GITEA_REPO:-TeaStore}"
CONFIG_REPO="${CONFIG_REPO:-teastore-config}"
GITEA_TOKEN="${GITEA_TOKEN:-${TEASTORE_GITEA_TOKEN:-}}"
: "${GITEA_TOKEN:?defina GITEA_TOKEN ou TEASTORE_GITEA_TOKEN (token do Gitea; nao versionar)}"
OUTPUT_DIR="${OUTPUT_DIR:-$SCRIPT_DIR/../../version/teastore-k8s}"
TEASTORE_NAMESPACE="${TEASTORE_NAMESPACE:-teastore}"

# Parse args
while [[ $# -gt 0 ]]; do
  case $1 in
    --falha) FALHA="$2"; shift 2 ;;
    --gitea-url) GITEA_URL="$2"; shift 2 ;;
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

# Read commit from file (baseline) — para falhas usa a tag de release (exp-v1.0.0-fN)
COMMIT_FILE="$SCRIPT_DIR/../TEASTORE_COMMIT"
COMMIT_FULL=""
if [[ -f "$COMMIT_FILE" ]]; then
  COMMIT_FULL="$(cat "$COMMIT_FILE" | tr -d '[:space:]')"
fi

# Release tag: baseline → BASELINE_RELEASE_TAG (exp-v1.0.0 por compatibilidade com as
# coleções antigas; a baseline do experimento de traces completos é exp-v1.1.0);
# fN-* → $RELEASE_PREFIX-N
RELEASE_TAG="${BASELINE_RELEASE_TAG:-exp-v1.0.0}"
if [[ "$FALHA" != "baseline" ]]; then
  N="$(echo "$FALHA" | grep -oE '^f[0-9]+' | head -1)"
  [[ -n "$N" ]] && RELEASE_TAG="${RELEASE_PREFIX:-exp-v1.0.0}-${N}"
fi

# Resolve commit da tag de release via Gitea API (font de verdade do release)
TAG_INFO=$(curl -sf -H "Authorization: token $GITEA_TOKEN" \
  "$GITEA_URL/api/v1/repos/$GITEA_ORG/$GITEA_REPO/tags/$RELEASE_TAG" 2>/dev/null || echo "{}")
RELEASE_COMMIT=$(echo "$TAG_INFO" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('commit',{}).get('sha','') or d.get('commit',{}).get('id',''))" 2>/dev/null || echo "")
if [[ -n "$RELEASE_COMMIT" ]]; then
  COMMIT_FULL="$RELEASE_COMMIT"
fi
COMMIT_SHORT="${COMMIT_FULL:0:7}"

# Query Gitea for commit date
COMMIT_DATE=$(curl -sf -H "Authorization: token $GITEA_TOKEN" \
  "$GITEA_URL/api/v1/repos/$GITEA_ORG/$GITEA_REPO/commits?sha=$RELEASE_TAG&limit=1" \
  | python3 -c "import json,sys; c=json.load(sys.stdin); print(c[0]['commit']['committer']['date'])" 2>/dev/null || echo "unknown")

# Get config repo commit
CONFIG_COMMIT=$(curl -sf -H "Authorization: token $GITEA_TOKEN" \
  "$GITEA_URL/api/v1/repos/$GITEA_ORG/$CONFIG_REPO/commits?limit=1" \
  | python3 -c "import json,sys; c=json.load(sys.stdin); print(c[0]['sha'][:7])" 2>/dev/null || echo "unknown")

# Serviço alvo da falha. Precisa casar com _falha_to_service() em ../lib.sh:
# o digest tem que vir do container PRINCIPAL do serviço que a falha afeta, não
# do webui. Ler sempre do webui grava a imagem errada em toda falha que não é
# de webui (f3/f6/f7/f8/f10/f11 persistence, f9 registry, f13 auth) — o campo
# que deveria fixar qual artefato foi implantado.
_falha_to_service() {
  local n
  n=$(echo "$1" | grep -oE '^f[0-9]+' | head -1 || true)
  case "$n" in
    f1|f2|f4|f5|f12|f14) echo "webui" ;;
    f3|f6|f7|f8|f10|f11) echo "persistence" ;;
    f9) echo "registry" ;;
    f13) echo "auth" ;;
    *) echo "webui" ;;  # baseline e desconhecidas: webui é o principal
  esac
}

TEASTORE_SERVICE="$(_falha_to_service "$FALHA")"
CONTAINER="teastore-${TEASTORE_SERVICE}"

# Get image digest from running pods (container principal do serviço da falha)
export MINIKUBE_HOME="${MINIKUBE_HOME:-/mnt/minikube-disk/.minikube}"
IMAGE_DIGEST=$(kubectl get pod -n "$TEASTORE_NAMESPACE" -l "run=${CONTAINER}" \
  -o jsonpath='{range .items[0].status.containerStatuses[*]}{.name}{"|"}{.imageID}{"\n"}{end}' 2>/dev/null \
  | grep "^${CONTAINER}|" | cut -d'|' -f2 | head -1)
# Strip docker-image:// prefix
IMAGE_DIGEST="${IMAGE_DIGEST#docker-image://}"

# Determine status and motivo based on falha
if [[ "$FALHA" == "baseline" ]]; then
  STATUS="SEM_ALTERACAO"
  MOTIVO="TeaStore em estado normal, sem injeção de falha."
  ARQUITECTURA="[]"
  PATCH_FILE=""
else
  STATUS="CONFIGURACOES_ALTERADAS"
  # Aliases: o usuario usa nome curto (f1..f10), os patches/repo usam nome longo
  declare -A PATCH_ALIASES=(
    [f1]=f1-latency [f2]=f2-memory [f3]=f3-sql [f4]=f4-path
    [f5]=f5-heap [f6]=f6-db [f7]=f7-pool [f8]=f8-table
    [f9]=f9-version [f10]=f10-cpu
  )
  # A tabela é chaveada pelo nome CURTO, mas $FALHA chega com o nome LONGO
  # (f10-cpu-contention). Consultar direto por $FALHA caía no default e deixava
  # 6 de 14 faults sem descrição e sem o patch correto — porque o patch também
  # sai desse ALIAS. Normaliza para fN antes de olhar.
  FALHA_SHORT="$(echo "$FALHA" | grep -oE '^f[0-9]+' | head -1 || true)"
  ALIAS="${PATCH_ALIASES[$FALHA_SHORT]:-$FALHA}"
  # New descriptions: real code/config changes
  declare -A DESCRICOES=(
    [f1-latency]="Algoritmo O(n^2) no WebUIController — loop quadrado de comparação de produtos"
    [f2-memory]="Memory leak — cache ConcurrentHashMap sem TTL nem eviction"
    [f3-sql]="Query SQL O(n^3) com JOINs desnecessários e LIKE%"
    [f4-path]="Path de catálogo de imagens incorreto (/opt/teastore/imagens/catalogo)"
    [f5-heap]="Heap JVM limitado a 64MB (-Xmx64m) no WebUI"
    [f6-db]="DB_HOST apontando para host inexistente (nuvem)"
    [f7-pool]="Pool de conexões mínimo (maxPoolSize=2) no Persistence"
    [f8-table]="Tabela PERSISTENCEPRODUCT renomeada para PERSISTENCEPRODUCT_F8"
    [f9-version]="Registry retorna formato v2 incompatível com clientes v1"
    [f10-cpu]="Thread pool com 100-200 threads no Persistence (overload)"
  )
  MOTIVO="${DESCRICOES[$ALIAS]:-Falha $FALHA desconhecida}"
  
  # Get patch content for diff field (repo teastore-config, pasta patches)
  PATCH_FILE="/tmp/teastore-config/patches/${ALIAS}.patch"
  # Spec 02_schemas: arquivos_alterados = list[dict] {"arquivo", "diff"}
  ARQUITECTURA=$(python3 - "$ALIAS" "$PATCH_FILE" <<'PY'
import json, sys
falha, patch = sys.argv[1], sys.argv[2]
try:
    with open(patch, encoding="utf-8", errors="replace") as f:
        diff = f.read()[:4000]
    arquivos = [{"arquivo": f"patches/{falha}.patch", "diff": diff}]
except FileNotFoundError:
    arquivos = []
print(json.dumps(arquivos, ensure_ascii=False))
PY
)
fi

# Generate version.json
cat <<EOF
{
  "configuracao": {
    "status": "$STATUS",
    "ambiente": "k8s",
    "falha": "$FALHA",
    "motivo": "$MOTIVO",
    "arquivos_alterados": $ARQUITECTURA
  },
  "aplicacao": {
    "nome": "teastore",
    "repo_url": "$GITEA_URL/$GITEA_ORG/$GITEA_REPO",
    "release_tag": "$RELEASE_TAG",
    "app_commit_version": "$COMMIT_SHORT",
    "dt_commit_version": "$COMMIT_DATE",
    "image_digest": "$IMAGE_DIGEST"
  },
  "config": {
    "repo_url": "$GITEA_URL/$GITEA_ORG/$CONFIG_REPO",
    "config_commit_version": "$CONFIG_COMMIT"
  }
}
EOF
