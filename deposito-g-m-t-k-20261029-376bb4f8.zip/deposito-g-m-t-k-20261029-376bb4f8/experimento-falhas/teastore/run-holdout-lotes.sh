#!/usr/bin/env bash
# Driver resumivel dos 3 lotes de hold-out do Stage 3 (HOLDOUT.md).
# Uso:  setsid nohup ./run-holdout-lotes.sh > /dev/null 2>&1 &
# Um lote e a unidade do pre-registro: se abortar, recomeca inteiro com a MESMA seed (ate 3 tentativas).
set -uo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
S3="$SELF_DIR/stage3-online"
OUT="$S3/resultados/holdout"
BASE_COLLECTION="$(cat "$SELF_DIR/resultados/baseline-collection.id")"
FALHAS="h1-image-cpu-throttle,h2-recommender-oom,h3-auth-jvm-heap,h4-db-cpu-throttle,h5-image-registry-misconfig,h6-recommender-down"
SEEDS=(20261011 20261012 20261013)
RETRIES=3

mkdir -p "$OUT"
echo "[driver] inicio $(date -u +%FT%TZ)  base=$BASE_COLLECTION" | tee -a "$OUT/driver.log"

for i in 1 2 3; do
    seed="${SEEDS[$((i-1))]}"
    mark="$OUT/lote${i}.done"
    if [ -f "$mark" ]; then
        echo "[driver] lote $i ja concluido, pulando" | tee -a "$OUT/driver.log"
        continue
    fi
    attempt=0
    while [ ! -f "$mark" ]; do
        attempt=$((attempt+1))
        if [ "$attempt" -gt "$RETRIES" ]; then
            echo "[driver] lote $i esgotou $RETRIES tentativas -- parando" | tee -a "$OUT/driver.log"
            exit 1
        fi
        echo "[driver] lote $i tentativa $attempt seed=$seed $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
        if "$SELF_DIR/coleta-lote-stage3.sh" -c "$BASE_COLLECTION" -f "$FALHAS" --seed "$seed" \
                >> "$OUT/lote${i}.log" 2>&1; then
            touch "$mark"
            echo "[driver] lote $i concluido $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
        else
            echo "[driver] lote $i tentativa $attempt falhou $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"
            sleep 120
        fi
    done
done

echo "[driver] hold-out completo $(date -u +%FT%TZ)" | tee -a "$OUT/driver.log"