#!/usr/bin/env bash
# Driver resumivel da COLETA DEFINITIVA (PROTOCOLO-COLETA-DEFINITIVA.md).
#
# Um lote e a unidade do pre-registro: se abortar, recomeca inteiro com a MESMA semente (ate 3
# tentativas). Diferente de run-inedita-lotes.sh, aqui a baseline e NOVA: o cluster foi reconstruido
# e o congelamento trocou de digest em 2026-10-15. Por isso o PRIMEIRO lote roda SEM `-c` -- e ele
# que faz a FASE 1 (aquecimento medido) e a FASE 2 (baseline + traces + artefatos dos modos) -- e os
# demais reusam a colecao recem-criada. Nao ha guarda de baseline antiga: o driver guarda em
# $OUT/baseline.id o id da baseline que ESTA coleta criou, e ignora o que ja estava no arquivo.
#
# Resumivel: o id "anterior" e fixado em $OUT/baseline_anterior.id na PRIMEIRA execucao, entao um
# driver reiniciado depois de o C1 criar a baseline reconhece a baseline nova como desta coleta. O
# coleta-lote-stage3.sh so grava resultados/baseline-collection.id no FIM da FASE 2 (baseline,
# traces e artefatos prontos): um C1 que aborta no meio da FASE 2 recomeca sem `-c`, do zero.
#
# Duracao da baseline e dos pacotes: as do congelamento (protocolo.baseline_s / pacote_s); o
# pre-voo do coleta-lote-stage3.sh reprova se divergirem.
#
# Nao usar run-baseline-only.sh para a baseline desta coleta: ele opera numa colecao fixa ja
# existente, nao cria colecao, nao faz o aquecimento medido (FASE 1), nao roda "Calcular Baseline" /
# "Coletar Traces de Baseline" e nao prepara os artefatos dos modos.
#
# Uso:  setsid nohup ./run-definitiva-lotes.sh > /dev/null 2>&1 &
#       LOTES="C1" ./run-definitiva-lotes.sh     # so o primeiro lote (baseline + h1-h6)
set -uo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$SELF_DIR/stage3-online/resultados/definitiva"
BASE_FILE="$SELF_DIR/resultados/baseline-collection.id"
H="h1-image-cpu-throttle,h2-recommender-oom,h3-auth-jvm-heap,h4-db-cpu-throttle,h5-image-registry-misconfig,h6-recommender-down"
G="g1-auth-cpu-throttle,g2-persistence-down,g3-image-memory-limit,g4-db-memory-limit,g5-recommender-cpu-throttle,g6-persistence-jvm-heap"
# C1-C2: h; C3-C4: g. Sementes novas (PROTOCOLO-COLETA-DEFINITIVA.md §2).
declare -A FALHAS_DO=([C1]="$H" [C2]="$H" [C3]="$G" [C4]="$G")
declare -A SEED_DO=([C1]=20261031 [C2]=20261032 [C3]=20261033 [C4]=20261034)
LOTES="${LOTES:-C1 C2 C3 C4}"
RETRIES=3

mkdir -p "$OUT"
CONG="$SELF_DIR/stage3-online/congelamento.json"
BASELINE_TIME="$(python3 -c "import json; print(json.load(open('$CONG'))['protocolo']['baseline_s'])")"
PACKAGE_WINDOW="$(python3 -c "import json; print(json.load(open('$CONG'))['protocolo']['pacote_s'])")"
export BASELINE_TIME PACKAGE_WINDOW
# Snapshot fixado na 1a execucao: baseline de coleta anterior (ou 547ba505) NAO vale para esta coleta.
[ -f "$OUT/baseline_anterior.id" ] || { cat "$BASE_FILE" 2>/dev/null || true; } > "$OUT/baseline_anterior.id"
OLD_BASE="$(cat "$OUT/baseline_anterior.id")"
log() { echo "[driver] $*" | tee -a "$OUT/driver.log"; }
log "inicio $(date -u +%FT%TZ)  lotes=$LOTES  baseline=${BASELINE_TIME}s pacotes=${PACKAGE_WINDOW}s  baseline_anterior=${OLD_BASE:-<nenhuma>}"

# Id da baseline DESTA coleta. Se ja foi criada (por esta rodada ou por outra tentativa), reusa.
base_atual() {
    if [ -f "$OUT/baseline.id" ]; then cat "$OUT/baseline.id"; return; fi
    local cur; cur="$(cat "$BASE_FILE" 2>/dev/null || true)"
    if [ -n "$cur" ] && [ "$cur" != "$OLD_BASE" ]; then
        echo "$cur" > "$OUT/baseline.id"; echo "$cur"; return
    fi
    echo ""
}

for lote in $LOTES; do
    falhas="${FALHAS_DO[$lote]:-}"; seed="${SEED_DO[$lote]:-}"
    [ -n "$falhas" ] || { log "lote desconhecido: $lote"; exit 1; }
    mark="$OUT/$lote.done"
    if [ -f "$mark" ]; then log "lote $lote ja concluido, pulando"; continue; fi
    attempt=0
    while [ ! -f "$mark" ]; do
        attempt=$((attempt+1))
        if [ "$attempt" -gt "$RETRIES" ]; then log "lote $lote esgotou $RETRIES tentativas -- parando"; exit 1; fi
        base="$(base_atual)"
        if [ -n "$base" ]; then
            log "lote $lote tentativa $attempt seed=$seed reusando baseline $base $(date -u +%FT%TZ)"
            args=(-c "$base" -f "$falhas" --seed "$seed")
        else
            log "lote $lote tentativa $attempt seed=$seed SEM baseline (fara FASE 1+2) $(date -u +%FT%TZ)"
            args=(-f "$falhas" --seed "$seed")
        fi
        if "$SELF_DIR/coleta-lote-stage3.sh" "${args[@]}" >> "$OUT/$lote.log" 2>&1; then
            base_atual >/dev/null   # grava o id da baseline criada no lote sem `-c`
            grep -oE 'lote do Stage 3: +[0-9]{8}T[0-9]{6}Z' "$OUT/$lote.log" | tail -1 | awk '{print $NF}' > "$OUT/$lote.run"
            touch "$mark"
            log "lote $lote concluido $(date -u +%FT%TZ) run=$(cat "$OUT/$lote.run") base=$(cat "$OUT/baseline.id" 2>/dev/null || echo ?)"
        else
            log "lote $lote tentativa $attempt falhou $(date -u +%FT%TZ)"
            sleep 120
        fi
    done
done
log "coleta definitiva completa $(date -u +%FT%TZ)"
