# Hold-out 2 do Stage 3 — pré-registro (2026-10-12, antes de qualquer coleta)

Commitado **antes** da coleta. Nada aqui muda depois de ver resultado; mudança é pré-registro novo e invalida
este como evidência. Contexto: `session.md` §42.46–§42.48.

## Por que existe

1. O hold-out 1 (`HOLDOUT.md`) só teve 3/18 incidentes ao vivo (defeito do harness, corrigido em `5bac6a03`) e
   os lotes 1–2 perderam os traces. Avaliado offline: insumo completo em 8 cenários (§42.47).
2. As versões `c` (`d1c-v1`, `d2c-v1`, `d4c-v1`, spec 42.14) foram desenhadas **olhando** h1–h6 e os 38 de
   calibração. Para elas, h1–h6 são desenvolvimento. Precisam de falhas que não viram.

## Parte A — completar o hold-out 1 (modos congelados v1)

Recoleta dos lotes 1 e 2 do `HOLDOUT.md` com as **mesmas sementes** (`20261011`, `20261012`), mesmas falhas
h1–h6, mesma baseline (`547ba505`), mesmos modos congelados (a0-v1, d1-v1, d2-v3, d3-v1, d4-v1). Junta-se ao lote 3
já coletado (`20261012T072332Z`). Reporta-se o que o `HOLDOUT.md` manda, e **à parte**, como desenvolvimento,
o resultado das versões `c` nesses cenários.

## Parte B — hold-out das versões `c`

Falhas por override de configuração sobre `exp-v1.1.0`, em pares alvo × tipo que **não aparecem** em nenhum dos
44 casos de desenvolvimento (F1–F14 × 3 lotes, h1–h6):

| id | alvo | causa injetada | tipo já visto em… | alvo já visto em… |
|---|---|---|---|---|
| `g1-auth-cpu-throttle` | auth | `limits.cpu=100m` | image (h1), db (h4), webui (F12) | F13, h3 |
| `g2-persistence-down` | persistence | `replicas=0` | recommender (h6) | F3, F6–F8, F10, F11 |
| `g3-image-memory-limit` | image | `limits.memory=128Mi` | recommender (h2), persistence (F11) | h1, h5 |
| `g4-db-memory-limit` | db | `limits.memory=96Mi` | persistence (F11), recommender (h2) | h4 |
| `g5-recommender-cpu-throttle` | recommender | `limits.cpu=100m` | image, db, webui | h2, h6 |
| `g6-persistence-jvm-heap` | persistence | `_JAVA_OPTIONS -Xmx48m` | webui (F5), auth (h3) | F3, F6–F8, F10, F11 |

Gabarito: `teastore-<alvo>` (`teastore-db` em g4). Implementação: `lib.sh` (`_falha_to_service`,
`_infra_resources_patch`, `_infra_env_patch`, `_apply_infra_config`) e `stage3-online/verificar_falha.py`
(só a causa). Três lotes (sementes `20261021`, `20261022`, `20261023`), ordem embaralhada por lote = 18 cenários.
Os oito modos rodam em todos: a0-v1, d1-v1, d2-v3, d3-v1, d4-v1, d1c-v1, d2c-v1, d4c-v1.

## Protocolo (A e B)

1. Baseline `547ba505` (90 min, a mesma do hold-out 1). Artefatos das versões `c` instalados pelo caminho do job
   ao vivo com os traces do backup (`stage3-online/instalar_artefatos_backup.py`; o Jaeger já expirou), `q`
   conferido contra o artefato offline do mesmo backup.
2. `stage3_config.modos = {"escolhidos": [os oito], "principal": "a0", "d1c"/"d2c"/"d4c":
   {"dependencias_sem_span": {"mysql": "teastore-db"}}}`.
3. Pré-voo: os oito modos = congelados (`congelamento.json`), job-runner no digest congelado.
4. Harness com hipótese única por cenário (`5bac6a03`). **Reserva, declarada agora:** se um incidente não abrir,
   o cenário é avaliado offline com o incidente reconstruído (`replay/holdout_offline.py`, fidelidade 15/15 em
   §42.47) e marcado como tal; os traces do cenário são salvos antes do TTL (`salvar-traces-lote3.sh`).

## O que se reporta (e só isto)

- Por modo, **separado**: Top-1 **sem empate** (número principal; acerto que dependeu de desempate não conta —
  §42.48), Top-1, Top-3, MRR, cobertura, com IC de Wilson. Parte A e Parte B em tabelas separadas.
- **H2** (pré-registrada): na Parte B, cada versão `c` tem Top-1 sem empate ≥ o da sua v1 (d1c ≥ d1, d2c ≥ d2,
  d4c ≥ d4). Reportada por par, com o número de cenários em que cada um acerta e o outro não.
- **H3** (pré-registrada): na Parte B, em g4 (db) as versões `c` nomeiam `teastore-db` no Top-3 em ao menos 2 dos
  3 cenários; as v1 não podem (não há span do banco).
- Limitações previstas: g2 derruba quase tudo (o webui não serve sem persistence) — sinal forte, mas também risco
  de poucos traces (abstenção por `poucos_traces` é resultado, não descarte).

## O que não se faz

Ajustar regra, parâmetro, limiar, lista de falhas ou gabarito olhando a Parte B; descartar cenário por efeito (só
pela causa, no verificador); fundir modos.
