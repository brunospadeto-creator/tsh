# Protocolo do consenso — higiene, a0-p, d9-k e v-cons

Registrado em 2026-10-14 (ARQ), **antes** de rodar qualquer etapa. Proposta: `session.md` §42.69. Base: a do
avaliador unificado (§42.68, `replay/protocolo_rapido.py unificado`): 54 cenários (28 f, 8 h, 18 g), 5 normais + 5
estáveis por cenário a 60 s, referência pré-falha deslocada nos estáveis. g = **teste**, lido uma vez, no fim, com o
parâmetro escolhido em dev (f + h, 36 cenários); exploratório (já aberto para os pais).

## 1. Fase 0 — higiene (antes de qualquer modo novo)

- **D0.1** eventos K8s pré-falha nos f: linha do tempo por cenário (`k8s_events_cluster.json`: `firstTimestamp`,
  `lastTimestamp`, `count`, motivo, objeto) contra início da referência, fim do normal e início do estável.
  Regra de corte fixada aqui: **um evento só conta a partir do início da referência do cenário** (`first_ts` cortado
  em `inicio_normal`, com `count` proporcional, como `_a_partir_de`); ocorrências anteriores são do cenário anterior.
- **D0.2** motivos de **sintoma** (entram nos modos): `OOMKilled`, `OOMKilling`, `BackOff`, `Unhealthy`, `Evicted`,
  `Failed`, `FailedScheduling`, `ProbeWarning`, `Killing` **só** se o pod alvo não foi trocado pelo harness (ver D0.1).
  Motivos de **operação** (não entram): `Scheduled`, `Pulling`, `Pulled`, `Created`, `Started`, `SuccessfulCreate`,
  `SuccessfulDelete`, `ScalingReplicaSet`, `Killing` de rollout. A lista final é a que a D0.2 mostrar no dado,
  dentro destas duas famílias; motivos novos encontrados vão para "operação" por padrão (conservador).
- **D0.3** normal limpo: por cenário, taxa de erro e mediana de latência da entrada no normal × no fim do normal do
  cenário anterior/baseline; "sujo" = erro > 2× a mediana dos normais do mesmo lote ou evento de sintoma no normal.
  Resultados finais reportados com e sem os sujos.
- **D0.4** cobertura: instante com < 30 traces na janela é excluído para **todos** os modos.
- **D0.5** gabarito × alvo: conferência `esperado` × alvo do harness (`avaliacao.json`, `simulacao.json`).
- **D0.6** d2 no g4: marcada (falha conhecida), só referência.

Se D0.1/D0.2 mudarem os eventos K8s que os modos recebem, a base unificada é recalculada com o filtro antes das
etapas seguintes (b2, a0-k, a0-d e a a0 com eventos filtrados).

## 2. a0-p (filho da a0)

Localizador. Entrada = a0 (k = 3, pacotes montados, sem métricas) com eventos K8s **filtrados** (D0.1 + D0.2).
Persistência: o 1º lugar no instante i é o serviço mais frequente entre os 1º lugares dos últimos n instantes
**decididos** do mesmo período (só passado; desempate: o mais recente); o resto do ranking vem do instante i.
Confiança = fração dos n com o mesmo 1º. Grade: n ∈ {1, 3, 5}. Escolha em dev pelo top-1 sabendo que é falha
(empate → menor n). **Sucesso**: dev ≥ a0 + 5 p.p. sem perder > 5 p.p. em f, h ou g.

## 3. d9-k (filho da d9)

Portão = o da d9 (L = 1,5, E = 0,1, dano off, R = 150), opcionalmente aberto também por evento K8s de sintoma na
janela. Ranking = o da d9 (`residuo_1`) completado até o top-3 pela ordem de efeito da d5 (`referencia.ranking_por_efeito`)
e, se ainda faltar, pelo ranking `profundo`; evento K8s de sintoma no serviço X põe X em 1º (vários: o de maior
`count` na janela). Persistência do 1º como na a0-p. Grade: n ∈ {1, 3, 5} × K8s abre o portão {não, sim}.
Escolha em dev por F1@1 com portão (empate → menos alarme → menor n). O canal K8s (promoção) é **regra de desenho**,
fixa (dev quase não tem evento de sintoma). **Sucesso**: F1@1 dev ≥ d9 sem aumentar o alarme em > 1 p.p.

## 4. v-cons (consenso)

Votantes: d9-k, a0-p, d6 (unificado, a = 1) e, na grade, um 4º ∈ {d1c, d6-u}. Portão = o da d9-k escolhido.
Voto: Borda no top-3 (3, 2, 1) com o 1º de cada votante pela persistência (n da grade); pesos iguais ou por
confiabilidade (logit do top-1 sabendo que é falha do votante, validação cruzada deixando o **tipo** de fora).
Desempate, em ordem: (1) serviço com evento K8s de sintoma na janela; (2) maior persistência; (3) mais votantes com o
serviço no top-3; (4) ordem da d9-k. Confiança = margem da Borda / total, calibrada em dev por faixas (tercis).
Grade: pesos {iguais, confiabilidade} × n {1, 3, 5} × votantes {3, 3+d1c, 3+d6-u} = 18. Escolha em dev pelo top-1
sabendo que é falha, estimado por validação cruzada deixando o tipo de fora (empate → mais simples).
**Sucesso**: dev ≥ d9 + 10 p.p. sabendo que é falha **e** F1@1 com portão em dev ≥ d9; McNemar pareado × d9 e × a0.

A margem do escore normalizada (desempate 4 da §42.69) foi retirada: os escores dos votantes não estão na mesma
escala e a a0 não expõe escore comparável; a ordem da d9-k ocupa o lugar.

## 5. Medida e relatório

Métricas e estatística da §3 do `PROTOCOLO-RAPIDO.md` (bootstrap por tipo; McNemar no acerto majoritário).
Relatório: dev (escolha) e g (uma leitura), por grupo, com e sem os cenários "normal sujo" (D0.3).
Saída: `resultados/protocolo-consenso/`.
