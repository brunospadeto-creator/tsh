#!/usr/bin/env python3
"""Dump dos traces brutos do Jaeger para uma janela de tempo -- mesmo método usado
pelo Stage 3 real (`JaegerClient` + `search_traces`, serviços menos os excluídos por
`DEFAULT_EXCLUDED_SERVICES`), mas sem passar pelo parsing de `recover_incident_trace`
(queremos o JSON cru do Jaeger para análise posterior, não os eventos já processados).

Uso: dump_traces.py <jaeger_endpoint> <window_start ISO> <window_end ISO> <output.json> [limit]

Chamado por run-stage3-online.sh com PYTHONPATH apontando para a raiz do repo.
"""

import datetime
import json
import sys


def main() -> int:
    if len(sys.argv) < 5:
        print(__doc__, file=sys.stderr)
        return 1
    endpoint, window_start, window_end, out_path = sys.argv[1:5]
    limit = int(sys.argv[5]) if len(sys.argv) > 5 else 2000

    from src.application.stage3.config import DEFAULT_EXCLUDED_SERVICES
    from src.application.stage3.traces import JaegerClient, search_traces, to_epoch_us

    client = JaegerClient(endpoint)
    services = [s for s in client.services() if s not in set(DEFAULT_EXCLUDED_SERVICES)]
    start_us = to_epoch_us(datetime.datetime.fromisoformat(window_start))
    end_us = to_epoch_us(datetime.datetime.fromisoformat(window_end))
    traces, n_splits = search_traces(client, services, start_us, end_us, limit)

    with open(out_path, "w") as f:
        json.dump({
            "window_start": window_start, "window_end": window_end, "jaeger_endpoint": endpoint,
            "services": services, "n_splits": n_splits, "n_traces": len(traces), "traces": traces,
        }, f, ensure_ascii=False)
    print(f"    {len(traces)} traces brutos salvos em {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
