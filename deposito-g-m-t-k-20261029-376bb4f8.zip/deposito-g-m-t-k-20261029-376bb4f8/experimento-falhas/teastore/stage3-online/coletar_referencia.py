#!/usr/bin/env python3
"""Coleta a janela de REFERÊNCIA do cenário -- traces do app saudável, sob a mesma carga, ANTES da
injeção da falha (Etapa F do plano de rastros).

Por que existe
--------------
A baseline global foi coletada uma vez, num ambiente e num momento específicos. Quando o experimento roda
várias falhas em sequência, o próprio experimento suja o ambiente: a F5 deixa `-Xmx64m` em algum serviço,
a F11 derruba pods por OOM, a F14 enche o disco de log. A baseline continua descrevendo o ambiente
*antes* dessas mudanças, então a janela da falha herda a deriva e a localização acusa sintoma onde só
mudou o cenário — o falso positivo que a Stage 3 começou alabels com "impossível" nos 4 traces em
abstenção.

A referência fecha isso: mesmo app, mesma carga do stresser, janela imediatamente anterior à injeção. A
localização passa a comparar a janela da falha contra as DUAS bases — a global (pega deriva de ambiente) e
a referência (pega o que a falha mudou dentro daquele ambiente) — e une as anomalias.

O que ela grava
---------------
Uma linha em `collection_baselines` com `status=completed` e só `service_stats`, que é o que
`localizar()` consome. Não roda PM4Py de propósito: uma janela de poucos minutos não tem traces
suficientes por endpoint para um PetriNet confiável, e o modelo de processo da referência não é usado por
ninguém — `process_models` fica vazio. Isso tambem evita que a referencia falhe com
`BaselineInsufficientError` e trave o lote por causa de um detalhe que ninguem consome.

Uso (chamado pelo run-stage3-online.sh antes de aplicar a falha):

    PYTHONPATH="$REPO_ROOT" python3 coletar_referencia.py \
        --system-id "$VERITAS_SYSTEM_ID" --referencia-id "$REF_ID" \
        --janela-seg 300 --out-dir "$FALHA_DIR/referencia"
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import sys
import time

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from src.application.stage3.baseline import (  # noqa: E402
    QUERY_PAUSE_SECONDS,
    _slices,
    search_traces,
)
from src.application.stage3.service_stats import baseline_service_stats  # noqa: E402
from src.application.stage3.traces import JaegerClient  # noqa: E402
from src.infra.settings import get_settings  # noqa: E402
from src.store.repository import Repository  # noqa: E402

UTC = datetime.UTC


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Coleta a janela de referência do cenário (Etapa F)")
    p.add_argument("--system-id", required=True)
    p.add_argument("--referencia-id", required=True,
                   help="collection_id da referência; é o que `incidents.referencia_collection_id` aponta")
    p.add_argument("--janela-seg", type=int, default=300, help="duração da janela de referência")
    p.add_argument("--janela-inicio", default="",
                   help="ISO do início da janela. O orquestrador passa o instante em que o stresser "
                        "subiu: ancorar em `agora - janela` pega o período ocioso anterior e a "
                        "referência sai com poucas traces, que é o oposto de uma referência")
    p.add_argument("--package-window", type=int, default=3,
                   help="herdado da collection de falhas; só para a collection da referência")
    p.add_argument("--jaeger", default=None, help="URL do Jaeger; default vem do stage3_config do system")
    p.add_argument("--out-dir", default=None, help="grava o service_stats em JSON para inspeção")
    p.add_argument("--min-traces", type=int, default=50,
                   help="abaixo disso a referência é fraca demais para ser base de comparação")
    return p.parse_args(argv)


def _system_config(repo: Repository, system_id: str):
    from src.application.stage3.baseline import _system_config as _cfg

    return _cfg(repo, system_id)


def coletar_referencia(
    system_id: str,
    referencia_id: str,
    janela_s: int,
    janela_inicio: str,
    package_window_s: int,
    jaeger_url: str | None,
    min_traces: int,
) -> dict:
    repo = Repository(get_settings().db_url)
    cfg = _system_config(repo, system_id)
    url = jaeger_url or cfg.resolved_jaeger_endpoint()
    if not url:
        raise ValueError("Jaeger nao configurado: passe --jaeger ou defina stage3_config.jaeger_endpoint")
    jaeger = JaegerClient(str(url))

    agora = datetime.datetime.now(UTC).replace(tzinfo=None)
    if janela_inicio:
        # O orquestrador passa o início da carga estável e espera `janela_s` antes de chamar: a janela é
        # [início, início + janela_s], não "até agora".
        inicio = datetime.datetime.fromisoformat(janela_inicio)
        if inicio.tzinfo is not None:
            inicio = inicio.astimezone(UTC).replace(tzinfo=None)
        if inicio >= agora:
            raise ValueError(
                f"janela de referencia com inicio {inicio.isoformat()} no futuro (agora {agora.isoformat()})"
            )
        fim = min(inicio + datetime.timedelta(seconds=janela_s), agora)
    else:
        fim = agora
        inicio = fim - datetime.timedelta(seconds=janela_s)
    janela_s = int((fim - inicio).total_seconds())
    # O coletor segura cada trace até decidir a amostragem (decision_wait 10 s + lote 2 s): consultar no
    # instante em que a janela fecha perde o fim dela. Espera o mesmo `trace_settle_seconds` do Stage 3.
    espera = (fim + datetime.timedelta(seconds=cfg.trace_settle_seconds)
              - datetime.datetime.now(UTC).replace(tzinfo=None)).total_seconds()
    if espera > 0:
        time.sleep(espera)
    # Uma janela só, sem paginar como a baseline faz: a referência é uma base pontual, não uma série
    # temporal. O tamanho do bucket vem de `cfg.discovery_bucket_sec`, o mesmo da baseline.
    janelas = [(inicio, fim)]

    disponiveis = set(jaeger.services()) - set(cfg.excluded_services)
    if not disponiveis:
        raise ValueError("nenhum servico disponivel no Jaeger para a referencia")
    todos = sorted(disponiveis)

    vistos: set[str] = set()
    brutos: list[dict] = []
    for lo, hi in _slices(inicio, fim):
        raw, _ = search_traces(jaeger, todos, lo, hi, cfg.trace_limit)
        time.sleep(QUERY_PAUSE_SECONDS)
        for trace_id, trace in raw.items():
            if trace_id in vistos:
                continue
            vistos.add(trace_id)
            brutos.append(trace)

    # `known_services` vem dos servicos que os traces nomeiam, para inferir arestas de chamada tambem
    # quando o chamador nao aparece como processo no Jaeger.
    conhecidos = sorted({p.get("serviceName") for t in brutos for p in (t.get("processes") or {}).values()
                         if p.get("serviceName")}) or todos
    stats = baseline_service_stats(brutos, janelas, cfg, conhecidos)

    if len(brutos) < min_traces:
        raise ValueError(
            f"referencia com apenas {len(brutos)} traces (minimo {min_traces}); "
            "a janela nao captou o cenario rodando -- aumente --janela-seg ou o warmup do stresser"
        )

    # `collection_baselines.collection_id` tem FK para `collections`, então a referência precisa de uma
    # collection de verdade -- não dá para gravar a baseline direto com um id solto.
    if repo.get_collection(referencia_id) is None:
        repo.create_collection({
            "collection_id": referencia_id,
            "system_id": system_id,
            "name": f"referencia {referencia_id}",
            "description": (
                "Janela de referência do cenário, coletada com o app saudável sob a mesma carga antes da "
                "injeção (Etapa F do plano-traces.md). Só service_stats; incidents.referencia_collection_id "
                "aponta para cá."
            ),
            "status": "completed",
            "package_window_seconds": package_window_s,
            "created_at": datetime.datetime.now(UTC).replace(tzinfo=None),
        })

    # `metric_stats` carrega so o vocabulario de servicos: e o que `known_services` le no
    # `collect_trace_baseline` da baseline real, e mantem as duas bases com os mesmos nomes.
    metric_stats = {s: [] for s in conhecidos}
    base = repo.create_or_replace_collection_baseline(referencia_id, system_id)
    repo.mark_baseline_completed(base.baseline_id, metric_stats, len(brutos))
    repo.update_baseline_trace_artifacts(
        base.baseline_id, {}, {}, service_graph={}, process_graphs={}, service_stats=stats,
    )
    return {
        "referencia_collection_id": referencia_id,
        "system_id": system_id,
        "window_start": inicio.isoformat(),
        "window_end": fim.isoformat(),
        "n_traces": len(brutos),
        "servicos": conhecidos,
        "operacoes": len(stats.get("operacoes") or {}),
        "arestas": len(stats.get("arestas") or []),
        "service_stats": stats,
    }


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        resultado = coletar_referencia(
            args.system_id, args.referencia_id, args.janela_seg, args.janela_inicio, args.package_window,
            args.jaeger, args.min_traces,
        )
    except Exception as exc:
        print(json.dumps({"erro": str(exc)}, ensure_ascii=False))
        return 1
    if args.out_dir:
        os.makedirs(args.out_dir, exist_ok=True)
        with open(os.path.join(args.out_dir, "referencia.json"), "w") as fh:
            json.dump(resultado, fh, ensure_ascii=False, default=str)
    # stdout é consumido pelo run-stage3-online.sh: só o JSON, sem log em volta.
    print(json.dumps(resultado, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
