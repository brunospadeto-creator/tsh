#!/usr/bin/env python3
"""Checagem funcional de saúde, não só estrutural.

O `health_gate.py` original só olhava estado de pod e coerência do registry. No lote
`081432Z` os cenários F1 e F2 passaram com "saudável antes=True" e o persistence respondendo HTTP 500 em
100% das `categories` — o portão não percebeu serviço quebrado, e os dois casos entraram no denominador
como se fossem erro do Stage 3 (grupo B do plano).

Duas camadas, uma só função de verdade:

- **sondas ativas** (`probe_webui`, `probe_generatedb`): o serviço responde certo agora;
- **taxa de erro HTTP** (`server_error_rates`): o serviço deixou de responder certo, medido sobre
  traces. A mesma função serve ao portão ao vivo (traces recentes do Jaeger) e à conferência offline
  dos insumos salvos (`checar_saude_insumos.py`), que é o critério de aceite da M1.

Sobre a referência: o plano pede "perto da baseline (<= 2x)". A baseline atual não persiste taxa de erro
por serviço (só `span_stats` com média/desvio/p95 de duração e `service_graph` com arestas de banco), e
persistir isso exigiria recoletar a baseline — que a M4 já exige. Então o limiar operativo é absoluto
(`max_share`), e o fator relativo a 2x fica disponível para quando houver linha de base de erro gravada.
"""

import datetime
import json
import subprocess
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any

WEBUI_PAGES = (
    ("index", "http://localhost:8080/tools.descartes.teastore.webui/index"),
    ("category", "http://localhost:8080/tools.descartes.teastore.webui/category?category=2&page=1"),
    ("product", "http://localhost:8080/tools.descartes.teastore.webui/product?id=7"),
    ("login", "http://localhost:8080/tools.descartes.teastore.webui/login"),
)
# Rota de descoberta de dados da persistence. O prefixo do serviço faz parte do path: sem ele a
# persistence responde 404 (é por isso que a checagem estrutural nunca via este sinal).
GENERATEDB_URL = (
    "http://localhost:8080/tools.descartes.teastore.persistence/rest/generatedb/finished"
    "?categories=5&products=100&users=100&orders=5"
)


@dataclass
class ErrorRate:
    """Taxa de respostas HTTP a partir de `min_status` entre os spans `server` que declaram status."""

    service: str
    n_status: int
    n_error: int
    min_status: int = 500

    @property
    def share(self) -> float:
        return self.n_error / self.n_status if self.n_status else 0.0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["share"] = round(self.share, 4)
        return data


def _tags(span: Mapping[str, Any]) -> dict[str, Any]:
    return {str(t.get("key")): t.get("value") for t in (span.get("tags") or [])}


def _status_of(span: Mapping[str, Any]) -> int | None:
    tags = _tags(span)
    raw = tags.get("http.response.status_code", tags.get("http.status_code"))
    try:
        return int(raw) if raw is not None else None
    except (TypeError, ValueError):
        return None


def server_error_rates(
    traces: Mapping[str, Mapping[str, Any]], *, min_spans: int = 1, min_status: int = 500
) -> dict[str, ErrorRate]:
    """Taxa de erro por serviço sobre traces brutos do Jaeger (formato de `/api/traces`).

    Só contam spans `server` com status HTTP declarado: os spans `client` do persistence (o JDBC) não
    têm status, e traces parciais sem raiz continuam contando — é a cobertura que a M1 quer, não a árvore.

    O corte é >= 500 (erro do servidor), não >= 400. A 404 é erro do cliente, não serviço quebrado: no
    lote `081432Z` ela sozinha acusava a persistence em 22% durante a F13, que é
    `GET /rest/products/{id}` respondendo "produto não existe" — comportamento normal, com a falha
    injetada no auth. A contaminação real (F1/F2) é HTTP 500, como o plano registra.
    """
    n_status: dict[str, int] = {}
    n_error: dict[str, int] = {}
    for trace in (traces or {}).values():
        processes = trace.get("processes") or {}
        for span in trace.get("spans") or []:
            tags = _tags(span)
            if str(tags.get("span.kind") or "") != "server":
                continue
            status = _status_of(span)
            if status is None:
                continue
            service = str((processes.get(span.get("processID")) or {}).get("serviceName") or "")
            if not service:
                continue
            n_status[service] = n_status.get(service, 0) + 1
            if status >= min_status:
                n_error[service] = n_error.get(service, 0) + 1
    return {
        service: ErrorRate(service, count, n_error.get(service, 0), min_status)
        for service, count in n_status.items()
        if count >= min_spans
    }


def error_rate_violations(
    rates: Mapping[str, ErrorRate],
    *,
    min_spans: int = 20,
    max_share: float = 0.20,
    max_factor: float = 2.0,
    baseline_rates: Mapping[str, float] | None = None,
    ignored: Sequence[str] = ("jaeger-all-in-one", "teastore-registry"),
) -> list[ErrorRate]:
    """Serviços com taxa de erro acima do absoluto (`max_share`) ou do relativo a 2x da baseline.

    `max_factor` só vale para quem tem linha de base de erro gravada; enquanto a baseline não persistir
    esse número, o corte é o absoluto. A entrada NÃO é excluída: erro nela é sintoma real de serviço
    quebrado, e é assim que F1/F2 foram pegos. O que sai da conta é o Jaeger e o registry — o registry
    responde 404/503 para sondas de descoberta que não são erro de aplicação (`excluded_services`).
    """
    skip = set(ignored)
    out: list[ErrorRate] = []
    for service, rate in sorted(rates.items()):
        if service in skip or rate.n_status < min_spans or rate.share < max_share:
            continue
        base = (baseline_rates or {}).get(service)
        if base is not None and base > 0 and rate.share <= max_factor * base:
            continue
        out.append(rate)
    return out


def _describe(rate: ErrorRate, baseline_rates: Mapping[str, float] | None, max_factor: float) -> str:
    base = (baseline_rates or {}).get(rate.service)
    ref = f" (baseline {base:.0%}, limite {max_factor:g}x)" if base is not None else ""
    return (f"{rate.service}: {rate.share:.0%} de {rate.n_status} respostas server "
            f"com código >= {rate.min_status}{ref}")


def error_rate_problems(rates: Mapping[str, ErrorRate], **kwargs: Any) -> list[str]:
    """As violações de `error_rate_violations` em texto, para o portão e o `health_pre.json`."""
    max_factor = float(kwargs.get("max_factor", 2.0))
    baseline_rates = kwargs.get("baseline_rates")
    return [_describe(rate, baseline_rates, max_factor)
            for rate in error_rate_violations(rates, **kwargs)]


# Grafo de chamada do TeaStore (chamador -> chamado). É propriedade da aplicação, não do experimento:
# o webui é a entrada e todos pedem dados à persistence; a auth pergunta à persistence se está logado;
# todo serviço consulta o registry para descobrir os outros. Serve para decidir se um erro observado é
# explicável pela falha injetada — erro no serviço injetado ou num chamador dele é esperado; erro num
# serviço que ele CHAMA não pode ser causado por ele (a seta vai no sentido oposto) e, portanto, é
# contaminação vinda de fora. Os traces não dão essa direção: não há span `client`, e todo span `server` da persistence aparece com o pai fora do trace.
TEASTORE_CALL_GRAPH: dict[str, tuple[str, ...]] = {
    "teastore-webui": ("teastore-auth", "teastore-image", "teastore-persistence", "teastore-recommender"),
    "teastore-auth": ("teastore-persistence",),
}
# Chamadores de cada serviço, para a transitividade. O registry NÃO entra: ele é folha (todo serviço o
# consulta para descobrir os outros), e incluí-lo faria o fecho transitivo de `webui` dar a volta e
# declarar todo serviço chamador dele — anulando o filtro. O registry também sai da checagem de erro.
TEASTORE_CALLERS: dict[str, frozenset[str]] = {
    callee: frozenset(caller for caller, callees in TEASTORE_CALL_GRAPH.items() if callee in callees)
    for callee in {c for callees in TEASTORE_CALL_GRAPH.values() for c in callees}
}
TEASTORE_ALL_SERVICES = (
    "teastore-webui", "teastore-auth", "teastore-image", "teastore-persistence", "teastore-recommender",
)


def callers_of(service: str, graph: Mapping[str, frozenset[str]] | None = None) -> frozenset[str]:
    """Serviços que chamam `service` (transitivo), para o filtro de causalidade da M1.

    O registry é folha: todo serviço o consulta para descobrir os outros, então chamador de `registry`
    é todo mundo. Mas ele não pode ser atravessado no fecho — senão o fecho de `webui` dá a volta pela
    chamada de descoberta e declara todo serviço chamador dele, anulando o filtro.
    """
    if service.endswith("registry"):
        return frozenset(TEASTORE_ALL_SERVICES) - {service}
    table = dict(TEASTORE_CALLERS if graph is None else graph)
    seen: set[str] = set()
    frontier = {service}
    while frontier:
        frontier = {caller for node in frontier for caller in table.get(node, ())} - seen
        seen |= frontier
    return frozenset(seen)


def unexplained_error_problems(
    rates: Mapping[str, ErrorRate],
    target_service: str,
    *,
    min_spans: int = 20,
    max_share: float = 0.20,
    max_factor: float = 2.0,
    baseline_rates: Mapping[str, float] | None = None,
    ignored: Sequence[str] = ("jaeger-all-in-one", "teastore-registry"),
    graph: Mapping[str, frozenset[str]] | None = None,
    min_status: int = 500,
) -> list[str]:
    """Erros altos que a falha injetada em `target_service` NÃO explica.

    Filtro de causalidade sobre `error_rate_problems`: o serviço injetado e os que o chamam podem
    Legitimamente errar; os que ELE chama não podem (a falha é injetada a jusante da chamada). É o que
    separa o grupo B do plano (F1 e F2 com o persistence quebrado de herança do rollback da F14, falha
    injetada no webui) das falhas que legítimamente quebram a persistence (F6, F7, F11).
    """
    target = target_service.removeprefix("teastore-")
    target_full = target_service if target_service.startswith("teastore-") else f"teastore-{target}"
    allowed = {target_full, f"tools.descartes.teastore.{target}"}
    allowed |= {c for c in callers_of(target_full, graph) if c.startswith("teastore-")}
    max_factor = float(max_factor)
    return [
        _describe(rate, baseline_rates, max_factor)
        for rate in error_rate_violations(
            rates, min_spans=min_spans, max_share=max_share, max_factor=max_factor,
            baseline_rates=baseline_rates, ignored=ignored,
        )
        if rate.service not in allowed
    ]


# ── sondas ativas ────────────────────────────────────────────────────


def _kubectl(*args: str, timeout: int = 30) -> str:
    return subprocess.run(["kubectl", *args], capture_output=True, text=True, timeout=timeout, check=True).stdout


def _kubectl_merged(*args: str, timeout: int = 30) -> str:
    """Como `_kubectl`, mas com stderr no stdout — o `wget -S` escreve os cabeçalhos HTTP em stderr."""
    return subprocess.run(
        ["kubectl", *args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=timeout, check=True,
    ).stdout


def _http_status_in_pod(namespace: str, pod: str, container: str, url: str, timeout: int = 20) -> int | None:
    """Status HTTP de uma URL chamada de dentro do pod (o service ClusterIP não é exposto no host)."""
    try:
        raw = _kubectl_merged(
            "exec", "-n", namespace, pod, "-c", container, "--",
            "wget", "-qSO-", "--timeout=5", "--tries=2", url,
            timeout=timeout + 10,
        )
    except Exception:
        return None
    for line in reversed(raw.splitlines()):
        if "HTTP/" in line:
            try:
                return int(line.split()[1])
            except (IndexError, ValueError):
                continue
    return None


def probe_webui(namespace: str, pod: str) -> dict[str, Any]:
    """`/index`, `/category`, `/product` e `/login` do webui têm que responder 200."""
    pages: dict[str, int | None] = {}
    problems: list[str] = []
    for name, url in WEBUI_PAGES:
        status = _http_status_in_pod(namespace, pod, "teastore-webui", url)
        pages[name] = status
        if status != 200:
            problems.append(f"webui/{name}: HTTP {status if status is not None else 'sem resposta'}")
    return {"pages": pages, "problems": problems, "ok": not problems}


def probe_generatedb(namespace: str, pod: str) -> dict[str, Any]:
    """`generatedb/finished` tem que responder com finished=true.

    O banco é efêmero (emptyDir): quando o pod da persistence reinicia, ele regenera do zero e o
    webui responde certo mas com o catálogo vazio. Essa é a condição que `restaurar_teastore` precisa
    esperar antes de devolver a apontar a imagem de release (pendência do plano de avaliação).

    A rota devolve `true`/`false` em texto puro, não JSON -- daí a tolerância aos dois formatos.
    """
    try:
        body = _kubectl_merged(
            "exec", "-n", namespace, pod, "-c", "teastore-persistence", "--",
            "wget", "-qO-", "--timeout=10", "--tries=2", GENERATEDB_URL, timeout=30,
        ).strip()
    except Exception as exc:
        return {"ok": False, "finished": None, "problems": [f"generatedb/finished não respondeu: {exc}"]}
    payload = body.rsplit("}", 1)[-1] if body.lstrip().startswith(("{", "[")) else body
    try:
        finished = bool(json.loads(body).get("finished")) if body.lstrip().startswith("{") \
            else payload.strip().strip("\"'").lower() == "true"
    except (json.JSONDecodeError, TypeError, AttributeError):
        return {"ok": False, "finished": None, "problems": [f"generatedb/finished ilegível: {body[:60]!r}"]}
    problems = [] if finished else ["generatedb/finished=false (banco efêmero regenerando)"]
    return {"ok": not problems, "finished": finished, "problems": problems}


def jaeger_traces(endpoint: str, services: Sequence[str], lookback_sec: int, limit: int = 200) -> dict[str, Any]:
    """Traces brutos do Jaeger na janela `(agora - lookback_sec, agora]`, para a camada de taxa de erro.

    A janela vai por `start`/`end` em microssegundos, e o filtro é refeito no cliente. Motivo: o Jaeger
    deste cluster IGNORA o parâmetro `lookback` -- `lookback=120s`, `30m` e `1h` devolvem exatamente o
    mesmo conjunto, e com `limit` o Jaeger entrega os traces mais ANTIGOS que casam. Usar `lookback`
    aqui faria o portão medir a falha do cenário anterior e acusar o cenário seguinte de contaminado
    (foi o que aconteceu na primeira versão desta função: 39% de erro no webui, vindos das 20:49,
    com o portão rodando às 21:26). O filtro do cliente é a rede de segurança para o caso de o
    storage também ignorar `start`/`end`.
    """
    import urllib.parse
    import urllib.request

    end_us = int(datetime.datetime.now(datetime.UTC).timestamp() * 1e6)
    start_us = end_us - int(lookback_sec * 1e6)
    out: dict[str, Any] = {}
    for service in services:
        query = urllib.parse.urlencode({
            "service": service, "start": start_us, "end": end_us, "limit": limit, "minDuration": "0ms",
        })
        try:
            with urllib.request.urlopen(f"{endpoint.rstrip('/')}/api/traces?{query}", timeout=30) as resp:
                traces = json.load(resp).get("data") or []
        except Exception:
            continue
        for trace in traces:
            # A API do Jaeger não tem `startTime` no trace, só nos spans: o início é o do primeiro span.
            inicios = [int(s["startTime"]) for s in trace.get("spans") or [] if s.get("startTime") is not None]
            if inicios and not start_us <= min(inicios) <= end_us:
                continue
            out[str(trace.get("traceID") or f"{service}-{len(out)}")] = trace
    return out


def summarize(
    rates: Mapping[str, ErrorRate], problems: Sequence[str], probes: Mapping[str, Mapping[str, Any]],
    *, min_spans: int = 20,
) -> dict[str, Any]:
    """Bloco único que vai para `health_pre.json`/`avaliacao.json`.

    `inconclusivo` avisa que a camada de taxa de erro não teve amostra suficiente para julgar -- entre
    cenários o stresser fica desligado, então sem carga prévia a janela costuma vir vazia. Não é um
    problema (não reprova o portão), mas o lote precisa saber que a checagem não rodou de fato: senão
    "saudável" vira ausência de evidência em vez de evidência de saúde.
    """
    total = sum(rate.n_status for rate in rates.values())
    return {
        "ok": not problems,
        "error_rates": {s: r.to_dict() for s, r in sorted(rates.items())},
        "problems": list(problems),
        "probes": {name: dict(value) for name, value in probes.items()},
        "n_status_spans": total,
        "inconclusivo": total < min_spans,
    }
