#!/usr/bin/env python3
"""Simula um incidente real durante um cenário de falha já aplicado no TeaStore,
sem depender de um motor Stage 1/2 treinado (plano de melhoria, 21/09/2026).

Coleta N pacotes de evidência reais em sequência, um por `--package-window`
segundos, com o mesmo código de produção usado por `execute_monitoring`
(`_collect_signals` + `collect_evidence` -- Loki/Prometheus/K8s de verdade contra
o TeaStore ao vivo). Como não há motor treinado/promovido pro TeaStore hoje, o
`stage1_result` de cada pacote é FORÇADO para "anomalous" (a falha foi injetada
deliberadamente pelo orquestrador -- não faz sentido depender de classificação
automática aqui). Em seguida chama a função real de abertura de incidente
(`maybe_open_incident_for_recent_anomalies` -- mesma regra de produção:
3 últimos logs anômalos com a mesma hipótese) e enfileira o job real do Stage 3
(`enqueue_stage3_job`) -- daí em diante é o job-runner processando um incidente
igual a qualquer outro, não uma simulação.

Precisa de acesso direto ao Postgres (`VERITAS_DB_URL`): não existe endpoint HTTP
para forçar `monitoring_logs`/abrir incidente. Rodar com PYTHONPATH na raiz do
repo (feito por run-stage3-online.sh).

Uso:
    simular_incidente.py --system-id ID --collection-id ID --falha NOME
                          --package-window SEG --out-dir DIR [--n-pacotes 3]

Imprime um único JSON de resultado em stdout (incident_id/job_id/erro).
"""

import argparse
import datetime
import json
import math
import os
import time
from concurrent.futures import Future, ThreadPoolExecutor


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--system-id", required=True)
    parser.add_argument("--collection-id", required=True)
    parser.add_argument("--falha", required=True)
    parser.add_argument("--package-window", type=int, required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--n-pacotes", type=int, default=3, help="tem que bater com o threshold de maybe_open_incident_for_recent_anomalies (padrão real: 3)")
    parser.add_argument(
        "--coleta-seg", type=int, default=0,
        help="se > 0, coleta pacotes continuamente por esse tempo (em vez de --n-pacotes) e abre o "
             "incidente com TODOS eles: a janela do incidente passa a cobrir a coleta inteira",
    )
    parser.add_argument(
        "--run-tag", default="",
        help="sufixo pra tornar a hipótese única por rodada (ex.: o run_id do orquestrador) -- sem "
             "isso, reexecutar a mesma falha esbarra no incidente ATIVO anterior com a mesma hipótese "
             "(maybe_open_incident_for_recent_anomalies não abre duplicata)",
    )
    parser.add_argument(
        "--referencia-collection-id", default="",
        help="collection_id da janela de referência do MESMO cenário, coletada antes da injeção "
             "(coletar_referencia.py). Fica em incidents.referencia_collection_id, e a localização "
             "passa a comparar a janela da falha também com essa base além da global.",
    )
    args = parser.parse_args()
    hypothesis = f"incidente__{args.run_tag}" if args.run_tag else "incidente"

    from src.application.stage3.tasks import enqueue_stage3_job
    from src.collector.providers.db_provider import DBVersionProvider
    from src.infra.settings import get_settings
    from src.monitor.tasks import _collect_signals, _load_baseline_drain_engine, _monitor_log
    from src.pipeline.pipeline import build_collect_config, collect_evidence
    from src.schemas.intermediate import RawSignalCollection
    from src.schemas.validation import get_package_schema_validator
    from src.store.repository import Repository

    os.makedirs(args.out_dir, exist_ok=True)
    repo = Repository(get_settings().db_url)

    system = repo.get_system(args.system_id)
    if system is None:
        print(json.dumps({"error": f"system not found: {args.system_id}"}))
        return 1
    if not system.stage3_enabled:
        print(json.dumps({"error": "stage3_enabled=false neste sistema -- habilite antes de rodar o script"}))
        return 1

    drain_engine, _baseline_failure_id = _load_baseline_drain_engine(repo, args.system_id, args.collection_id)
    active_cenario = getattr(system, "active_version_cenario", None) or "baseline"
    version_context = DBVersionProvider(repo).get(args.system_id, active_cenario)
    validator = get_package_schema_validator()

    packages_meta: list[dict] = []
    # a coleta levava ~4,4 s por pacote de 3 s porque cada janela começava em
    # "agora", depois de esperar o trabalho anterior. O pacote entrava ~1,4 s atrasado, o atraso se
    # acumulava e ~32% da linha do tempo ficava sem evidência -- ausência de sinal que o relatório lia
    # como "a falha não se manifestou". Duas correções:
    #   1. as janelas são ancoradas numa grade de relógio (janela i = [t0+i*W, t0+(i+1)*W]), então são
    #      contíguas por construção: a cobertura deixa de depender da velocidade da coleta;
    #   2. a consulta ao Loki/Prometheus da janela i+1 é agendada numa thread que dorme até a grade
    #      fechar, de modo que a janela i+1 já está sendo consultada quando a i termina de ser montada.
    # Não dá para consultar antes: a janela precisa ter ocorrido. A montagem do pacote e o drain
    # continuam na thread principal e em ordem, porque o Drain é stateful.
    grade_inicio = datetime.datetime.now(datetime.UTC)
    janela_s = args.package_window
    janela_total_s = args.coleta_seg if args.coleta_seg > 0 else args.n_pacotes * janela_s
    n_janelas = max(1, math.ceil(janela_total_s / janela_s))

    def janela_de(i: int) -> tuple[str, str]:
        fim = grade_inicio + datetime.timedelta(seconds=(i + 1) * janela_s)
        ini = fim - datetime.timedelta(seconds=janela_s)
        return ini.isoformat().replace("+00:00", "Z"), fim.isoformat().replace("+00:00", "Z")

    def buscar(i: int):
        """Consulta a janela i, dormindo antes se ela ainda não tiver ocorrido."""
        alvo = grade_inicio + datetime.timedelta(seconds=(i + 1) * janela_s)
        restante = (alvo - datetime.datetime.now(datetime.UTC)).total_seconds()
        if restante > 0:
            time.sleep(restante)
        ws, we = janela_de(i)
        return _collect_signals(system, ws, we)

    pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="sinais")
    futuro: Future | None = None
    try:
        for i in range(n_janelas):
            window_start, window_end = janela_de(i)
            if futuro is None:
                futuro = pool.submit(buscar, i)
            raw = futuro.result()
            futuro = pool.submit(buscar, i + 1) if i + 1 < n_janelas else None
            if raw is None:
                packages_meta.append({"index": i, "error": "falha ao consultar Loki/Prometheus"})
                continue

            raw_collection = RawSignalCollection(
                logs=raw["logs"] or [], metrics=raw["metrics"] or {},
                metrics_by_entity=raw.get("metrics_by_entity") or {},
                k8s_events=raw.get("k8s_events") or None,
            )
            collect_config = build_collect_config(system.pipeline_config, window_start, window_end)
            collect_config.window_seconds = args.package_window

            pkgs = collect_evidence(
                raw_collection, args.system_id, collect_config,
                source_run_id=f"stage3-online-sim:{args.falha}", drain_engine=drain_engine,
                version_context=version_context, cenario=active_cenario,
            )
            for pkg in pkgs:
                validator.validate_and_warn(pkg, context=f"stage3-online-sim system={args.system_id}")
            if not pkgs:
                packages_meta.append({"index": i, "error": "nenhum pacote de evidência gerado"})
                continue

            pkg = pkgs[0]
            pkg_path = os.path.join(args.out_dir, f"pkg-{i + 1}.json")
            with open(pkg_path, "w") as f:
                json.dump(pkg.to_old_dict(), f, ensure_ascii=False, default=str)

            log_entry = _monitor_log(
                args.system_id, run_id=f"stage3-online-sim:{args.falha}", collection_id=args.collection_id,
                window_start=window_start, window_end=window_end, package_window_seconds=args.package_window,
                steps=[{
                    "name": "Simulação (stage3-online)", "status": "completed",
                    "detail": f"stage1_result forçado para anomalous -- falha '{args.falha}' injetada "
                              "deliberadamente pelo orquestrador, sem motor Stage1/2 treinado",
                }],
                evidence_id=pkg.evidence_id, stage1_result="anomalous", primary_hypothesis=hypothesis, confidence=1.0,
                contract_json={"forced_anomalous": True, "falha": args.falha},
                # já reduzido pelo S3 (entidade -> métrica -> pico), como `execute_monitoring` grava; o
                # `raw["metrics_by_entity"]` cru (listas) era descartado e o Stage 3 ficava sem métrica
                metrics_by_entity=pkg.metrics_by_entity,
            )
            saved = repo.save_monitoring_log(log_entry)
            packages_meta.append({
                "index": i, "log_id": saved.log_id, "window_start": window_start, "window_end": window_end,
                "evidence_package_file": pkg_path,
            })
    finally:
        # Sem este shutdown a thread de pré-carga fica esperando a grade e o processo não encerra.
        pool.shutdown(wait=False, cancel_futures=True)

    # Com --coleta-seg o incidente nasce de todos os logs salvos (janela = coleta inteira); sem ele,
    # vale o threshold real de produção (3), igual ao monitoramento.
    n_saved = sum(1 for p in packages_meta if p.get("log_id"))
    threshold = n_saved if args.coleta_seg > 0 and n_saved >= 3 else 3
    incident = repo.maybe_open_incident_for_recent_anomalies(args.system_id, threshold=threshold)
    result: dict = {"falha": args.falha, "hypothesis": hypothesis, "packages": packages_meta}
    if incident is None:
        result["error"] = (
            "incidente não abriu -- confira se já existe um incidente ATIVO com a mesma hipótese "
            f"('{hypothesis}'), ou se algum monitoring_log recente não-anômalo entrou no meio dos 3"
        )
        print(json.dumps(result, ensure_ascii=False))
        return 0

    if args.referencia_collection_id:
        # A referência do cenário (Etapa F) entra no incidente para a localização comparar a janela da
        # falha com ela além da baseline global. `update_incident` só grava o que está na allowlist, então
        # uma coluna nova precisa estar lá -- daí o teste de link abaixo.
        repo.update_incident(args.system_id, incident.incident_id,
                             {"referencia_collection_id": args.referencia_collection_id})
        incident.referencia_collection_id = args.referencia_collection_id

    job = enqueue_stage3_job(repo, incident)
    # Modos d1–d4 escolhidos em stage3_config.modos; com o padrão ["a0"] não enfileira nada
    from src.application.stage3.abordagens.despacho import despachar_modos

    jobs_modos = despachar_modos(repo, incident)
    result["jobs_modos"] = {json.loads(j.payload_json)["modo"] if isinstance(j.payload_json, str)
                            else j.payload_json["modo"]: j.job_id for j in jobs_modos}
    result.update({
        "incident_id": incident.incident_id, "hypothesis": incident.hypothesis,
        "window_start": incident.window_start.isoformat() if incident.window_start else None,
        "window_end": incident.window_end.isoformat() if incident.window_end else None,
        "job_id": job.job_id if job else None,
        "referencia_collection_id": incident.referencia_collection_id or None,
    })
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
