#!/usr/bin/env python3
"""Checagem de saúde do TeaStore entre cenários (M1 do plano de avaliação).

O lote F1-F14 aplicava a falha seguinte sem esperar o rollback da anterior terminar: a F13 (probe do
auth) deixava o auth inalcançável/sem registro durante a F14 nos 3 lotes, e o persistence seguia
lento depois da F3. Esta checagem roda ANTES de cada cenário e só libera quando:

1. todo deployment do namespace tem as réplicas prontas e nenhum pod está terminando/pendente;
2. o registry do TeaStore lista, para cada serviço registrável, exatamente os IPs dos pods prontos
   (instância velha ainda registrada ou pod novo sem registro = o webui chamaria o endereço errado);
3. (M1) as páginas do webui respondem 200 e a persistence tem `generatedb/finished=true`;
4. (M1) a taxa de erro HTTP por serviço está perto da baseline — o persistence respondendo 500 em
   metade das `categories` passou como "saudável" no lote `081432Z` (F1 e F2 saíram 0/2 por isso).

Se não ficar saudável no prazo, reinicia (uma vez) os deployments com problema e espera de novo.
O resultado vai para o JSON de saída e para `avaliacao.json`, para excluir/estratificar casos
contaminados na análise.

Uso: health_gate.py --out health_pre.json [--namespace teastore] [--timeout 300]
"""

import argparse
import datetime
import json
import os
import subprocess
import sys
import time
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from saude_funcional import (  # noqa: E402
    error_rate_problems,
    jaeger_traces,
    probe_generatedb,
    probe_webui,
    server_error_rates,
    summarize,
)

REGISTERED = ("persistence", "auth", "image", "recommender")
REGISTRY_URL = "http://teastore-registry:8080/tools.descartes.teastore.registry/rest/services/tools.descartes.teastore.{}/"
# Traces para a camada de erro (M1): só interessam os serviços do TeaStore, e o Jaeger em si não.
ERROR_CHECK_SERVICES = ("teastore-webui", "teastore-auth", "teastore-image", "teastore-persistence",
                        "teastore-recommender")


def _kubectl(*args: str, timeout: int = 30) -> str:
    return subprocess.run(["kubectl", *args], capture_output=True, text=True, timeout=timeout, check=True).stdout


def _service_of(pod: dict[str, Any]) -> str:
    labels = pod["metadata"].get("labels") or {}
    name = labels.get("run") or labels.get("app.kubernetes.io/name") or pod["metadata"]["name"]
    return str(name).removeprefix("teastore-").split("-")[0]


def _pod_for_ip(namespace: str, ip: str) -> str | None:
    """Nome do pod com este IP; a lista de pods já está no payload do registry, evita outro round-trip."""
    pods = json.loads(_kubectl("get", "pods", "-n", namespace, "-o", "json"))["items"]
    return next((p["metadata"]["name"] for p in pods if p.get("status", {}).get("podIP") == ip), None)


def check_functional(
    namespace: str, ready_ips: dict[str, set[str]], jaeger: str, lookback_sec: int,
    min_spans: int, max_share: float, baseline_rates: dict[str, float] | None,
) -> dict[str, Any]:
    """Camada funcional da M1: o serviço responde certo, não só o pod estar pronto.

    Sondas ativas primeiro (rápidas e cirúrgicas): sem elas, o banco efêmero regenerando ou o webui
    devolvendo 500 só apareceriam como "taxa de erro alta" minutos depois, sem dizer qual serviço.
    A taxa de erro ao vivo vem de traces recentes do Jaeger e é a que pega a contaminação residual
    (F1/F2): erro difuso que nenhuma sonda isolada revela.
    """
    probes: dict[str, dict[str, Any]] = {}
    problems: list[str] = []
    webui_ip = next(iter(ready_ips.get("webui", set())), "")
    if webui_ip:
        webui_pod = _pod_for_ip(namespace, webui_ip)
        if webui_pod:
            probes["webui"] = probe_webui(namespace, webui_pod)
        else:
            problems.append("pod webui pronto não encontrado para as sondas funcionais")
    else:
        problems.append("nenhum pod webui pronto para as sondas funcionais")
    persistence_ip = next(iter(ready_ips.get("persistence", set())), "")
    if persistence_ip:
        persistence_pod = _pod_for_ip(namespace, persistence_ip)
        if persistence_pod:
            probes["generatedb"] = probe_generatedb(namespace, persistence_pod)
        else:
            problems.append("pod persistence pronto não encontrado para a sonda generatedb")
    else:
        problems.append("nenhum pod persistence pronto para a sonda generatedb")
    for name, probe in probes.items():
        problems.extend(f"{name}: {p}" for p in probe.get("problems") or [])

    rates: dict[str, Any] = {}
    if jaeger:
        traces = jaeger_traces(jaeger, ERROR_CHECK_SERVICES, lookback_sec)
        rates = server_error_rates(traces, min_status=500)
        problems.extend(error_rate_problems(
            rates, min_spans=min_spans, max_share=max_share, baseline_rates=baseline_rates,
        ))
    else:
        problems.append("sem endpoint do Jaeger: camada de taxa de erro da M1 não avaliada")
    return summarize(rates, problems, probes, min_spans=min_spans)


def check(namespace: str, *, jaeger: str = "", lookback_sec: int = 120, min_spans: int = 20,
          max_share: float = 0.20, baseline_rates: dict[str, float] | None = None) -> dict[str, Any]:
    problems: list[str] = []
    bad_deployments: set[str] = set()
    deployments = json.loads(_kubectl("get", "deploy", "-n", namespace, "-o", "json"))["items"]
    for dep in deployments:
        name = dep["metadata"]["name"]
        want = int(dep["spec"].get("replicas") or 0)
        ready = int((dep.get("status") or {}).get("readyReplicas") or 0)
        updated = int((dep.get("status") or {}).get("updatedReplicas") or 0)
        if ready < want or updated < want:
            problems.append(f"{name}: {ready}/{want} prontas ({updated} atualizadas)")
            bad_deployments.add(name)

    pods = json.loads(_kubectl("get", "pods", "-n", namespace, "-o", "json"))["items"]
    ready_ips: dict[str, set[str]] = {}
    webui_pod = None
    for pod in pods:
        name = pod["metadata"]["name"]
        if "stresser" in name:
            continue
        status = pod.get("status") or {}
        conditions = {c["type"]: c["status"] for c in status.get("conditions") or []}
        if pod["metadata"].get("deletionTimestamp"):
            problems.append(f"{name}: terminando")
            continue
        if status.get("phase") != "Running" or conditions.get("Ready") != "True":
            problems.append(f"{name}: {status.get('phase')} ready={conditions.get('Ready')}")
            continue
        service = _service_of(pod)
        ready_ips.setdefault(service, set()).add(str(status.get("podIP")))
        if service == "webui":
            webui_pod = name

    registry: dict[str, list[str]] = {}
    if webui_pod is None:
        problems.append("nenhum pod webui pronto para consultar o registry")
    else:
        for service in REGISTERED:
            try:
                raw = _kubectl("exec", "-n", namespace, webui_pod, "-c", "teastore-webui", "--",
                               "wget", "-qO-", "--timeout=5", REGISTRY_URL.format(service), timeout=20)
                listed = sorted(str(x).split(":")[0] for x in json.loads(raw or "[]"))
            except Exception as exc:  # registry fora: o próprio registry é problema
                problems.append(f"registry não respondeu para {service}: {exc}")
                bad_deployments.add("teastore-registry")
                continue
            registry[service] = listed
            expected = sorted(ready_ips.get(service, set()))
            if listed != expected:
                problems.append(f"registry lista {service}={listed}, pods prontos={expected}")
                bad_deployments.add(f"teastore-{service}")
    functional = check_functional(namespace, ready_ips, jaeger, lookback_sec, min_spans, max_share,
                                 baseline_rates)
    return {
        "ok": not problems and functional["ok"],
        "problems": [*problems, *functional["problems"]],
        "bad_deployments": sorted(bad_deployments),
        "registry": registry, "ready_ips": {k: sorted(v) for k, v in ready_ips.items()},
        "saude_funcional": functional,
        "checked_at": datetime.datetime.now(datetime.UTC).isoformat(),
    }


def wait_healthy(namespace: str, timeout: int, interval: int = 10, **kwargs: Any) -> tuple[dict[str, Any], int]:
    start = time.monotonic()
    attempts = 0
    while True:
        attempts += 1
        try:
            result = check(namespace, **kwargs)
        except Exception as exc:
            result = {"ok": False, "problems": [f"checagem falhou: {exc}"], "bad_deployments": []}
        if result["ok"] or time.monotonic() - start >= timeout:
            return result, attempts
        time.sleep(interval)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", required=True)
    parser.add_argument("--namespace", default="teastore")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--no-remediate", action="store_true")
    parser.add_argument("--jaeger", default=os.environ.get("JAEGER_QUERY_URL", ""),
                        help="endpoint do Jaeger para a camada de taxa de erro da M1")
    parser.add_argument("--error-lookback", type=int, default=120,
                        help="segundos de traces para medir a taxa de erro antes do cenário")
    parser.add_argument("--error-min-spans", type=int, default=20)
    parser.add_argument("--error-max-share", type=float, default=0.20)
    parser.add_argument("--baseline-rates", default="",
                        help="JSON de taxas de erro por serviço para o corte relativo (2x)")
    args = parser.parse_args()

    baseline_rates: dict[str, float] | None = None
    if args.baseline_rates:
        try:
            with open(args.baseline_rates) as f:
                baseline_rates = {k: float(v) for k, v in (json.load(f).get("error_rates") or {}).items()}
        except (OSError, ValueError, AttributeError, json.JSONDecodeError) as exc:
            print(f"    AVISO: --baseline-rates ignorado ({exc}); corte só absoluto.", file=sys.stderr)

    kwargs = {"jaeger": args.jaeger, "lookback_sec": args.error_lookback, "min_spans": args.error_min_spans,
              "max_share": args.error_max_share, "baseline_rates": baseline_rates}
    t0 = time.monotonic()
    result, attempts = wait_healthy(args.namespace, args.timeout, **kwargs)
    remediation: list[str] = []
    if not result["ok"] and not args.no_remediate and result.get("bad_deployments"):
        for dep in result["bad_deployments"]:
            try:
                _kubectl("rollout", "restart", f"deployment/{dep}", "-n", args.namespace)
                remediation.append(dep)
            except Exception as exc:
                remediation.append(f"{dep}: falhou ({exc})")
        result, more = wait_healthy(args.namespace, args.timeout, **kwargs)
        attempts += more
    result.update({"attempts": attempts, "seconds": round(time.monotonic() - t0, 1), "remediation": remediation,
                   "contaminado": not result["ok"]})
    with open(args.out, "w") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    functional = result.get("saude_funcional") or {}
    state = "OK" if result["ok"] else "NÃO SAUDÁVEL"
    if result["ok"] and functional.get("inconclusivo"):
        state = "OK (taxa de erro inconclusiva)"
    print(f"    health gate: {state} em {result['seconds']}s"
          + (f" (reiniciados: {', '.join(remediation)})" if remediation else "")
          + ("" if result["ok"] else f" -- {'; '.join(result['problems'][:4])}"))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
