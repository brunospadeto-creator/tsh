#!/usr/bin/env python3
"""Pacotes de evidência contínuos fora da coleta do incidente.

O `simular_incidente.py` só grava pacotes do período estável sob falha. A avaliação do Stage 3 isolado
precisa também dos instantes **normais** (janela de referência) e da **transição** (implantação → estável),
para a a0 ter negativos e para medir se o aquecimento importa. Este coletor roda em segundo plano, ao lado do
cenário, e grava `pkg-<fim da janela>.json` a cada `--package-window` s, com o **mesmo código** de produção
(`_collect_signals` + `collect_evidence`, grade de relógio, Drain da baseline). Diferente do simulador:
não grava `monitoring_logs`, não força anomalia, não abre incidente — não muda nada no sistema.

Para quando recebe SIGTERM (o harness o encerra logo antes do `simular_incidente.py`) ou após `--max-seg`.

Uso (PYTHONPATH na raiz do repo, Postgres acessível como no simulador):
    coletar_pacotes_continuos.py --system-id ID --collection-id ID --package-window 3 --out-dir DIR
"""

import argparse
import datetime
import json
import os
import signal
import time
from concurrent.futures import Future, ThreadPoolExecutor

PARAR = False


def _parar(_sig, _frame) -> None:
    global PARAR
    PARAR = True


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--system-id", required=True)
    ap.add_argument("--collection-id", required=True)
    ap.add_argument("--package-window", type=int, required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--max-seg", type=int, default=3600, help="teto de segurança")
    args = ap.parse_args()
    signal.signal(signal.SIGTERM, _parar)
    signal.signal(signal.SIGINT, _parar)

    from src.collector.providers.db_provider import DBVersionProvider
    from src.infra.settings import get_settings
    from src.monitor.tasks import _collect_signals, _load_baseline_drain_engine
    from src.pipeline.pipeline import build_collect_config, collect_evidence
    from src.schemas.intermediate import RawSignalCollection
    from src.store.repository import Repository

    os.makedirs(args.out_dir, exist_ok=True)
    repo = Repository(get_settings().db_url)
    system = repo.get_system(args.system_id)
    if system is None:
        print(json.dumps({"error": f"system not found: {args.system_id}"}))
        return 1
    drain_engine, _ = _load_baseline_drain_engine(repo, args.system_id, args.collection_id)
    cenario = getattr(system, "active_version_cenario", None) or "baseline"
    version_context = DBVersionProvider(repo).get(args.system_id, cenario)

    janela_s = args.package_window
    inicio = datetime.datetime.now(datetime.UTC)
    n_max = max(1, args.max_seg // janela_s)

    def janela_de(i: int) -> tuple[datetime.datetime, datetime.datetime]:
        fim = inicio + datetime.timedelta(seconds=(i + 1) * janela_s)
        return fim - datetime.timedelta(seconds=janela_s), fim

    def buscar(i: int):
        ini, fim = janela_de(i)
        while not PARAR and datetime.datetime.now(datetime.UTC) < fim:
            time.sleep(min(0.5, (fim - datetime.datetime.now(datetime.UTC)).total_seconds() + 0.01))
        if PARAR:
            return None
        return _collect_signals(system, ini.isoformat().replace("+00:00", "Z"), fim.isoformat().replace("+00:00", "Z"))

    gravados, erros = 0, 0
    pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="sinais")
    futuro: Future | None = pool.submit(buscar, 0)
    try:
        for i in range(n_max):
            raw = futuro.result() if futuro else None
            if PARAR:
                break
            futuro = pool.submit(buscar, i + 1) if i + 1 < n_max else None
            ini, fim = janela_de(i)
            if raw is None:
                erros += 1
                continue
            ws, we = ini.isoformat().replace("+00:00", "Z"), fim.isoformat().replace("+00:00", "Z")
            cfg = build_collect_config(system.pipeline_config, ws, we)
            cfg.window_seconds = janela_s
            pkgs = collect_evidence(
                RawSignalCollection(logs=raw["logs"] or [], metrics=raw["metrics"] or {},
                                    metrics_by_entity=raw.get("metrics_by_entity") or {},
                                    k8s_events=raw.get("k8s_events") or None),
                args.system_id, cfg, source_run_id="stage3-pacotes-continuos", drain_engine=drain_engine,
                version_context=version_context, cenario=cenario,
            )
            if not pkgs:
                erros += 1
                continue
            nome = fim.strftime("pkg-%Y%m%dT%H%M%S") + f"{fim.microsecond // 1000:03d}Z.json"
            destino = os.path.join(args.out_dir, nome)
            with open(destino + ".tmp", "w") as f:  # SIGTERM no meio da escrita não deixa pacote pela metade
                json.dump(pkgs[0].to_old_dict(), f, ensure_ascii=False, default=str)
            os.replace(destino + ".tmp", destino)
            gravados += 1
    finally:
        pool.shutdown(wait=False, cancel_futures=True)
    print(json.dumps({"gravados": gravados, "erros": erros, "inicio": inicio.isoformat()}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
