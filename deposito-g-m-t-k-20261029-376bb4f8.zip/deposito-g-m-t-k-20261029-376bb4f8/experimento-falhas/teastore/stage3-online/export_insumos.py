#!/usr/bin/env python3
"""Exporta do Postgres os insumos do Stage 3 que não estão nos arquivos da rodada.

Com isso uma rodada salva em `resultados/<RUN_ID>/` pode ser reexecutada offline (`replay/replay.py`)
sem cluster, sem stresser e sem reinjetar a falha.

Modos:
  baseline   <collection_id> <out.json>  -- linha completa de `collection_baselines` (PetriNets por
             endpoint, `span_stats`, `service_graph`, `metric_stats`) + `stage3_config` do sistema.
  incidente  <incident_id>   <out.json>  -- os `monitoring_logs` do incidente e os `series_packages`
             anteriores (série temporal de métrica usada pelo Stage 3).

Uso: PYTHONPATH=<repo> VERITAS_DB_URL=... export_insumos.py <modo> <id> <out.json> [--system-id ID]
"""

import argparse
import datetime
import json
import sys
from typing import Any


def _iso(value: Any) -> Any:
    return value.isoformat() if isinstance(value, datetime.datetime) else value


def _row(obj: Any, columns: list[str]) -> dict[str, Any]:
    return {c: _iso(getattr(obj, c, None)) for c in columns}


LOG_COLUMNS = [
    "log_id", "system_id", "run_id", "collection_id", "evidence_id", "contract_id", "collected_at",
    "window_start", "window_end", "package_window_seconds", "stage1_result", "primary_hypothesis",
    "confidence", "contract_json", "metrics_by_entity_json",
]


def export_baseline(repo: Any, collection_id: str, system_id: str | None) -> dict[str, Any]:
    row = repo.get_collection_baseline(collection_id)
    if row is None:
        raise SystemExit(f"baseline da coleção {collection_id} não encontrada")
    out = _row(row, [
        "baseline_id", "collection_id", "system_id", "status", "n_samples", "computed_at", "trace_status",
        "metric_stats", "process_models", "span_stats", "service_graph", "service_stats",
    ])
    system = repo.get_system(system_id or row.system_id)
    out["system"] = {
        "system_id": system.system_id, "name": system.name, "k8s_namespace": getattr(system, "k8s_namespace", None),
        "stage3_config": dict(system.stage3_config or {}),
    } if system else None
    out["exported_at"] = datetime.datetime.now(datetime.UTC).isoformat()
    return out


def export_incident(repo: Any, incident_id: str, system_id: str) -> dict[str, Any]:
    incident = repo.get_incident(system_id, incident_id)
    if incident is None:
        raise SystemExit(f"incidente {incident_id} não encontrado")
    logs = repo.get_monitoring_logs(json.loads(incident.log_ids_json or "[]"))
    system = repo.get_system(system_id)
    series = int(dict(system.stage3_config or {}).get("series_packages", 20)) if system else 20
    previous = repo.list_monitoring_logs_before(
        system_id, logs[0].run_id if logs else None, incident.window_start, series,
    )
    return {
        "incident": _row(incident, [
            "incident_id", "system_id", "profile_id", "hypothesis", "status", "window_start", "window_end",
            "created_at", "log_ids_json",
        ]),
        "logs": [_row(log, LOG_COLUMNS) for log in logs],
        "previous_logs": [_row(log, LOG_COLUMNS) for log in previous],
        "exported_at": datetime.datetime.now(datetime.UTC).isoformat(),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("mode", choices=["baseline", "incidente"])
    parser.add_argument("id")
    parser.add_argument("out")
    parser.add_argument("--system-id", default="f530cda3-e337-4c63-a7dc-d57c8722afef")
    args = parser.parse_args()

    from src.infra.settings import get_settings
    from src.store.repository import Repository

    repo = Repository(get_settings().db_url)
    data = (export_baseline(repo, args.id, args.system_id) if args.mode == "baseline"
            else export_incident(repo, args.id, args.system_id))
    with open(args.out, "w") as f:
        json.dump(data, f, ensure_ascii=False, default=str)
    print(f"    {args.mode} {args.id} exportado em {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
