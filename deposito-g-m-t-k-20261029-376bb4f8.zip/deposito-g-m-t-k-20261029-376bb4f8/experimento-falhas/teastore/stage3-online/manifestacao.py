"""M2 do plano -- checagem de manifestação da falha (o lote 081432Z tem falhas que não se manifestam).

O Stage 3 pressupõe que a falha injetada produziu sinal. No lote `081432Z` isso não vale: F4, F8, F10 e
F14 entram na avaliação e não deixam sinal nenhum em erro, latência, métrica, log ou evento de K8s --
ainda assim ocupam lugar no denominador principal e derrubam a taxa de acerto.

Este módulo classifica cada caso em três faixas antes do Stage 3:

- `manifesta`      -- pelo menos um sintoma acima da referência da baseline no serviço esperado;
- `silenciosa`     -- todos os sinais foram avaliáveis e nenhum passou do limiar;
- `indeterminado`  -- não dá para dizer (faltou traces, pacotes ou baseline para o serviço).

A comparação é sempre contra a **baseline** do mesmo sistema, e o objeto de interesse é o serviço
esperado da falha (`expected_service`), não o serviço que o Stage 3 acabou escolhendo: se o sintoma
está em outro serviço, a checagem diria que o caso se manifestou mesmo assim -- o que o Stage 3
precisa corrigir por outro caminho (M3).
"""

from __future__ import annotations

import datetime
import json
import os
import re
import statistics
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any

from saude_funcional import _tags, server_error_rates

MANIFESTA = "manifesta"
LATENCIA_MIN_DIF_MS = 1.0
SILENCIOSA = "silenciosa"
INDETERMINADO = "indeterminado"


@dataclass
class Sinal:
    nome: str
    detectado: bool
    avaliavel: bool
    detalhe: str
    valor: float | None = None
    referencia: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _carregar(caminho: str) -> Any:
    try:
        with open(caminho) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _pacotes(case_dir: str) -> list[str]:
    pasta = os.path.join(case_dir, "evidence_packages")
    if not os.path.isdir(pasta):
        return []
    return [os.path.join(pasta, n) for n in sorted(os.listdir(pasta)) if n.startswith("pkg-")]


def _servico_da_entidade(nome: str, conhecidos: Sequence[str]) -> str | None:
    """`teastore-auth-54f86cf576-d4cn4` -> `teastore-auth`, casando com os serviços da baseline."""
    for servico in sorted(conhecidos, key=len, reverse=True):
        if nome == servico or nome.startswith(f"{servico}-"):
            return servico
    return None


def _dump_da_janela(case_dir: str) -> Mapping[str, Any]:
    """Traces da janela de coleta (`traces.json`: depois do aquecimento, a mesma do incidente).

    Não usa `traces_full_scenario.json`: ele começa antes da injeção e inclui o pod recriado pela própria
    falha respondendo com a JVM fria (p95 do webui de 38 s na F4) -- sintoma da injeção, não da falha.
    Janela vazia é resultado, não ausência de dado: na F5 o webui travado não responde nada.
    """
    for nome in ("traces.json", "traces_stage3_window.json"):
        bruto = _carregar(os.path.join(case_dir, nome))
        if bruto and bruto.get("window_start"):
            return bruto
    return {}


def _janela(case_dir: str) -> Mapping[str, Any]:
    return _dump_da_janela(case_dir).get("traces") or {}


def sinal_erro_http(servico: str, traces: Mapping[str, Any], *, min_spans: int, max_share: float) -> Sinal:
    rates = server_error_rates(traces, min_spans=min_spans)
    rate = rates.get(servico)
    if rate is None:
        return Sinal("erro_http", False, False, f"menos de {min_spans} spans de servidor com status no serviço")
    detectado = rate.share >= max_share
    return Sinal(
        "erro_http", detectado, True,
        f"{rate.n_error}/{rate.n_status} respostas >= {rate.min_status} ({rate.share:.0%})",
        valor=rate.share, referencia=max_share,
    )


def _curto(servico: str) -> str:
    """`teastore-persistence` -> `persistence`: o prefixo das atividades em `span_stats`."""
    return servico.split("-", 1)[1] if servico.startswith("teastore-") else servico


def _servico_do_span(span: Mapping[str, Any], processos: Mapping[str, Any]) -> str:
    return str((processos.get(span.get("processID")) or {}).get("serviceName") or "")


def _tem_pai_no_trace(span: Mapping[str, Any], ids: set[str]) -> bool:
    pais = [r for r in span.get("references") or [] if r.get("refType") == "CHILD_OF"]
    return any(str(r.get("spanID")) in ids for r in pais)


def _minutos(case_dir: str) -> float | None:
    """Duração da janela de coleta (window_start/window_end gravados pelo dump_traces.py)."""
    bruto = _dump_da_janela(case_dir)
    try:
        ini = datetime.datetime.fromisoformat(str(bruto["window_start"]))
        fim = datetime.datetime.fromisoformat(str(bruto["window_end"]))
    except (KeyError, ValueError):
        return None
    minutos = (fim - ini).total_seconds() / 60.0
    return minutos if minutos > 0 else None


def sinal_latencia(
    servico: str, traces: Mapping[str, Any], span_stats: Mapping[str, Any], *, fator: float
) -> Sinal:
    """p95 de cada operação do serviço esperado contra o p95 da mesma atividade na baseline.

    As atividades de `span_stats` são `"<serviço curto>: <operationName>"`, agrupadas por endpoint de
    entrada; a mesma atividade pode aparecer sob vários endpoints, e a referência é o maior p95 entre eles
    (conservador: só dispara o que passa do pior caso normal).
    """
    prefixo = f"{_curto(servico)}: "
    chaves: dict[str, float] = {}
    for filhos in span_stats.values():
        for atividade, stats in (filhos or {}).items():
            if str(atividade).startswith(prefixo) and isinstance(stats, list) and len(stats) >= 5:
                chaves[str(atividade)] = max(chaves.get(str(atividade), 0.0), float(stats[4]))
    if not chaves:
        return Sinal("latencia_p95", False, False, "baseline sem atividades do serviço esperado")

    por_operacao: dict[str, list[float]] = defaultdict(list)
    for trace in traces.values():
        processos = trace.get("processes") or {}
        for span in trace.get("spans") or []:
            if _servico_do_span(span, processos) != servico:
                continue
            rotulo = f"{prefixo}{span.get('operationName')}"
            if rotulo in chaves and span.get("duration"):
                por_operacao[rotulo].append(span["duration"] / 1000.0)
    por_operacao = {op: v for op, v in por_operacao.items() if len(v) >= 5}
    if not por_operacao:
        return Sinal("latencia_p95", False, False, "menos de 5 spans por operação do serviço esperado na janela")

    pior: tuple[float, str] | None = None
    for operacao, amostras in por_operacao.items():
        p95 = statistics.quantiles(amostras, n=20)[-1] if len(amostras) >= 2 else max(amostras)
        # Piso absoluto: operações de microssegundos (sendRedirect 0,1 ms × 0,0 ms) davam razões enormes.
        if p95 - chaves[operacao] < LATENCIA_MIN_DIF_MS:
            razao = min(1.0, p95 / chaves[operacao]) if chaves[operacao] else 0.0
        else:
            razao = p95 / chaves[operacao] if chaves[operacao] else float("inf")
        if pior is None or razao > pior[0]:
            pior = (razao, f"{operacao} p95={p95:.1f}ms vs {chaves[operacao]:.1f}ms ({razao:.1f}x)")
    assert pior is not None
    detectado = pior[0] >= fator
    return Sinal("latencia_p95", detectado, True, pior[1], valor=round(pior[0], 2), referencia=fator)


def sinal_metrica(
    servico: str, pacotes: Sequence[Mapping[str, Any]], metric_stats: Mapping[str, Any], *, fator: float
) -> Sinal:
    """Métrica do serviço esperado mais deslocada contra a baseline.

    O corte é **acima do máximo da baseline**, não acima do p95. Medido nos 13 casos do lote `081432Z`, os
    dois cortes divergem em exatamente um: razão-sobre-p95 dispara na F5 com `cpu_usage` a 2,5x o p95
    (mediana 1,001 contra p95 0,395), mas a falha injetada na F5 é heap JVM (`-Xms32m -Xmx32m`) — o
    `cpu_usage` é efeito colateral de GC, não o sintoma. No corte sobre o máximo a métrica fica em 1,8x e a
    F5 continua sem sinal. "Esse valor nunca aconteceu na baseline" é a pergunta que não gera falso
    positivo, e é a que o leitor do lote consegue auditar.

    `fator` fica como tolerância sobre o máximo: uma métrica tem de passar o teto histórico por uma
    margem, senão jitter de amostragem volta a entrar.
    """
    conhecidos = list(metric_stats)
    amostras: dict[str, list[float]] = defaultdict(list)
    for pacote in pacotes:
        for entidade, metricas in (pacote.get("metrics_by_entity") or {}).items():
            alvo = _servico_da_entidade(str(entidade), conhecidos)
            if alvo != servico:
                continue
            for metrica, valor in (metricas or {}).items():
                if isinstance(valor, (int, float)):
                    amostras[str(metrica)].append(float(valor))
    if not amostras:
        return Sinal("metrica_deslocada", False, False, "pacotes sem métricas do serviço esperado")

    base_servico = metric_stats.get(servico) or {}
    piores: list[tuple[float, str]] = []
    ausentes: list[str] = []
    for metrica, valores in amostras.items():
        stats = base_servico.get(metrica)
        if not (isinstance(stats, list) and len(stats) >= 5):
            # A métrica não é coletada para este serviço -- a F12 é exatamente isso: `cpu_throttled`
            # só aparece para o teastore-db, e o webui sob `limits.cpu:150m` não tem a métrica em nenhum
            # pacote nem na baseline. Não dá para culpar nem absolver a partir de um dado ausente.
            ausentes.append(metrica)
            continue
        max_base = float(stats[3])
        mediana = statistics.median(valores)
        # Métrica ausente da baseline que passou a existir: com max=0 o ratio daria 0 e sumiria.
        if max_base <= 0:
            razao = float("inf") if mediana > 0 else 0.0
        else:
            razao = mediana / max_base
        piores.append((razao, f"{metrica} mediana={mediana:.1f} vs max={max_base:.1f} da baseline "
                              f"({'novo' if razao == float('inf') else f'{razao:.1f}x'})"))
    if not piores:
        return Sinal("metrica_deslocada", False, False,
                     f"nenhuma métrica do serviço esperado é coletada "
                     f"(ausentes: {', '.join(sorted(ausentes)[:4])})")
    pior = max(piores, key=lambda par: par[0])
    detectado = pior[0] >= fator
    detalhe = pior[1]
    if ausentes:
        detalhe += f" [sem coleta para este serviço: {', '.join(sorted(ausentes)[:4])}]"
    return Sinal("metrica_deslocada", detectado, True, detalhe,
                 valor=None if pior[0] == float("inf") else round(pior[0], 2), referencia=fator)


def sinal_eventos_k8s(servico: str, pacotes: Sequence[Mapping[str, Any]]) -> Sinal:
    """Eventos de infraestrutura que mencionam o serviço esperado (Restart/OOM/BackOff/falha de probe)."""
    eventos: list[Any] = []
    for pacote in pacotes:
        bloco = pacote.get("k8s_infrastructure_events")
        itens = bloco if isinstance(bloco, list) else ((bloco or {}).get("items") or [])
        eventos.extend(evento for evento in itens if servico in json.dumps(evento, default=str))
    return Sinal(
        "eventos_k8s", bool(eventos), True,
        (f"{len(eventos)} evento(s) de infraestrutura no serviço esperado" if eventos
         else "nenhum evento de infraestrutura"),
        valor=float(len(eventos)),
    )


# Sintomas de "sumiu": a falha que derruba um serviço não produz MAIS erro ou latência nele -- produz
# menos tráfego. Sem estes sinais, F5/F12 (webui travado), F6 (persistence inalcançável) e F9 (registry)
# saíam como silenciosas no lote `081432Z`, sendo os casos de sinal mais forte. Os limiares são os mesmos
# dos votos do Stage 3 (`Stage3Config`), repetidos aqui porque este script roda fora do `src`.
ENTRADA = "teastore-webui"
INANICAO_MAX_POR_MIN = 15.0          # starve_min_roots_per_min
AUSENCIA_MAX_PRESENCA = 0.5          # missing_min_trace_share: ausente em >= 50% dos traces
AUSENCIA_MIN_TRACES = 20
REGISTRY = "teastore-registry"
DESCOBERTA_ROTA = re.compile(r"/services/([^/?]+)")   # discovery_route_regex
DESCOBERTA_MIN_CONSULTAS = 10        # discovery_min_lookups
DESCOBERTA_BALDE_S = 30              # discovery_bucket_sec
DESCOBERTA_MIN_BALDES = 0.5          # discovery_min_bucket_share


def _raizes_da_entrada(traces: Mapping[str, Any]) -> list[tuple[str, set[str]]]:
    """(endpoint, serviços presentes) de cada trace com raiz `server` na entrada."""
    saida = []
    for trace in traces.values():
        processos = trace.get("processes") or {}
        spans = trace.get("spans") or []
        ids = {str(s.get("spanID")) for s in spans}
        endpoint = None
        for span in spans:
            if (_servico_do_span(span, processos) == ENTRADA and not _tem_pai_no_trace(span, ids)
                    and str(_tags(span).get("span.kind") or "") == "server"):
                endpoint = str(span.get("operationName"))
                break
        if endpoint:
            saida.append((endpoint, {_servico_do_span(s, processos) for s in spans}))
    return saida


def sinal_inanicao(servico: str, traces: Mapping[str, Any], minutos: float | None) -> Sinal:
    """A entrada quase não recebe requisições: o próprio webui travou (voto `inanicao`)."""
    if servico != ENTRADA:
        return Sinal("inanicao_entrada", False, False, "só se aplica ao serviço de entrada")
    if not minutos:
        return Sinal("inanicao_entrada", False, False, "janela dos traces desconhecida")
    taxa = len(_raizes_da_entrada(traces)) / minutos
    return Sinal("inanicao_entrada", taxa < INANICAO_MAX_POR_MIN, True,
                 f"{taxa:.1f} requisições/min na entrada (limiar {INANICAO_MAX_POR_MIN:.0f}/min)",
                 valor=round(taxa, 2), referencia=INANICAO_MAX_POR_MIN)


def sinal_ausencia(servico: str, traces: Mapping[str, Any], span_stats: Mapping[str, Any]) -> Sinal:
    """O serviço some dos traces dos endpoints que, na baseline, sempre o chamam (voto `chamada_ausente`)."""
    if servico == ENTRADA:
        return Sinal("ausencia", False, False, "a entrada não pode faltar do próprio trace")
    prefixo = f"{_curto(servico)}: "
    endpoints = {ep for ep, filhos in span_stats.items() if any(str(a).startswith(prefixo) for a in filhos or {})}
    if not endpoints:
        return Sinal("ausencia", False, False, "baseline sem endpoint que chame o serviço esperado")
    casos = [presentes for ep, presentes in _raizes_da_entrada(traces) if ep in endpoints]
    if len(casos) < AUSENCIA_MIN_TRACES:
        return Sinal("ausencia", False, False,
                     f"{len(casos)} traces dos endpoints que chamam o serviço (mínimo {AUSENCIA_MIN_TRACES})")
    presenca = sum(servico in p for p in casos) / len(casos)
    return Sinal("ausencia", presenca < AUSENCIA_MAX_PRESENCA, True,
                 f"presente em {presenca:.0%} de {len(casos)} traces dos endpoints que o chamam na baseline",
                 valor=round(presenca, 3), referencia=AUSENCIA_MAX_PRESENCA)


def sinal_descoberta(servico: str, traces: Mapping[str, Any], minutos: float | None) -> Sinal:
    """Consultas sustentadas ao registry pelo serviço esperado: ele está inalcançável (voto `descoberta`).

    Para o próprio registry o sintoma é o inverso -- todo mundo pergunta por todo mundo, sem convergir --,
    então conta qualquer alvo.
    """
    if not minutos:
        return Sinal("descoberta", False, False, "janela dos traces desconhecida")
    alvo = _curto(servico)
    inicio: int | None = None
    horarios: list[int] = []
    for trace in traces.values():
        processos = trace.get("processes") or {}
        for span in trace.get("spans") or []:
            if _servico_do_span(span, processos) != REGISTRY:
                continue
            tags = _tags(span)
            caminho = str(tags.get("url.path") or tags.get("http.target") or tags.get("http.url") or "")
            m = DESCOBERTA_ROTA.search(caminho)
            if not m or (servico != REGISTRY and alvo not in m.group(1)):
                continue
            t = int(span.get("startTime") or 0)
            horarios.append(t)
            inicio = t if inicio is None else min(inicio, t)
    n_baldes = max(1, int(minutos * 60 // DESCOBERTA_BALDE_S))
    if len(horarios) < DESCOBERTA_MIN_CONSULTAS or inicio is None:
        return Sinal("descoberta", False, True, f"{len(horarios)} consultas ao registry pelo serviço",
                     valor=0.0, referencia=DESCOBERTA_MIN_BALDES)
    baldes = {min(int((t - inicio) / 1e6 // DESCOBERTA_BALDE_S), n_baldes - 1) for t in horarios}
    fracao = len(baldes) / n_baldes
    return Sinal("descoberta", fracao >= DESCOBERTA_MIN_BALDES, True,
                 f"{len(horarios)} consultas em {len(baldes)}/{n_baldes} intervalos de {DESCOBERTA_BALDE_S}s",
                 valor=round(fracao, 3), referencia=DESCOBERTA_MIN_BALDES)


def classificar_por_anomalias(case_dir: str, expected_service: str, baseline: Mapping[str, Any]) -> dict[str, Any]:
    """M8: "manifesta" = o detector de anomalias do Stage 3 (localizacao.py) acha anomalia no serviço injetado.

    Mesmo critério que a localização usa -- um só "anômalo" no projeto --, com a configuração do sistema
    gravada na baseline. Janela = `traces.json` (coleta, depois do aquecimento). Anomalia explicada por
    outro serviço conta: a pergunta aqui é se a falha deixou sintoma, não quem o Stage 3 culparia.
    """
    import sys as _sys

    raiz = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
    if raiz not in _sys.path:
        _sys.path.insert(0, raiz)
    from src.application.stage3.config import resolve_config
    from src.application.stage3.localizacao import localizar
    from src.application.stage3.service_stats import extract, summarize_extract

    cfg = resolve_config({**((baseline.get("system") or {}).get("stage3_config") or {}),
                          "localization_mode": "anomalias"})
    dump = _dump_da_janela(case_dir)
    minutos = _minutos(case_dir)
    pacotes = [p for p in (_carregar(c) for c in _pacotes(case_dir)) if p]
    observadas: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    eventos: list[Any] = []
    for pacote in pacotes:
        for entidade, metricas in (pacote.get("metrics_by_entity") or {}).items():
            servico = _servico_da_entidade(str(entidade), list(baseline.get("metric_stats") or {})) or str(entidade)
            for nome, valor in (metricas or {}).items():
                if isinstance(valor, (int, float)):
                    observadas[servico][nome].append(float(valor))
        bloco = pacote.get("k8s_infrastructure_events")
        eventos.extend(bloco if isinstance(bloco, list) else ((bloco or {}).get("items") or []))
    mediana = {e: {m: statistics.median(v) for m, v in ms.items()} for e, ms in observadas.items()}
    janela_stats = None
    if dump and minutos:
        inicio = datetime.datetime.fromisoformat(str(dump["window_start"]).replace("Z", "+00:00"))
        fim = datetime.datetime.fromisoformat(str(dump["window_end"]).replace("Z", "+00:00"))
        janela_stats = summarize_extract(extract(
            dump.get("traces") or {}, [(inicio, fim)], entry_services=list(cfg.entry_services),
            entry_operation_regex=cfg.entry_operation_regex, discovery_service=cfg.discovery_service,
            discovery_route_regex=cfg.discovery_route_regex, known_services=list(baseline.get("metric_stats") or {}),
            bucket_seconds=float(cfg.discovery_bucket_sec),
        ))
    _, anomalias, _ = localizar(
        base_stats=baseline.get("service_stats"), janela_stats=janela_stats,
        metric_stats=baseline.get("metric_stats") or {}, observadas=mediana, eventos_k8s=eventos,
        ranking_estrutural=[], cfg=cfg,
    )
    do_servico = [a for a in anomalias if a.servico == expected_service]
    trafego = bool(janela_stats and (janela_stats.get("n_buckets") or 0))
    classificacao = MANIFESTA if do_servico else (SILENCIOSA if trafego else INDETERMINADO)
    sinais = [{"nome": a.tipo, "detectado": True, "avaliavel": True, "detalhe": a.detalhe,
               "valor": round(a.escore, 2), "referencia": cfg.anomaly_k, "explicada_por": a.explicada_por}
              for a in sorted(do_servico, key=lambda a: -abs(a.escore))]
    return {
        "servico_esperado": expected_service, "classificacao": classificacao, "criterio": "anomalias-m8",
        "n_sinais": len(sinais), "n_sinais_positivos": len(sinais), "sinais": sinais,
        "anomalias_outros_servicos": sorted({f"{a.servico}:{a.tipo}" for a in anomalias
                                             if a.servico != expected_service}),
        "n_pacotes": len(pacotes), "n_traces": len(dump.get("traces") or {}) if dump else 0,
    }


def classificar_manifestacao(
    case_dir: str,
    expected_service: str,
    baseline: Mapping[str, Any],
    *,
    min_spans: int = 20,
    max_share: float = 0.20,
    fator_latencia: float = 2.0,
    fator_metrica: float = 2.0,
) -> dict[str, Any]:
    if baseline.get("service_stats"):
        return classificar_por_anomalias(case_dir, expected_service, baseline)
    traces = _janela(case_dir)
    minutos = _minutos(case_dir)
    brutos = _pacotes(case_dir)
    pacotes = [p for p in (_carregar(c) for c in brutos) if p]
    span_stats = baseline.get("span_stats") or {}
    sinais = [
        sinal_erro_http(expected_service, traces, min_spans=min_spans, max_share=max_share),
        sinal_latencia(expected_service, traces, span_stats, fator=fator_latencia),
        sinal_metrica(expected_service, pacotes, baseline.get("metric_stats") or {}, fator=fator_metrica),
        sinal_eventos_k8s(expected_service, pacotes),
        sinal_inanicao(expected_service, traces, minutos),
        sinal_ausencia(expected_service, traces, span_stats),
        sinal_descoberta(expected_service, traces, minutos),
    ]
    positivos = [s for s in sinais if s.detectado]
    # "Silenciosa" exige ter olhado o tráfego do serviço: sem spans suficientes dele (erro_http) nem dos
    # endpoints que o chamam (ausencia), a falta de sinal é falta de amostra, não ausência de sintoma.
    trafego_avaliado = any(s.avaliavel for s in sinais if s.nome in ("erro_http", "ausencia", "inanicao_entrada"))
    if positivos:
        classificacao = MANIFESTA
    elif trafego_avaliado:
        classificacao = SILENCIOSA
    else:
        classificacao = INDETERMINADO
    return {
        "servico_esperado": expected_service,
        "classificacao": classificacao,
        "n_sinais": len(sinais),
        "n_sinais_positivos": len(positivos),
        "sinais": [s.to_dict() for s in sinais],
        "n_pacotes": len(pacotes),
        "n_traces": len(traces),
    }
