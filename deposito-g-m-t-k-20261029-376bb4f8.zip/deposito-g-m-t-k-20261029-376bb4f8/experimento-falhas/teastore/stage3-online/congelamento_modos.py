#!/usr/bin/env python3
"""Congelamento **por modo** do Stage 3 (decisão do autor).

O congelamento anterior (`codigo.src_tree`) pinava o **tree inteiro de `src/`**. Isso não serve
agora: D1–D4 são escritas na `main`, dentro de `src/`, e um `.md` de spec mudaria o hash sem mudar
uma linha do que roda. Aqui cada **modo** tem a sua lista de arquivos e o seu hash, e o pré-voo
confere **só os modos escolhidos**.

O que cada hash cobre, e o que não:

- **Cobre** os arquivos de decisão do modo. É o que permite dizer "a A0 que rodou é a A0 que foi
  calibrada", independentemente do resto de `src/` ter mudado.
- **Não cobre** a infraestrutura compartilhada (store, schemas, collector, pipeline, web). Ela é
  coberta pelo **digest da imagem do job-runner**, que o pré-voo já confere. Dividir assim evita
  duplicar a mesma garantia em dois lugares.

O hash de um modo é
`sha256("\n".join(f"{caminho}:{sha256(conteudo)}" para caminho em ordem alfabética))`
— muda se **qualquer** arquivo da lista mudar.

**Como a lista da A0 foi derivada** (item 3.8 do registro manda conferir pelos imports): é o fecho
transitivo de imports de `src/application/stage3/tasks.py`, que é a raiz do `stage3_diagnosis`,
restrito a `src/application/stage3/`. São 17 arquivos. `egads.py` entra porque
`conformance.py`, `problem_map.py` e `attribution.py` o importam — e é ele que faz os testes
unilaterais de anomalia, ou seja, o `anomaly_k` que a sensibilidade da Fase 2 reprovou. Os 30
arquivos de fora de `stage3/` que o fecho também alcança (collector, pipeline, store, schemas) são
infraestrutura e ficam sob o digest da imagem.

Uso (do diretório `experimento-falhas/teastore/stage3-online/`):

    python3 congelamento_modos.py --listar
    python3 congelamento_modos.py --hash a0
    python3 congelamento_modos.py --verificar a0
    python3 congelamento_modos.py --emitir          # bloco JSON para o congelamento.json

Sai com 1 se algum modo escolhido divergir do congelado ou tiver arquivo sujo.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(SELF_DIR)))
CONG = os.path.join(SELF_DIR, "congelamento.json")

# Fecho transitivo de imports de src/application/stage3/tasks.py, so dentro de stage3/.
ARQUIVOS_A0: tuple[str, ...] = tuple(
    f"src/application/stage3/{m}.py"
    for m in (
        "attribution", "audit_package", "baseline", "config", "conformance", "edges", "egads",
        "entities", "llm_synthesis", "localizacao", "problem_map", "process_models",
        "service_stats", "tasks", "traces", "types", "votes",
    )
)

PASTA_STAGE3 = "src/application/stage3"
PASTA_ABORDAGENS = f"{PASTA_STAGE3}/abordagens"


def fecho_de_imports(raizes: tuple[str, ...]) -> tuple[str, ...]:
    """Fecho transitivo de imports a partir de `raizes` (módulos `src.…`), restrito a `stage3/`.

    O mesmo critério que derivou a lista da a0 (o teste de fecho usa esta função). `from pkg import
    mod` entra quando `pkg/mod.py` existe — é assim que `egads` entra na a0 e `calibracao` nos d_k.
    """
    import ast

    vistos: set[str] = set()
    pilha = list(raizes)
    while pilha:
        mod = pilha.pop()
        if mod in vistos:
            continue
        vistos.add(mod)
        caminho = os.path.join(REPO_ROOT, mod.replace(".", "/") + ".py")
        if not os.path.isfile(caminho):
            continue
        with open(caminho) as fh:
            arvore = ast.parse(fh.read())
        for no in ast.walk(arvore):
            nomes: list[str] = []
            if isinstance(no, ast.Import):
                nomes = [a.name for a in no.names]
            elif isinstance(no, ast.ImportFrom) and (no.module or "").startswith("src."):
                base = no.module or ""
                nomes = [base] + [
                    f"{base}.{a.name}" for a in no.names
                    if os.path.isfile(os.path.join(REPO_ROOT, f"{base}.{a.name}".replace(".", "/") + ".py"))
                ]
            pilha.extend(n for n in nomes if n.startswith("src."))
    return tuple(sorted(
        m.replace(".", "/") + ".py" for m in vistos
        if m.startswith("src.application.stage3.")
        and os.path.isfile(os.path.join(REPO_ROOT, m.replace(".", "/") + ".py"))
    ))


# Cada d_k: fecho de imports do arquivo do modo + do provedor de traces ao vivo (`jaeger.py`, que
# define o insumo). Inclui os utilitários comuns (`base`, `processo`, `estatistica`, `calibracao`) e
# o que eles importam da a0 por utilitário (`traces`, `process_models`, …): se mudarem, o modo muda.
_PROVEDOR = "src.application.stage3.abordagens.jaeger"
ARQUIVOS_D1: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d1_conformance", _PROVEDOR))
ARQUIVOS_D2: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d2_diferencial", _PROVEDOR))
ARQUIVOS_D3: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d3_drift", _PROVEDOR))
ARQUIVOS_D4: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d4_estocastico", _PROVEDOR))
# Versões `c`: o fecho inclui o arquivo da v1 que cada uma importa e o `causal.py`.
ARQUIVOS_D1C: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d1c_conformance", _PROVEDOR))
ARQUIVOS_D2C: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d2c_diferencial", _PROVEDOR))
ARQUIVOS_D4C: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d4c_estocastico", _PROVEDOR))
# Modos novos: congelados antes do teste nos g.
ARQUIVOS_D5: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d5_portao", _PROVEDOR))
ARQUIVOS_D6: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d6_residuo", _PROVEDOR))
ARQUIVOS_D7: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d7_assinatura", _PROVEDOR))
# Soluções definitivas: o fecho do v-cons-b inclui o da d9-k, a0-b e d6.
ARQUIVOS_D9K: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.d9k_portao_grafo_k8s", _PROVEDOR))
ARQUIVOS_VCONSB: tuple[str, ...] = fecho_de_imports(("src.application.stage3.abordagens.vconsb_consenso", _PROVEDOR))

MODOS: dict[str, dict[str, Any]] = {
    "a0": {
        "versao": "a0-v1",
        "descricao": "localizacao atual (localization_mode=anomalias), legada e congelada",
        "arquivos": ARQUIVOS_A0,
    },
    "d1": {"versao": "d1-v1", "descricao": "conformance populacional", "arquivos": ARQUIVOS_D1},
    "d2": {"versao": "d2-v3", "descricao": "comparacao de processos", "arquivos": ARQUIVOS_D2},
    "d3": {"versao": "d3-v1", "descricao": "drift de processo", "arquivos": ARQUIVOS_D3},
    "d4": {"versao": "d4-v1", "descricao": "modelo estocastico", "arquivos": ARQUIVOS_D4},
    "d1c": {"versao": "d1c-v1", "descricao": "conformance, atribuicao causal", "arquivos": ARQUIVOS_D1C},
    "d2c": {"versao": "d2c-v1", "descricao": "comparacao de processos, atribuicao causal", "arquivos": ARQUIVOS_D2C},
    "d4c": {"versao": "d4c-v1", "descricao": "modelo estocastico, atribuicao causal", "arquivos": ARQUIVOS_D4C},
    "d5": {"versao": "d5-v1", "descricao": "portao por referencia da mesma sessao", "arquivos": ARQUIVOS_D5},
    "d6": {"versao": "d6-v1", "descricao": "localizacao por residuo dado os filhos", "arquivos": ARQUIVOS_D6},
    "d7": {"versao": "d7-v1", "descricao": "assinatura derivada do grafo", "arquivos": ARQUIVOS_D7},
    "d9-k": {"versao": "d9-k-v1", "descricao": "d9 + eventos K8s de sintoma (solucao definitiva)",
             "arquivos": ARQUIVOS_D9K},
    "v-cons-b": {"versao": "v-cons-b-v1", "descricao": "consenso d9-k + a0-b + d6 (solucao definitiva)",
                 "arquivos": ARQUIVOS_VCONSB},
}

TODOS = ("a0", "d1", "d2", "d3", "d4", "d1c", "d2c", "d4c", "d5", "d6", "d7", "d9-k", "v-cons-b")


def arquivos_do_modo(modo: str) -> tuple[str, ...]:
    if modo not in MODOS:
        raise SystemExit(f"modo desconhecido: {modo!r} (esperado: {', '.join(TODOS)})")
    return tuple(sorted(MODOS[modo]["arquivos"]))


def sha256_arquivo(rel: str) -> str:
    path = os.path.join(REPO_ROOT, rel)
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def hash_modo(modo: str) -> str:
    arqs = arquivos_do_modo(modo)
    if not arqs:
        raise ValueError(f"modo {modo!r} sem lista de arquivos")
    partes = []
    for rel in arqs:
        path = os.path.join(REPO_ROOT, rel)
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        partes.append(f"{rel}:{sha256_arquivo(rel)}")
    return hashlib.sha256("\n".join(partes).encode()).hexdigest()


def sujos(modo: str) -> list[str]:
    """Arquivos do modo com mudanca nao commitada (o que roda != o que esta gravado)."""
    arqs = arquivos_do_modo(modo)
    if not arqs:
        return []
    out = subprocess.run(
        ["git", "-C", REPO_ROOT, "status", "--porcelain", "--", *arqs],
        capture_output=True, text=True, check=False,
    ).stdout.splitlines()
    return [line for line in out if line.strip()]


def _cong() -> dict[str, Any]:
    with open(CONG) as fh:
        return json.load(fh)


def verificar(modos: list[str]) -> int:
    cong = _cong().get("modos") or {}
    falhas = 0
    for modo in modos:
        arqs = arquivos_do_modo(modo)
        if not arqs:
            print(f"ruim  modo {modo}: lista de arquivos vazia (a spec 42 precisa ser revisada)")
            falhas += 1
            continue
        gravado = (cong.get(modo) or {}).get("sha256")
        try:
            atual = hash_modo(modo)
        except (FileNotFoundError, ValueError) as exc:
            print(f"ruim  modo {modo}: {exc}")
            falhas += 1
            continue
        if gravado is None:
            print(f"ruim  modo {modo}: sem sha256 no congelamento.json")
            falhas += 1
            continue
        if gravado == atual:
            print(f"ok    modo {modo}: {len(arqs)} arquivos, sha256 {atual[:12]}")
        else:
            print(f"ruim  modo {modo}: sha256 {atual[:12]} != congelado {gravado[:12]}")
            falhas += 1
        sujo = sujos(modo)
        if sujo:
            print(f"ruim  modo {modo}: {len(sujo)} arquivo(s) com mudanca nao commitada")
            falhas += 1
    return 1 if falhas else 0


def emitir() -> None:
    """Bloco `modos` para o congelamento.json, com os modos que tem lista de arquivos."""
    bloco: dict[str, Any] = {}
    for modo in TODOS:
        arqs = arquivos_do_modo(modo)
        if not arqs:
            continue
        bloco[modo] = {
            "versao": MODOS[modo]["versao"],
            "descricao": MODOS[modo]["descricao"],
            "arquivos": list(arqs),
            "n_arquivos": len(arqs),
            "sha256": hash_modo(modo),
        }
    print(json.dumps({"modos": bloco}, indent=2, ensure_ascii=False))


def lista() -> None:
    for modo in TODOS:
        arqs = arquivos_do_modo(modo)
        marca = f"{len(arqs)} arquivos" if arqs else "SEM LISTA (nao roda)"
        print(f"{modo:>4}  {MODOS[modo]['versao']:<8} {marca:<28} {MODOS[modo]['descricao']}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--listar", action="store_true")
    ap.add_argument("--hash", metavar="MODO")
    ap.add_argument("--verificar", nargs="+", metavar="MODO")
    ap.add_argument("--emitir", action="store_true")
    args = ap.parse_args()
    if args.listar:
        lista()
        return 0
    if args.hash:
        print(hash_modo(args.hash))
        return 0
    if args.emitir:
        emitir()
        return 0
    if args.verificar:
        return verificar(args.verificar)
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())