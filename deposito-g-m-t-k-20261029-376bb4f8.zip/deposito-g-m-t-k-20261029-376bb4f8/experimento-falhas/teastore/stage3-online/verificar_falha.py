#!/usr/bin/env python3
"""Confere, depois da implantação, que o TeaStore está no ar COM a falha do cenário, e só com ela.

Até aqui `aplicar_falha_build` aplicava a falha e `wait_for_teastore_ready` dormia 20 s nas falhas de
infra sem conferir nada: um `kubectl patch` que não pegou, um rollout que não terminou ou um pod antigo
ainda servindo passavam como cenário válido, e o Stage 3 era avaliado contra uma falha que não estava lá.

**Só a causa reprova** (D5). Três testes, todos sobre o que está RODANDO (o pod mais
novo do serviço), não só sobre o deployment:

1. **falha aplicada** -- o pod do serviço-alvo tem a assinatura da falha: a imagem `<base>-fN` nas falhas
   de código; o env/limite/probe/volume do override nas falhas de infra (f4, f5, f6, f11, f12, f13, f14).
2. **versão injetada serve o tráfego** -- nenhum pod vivo do alvo na especificação antiga. Regra genérica,
   que barra a f13 sem conhecer a f13.
3. **demais serviços na base e sem override** -- os outros seis serviços estão na imagem base e sem
   override de falha (resíduo de cenário anterior contaminaria este).

O **efeito** da falha não reprova: estado do pod-alvo (Ready, OOM em loop na f11, NotReady na f13), Ready
dos demais e o HTTP do webui vão para `observacoes`, com o status das quatro páginas, sem exigir 200. Exigir
o efeito é usar o gabarito do efeito, e foi o que descartou F2, F5 e F12 — nas quais **parar de servir é a
falha** (F5 com 4 tentativas e F12 com 18, sem resposta alguma, e "0 requisições × 267 na baseline" já na
calibração). A f2 respondia 200 e morreu durante o warmup.

Repete até `--timeout`; sai 0 quando os três passam, 1 quando o prazo acaba. O relatório vai para `--out`.

Uso: verificar_falha.py --falha f6-db-connectivity --exp-base exp-v1.1.0 --out verificacao.json
"""

from __future__ import annotations

import argparse
import datetime
import json
import re
import subprocess
import sys
import time
from typing import Any

SERVICOS = ("registry", "db", "persistence", "auth", "image", "recommender", "webui")
SERVICO_DA_FALHA = {
    "f1": "webui", "f2": "webui", "f4": "webui", "f5": "webui", "f12": "webui", "f14": "webui",
    "f3": "persistence", "f6": "persistence", "f7": "persistence", "f8": "persistence",
    "f10": "persistence", "f11": "persistence", "f9": "registry", "f13": "auth",
    # hold-out (HOLDOUT.md)
    "h1": "image", "h2": "recommender", "h3": "auth", "h4": "db", "h5": "image", "h6": "recommender",
    # hold-out 2 (HOLDOUT-2.md)
    "g1": "auth", "g2": "persistence", "g3": "image", "g4": "db", "g5": "recommender", "g6": "persistence",
}
INFRA = {"f4", "f5", "f6", "f11", "f12", "f13", "f14", "h1", "h2", "h3", "h4", "h5", "h6",
         "g1", "g2", "g3", "g4", "g5", "g6"}
# Falhas cuja causa é o deployment com 0 réplicas (dependência indisponível): não há pod para inspecionar.
SEM_REPLICAS = {"h6", "g2"}
# Estado do pod-alvo que a falha produz. f11 (limits.memory=96Mi) entra em OOM/BackOff e f13 (probe em
# /healthz) fica NotReady -- únicos com eventos no lote 20260927T051757Z; as demais ficam Ready.
WEBUI_PAGINAS = {
    "index": "/tools.descartes.teastore.webui/index",
    "category": "/tools.descartes.teastore.webui/category?category=2&page=1",
    "product": "/tools.descartes.teastore.webui/product?id=7",
    "login": "/tools.descartes.teastore.webui/login",
}


def _kubectl_json(*args: str) -> dict[str, Any]:
    out = subprocess.run(["kubectl", *args, "-o", "json"], capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


def _http_status(namespace: str, pod: str, path: str) -> int | None:
    """Status HTTP de dentro do pod do webui. Sem `check`: o wget sai != 0 num 500, e o 500 importa."""
    try:
        proc = subprocess.run(
            ["kubectl", "exec", "-n", namespace, pod, "-c", "teastore-webui", "--",
             "wget", "-qSO", "/dev/null", "--timeout=15", "--tries=1", f"http://localhost:8080{path}"],
            capture_output=True, text=True, timeout=40,
        )
    except subprocess.TimeoutExpired:
        return None
    for line in reversed((proc.stderr + proc.stdout).splitlines()):
        m = re.search(r"HTTP/\S+\s+(\d{3})", line)
        if m:
            return int(m.group(1))
    return None


def _num(falha: str) -> str:
    m = re.match(r"^([fhg]\d+)", falha)
    if not m or m.group(1) not in SERVICO_DA_FALHA:
        raise SystemExit(f"falha desconhecida: {falha}")
    return m.group(1)


def _pod_atual(pods: list[dict[str, Any]], servico: str) -> dict[str, Any] | None:
    """Pod mais novo do serviço, fora os que estão terminando (resíduo do rollout)."""
    vivos = [p for p in pods
             if (p["metadata"].get("labels") or {}).get("run") == f"teastore-{servico}"
             and not p["metadata"].get("deletionTimestamp")]
    return max(vivos, key=lambda p: p["metadata"]["creationTimestamp"]) if vivos else None


def _container(pod: dict[str, Any], servico: str) -> dict[str, Any]:
    return next((c for c in pod["spec"]["containers"] if c["name"] == f"teastore-{servico}"), {})


def _status_container(pod: dict[str, Any], servico: str) -> dict[str, Any]:
    return next((c for c in pod["status"].get("containerStatuses") or [] if c["name"] == f"teastore-{servico}"), {})


def _env(container: dict[str, Any]) -> dict[str, str]:
    return {e["name"]: str(e.get("value", "")) for e in container.get("env") or []}


def _overrides(pod: dict[str, Any], servico: str) -> list[str]:
    """Marcas de override de falha de infra presentes no pod (vazio = configuração base)."""
    c = _container(pod, servico)
    achados = []
    volumes_cm = {(v.get("configMap") or {}).get("name") for v in pod["spec"].get("volumes") or []}
    for cm in ("falha-invalid-path", "falha-log-debug"):
        if cm in volumes_cm:
            achados.append(f"volume {cm}")
    env = _env(c)
    if "-Xmx64m" in env.get("_JAVA_OPTIONS", ""):
        achados.append("_JAVA_OPTIONS -Xmx64m")
    if env.get("DB_HOST") == "db-host-inexistente":
        achados.append("DB_HOST=db-host-inexistente")
    if "-Xmx40m" in env.get("_JAVA_OPTIONS", ""):
        achados.append("_JAVA_OPTIONS -Xmx40m")
    if "-Xmx48m" in env.get("_JAVA_OPTIONS", ""):
        achados.append("_JAVA_OPTIONS -Xmx48m")
    if env.get("REGISTRY_HOST") == "registry-inexistente":
        achados.append("REGISTRY_HOST=registry-inexistente")
    limites = (c.get("resources") or {}).get("limits") or {}
    for chave, valor in (("memory", "96Mi"), ("memory", "128Mi"), ("cpu", "150m"), ("cpu", "120m"), ("cpu", "110m"),
                         ("cpu", "100m")):
        if limites.get(chave) == valor:
            achados.append(f"limits.{chave}={valor}")
    if ((c.get("readinessProbe") or {}).get("httpGet") or {}).get("path") == "/healthz":
        achados.append("readinessProbe /healthz")
    return achados


ASSINATURA_INFRA = {
    "f4": "volume falha-invalid-path", "f5": "_JAVA_OPTIONS -Xmx64m", "f6": "DB_HOST=db-host-inexistente",
    "f11": "limits.memory=96Mi", "f12": "limits.cpu=150m", "f13": "readinessProbe /healthz",
    "f14": "volume falha-log-debug",
    "h1": "limits.cpu=120m", "h2": "limits.memory=128Mi", "h3": "_JAVA_OPTIONS -Xmx40m",
    "h4": "limits.cpu=110m", "h5": "REGISTRY_HOST=registry-inexistente",
    "g1": "limits.cpu=100m", "g3": "limits.memory=128Mi", "g4": "limits.memory=96Mi", "g5": "limits.cpu=100m",
    "g6": "_JAVA_OPTIONS -Xmx48m",
}


def _tag(image: str) -> str:
    return image.rsplit(":", 1)[-1] if ":" in image.rsplit("/", 1)[-1] else ""


def verificar(falha: str, exp_base: str, namespace: str) -> dict[str, Any]:
    """Verifica **a causa** da falha, nunca o efeito.

    Reprova quando a falha não está no pod que roda, quando outro serviço saiu da base ou
    recebeu override, ou quando sobrou pod vivo do alvo na especificação antiga (isto é, a
    versão injetada não serve o tráfego). Estado do pod, Ready e HTTP do webui são
    **observações**: exigir o efeito seria usar o gabarito do efeito, e é o que descartou
    F2/F5/F12 — nas quais parar de servir é a própria falha.
    """
    n = _num(falha)
    alvo = SERVICO_DA_FALHA[n]
    pods = _kubectl_json("get", "pods", "-n", namespace)["items"]
    testes: list[dict[str, Any]] = []
    observacoes: dict[str, Any] = {}

    def teste(nome: str, ok: bool, detalhe: str) -> None:
        testes.append({"teste": nome, "ok": bool(ok), "detalhe": detalhe})

    # 1. causa: assinatura da falha no pod mais novo do alvo
    pod = _pod_atual(pods, alvo)
    if n in SEM_REPLICAS:
        # dependência indisponível: a causa é o deployment com 0 réplicas e nenhum pod vivo do alvo
        dep = _kubectl_json("get", "deployment", f"teastore-{alvo}", "-n", namespace)
        rep = (dep.get("spec") or {}).get("replicas")
        teste("falha aplicada", rep == 0 and pod is None,
              f"teastore-{alvo}: replicas={rep}, pod vivo={pod['metadata']['name'] if pod else 'nenhum'}")
    elif pod is None:
        teste("falha aplicada", False, f"nenhum pod de teastore-{alvo}")
    else:
        image = _container(pod, alvo).get("image", "")
        marcas = _overrides(pod, alvo)
        if n in INFRA:
            esperada = ASSINATURA_INFRA[n]
            # o db não vem do registry de releases (imagem própria do banco): não tem tag de release
            ok = esperada in marcas and marcas == [esperada] and (alvo == "db" or _tag(image) == exp_base)
            teste("falha aplicada", ok,
                  f"{pod['metadata']['name']}: override {marcas or 'nenhum'} (esperado [{esperada}]), "
                  f"imagem {_tag(image) or image} (esperada {exp_base})")
        else:
            esperada = f"{exp_base}-{n}"
            ok = _tag(image) == esperada and not marcas
            teste("falha aplicada", ok,
                  f"{pod['metadata']['name']}: imagem {_tag(image) or image} (esperada {esperada})"
                  + (f", override inesperado {marcas}" if marcas else ""))

        # 2. causa: a versão injetada serve o tráfego — nenhum pod vivo do alvo na especificação antiga
        antigos = [p["metadata"]["name"] for p in pods
                   if (p["metadata"].get("labels") or {}).get("run") == f"teastore-{alvo}"
                   and not p["metadata"].get("deletionTimestamp") and p is not pod
                   and (_container(p, alvo).get("image") != _container(pod, alvo).get("image")
                        or _overrides(p, alvo) != _overrides(pod, alvo))]
        teste("versão injetada serve o tráfego", not antigos,
              "nenhum pod vivo do alvo na especificação antiga" if not antigos
              else f"pods antigos ainda vivos: {antigos}")

        # observação: estado do pod-alvo (o efeito da falha não reprova)
        st = _status_container(pod, alvo)
        observacoes["alvo"] = {
            "pod": pod["metadata"]["name"], "servico": f"teastore-{alvo}",
            "ready": bool(st.get("ready")), "restarts": int(st.get("restartCount") or 0),
            "ultimo_termino": ((st.get("lastState") or {}).get("terminated") or {}).get("reason") or "",
            "esperando": ((st.get("state") or {}).get("waiting") or {}).get("reason") or "",
        }

    # 3. causa: só ela — os demais serviços na base, sem override (Ready vai para observação)
    residuos, outros_ready = [], []
    for servico in SERVICOS:
        if servico == alvo:
            continue
        p = _pod_atual(pods, servico)
        if p is None:
            residuos.append(f"{servico}: sem pod")
            continue
        tag = _tag(_container(p, servico).get("image", ""))
        if servico != "db" and tag != exp_base:
            residuos.append(f"{servico}: imagem {tag} (esperada {exp_base})")
        if _overrides(p, servico):
            residuos.append(f"{servico}: override {_overrides(p, servico)}")
        if not any(c.get("type") == "Ready" and c.get("status") == "True" for c in p["status"].get("conditions") or []):
            outros_ready.append(f"{servico}: não está Ready")
    teste("demais serviços na base e sem override", not residuos, "; ".join(residuos) or "6/6 na base, sem override")
    observacoes["outros_nao_ready"] = outros_ready

    # observação: aplicação no ar — o webui responde HTTP (qualquer status) em /index
    webui = _pod_atual(pods, "webui")
    paginas: dict[str, int | None] = {}
    if webui is None:
        observacoes["webui_http"] = {"erro": "nenhum pod do webui"}
    else:
        nome_pod = webui["metadata"]["name"]
        paginas = {nome: _http_status(namespace, nome_pod, path) for nome, path in WEBUI_PAGINAS.items()}
        observacoes["webui_http"] = paginas

    return {
        "falha": falha, "servico_alvo": alvo, "exp_base": exp_base,
        "ok": all(t["ok"] for t in testes), "testes": testes,
        "observacoes": observacoes, "webui_http": paginas,
        "momento": datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--falha", required=True)
    ap.add_argument("--exp-base", required=True)
    ap.add_argument("--namespace", default="teastore")
    ap.add_argument("--timeout", type=int, default=300)
    ap.add_argument("--intervalo", type=int, default=15)
    ap.add_argument("--fase", default="pos-implantacao")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    prazo = time.monotonic() + args.timeout
    tentativas = 0
    while True:
        tentativas += 1
        try:
            r = verificar(args.falha, args.exp_base, args.namespace)
        except subprocess.SubprocessError as exc:
            r = {"falha": args.falha, "ok": False, "testes": [{"teste": "kubectl", "ok": False, "detalhe": str(exc)}]}
        if r["ok"] or time.monotonic() >= prazo:
            break
        time.sleep(args.intervalo)
    r.update(fase=args.fase, tentativas=tentativas)
    with open(args.out, "w") as f:
        json.dump(r, f, indent=2)

    print(f"    Verificação [{args.fase}] de {args.falha} ({tentativas} tentativa(s)):")
    for t in r["testes"]:
        print(f"      [{'OK' if t['ok'] else 'FALHOU'}] {t['teste']}: {t['detalhe']}")
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
