#!/usr/bin/env python3
"""Qualidade da coleta de pacotes.

O lote `081432Z` gerou ~62-70 pacotes em 300 s com janela de 3 s, onde o esperado seria ~100. Como a
janela é de 3 s e cada pacote leva mais que isso para ser coletado, a coleta não consegue preencher a
linha do tempo: sobram buracos. Um buraco não é ruído benigno -- é **tempo sem evidência**, e o Stage 3
lê ausência de sinal como "nada aconteceu". Com 30% da janela sem dado, um caso real pode virar
silencioso por falta de amostragem, não por ausência de falha.

Este script mede, por caso: quantos pacotes vieram, a cobertura da janela, o tamanho de cada buraco e a
contagem esperada. Escreve `qualidade_coleta.json` no diretório do lote e sai diferente de zero se a
cobertura cair abaixo do aceitável.

Uso: checar_pacotes.py <resultados/RUN_ID> [--min-cobertura 0.95] [--saida-json <caminho>]
"""

from __future__ import annotations

import argparse
import datetime
import glob
import json
import os
import sys


def _iso(valor: str) -> datetime.datetime | None:
    try:
        return datetime.datetime.fromisoformat(str(valor).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def _janelas(case_dir: str) -> list[tuple[datetime.datetime, datetime.datetime]]:
    janelas = []
    for caminho in sorted(glob.glob(os.path.join(case_dir, "evidence_packages", "pkg-*.json"))):
        try:
            with open(caminho) as f:
                pacote = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        inicio, fim = _iso(pacote.get("window_start")), _iso(pacote.get("window_end"))
        if inicio and fim and fim >= inicio:
            janelas.append((inicio, fim))
    return sorted(janelas)


def medir(case_dir: str, janela_s: float, min_cobertura: float) -> dict:
    janelas = _janelas(case_dir)
    nome = os.path.basename(case_dir.rstrip("/"))
    if not janelas:
        return {"caso": nome, "n_pacotes": 0, "erro": "nenhum pacote com janela legível"}

    inicio, fim = janelas[0][0], janelas[-1][1]
    total_s = (fim - inicio).total_seconds() or 1.0
    # Duração observada das janelas: uma janela de 3 s que chega com 12 s de extensão já é um sinal de
    # que a coleta estoura a janela, e é isso que come a linha do tempo.
    duracoes = [(f - i).total_seconds() for i, f in janelas]
    # Todo buraco conta como tempo sem evidência, não só os grandes. No `081432Z` os buracos são
    # justamente pequenos e frequentes -- a coleta de cada pacote leva ~4 s para uma janela de 3 s, o
    # pacote seguinte entra ~1 s atrasado, e o atraso se acumula. Se eu só contasse buracos acima de
    # meia janela, os 66 s de drift do `f10` desapareceriam do relatório.
    buracos = [
        {"de": anterior[1].isoformat(), "ate": seguinte[0].isoformat(),
         "segundos": round((seguinte[0] - anterior[1]).total_seconds(), 1)}
        for anterior, seguinte in zip(janelas, janelas[1:])
        if seguinte[0] > anterior[1]
    ]
    sem_evidencia = sum(b["segundos"] for b in buracos)
    cobertura = min(sum(duracoes) / total_s, 1.0)
    # Buracos que valem a pena listar: a partir de uma janela inteira, que é quando a lacuna já
    # custa um pacote de evidência inteiro.
    lacunas = [b for b in buracos if b["segundos"] >= janela_s]
    return {
        "caso": nome,
        "n_pacotes": len(janelas),
        "n_esperado": max(1, round(total_s / janela_s)),
        "janela_s": janela_s,
        "span_s": round(total_s, 1),
        "cobertura": round(cobertura, 3),
        "tempo_sem_evidencia_s": round(sem_evidencia, 1),
        "duracao_janela_mediana_s": round(sorted(duracoes)[len(duracoes) // 2], 1),
        "n_buracos": len(buracos),
        "n_lacunas": len(lacunas),
        "maior_lacuna_s": round(max((b["segundos"] for b in lacunas), default=0.0), 1),
        "lacunas": lacunas[:20],
        "atende_minimo": cobertura >= min_cobertura,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("run_dir")
    # 0,95 e o aceite da Etapa F do plano de rastros; o padrao antigo (0,8) era o piso aceito na
    # avaliacao anterior, quando a coleta perdia ~32% da linha do tempo.
    parser.add_argument("--min-cobertura", type=float, default=0.95)
    parser.add_argument("--saida-json", default="")
    args = parser.parse_args()

    run_dir = args.run_dir.rstrip("/")
    manifest = {}
    try:
        with open(os.path.join(run_dir, "manifest.json")) as f:
            manifest = json.load(f)
    except (OSError, json.JSONDecodeError):
        pass
    janela_s = float(manifest.get("package_window_seconds") or 3.0)

    # Cenário descartado pela verificação da falha não foi coletado: não é lacuna de cobertura.
    casos = [d for d in sorted(glob.glob(os.path.join(run_dir, "[fhg][0-9]*")))
             if os.path.isdir(d) and not os.path.exists(os.path.join(d, "FALHA_NAO_VERIFICADA"))]
    if not casos:
        print(f"nenhum caso em {run_dir}", file=sys.stderr)
        return 2
    resultados = [medir(d, janela_s, args.min_cobertura) for d in casos]
    com_pacotes = [r for r in resultados if r.get("n_pacotes")]
    cobertura_media = round(sum(r["cobertura"] for r in com_pacotes) / len(com_pacotes), 3) if com_pacotes else 0.0
    resumo = {
        "run_id": os.path.basename(run_dir),
        "janela_s": janela_s,
        "min_cobertura": args.min_cobertura,
        "cobertura_media": cobertura_media,
        "n_casos": len(resultados),
        "n_casos_ok": sum(bool(r.get("atende_minimo")) for r in com_pacotes),
        "casos": resultados,
    }
    saida = args.saida_json or os.path.join(run_dir, "qualidade_coleta.json")
    with open(saida, "w") as f:
        json.dump(resumo, f, ensure_ascii=False, indent=2)

    print(f"pacotes: janela declarada {janela_s:g}s | cobertura média {cobertura_media:.0%} "
          f"(mínimo {args.min_cobertura:.0%})")
    print(f"{'caso':24s} {'pacotes':>8s} {'esperado':>9s} {'cobertura':>10s} {'s/mediana':>10s} {'sem evid.':>10s}")
    for r in resultados:
        if not r.get("n_pacotes"):
            print(f"{r['caso']:24s} {r.get('erro', 'sem pacotes')}")
            continue
        marca = "" if r["atende_minimo"] else "  <- abaixo do mínimo"
        print(f"{r['caso']:24s} {r['n_pacotes']:8d} {r['n_esperado']:9d} {r['cobertura']:10.0%} "
              f"{r['duracao_janela_mediana_s']:9.1f}s {r['tempo_sem_evidencia_s']:9.1f}s{marca}")
    print(f"\n-> {saida}")
    return 0 if resumo["n_casos_ok"] == len(com_pacotes) else 1


if __name__ == "__main__":
    sys.exit(main())
