#!/usr/bin/env python3
"""Resumo de um lote (Top-1/Top-2/Top-3/MRR), geral e só com os casos que começaram saudáveis.

Acrescenta a estratificação da M2 (`manifestacao.py`): o número principal passa a contar só os casos em
que a falha **se manifestou**, e as falhas silenciosas saem do denominador -- contabilizá-las como erro
de diagnóstico pune o Stage 3 por um caso em que não havia o que diagnosticar.

Uso: avaliar_lote.py <resultados/RUN_ID>   -> grava resumo.json e resumo.md no diretório do lote.
"""

import glob
import json
import os
import sys


def _metrics(rows: list[dict]) -> dict:
    n = len(rows)
    if not n:
        return {"n": 0}
    respondidos = [r for r in rows if r.get("respondeu", True)]
    return {
        "n": n, "top1": sum(bool(r.get("matched")) for r in rows), "top2": sum(bool(r.get("top2")) for r in rows),
        "top3": sum(bool(r.get("top3")) for r in rows), "mrr": round(sum(r.get("rr", 0.0) for r in rows) / n, 3),
        # abstenção conta como erro acima; aqui o recorte dos casos em que o Stage 3 publicou suspeito
        "abstencoes": n - len(respondidos), "respondidos": len(respondidos),
        "top1_respondidos": sum(bool(r.get("matched")) for r in respondidos),
        "top2_respondidos": sum(bool(r.get("top2")) for r in respondidos),
        "top3_respondidos": sum(bool(r.get("top3")) for r in respondidos),
    }


def _manifestacao(rows: list[dict]) -> dict:
    """Separa manifestas / silenciosas / indeterminadas e lista as silenciosas por falha (M2)."""
    classes: dict[str, list[dict]] = {"manifesta": [], "silenciosa": [], "indeterminado": []}
    for row in rows:
        nome = (row.get("manifestacao") or {}).get("classificacao") or "indeterminado"
        classes.setdefault(nome, []).append(row)
    return {
        "manifestas": _metrics(classes["manifesta"]),
        "n_silenciosas": len(classes["silenciosa"]),
        "n_indeterminadas": len(classes["indeterminado"]),
        "silenciosas": sorted(r["falha"] for r in classes["silenciosa"]),
        "indeterminadas": sorted(r["falha"] for r in classes["indeterminado"]),
    }


def _fmt(m: dict) -> str:
    if not m.get("n"):
        return "sem casos"
    n = m["n"]
    line = (f"Top-1 {m['top1']}/{n} ({m['top1'] / n:.0%}) · Top-2 {m['top2']}/{n} ({m['top2'] / n:.0%}) · "
            f"Top-3 {m['top3']}/{n} ({m['top3'] / n:.0%}) · MRR {m['mrr']}")
    ab, na = m.get("abstencoes", 0), m.get("respondidos", n)
    line += f" · abstenções {ab}/{n} ({ab / n:.0%})"
    if ab and na:
        line += (f" · só respondidos: Top-1 {m['top1_respondidos']}/{na} ({m['top1_respondidos'] / na:.0%}), "
                 f"Top-2 {m['top2_respondidos']}/{na} ({m['top2_respondidos'] / na:.0%}), "
                 f"Top-3 {m['top3_respondidos']}/{na} ({m['top3_respondidos'] / na:.0%})")
    return line


def _llm(rows: list[dict]) -> str:
    """Provedor e coerência da síntese."""
    providers = sorted({str(r.get("llm_provider")) for r in rows if r.get("llm_provider")}) or ["?"]
    judged = [r for r in rows if r.get("confidence_coherent") is not None]
    incoherent = sum(r["confidence_coherent"] is False for r in judged)
    abstained = sum(bool(r.get("llm_abstain")) for r in rows)
    return (f"provedor {', '.join(providers)} · confiança acima da localização em {incoherent}/{len(judged)} · "
            f"abstenções {abstained}/{len(rows)}")


def _partition(run_id: str) -> str:
    """`teste` se o lote não está na calibração de `replay/particao.json`."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "replay", "particao.json")
    try:
        with open(path) as f:
            calib = set(json.load(f).get("calibracao") or [])
    except (OSError, json.JSONDecodeError):
        return "?"
    return "calibração" if run_id in calib else "teste"


def main() -> int:
    run_dir = sys.argv[1]
    rows = []
    for path in glob.glob(os.path.join(run_dir, "[fhg][0-9]*", "avaliacao.json")):
        with open(path) as f:
            rows.append(json.load(f))
    rows.sort(key=lambda r: int(r["falha"].split("-")[0][1:]))
    healthy = [r for r in rows if r.get("health_pre_ok") is not False]
    summary = {"run_id": os.path.basename(run_dir.rstrip("/")), "geral": _metrics(rows),
               "saudaveis": _metrics(healthy), "manifestacao": _manifestacao(rows),
               "particao": _partition(os.path.basename(run_dir.rstrip("/"))), "rows": rows}
    with open(os.path.join(run_dir, "resumo.json"), "w") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    quiet = summary["manifestacao"]["silenciosas"]
    lines = [f"# Lote {summary['run_id']} ({summary['particao']})", "", f"- Geral: **{_fmt(summary['geral'])}**",
             f"- Só casos que começaram saudáveis: **{_fmt(summary['saudaveis'])}**",
             f"- **Só falhas que se manifestaram (número principal, M2): "
             f"{_fmt(summary['manifestacao']['manifestas'])}**",
             f"- Falhas silenciosas: {summary['manifestacao']['n_silenciosas']}"
             + (f" ({', '.join(quiet)})" if quiet else "")
             + (f" · indeterminadas: {summary['manifestacao']['n_indeterminadas']}"
                if summary["manifestacao"]["n_indeterminadas"] else ""),
             f"- Síntese: {_llm(rows)}", "",
             "| falha | esperado | posição | ranking | votos do esperado | status | saudável antes | manifestação |",
             "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        status = str(r.get("status")) + (f" ({r['abstain_reason']})" if r.get("abstain_reason") else "")
        classes = (r.get("manifestacao") or {}).get("classificacao") or "indeterminado"
        lines.append(
            f"| {r['falha']} | {r['expected_service'].replace('teastore-', '')} | {r.get('rank') or '—'} | "
            f"{', '.join(s.replace('teastore-', '') for s in r.get('ranking') or [])} | "
            f"{'+'.join(r.get('expected_votes') or []) or '—'} | {status} | {r.get('health_pre_ok')} | {classes} |")
    with open(os.path.join(run_dir, "resumo.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines[:5]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
