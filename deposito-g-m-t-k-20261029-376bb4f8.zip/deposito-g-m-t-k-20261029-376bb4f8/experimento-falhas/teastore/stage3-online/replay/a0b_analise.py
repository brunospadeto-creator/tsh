#!/usr/bin/env python3
"""Leitura da a0-b na base limpa do protocolo do consenso.

Compara a0-b × a0 × d9 × d9-k (F1@1/2/3 com portão; top-1/2/3 sabendo que é falha; alarme; f/h/g), McNemar
pareado, e recalcula o v-cons com a a0-b no lugar da a0-p (n = 5, pesos por confiabilidade).
Saída: `resultados/protocolo-consenso/a0b.md`.

Uso: replay/a0b_analise.py
"""
from __future__ import annotations

import os
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import consenso as C  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812


def _linha(nome: str, v: list[dict[str, Any]], inv: dict[str, Any]) -> str:
    cel = []
    for g in ("fhg", "fh", "g"):
        pc = A.por_cenario([r for r in v if inv[r["cenario"]]["grupo"] in g], inv)
        cs = list(pc.values())
        est = [x for x in cs if x.get("n_est")]
        o = [sum(x[f"o{k}"] / x["n_est"] for x in est) / len(est) for k in (1, 2, 3)]
        cel.append((A.f1(cs, 1), A.f1(cs, 2), A.f1(cs, 3), *o, A._taxa(cs, "alarme", "n_nor")))
    t, d, g = cel
    grupos = C._por_grupo(v, inv)
    return (f"| {nome} | {t[0]:.3f} | {t[1]:.3f} | {t[2]:.3f} | {t[3]:.0%} | {t[4]:.0%} | {t[5]:.0%} | "
            f"{t[6]:.1%} | {d[0]:.3f} | {d[3]:.0%} | {g[0]:.3f} | {g[3]:.0%} | {grupos['f']:.0%} | {grupos['h']:.0%} |")


def main() -> int:
    inv = A._inv()
    rs, _fora = C.base(inv)
    rs += [r for r in C._novos(inv, os.path.join(C.SAIDA, "limpo-a0b"), "*.jsonl.gz")
           if (r["cenario"], r["t"]) not in _fora]
    serie = C._series(rs)
    d9k = C.variante_persistente(serie, "d9-k", 1, "d9-k", True)
    a0p = C.variante_persistente(serie, "a0", 5, "a0-p")
    a0bp = C.variante_persistente(serie, "a0-b", 5, "a0-b-p")
    pm: dict[str, list[dict[str, Any]]] = {}
    for r in rs:
        pm.setdefault(r["modo"], []).append(r)
    s2 = dict(serie)
    for v in (d9k, a0p, a0bp):
        s2.update(C._series(v))
    dev = {inv[c]["tipo"] for c in inv if inv[c]["grupo"] != "g"}
    votos = {}
    for nome, terceiro in (("v-cons (a0-p, §42.70)", "a0-p"), ("v-cons-b (a0-b no lugar da a0-p)", "a0-b-p")):
        vs = ["d9-k", terceiro, "d6"]
        sr = {m: [r for (mm, _c, _p), lst in s2.items() if mm == m for r in lst] for m in vs}
        votos[nome] = C.votar(s2, inv, vs, 5, C._pesos_conf(sr, inv, vs, dev), d9k, nome)
    finais = {**votos, "d9-k": d9k, "d9": pm["d9"], "a0": pm["a0"], "a0-b": pm["a0-b"], "a0-b-p (n=5)": a0bp,
              "d6": pm["d6"]}
    out = ["# a0-b — a0 calibrada só pela baseline (PROTOCOLO-A0B.md)", "",
           "Base limpa (50 cenários com traces no estável). Nenhum parâmetro da a0-b usa falha: todos os cenários são "
           "teste. 'sabendo' = top-k com oráculo, média por cenário. g exploratório para os demais modos.", "",
           "| modo | F1@1 | F1@2 | F1@3 | sabendo top-1 | top-2 | top-3 | alarme | F1@1 dev | sabendo dev | "
           "F1@1 g | sabendo g | f | h |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    out += [_linha(m, v, inv) for m, v in finais.items()]

    def maj(v: list[dict[str, Any]]) -> dict[str, bool]:
        return {c: x["o1"] / x["n_est"] > 0.5 for (_m, c), x in A.por_cenario(v, inv).items() if x.get("n_est")}
    out += ["", "## McNemar pareado (acerto majoritário sabendo que é falha)", "",
            "| comparação | grupo | cenários | só o 1º | só o 2º | p |", "|---|---|---|---|---|---|"]
    for a_, b_ in (("a0-b", "a0"), ("a0-b", "d9"), ("v-cons-b (a0-b no lugar da a0-p)", "v-cons (a0-p, §42.70)"),
                   ("v-cons-b (a0-b no lugar da a0-p)", "d9")):
        ma, mb = maj(finais[a_]), maj(finais[b_])
        for grupos, rot in (("fh", "dev"), ("g", "g"), ("fhg", "todos")):
            cs = sorted(c for c in set(ma) & set(mb) if inv[c]["grupo"] in grupos)
            n01, n10, p = A._mcnemar([ma[c] for c in cs], [mb[c] for c in cs])
            out.append(f"| {a_} × {b_} | {rot} | {len(cs)} | {n01} | {n10} | {p:.3f} |")
    gb, ga = C._por_grupo(pm["a0-b"], inv)["fhg"], C._por_grupo(pm["a0"], inv)["fhg"]
    out += ["", f"Critério (§3): a0-b {gb:.0%} × a0 {ga:.0%} sabendo que é falha (todos) → "
            + ("**sobrevive** (≥ a0 − 5 p.p.)" if gb >= ga - 0.05 else "**não sobrevive** (< a0 − 5 p.p.)") + "."]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(C.SAIDA, "a0b.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
