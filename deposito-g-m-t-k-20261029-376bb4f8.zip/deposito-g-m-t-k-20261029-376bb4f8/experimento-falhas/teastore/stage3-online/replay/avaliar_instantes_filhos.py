#!/usr/bin/env python3
"""Os filhos da Parte V por instante, **só em desenvolvimento** (f, h).

Primeiro teste dos oito modos novos (a0-k, a0-d, d2c-r, d2c-cp, d6-k, d6-u, d9-2h, d9+m), com a mesma
regra de contagem de `metricas_instantes` (estável: TP se o esperado é o topo; normal: decidiu = alarme).
Os g não são lidos.

**Referência travada no estável.** Os modos com referência da própria sessão (`lookback`) "habituam" à
falha quando a referência inteira já está sob falha. A d5/d9 resolvem isso com a trava do avaliador
sequencial; aqui o equivalente é dar a cada instante estável, como lookback, os eventos do **pré-falha**
(até o fim do período normal) **deslocados no tempo** para terminar no início da janela — a referência que
a trava teria fixado ao abrir. Vale para traces e eventos K8s. Nos instantes normais o lookback é o real.

Configuração: a do sistema (`entry_services`, `dependencias_sem_span`); portão da d9-2h/d9+m = o da d9
escolhido em dev (L=1.5, E=0.1, dano off, R=150); d6-k/d6-u sobre o artefato d2c (`-w120`) com q = 1e-50
(a emenda 1 com o L escolhido em dev); d2c-r com q = 1e-50. Sem métricas (só o h3 tem pacotes contínuos):
a a0-d e a d9+m rodam sem o canal de métricas.

Saída: `resultados/instantes-filhos/<RUN>__<falha>.jsonl.gz` + `resumo.md`.

Uso: replay/avaliar_instantes_filhos.py [--jobs 16] [--passo 15]
"""
from __future__ import annotations

import argparse
import copy
import dataclasses
import datetime
import glob
import gzip
import json
import os
import re
import sys
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import avaliar_instantes as AI  # noqa: E402, N812
import diagnostico_dev as DD  # noqa: E402, N812
import metricas_d8d9 as M8  # noqa: E402, N812
import metricas_instantes as M  # noqa: E402, N812
import preparar_baseline_abordagens as P  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import (  # noqa: E402
    a0d_regua,
    a0k_k8s,
    d2ccp_ponto_mudanca,
    d2cr_nulo_rolante,
    d6k_aresta,
    d6u_uniao,
    d9_2h_grafo,
    d9m_grafo,
)
from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: E402

SAIDA_PADRAO = os.path.join(R.RESULTADOS, "instantes-filhos")
LOOKBACK_SEG = 600
SISTEMA = {"entry_services": P.ENTRY_SERVICES, **P.CFG_SISTEMA_MODOS_C}
PORTAO_D9 = {"limiar": 1.5, "limiar_erro": 0.10, "limiar_dano_lat": None, "ref_seg": 150}
Q_D2C = 1e-50
MODOS: dict[str, tuple[Any, dict[str, Any], bool]] = {   # nome -> (módulo, cfg, usa artefato d2c)
    "a0-k": (a0k_k8s, {}, False),
    "a0-d": (a0d_regua, {}, False),
    "d2c-r": (d2cr_nulo_rolante, {"q": Q_D2C}, False),
    "d2c-cp": (d2ccp_ponto_mudanca, {}, False),
    "d6-k": (d6k_aresta, {}, True),
    "d6-u": (d6u_uniao, {}, True),
    "d9-2h": (d9_2h_grafo, PORTAO_D9, False),
    "d9+m": (d9m_grafo, PORTAO_D9, False),
}


def _k8s_dicts(case_dir: str) -> list[dict[str, Any]]:
    """Eventos K8s do cenário no formato do coletor (`ts` = último, `res`, `reason`, `count`) + `first_ts`."""
    caminho = os.path.join(case_dir, "k8s_events_cluster.json")
    if not os.path.exists(caminho):
        return []
    saida = []
    for it in R._load(caminho).get("items") or []:
        nome = (it.get("involvedObject") or {}).get("name") or ""
        m = re.match(r"^(teastore-[a-z]+)", nome)
        ini = it.get("firstTimestamp") or it.get("eventTime") or (it.get("metadata") or {}).get("creationTimestamp")
        if m and ini:
            saida.append({"first_ts": AI._utc(ini), "ts": AI._utc(it.get("lastTimestamp") or ini), "res": m.group(1),
                          "reason": it.get("reason") or "", "count": int(it.get("count") or 1)})
    return saida


def _visao_em(eventos: list[dict[str, Any]], t: datetime.datetime) -> list[dict[str, Any]]:
    """O que o coletor veria no instante `t`: eventos já iniciados, cortados em `t` com o `count` proporcional."""
    saida = []
    for e in eventos:
        if e["first_ts"] > t:
            continue
        ts = min(e["ts"], t)
        dur = (e["ts"] - e["first_ts"]).total_seconds()
        frac = (ts - e["first_ts"]).total_seconds() / dur if dur > 0 else 1.0
        saida.append({**e, "ts": ts, "count": max(1, round(e["count"] * frac))})
    return saida


def _a_partir_de(eventos: list[dict[str, Any]], inicio: datetime.datetime) -> list[dict[str, Any]]:
    """Só a parte dos eventos depois de `inicio`, com o `count` proporcional (a referência travada fica sem eles)."""
    saida = []
    for e in eventos:
        if e["ts"] < inicio:
            continue
        dur = (e["ts"] - e["first_ts"]).total_seconds()
        novo_ini = max(e["first_ts"], inicio)
        frac = (e["ts"] - novo_ini).total_seconds() / dur if dur > 0 else 1.0
        saida.append({**e, "first_ts": novo_ini, "count": max(1, round(e["count"] * frac))})
    return saida


def _iso(eventos: list[dict[str, Any]], delta: datetime.timedelta = datetime.timedelta(0)) -> list[dict[str, Any]]:
    return [{**e, "ts": (e["ts"] + delta).isoformat(), "first_ts": (e["first_ts"] + delta).isoformat()}
            for e in eventos]


def _deslocar_traces(eventos: list[Any], delta_us: int) -> list[Any]:
    return [dataclasses.replace(e, start_us=e.start_us + delta_us) for e in eventos]


def _artefato_d2c(case_dir: str) -> dict[str, Any]:
    colecao = R._load(os.path.join(os.path.dirname(case_dir), "manifest.json"))["collection_id"]
    with open(P.caminho_artefato(colecao, "d2c", "-w120")) as f:
        art = json.load(f)
    art = copy.deepcopy(art)
    art.setdefault("calibracao", {}).update({"q": Q_D2C, "fp_alvo": None})
    return art


def rodar_caso(job: tuple[str, float, str]) -> str:
    case_dir, passo, saida = job
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência ou pacotes -- fora"
    t0 = time.monotonic()
    eventos = AI.eventos_do_caso(case_dir)
    k8s = _k8s_dicts(case_dir)
    art_d2c = _artefato_d2c(case_dir)
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=LOOKBACK_SEG), fim_normal))
    pre_k8s = _visao_em(k8s, fim_normal)
    linhas = []
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, passo):
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if periodo == "estavel":   # trava: a referência é o pré-falha, deslocado para terminar no início da janela
            delta = janela[0] - fim_normal
            lookback = _deslocar_traces(pre_falha, int(delta.total_seconds() * 1e6))
            k8s_todos = _iso(pre_k8s, delta) + _iso(_a_partir_de(_visao_em(k8s, t), janela[0]))
        else:   # a visão real do coletor em `t` (a a0-k reparte cada evento entre referência e janela)
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=LOOKBACK_SEG), janela[0]))
            k8s_todos = _iso(_visao_em(k8s, t))
        entrada = EntradaIncidente(
            incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
            traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=k8s_todos,
            config_sistema={"entry_services": P.ENTRY_SERVICES})
        for nome, (mod, cfg, usa_d2c) in MODOS.items():
            try:
                d = mod.decidir(entrada, art_d2c if usa_d2c else {}, {**SISTEMA, **cfg})
                linha = {"status": d.status, "motivo": d.motivo_abstencao,
                         "ranking": [i.servico for i in d.ranking][:3]}
            except Exception as exc:  # noqa: BLE001 - um instante quebrado não derruba o cenário
                linha = {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}"[:200], "ranking": []}
            linhas.append(json.dumps({"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat(),
                                      "modo": nome, "n_traces": len({e.case_id for e in dentro}), **linha}))
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def resumo(saida: str) -> str:
    por: dict[str, dict[str, dict[str, int]]] = defaultdict(lambda: defaultdict(lambda: dict.fromkeys(M8.CAMPOS, 0)))
    falhas: dict[str, int] = defaultdict(int)
    for arq in sorted(glob.glob(os.path.join(saida, "*.jsonl.gz"))):
        with gzip.open(arq, "rt") as f:
            for x in f:
                if not x.strip():
                    continue
                r = json.loads(x)
                esp = M.esperado(r["run_id"], r["falha"])
                falhas[r["modo"]] += r["status"] == "falhou"
                M8._somar(por[r["modo"]][f"{r['run_id']}/{r['falha']}"], r["periodo"], r["status"] == "decidiu",
                          r["ranking"], esp)
    out = ["# Filhos da Parte V — primeiro teste por instante, só desenvolvimento (f, h)", "",
           f"Gerado por `replay/avaliar_instantes_filhos.py` em {datetime.datetime.now(datetime.UTC):%Y-%m-%dT%H:%MZ}. "
           "Referência travada no pré-falha nos estáveis. Parâmetros de partida (sem grade). Os g não foram lidos. "
           "Referência: d9 F1@1 dev 0,594 (alarme 0%, acerto@1 52%), d2c 0,316 (§42.63).", "",
           "| modo | cenários | F1@1 | F1@3 | alarme normais | decide estáveis | acerto@1 estáveis | falhou |",
           "|---|---|---|---|---|---|---|---|"]
    por_cen_modo: dict[str, dict[str, float]] = defaultdict(dict)
    for modo in MODOS:
        cens = por.get(modo) or {}
        if not cens:
            continue
        tot = M8.somar_campos(list(cens.values()))
        f1, f3 = M.f1(M8.para_contar(tot, 1)), M.f1(M8.para_contar(tot, 3))
        out.append(f"| {modo} | {len(cens)} | {f1:.3f} | {f3:.3f} | "
                   f"{tot['alarme_nor'] / max(1, tot['n_nor']):.1%} | {tot['decide_est'] / max(1, tot['n_est']):.0%} | "
                   f"{tot['tp1'] / max(1, tot['n_est']):.0%} | {falhas[modo]} |")
        for c, v in cens.items():
            por_cen_modo[c][modo] = v["tp1"] / v["n_est"] if v["n_est"] else 0.0
    modos = [m for m in MODOS if por.get(m)]
    out += ["", "## Acerto@1 por cenário (estáveis)", "", "| cenário | gabarito | " + " | ".join(modos) + " |",
            "|---|---|" + "---|" * len(modos)]
    for c in sorted(por_cen_modo):
        run_id, falha = c.split("/", 1)
        out.append(f"| {c} | {M.esperado(run_id, falha).replace('teastore-', '')} | "
                   + " | ".join(f"{por_cen_modo[c].get(m, 0):.0%}" for m in modos) + " |")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--passo", type=float, default=15.0)
    ap.add_argument("--saida", default=SAIDA_PADRAO)
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--falhas")
    ap.add_argument("--so-resumo", action="store_true")
    args = ap.parse_args()
    if not args.so_resumo:
        casos = [c for run in DD.RUNS_DEV for c in sorted(glob.glob(os.path.join(R.RESULTADOS, run, "[fh][0-9]*")))
                 if os.path.isdir(c) and (not args.falhas or os.path.basename(c) in args.falhas.split(","))]
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(rodar_caso, [(c, args.passo, args.saida) for c in casos]):
                print(msg, flush=True)
    texto = resumo(args.saida)
    os.makedirs(args.saida, exist_ok=True)
    with open(os.path.join(args.saida, "resumo.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
