#!/usr/bin/env python3
"""`g-m∨t|mf` (`bases-externas/metricas-rz/PROTOCOLO.md`, iteração 5) **sem mudança** na definitiva do TeaStore.

Mesmo código do RCAEval (`ciclo.escores(..., familia=True)`, `normalizadores`, `tau_gate`, `ranking_rzl`, `_u`);
só o adaptador de métricas é daqui:

- **Métricas:** `metrics_by_entity` dos pacotes de evidência da sessão (`evidence_packages_continuos/` até a
  abertura do incidente e `evidence_packages/` na janela da falha), um pacote a cada 3 s, por pod → **por serviço**
  (média dos pods do serviço no pacote; serviço = nome do pod sem os dois sufixos do ReplicaSet). Correção após a 1ª
  rodada: por pod, o pod recriado pela injeção não tinha referência e o culpado sumia do ranking (top-1 0%). Família = nome da métrica (cpu_usage, cpu_throttled, memoria_*, fs_*,
  latencia_pura_ms). Tempo = `window_end`.
- **Baseline (desvio declarado):** a coleção 32c273a6 só guarda resumos das métricas, sem série. As janelas de
  baseline das métricas são o trecho da própria sessão **antes** do período normal medido (do 1º pacote + 240 s até
  o início do normal, passo 60 s; referência `[t − 720, t − 120)` cortada no 1º pacote), juntando as 24 sessões.
  Nenhum instante medido entra. O portão de traces (`d9-b+c@0.01`) é o já gravado pelo `baseline_dinamica.py`
  (λ e q da baseline 32c273a6).
- **Instantes:** os do `baseline_dinamica.py` (mesma entrada e D0.4). Referência das métricas: estável → os 600 s
  antes do fim do normal (o pré-falha); normal → `[t − 720, t − 120)`.

Saída: `resultados/protocolo-metricas-rz/def/` e `resultado.md`. Uso: replay/metricas_rz_teastore.py [--jobs 24]
"""
from __future__ import annotations

import argparse
import datetime
import glob
import gzip
import json
import os
import sys
import time
import warnings
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import baseline_dinamica as BDT  # noqa: E402, N812
import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import hibrido_d9a as H  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

sys.path.insert(0, os.path.join(SELF_DIR, "..", "..", "..", "..", "bases-externas", "metricas-rz"))
import ciclo as CI  # noqa: E402, N812  (depois dos módulos do replay)

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-metricas-rz")
TRACES = "d9-b+c@0.01"
INICIO_BASELINE = 240
NOVOS = ("m-rzf", "g-m|mf", "g-m∨t|mf", "g-m∧t|mf")


def _ts(s: str) -> float:
    return datetime.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def serie(case_dir: str) -> tuple[Any, Any, list[str]]:
    import numpy as np  # noqa: PLC0415
    import pandas as pd  # noqa: PLC0415
    por: dict[tuple[str, str], dict[float, list[float]]] = {}
    arqs = glob.glob(os.path.join(case_dir, "evidence_packages_continuos", "*.json")) + \
        glob.glob(os.path.join(case_dir, "evidence_packages", "*.json"))
    for arq in arqs:
        with open(arq) as f:
            d = json.load(f)
        t = _ts(d["window_end"])
        for pod, ms in (d.get("metrics_by_entity") or {}).items():
            for m, v in ms.items():
                if isinstance(v, (int, float)):   # por serviço (média dos pods): a falha recria o pod do culpado
                    por.setdefault((pod.rsplit("-", 2)[0], m), {}).setdefault(t, []).append(float(v))
    chaves = sorted(por)
    fams = {f: f"f{i}" for i, f in enumerate(sorted({m for _, m in chaves}))}
    df = pd.concat([pd.Series({t: float(np.mean(v)) for t, v in por[k].items()}, name=i)
                    for i, k in enumerate(chaves)], axis=1).sort_index()
    cols = [f"{svc}_{fams[m]}" for svc, m in chaves]
    return df.index.to_numpy(dtype=float), df.to_numpy(dtype=float), cols


def rodar_caso(case_dir: str) -> dict[str, Any]:
    """Escores das janelas de baseline e dos instantes do caso, e as linhas do portão de traces."""
    warnings.simplefilter("ignore", RuntimeWarning)
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    with gzip.open(os.path.join(BDT.SAIDA, "def", f"{run_id}__{falha}.jsonl.gz"), "rt") as f:
        gate = [json.loads(x) for x in f if x.strip()]
    gate = [r for r in gate if r["modo"] == TRACES]
    per = PR.AI.periodos(case_dir)
    ini_normal, fim_normal = per["normal"][0].timestamp(), per["normal"][1].timestamp()
    tempo, val, cols = serie(case_dir)
    base, inst = {}, {}
    t = tempo[0] + INICIO_BASELINE
    while t <= ini_normal:
        base[str(t)] = CI.escores(tempo, val, cols, t, (t - CI.JANELA - CI.REF, t - CI.JANELA), familia=True)
        t += 60
    for r in gate:
        t = _ts(r["t"])
        ref = (fim_normal - CI.REF, fim_normal) if r["periodo"] == "estavel" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        inst[r["t"]] = CI.escores(tempo, val, cols, t, ref, familia=True)
    return {"run_id": run_id, "falha": falha, "base": base, "inst": inst, "gate": gate}


def gravar(res: list[dict[str, Any]]) -> dict[str, Any]:
    pseudo = [{"periodo": "normal", "na_baseline": True, "grupo": "teastore", "caso": f"{r['run_id']}/{r['falha']}",
               "t": t} for r in res for t in r["base"]]
    es = {(f"{r['run_id']}/{r['falha']}", t): e for r in res for t, e in r["base"].items()}
    norm = CI.normalizadores(pseudo, es)["teastore"]
    tau = CI.tau_gate(pseudo, es, {"teastore": norm})["teastore"]
    os.makedirs(os.path.join(SAIDA, "def"), exist_ok=True)
    for r in res:
        linhas = []
        for g in r["gate"]:
            e = r["inst"][g["t"]]
            rk = CI.ranking_rzl(e, norm)
            gm = max(CI._u(e, norm).values(), default=0.0) >= tau
            gt = g["status"] == "decidiu"
            base = {"run_id": r["run_id"], "falha": r["falha"], "periodo": g["periodo"], "t": g["t"], "forcado": rk}
            for modo, dec in (("m-rzf", bool(rk)), ("g-m|mf", gm and bool(rk)), ("g-m∨t|mf", gm or gt),
                              ("g-m∧t|mf", gm and gt)):
                linhas.append(json.dumps({**base, "modo": modo, "status": "decidiu" if dec else "absteve",
                                          "ranking": rk if dec else []}))
        with gzip.open(os.path.join(SAIDA, "def", f"{r['run_id']}__{r['falha']}.jsonl.gz"), "wt") as f:
            f.write("\n".join(linhas) + "\n")
    cal = {"n_janelas": len(pseudo), "tau": tau, "N": norm}
    with open(os.path.join(SAIDA, "calibracao.json"), "w") as f:
        json.dump(cal, f, indent=1)
    return cal


def analisar(cal: dict[str, Any]) -> str:
    cs = DF.casos(DF.runs())
    inv = H._inv("def", cs)
    rs = C._novos(inv, os.path.join(SAIDA, "def"), "*.jsonl.gz")
    rs += [r for r in C._novos(inv, os.path.join(BDT.SAIDA, "def"), "*.jsonl.gz")
           if r["modo"] in ("d9-k", "d9", TRACES, "d9-k-b+c@0.01")]
    rs += [r for r in C._novos(inv, os.path.join(H.SAIDA, "def"), "*.jsonl.gz") if r["modo"] == "d9-k+a"]
    rs += [{**r, "modo": "v-cons-b"} for r in C._novos(inv, DF.SAIDA, "*.jsonl.gz") if r["modo"] == "v-cons-b-prod"]
    instantes = {(r["cenario"], r["t"]) for r in rs if r["modo"] == "m-rzf"}
    rs = [r for r in rs if (r["cenario"], r["t"]) in instantes]
    pcs: dict[str, dict[str, Any]] = {}
    for (m, c), x in A.por_cenario(rs, inv).items():
        pcs.setdefault(m, {})[c] = x
    out = ["# `g-m∨t|mf` sem mudança — TeaStore definitiva (teste de 10 min, exploratório)", "",
           "`replay/metricas_rz_teastore.py`. Mesmo código do RCAEval; só o adaptador de métricas é daqui. Baseline "
           "das métricas = trecho de cada sessão antes do período normal medido (desvio declarado: a coleção 32c273a6 "
           "não tem série de métricas). Instantes e portão de traces do `baseline_dinamica.py`.", "",
           f"Janelas de baseline das métricas: {cal['n_janelas']}; τ do g-m = {cal['tau']:.3f}; famílias com N: "
           f"{sum(1 for v in cal['N'].values() if v > 0)} de {len(cal['N'])}.", "",
           f"## Definitiva ({len(pcs.get('m-rzf', {}))} cenários, {len(instantes)} instantes)", "",
           "| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |",
           "|---|---|---|---|---|---|---|"]
    for m in ("d9-k", "v-cons-b", "d9-k+a", "d9", "d9-k-b+c@0.01", TRACES, *NOVOS):
        if m not in pcs:
            continue
        r, ic = DF.metricas(pcs[m]), DF._boot(pcs[m], A.f1)
        out.append(f"| {m} | {r['f1']:.3f} [{ic[0]:.3f}–{ic[1]:.3f}] | {r['f2']:.3f} | {r['alarme']:.1%} | "
                   f"{r['abst']:.0%} | {r['o1']:.0%} | {r['o2']:.0%} |")
    out.append("")
    for a, b in (("g-m∨t|mf", "d9-k"), ("g-m∨t|mf", "d9-k+a"), ("g-m∨t|mf", TRACES)):
        if a in pcs and b in pcs:
            sa, sb, p = DF.mcnemar(pcs[a], pcs[b], "tp1")
            out.append(f"- McNemar {a} × {b} (top-1 com portão): só {a} {sa}, só {b} {sb}, p = {p:.3f}")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    t0 = time.monotonic()
    cs = DF.casos(DF.runs())
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    with ProcessPoolExecutor(args.jobs) as ex:
        res = list(ex.map(rodar_caso, cs))
    print(f"{len(res)} cenários em {time.monotonic() - t0:.0f}s", flush=True)
    texto = analisar(gravar(res))
    with open(os.path.join(SAIDA, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
