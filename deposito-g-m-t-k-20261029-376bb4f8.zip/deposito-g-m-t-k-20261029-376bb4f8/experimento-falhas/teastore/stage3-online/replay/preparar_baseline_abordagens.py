#!/usr/bin/env python3
"""Artefatos de baseline dos modos d1–d4 a partir dos backups de traces normais.

Lê `traces_baseline.json.gz` da coleção (só traces **normais**: nenhum caso de falha entra aqui),
monta o insumo comum (`processo.eventos_de_traces_brutos`) e chama `preparar_baseline()` de cada modo
pedido — que inclui a calibração normal × normal por validação cruzada.

Uso (de `experimento-falhas/teastore/stage3-online/`):

    python3 replay/preparar_baseline_abordagens.py --colecoes todas --modos d2
    python3 replay/preparar_baseline_abordagens.py --colecoes d7cd3536 --modos d0_nula,d2

Saída: `resultados/insumos/abordagens-<coleção8>-<modo>.json` e um resumo da calibração no stdout.
"""
from __future__ import annotations

import argparse
import glob
import gzip
import json
import os
import sys
import time
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(SELF_DIR)
REPO_ROOT = os.path.abspath(os.path.join(BASE_DIR, "../../.."))
RESULTADOS = os.path.join(BASE_DIR, "resultados")
INSUMOS = os.path.join(RESULTADOS, "insumos")
sys.path.insert(0, REPO_ROOT)

from src.application.stage3.abordagens import processo, registro  # noqa: E402

# Coleção → backup de traces normais. Os 38 casos usam só estas duas.
# `TEASTORE_BACKUPS`: pasta com os backups `baseline-*/traces_baseline.json.gz` (no depósito, parte 3).
BACKUPS_DIR = os.environ.get("TEASTORE_BACKUPS", "/mnt/gpu-disk/backups-misete")
BACKUPS: dict[str, str] = {
    "d7cd3536": os.path.join(BACKUPS_DIR, "baseline-25m-20260926T081613Z", "traces_baseline.json.gz"),
    "2032361d": os.path.join(RESULTADOS, "coleta-20261001T221019Z", "traces_baseline.json.gz"),
    # baseline longa do hold-out (90 min, HOLDOUT.md)
    "547ba505": os.path.join(BACKUPS_DIR, "baseline-90m-20261003T223714Z", "traces_baseline.json.gz"),
    # baseline da coleta definitiva (90 min, PROTOCOLO-COLETA-DEFINITIVA.md §4)
    "32c273a6": os.path.join(BACKUPS_DIR, "baseline-90m-20261015T165318Z", "traces_baseline.json.gz"),
}
ENTRY_SERVICES = ["teastore-webui"]  # stage3_config.entry_services do sistema (baseline.json)


def caminho_artefato(colecao: str, modo: str, sufixo: str = "") -> str:
    return os.path.join(INSUMOS, f"abordagens-{colecao[:8]}-{modo}{sufixo}.json")


def backup_de(colecao: str) -> str:
    """Backup dos traces normais da coleção: `BACKUPS`, ou o `traces_baseline.json.gz` da coleta que a criou
    (`resultados/coleta-*/collection.id`; coletas com `-c` também gravam o id, mas sem o backup)."""
    if colecao[:8] in BACKUPS:
        return BACKUPS[colecao[:8]]
    for arq in sorted(glob.glob(os.path.join(RESULTADOS, "coleta-*", "collection.id"))):
        with open(arq) as f:
            achou = f.read().strip()[:8] == colecao[:8]
        backup = os.path.join(os.path.dirname(arq), "traces_baseline.json.gz")
        if achou and os.path.exists(backup):
            return backup
    raise SystemExit(f"sem backup de traces da baseline para a coleção {colecao[:8]}")


def carregar_eventos(colecao: str) -> list[Any]:
    with gzip.open(backup_de(colecao)) as f:
        brutos = json.load(f).get("traces") or {}
    return processo.eventos_de_traces_brutos(brutos, ENTRY_SERVICES)


# Configuração de sistema do TeaStore para os modos `c`: o banco não emite span próprio, e o
# span cliente JDBC traz `db.system`, não o nome do serviço. Espelha `stage3_config.modos.<modo>` ao vivo.
CFG_SISTEMA_MODOS_C: dict[str, Any] = {"dependencias_sem_span": {"mysql": "teastore-db"}}


def cfg_do_modo(modo: str, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    """Configuração `stage3_config.modos` do modo: padrão do modo + `fp_alvo` comum."""
    sistema = CFG_SISTEMA_MODOS_C if modo.endswith("c") or modo in {"d6", "d7"} else {}
    return {"fp_alvo": 0.05, **sistema, **(extra or {})}


def preparar(colecao: str, modos: list[str], eventos: list[Any] | None = None,
             extra: dict[str, Any] | None = None, sufixo: str = "") -> dict[str, dict[str, Any]]:
    """`extra`/`sufixo`: variante da avaliação do Stage 3 isolado, gravada ao lado
    do artefato padrão sem sobrescrevê-lo."""
    eventos = eventos if eventos is not None else carregar_eventos(colecao)
    saida: dict[str, dict[str, Any]] = {}
    for modo in modos:
        t0 = time.monotonic()
        artefato = registro.MODOS[modo].preparar_baseline(eventos, [], cfg_do_modo(modo, extra))
        artefato["_preparo"] = {"colecao": colecao, "segundos": round(time.monotonic() - t0, 1),
                                "n_eventos": len(eventos),
                                "n_traces": len({e.case_id for e in eventos})}
        os.makedirs(INSUMOS, exist_ok=True)
        with open(caminho_artefato(colecao, modo, sufixo), "w") as f:
            json.dump(artefato, f, default=str)
        saida[modo] = artefato
    return saida


def carregar_ou_preparar(colecao: str, modo: str) -> dict[str, Any]:
    """O que o replay usa: o artefato gravado, ou prepara do backup se faltar."""
    caminho = caminho_artefato(colecao, modo)
    if os.path.exists(caminho):
        with open(caminho) as f:
            return json.load(f)
    return preparar(colecao, [modo])[modo]


def _linha_calibracao(colecao: str, modo: str, artefato: dict[str, Any]) -> str:
    c = artefato.get("calibracao") or {}
    p = artefato.get("_preparo") or {}
    if "c" in c:  # d3: calibração por série
        return (f"{colecao[:8]} {modo:8s} c={c['c']} m={c['m']} alfa={c['alfa']:g} "
                f"series_normais={c['n_series']} motivo={c.get('motivo') or 'ok'} ({p.get('segundos')}s)")
    if c.get("q") is None:
        return f"{colecao[:8]} {modo:8s} q=None motivo={c.get('motivo')} ({p.get('segundos')}s)"
    estat = sorted(s for s in c.get("estatistica_por_janela") or [] if s is not None)
    return (f"{colecao[:8]} {modo:8s} q={c['q']:.3g} decidindo={c['n_decidindo']}/{c['n_validas']} "
            f"menor_estat={estat[0]:.3g} mediana={estat[len(estat) // 2]:.3g} "
            f"traces={p.get('n_traces')} ({p.get('segundos')}s)")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--colecoes", default="todas", help="ids (8 chars) separados por vírgula, ou 'todas'")
    ap.add_argument("--modos", required=True, help="modos separados por vírgula (d0_nula, d2, ...) ou 'todos'")
    ap.add_argument("--janela-seg", type=float, help="tamanho_janela_seg da calibração (padrão: o do modo)")
    ap.add_argument("--fp-alvo", type=float, help="fp_alvo (padrão 0.05)")
    ap.add_argument("--sufixo", default="", help="sufixo do arquivo do artefato, ex.: -w120")
    args = ap.parse_args()
    extra = {k: v for k, v in {"tamanho_janela_seg": args.janela_seg, "fp_alvo": args.fp_alvo}.items()
             if v is not None}
    colecoes = list(BACKUPS) if args.colecoes == "todas" else [c[:8] for c in args.colecoes.split(",")]
    modos = list(registro.MODOS) if args.modos == "todos" else args.modos.split(",")
    desconhecidos = [m for m in modos if m not in registro.MODOS]
    if desconhecidos:
        raise SystemExit(f"modos sem implementação: {desconhecidos}")
    for colecao in colecoes:
        artefatos = preparar(colecao, modos, extra=extra, sufixo=args.sufixo)
        for modo, artefato in artefatos.items():
            print(_linha_calibracao(colecao, modo, artefato))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
