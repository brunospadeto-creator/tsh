#!/usr/bin/env python3
"""Análise do protocolo rápido (`experimento-falhas/teastore/PROTOCOLO-RAPIDO.md`).

Registros normalizados `{cenario, modo, periodo, t, seg, decidiu, ranking, forcado}`:
`seg` = segundos desde o início do período; `decidiu`/`ranking` = parâmetro final (com portão);
`forcado` = ranking da decisão forçada (oráculo).

Fontes: gravados a 15 s (`instantes/`: d1–d7 pelo registro do fp 0,20 + limiar L; `instantes-d9/`;
`instantes-filhos/`; a0 `k=3`) e os novos a 60 s (`protocolo-rapido/modos/`, `protocolo-rapido/a0/`).

Subcomandos: `amostragem` (E2/E3), `vies` (V1), `e1` (pacotes montados da a0), `final` (tabela única, S, V2, V3),
`unificado` (o mesmo sobre o avaliador unificado da opção A + comparação com o mecanismo antigo).

Uso: replay/protocolo_rapido_analise.py amostragem | vies | e1 | final | unificado
"""
from __future__ import annotations

import argparse
import datetime
import glob
import gzip
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import metricas_instantes as M  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812

INV_ARQ = os.path.join(PR.SAIDA, "inventario.json")
L_FINAL = {"d1": 1e-10, "d1c": 1e-200, "d2": 1e-20, "d2c": 1e-50, "d4": 1e-05, "d4c": 1e-05, "d6": 1e-50,
           "d7": 1e-20}
D9_PARAM = "L=1.5,E=0.1,D=off,R=150"
D5_PARAM = "L=1.5,E=0.05,D=off,R=150"
PUBLICADO_DEV = {"d9": 0.594, "d2c": 0.316, "d6-u": 0.337, "d6-k": 0.320, "d2c-r": 0.256, "d9+m": 0.218,
                 "d2c-cp": 0.123, "a0-k": 0.105, "a0-d": 0.105, "d9-2h": 0.075}
PAIS = {"a0-k": "a0", "a0-d": "a0", "d2c-r": "d2c", "d2c-cp": "d2c", "d6-k": "d6", "d6-u": "d6",
        "d9-2h": "d9", "d9+m": "d9"}


def _inv() -> dict[str, Any]:
    with open(INV_ARQ) as f:
        return json.load(f)


def _utc(s: str) -> datetime.datetime:
    return datetime.datetime.fromisoformat(s)


def _seg(inv: dict[str, Any], cen: str, periodo: str, t: str) -> float:
    i = inv[cen]
    if periodo == "normal":
        ini = _utc(i["fim_normal"]) - datetime.timedelta(seconds=i["periodos_seg"]["normal"])
    elif periodo == "transicao":
        ini = _utc(i["fim_normal"])
    else:
        ini = _utc(i["inicio_estavel"])
    return round((_utc(t) - ini).total_seconds())


def _linhas(arq: str):
    abrir = gzip.open if arq.endswith(".gz") else open
    with abrir(arq, "rt") as f:
        for x in f:
            if x.strip():
                yield json.loads(x)


def gravados(inv: dict[str, Any], periodos: tuple[str, ...] = ("normal", "estavel")) -> list[dict[str, Any]]:
    res = PR.R.RESULTADOS
    out: list[dict[str, Any]] = []

    def add(r: dict[str, Any], modo: str, decidiu: bool, ranking: list[str], forcado: list[str]) -> None:
        cen = f"{r['run_id']}/{r['falha']}"
        if cen in inv and r["periodo"] in periodos:
            out.append({"cenario": cen, "modo": modo, "periodo": r["periodo"], "t": r["t"],
                        "seg": _seg(inv, cen, r["periodo"], r["t"]), "decidiu": decidiu,
                        "ranking": ranking if decidiu else [], "forcado": forcado})

    for arq in sorted(glob.glob(os.path.join(res, "instantes", "*.jsonl"))):
        nome = os.path.basename(arq)
        if nome.endswith("__d5.jsonl"):
            for r in _linhas(arq):
                if r.get("param") == D5_PARAM:
                    add(r, "d5", r["status"] == "decidiu", r["ranking"], [])
            continue
        if nome.endswith("__a0.jsonl"):
            for r in _linhas(arq):
                if r.get("param") == "k=3":
                    add(r, "a0", r["status"] == "decidiu", r["ranking"], r["ranking"])
            continue
        for r in _linhas(arq):
            modo = r["modo"]
            if r.get("fp_alvo") != M.FP_FROUXO:
                continue
            if modo == "d3":
                add(r, "d3", r["status"] == "decidiu", r["ranking"], r["ranking"])
                continue
            if modo == "d6" and r.get("variante") != "a=1":
                continue
            if modo not in L_FINAL:
                continue
            est = r.get("estatistica")
            ok = r["status"] == "decidiu" and est is not None and est <= L_FINAL[modo]
            if modo == "d7":
                sim = r.get("similaridade_topo")
                ok = ok and sim is not None and sim >= 0.5
            add(r, modo, ok, r["ranking"], r["ranking"] if r["status"] == "decidiu" else [])
    for arq in sorted(glob.glob(os.path.join(res, "instantes-d9", "*__d9.jsonl.gz"))):
        for r in _linhas(arq):
            if r.get("param") == D9_PARAM:
                rk = (r.get("rankings") or {}).get("residuo_1") or []
                add(r, "d9", r["status"] == "decidiu" and bool(rk), rk, [])
    for arq in sorted(glob.glob(os.path.join(res, "instantes-filhos", "*.jsonl.gz"))):
        for r in _linhas(arq):
            add(r, r["modo"], r["status"] == "decidiu", r["ranking"], [])
    return out


def novos(inv: dict[str, Any], sub: str = "modos", padrao: str = "*.jsonl.gz",
          modos: set[str] | None = None) -> list[dict[str, Any]]:
    out = []
    for arq in sorted(glob.glob(os.path.join(PR.SAIDA, sub, padrao))):
        for r in _linhas(arq):
            cen = f"{r['run_id']}/{r['falha']}"
            if r["periodo"] not in ("normal", "estavel") or (modos and r["modo"] not in modos):
                continue
            if r.get("param") not in (None, "k=3"):
                continue
            dec = r["status"] == "decidiu"
            out.append({"cenario": cen, "modo": r["modo"], "periodo": r["periodo"], "t": r["t"],
                        "seg": _seg(inv, cen, r["periodo"], r["t"]), "decidiu": dec,
                        "ranking": r["ranking"] if dec else [],
                        "forcado": r["forcado"] if "forcado" in r else (r["ranking"] if dec else [])})
    return out


def base_final(inv: dict[str, Any]) -> list[dict[str, Any]]:
    """A base única: d1–d7 gravados (60 s; d3 a 15 s, E2), novos a 60 s (d9+m a 15 s, E2) e a a0 montada."""
    grav = gravados(inv)
    rs = sub60([r for r in grav if r["modo"] in ("d1", "d1c", "d2", "d4", "d4c", "d7")])
    rs += [r for r in grav if r["modo"] == "d3"]
    quinze = novos(inv, "modos15")
    trocar = {r["modo"] for r in quinze}
    rs += [r for r in novos(inv) if r["modo"] not in trocar] + quinze
    rs += novos(inv, "a0", "*__a0.jsonl")
    return rs


def base_unificada(inv: dict[str, Any]) -> list[dict[str, Any]]:
    """Opção A: todos os modos de traces do avaliador unificado (60 s; d3 e d9+m a 15 s, E2) + a a0."""
    quinze = novos(inv, "unificado15")
    trocar = {r["modo"] for r in quinze}
    return ([r for r in novos(inv, "unificado") if r["modo"] not in trocar] + quinze
            + novos(inv, "a0", "*__a0.jsonl"))


def comparacao(inv: dict[str, Any], antigo: list[dict[str, Any]], novo: list[dict[str, Any]]) -> list[str]:
    """Mesmo modo nos dois mecanismos: F1@1, oráculo@1 e cenários que mudam o acerto majoritário."""
    pa, pn = por_cenario(antigo, inv), por_cenario(novo, inv)
    modos = sorted({m for m, _ in pa} & {m for m, _ in pn})
    out = ["", "## Mecanismo antigo (§42.66) × avaliador unificado, mesmo modo", "",
           "| modo | F1@1 antigo | F1@1 unificado | oráculo@1 antigo | oráculo@1 unificado | "
           "cenários que mudam (com portão) | cenários que mudam (oráculo) |", "|---|---|---|---|---|---|---|"]
    for m in modos:
        cens = sorted(c for mm, c in pa if mm == m and (m, c) in pn)
        a, n = [pa[(m, c)] for c in cens], [pn[(m, c)] for c in cens]
        mg = sum(_maj(pa[(m, c)], "tp1") != _maj(pn[(m, c)], "tp1") for c in cens)
        mo = sum(_maj(pa[(m, c)], "o1") != _maj(pn[(m, c)], "o1") for c in cens)
        out.append(f"| {m} | {f1(a):.3f} | {f1(n):.3f} | {_taxa(a, 'o1', 'n_est'):.0%} | "
                   f"{_taxa(n, 'o1', 'n_est'):.0%} | {mg} | {mo} |")
    return out


def e1() -> str:
    """E1: a0 com pacotes montados × a0 com pacotes reais (sem métricas), nos 13 cenários com pacotes."""
    inv = _inv()
    pc = por_cenario(novos(inv, "a0", "*__a0.jsonl") + novos(inv, "a0-real", "*__a0r.jsonl"), inv)
    out = ["## E1 — a0 com pacotes montados × reais (sem métricas, k=3, 60 s)", "",
           "| cenário | acerto@1 montados | acerto@1 reais | alarme montados | alarme reais |", "|---|---|---|---|---|"]
    muda = 0
    for c in sorted({c for m, c in pc if m == "a0r"}):
        a, b = pc.get(("a0", c), {}), pc.get(("a0r", c), {})
        muda += _maj(a, "tp1") != _maj(b, "tp1")
        out.append(f"| {c} | {_taxa([a], 'tp1', 'n_est'):.0%} | {_taxa([b], 'tp1', 'n_est'):.0%} | "
                   f"{_taxa([a], 'alarme', 'n_nor'):.0%} | {_taxa([b], 'alarme', 'n_nor'):.0%} |")
    out += ["", f"Cenários que mudam o acerto@1 majoritário: {muda} → E1 {'ok' if muda <= 1 else 'FALHA'} (≤ 1)."]
    return "\n".join(out) + "\n"


def sub60(rs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [r for r in rs if r["seg"] % 60 == 0]


def por_cenario(rs: list[dict[str, Any]], inv: dict[str, Any]) -> dict[tuple[str, str], dict[str, float]]:
    """(modo, cenário) -> contagens e taxas."""
    acc: dict[tuple[str, str], Counter] = defaultdict(Counter)
    for r in rs:
        c = acc[(r["modo"], r["cenario"])]
        esp = inv[r["cenario"]]["esperado"]
        if r["periodo"] == "normal":
            c["n_nor"] += 1
            c["alarme"] += r["decidiu"]
        else:
            c["n_est"] += 1
            c["dec"] += r["decidiu"]
            c["tp1"] += r["decidiu"] and r["ranking"][:1] == [esp]
            c["tp2"] += r["decidiu"] and esp in r["ranking"][:2]
            c["tp3"] += r["decidiu"] and esp in r["ranking"][:3]
            c["o1"] += r["forcado"][:1] == [esp]
            c["o2"] += esp in r["forcado"][:2]
            c["o3"] += esp in r["forcado"][:3]
    return {k: dict(v) for k, v in acc.items()}


def f1(cs: list[dict[str, float]], k: int = 1) -> float:
    tp = sum(c.get(f"tp{k}", 0) for c in cs)
    dec_err = sum(c.get("dec", 0) - c.get(f"tp{k}", 0) for c in cs)
    fn = sum(c.get("n_est", 0) - c.get(f"tp{k}", 0) for c in cs)
    fp = dec_err + sum(c.get("alarme", 0) for c in cs)
    den = 2 * tp + fp + fn
    return 2 * tp / den if den else 0.0


def _taxa(cs: list[dict[str, float]], num: str, den: str) -> float:
    d = sum(c.get(den, 0) for c in cs)
    return sum(c.get(num, 0) for c in cs) / d if d else float("nan")


def _maj(c: dict[str, float], chave: str) -> bool:
    return c.get("n_est", 0) > 0 and c.get(chave, 0) / c["n_est"] > 0.5


def amostragem() -> str:
    inv = _inv()
    rs = gravados(inv)
    cheio, red = por_cenario(rs, inv), por_cenario(sub60(rs), inv)
    modos = sorted({m for m, _ in cheio})
    out = ["## E2/E3 — amostragem reduzida (15 s × 60 s) e reprodução, sobre o gravado", "",
           "| modo | cenários | F1@1 dev 15 s | publicado dev | F1@1 dev 60 s | F1@1 todos 15 s | F1@1 todos 60 s | "
           "acerto@1 15 s | acerto@1 60 s | oráculo@1 15 s | oráculo@1 60 s | cenários que mudam (maj.) | E2 |",
           "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for m in modos:
        cens = sorted(c for mm, c in cheio if mm == m)
        dev = [c for c in cens if inv[c]["grupo"] != "g"]
        a = [cheio[(m, c)] for c in cens]
        b = [red.get((m, c), {}) for c in cens]
        ad, bd = [cheio[(m, c)] for c in dev], [red.get((m, c), {}) for c in dev]
        mudam = sum(_maj(cheio[(m, c)], "tp1") != _maj(red.get((m, c), {}), "tp1") for c in cens)
        d_f1, d_ac = abs(f1(a) - f1(b)), abs(_taxa(a, "tp1", "n_est") - _taxa(b, "tp1", "n_est"))
        ok = d_f1 <= 0.03 and d_ac <= 0.05 and mudam <= 1
        pub = PUBLICADO_DEV.get(m)
        out.append(f"| {m} | {len(cens)} | {f1(ad):.3f} | {pub if pub is not None else '—'} | {f1(bd):.3f} | "
                   f"{f1(a):.3f} | {f1(b):.3f} | {_taxa(a, 'tp1', 'n_est'):.0%} | {_taxa(b, 'tp1', 'n_est'):.0%} | "
                   f"{_taxa(a, 'o1', 'n_est'):.0%} | {_taxa(b, 'o1', 'n_est'):.0%} | {mudam} | "
                   f"{'ok' if ok else 'FALHA'} |")
    return "\n".join(out) + "\n"


def vies() -> str:
    """V1: acerto@1 da a0 (k=3, 15 s, 12 g) pelo tempo desde a injeção (início da transição)."""
    inv = _inv()
    rs = gravados(inv, ("transicao", "estavel"))
    rs = [r for r in rs if r["modo"] == "a0" and inv[r["cenario"]]["grupo"] == "g"]
    faixas: dict[str, list[bool]] = defaultdict(list)
    por_cen: dict[str, dict[str, list[bool]]] = defaultdict(lambda: defaultdict(list))
    for r in rs:
        esp = inv[r["cenario"]]["esperado"]
        ok = r["decidiu"] and r["ranking"][:1] == [esp]
        if r["periodo"] == "transicao":
            faixa = "transição 0–120 s" if r["seg"] <= 120 else "transição > 120 s"
        else:
            faixa = "estável"
        faixas[faixa].append(ok)
        por_cen[r["cenario"]][faixa].append(ok)
    out = ["## V1 — a0 (k=3) por tempo desde a injeção, 12 g, passo 15 s", "",
           "| faixa | instantes | acerto@1 |", "|---|---|---|"]
    for f in ("transição 0–120 s", "transição > 120 s", "estável"):
        v = faixas.get(f) or []
        out.append(f"| {f} | {len(v)} | {sum(v) / len(v):.0%} |" if v else f"| {f} | 0 | — |")
    ini, est = faixas.get("transição 0–120 s") or [], faixas.get("estável") or []
    if ini and est:
        dif = sum(ini) / len(ini) - sum(est) / len(est)
        out += ["", f"Diferença (0–120 s) − estável = {dif:+.0%} → V1 {'VALE' if dif >= 0.30 else 'não vale'} "
                "(critério ≥ +30 p.p.)."]
    out += ["", "| cenário | 0–120 s | > 120 s | estável |", "|---|---|---|---|"]
    for c in sorted(por_cen):
        cel = [por_cen[c].get(f) or [] for f in ("transição 0–120 s", "transição > 120 s", "estável")]
        out.append(f"| {c} | " + " | ".join(f"{sum(v) / len(v):.0%}" if v else "—" for v in cel) + " |")
    return "\n".join(out) + "\n"


def _bootstrap_tipo(valores: dict[str, float], inv: dict[str, Any], n: int = 2000) -> tuple[float, float]:
    """IC 95% da média por cenário, reamostrando tipos de falha (as repetições do tipo vão juntas)."""
    por_tipo: dict[str, list[float]] = defaultdict(list)
    for c, v in valores.items():
        por_tipo[inv[c]["tipo"]].append(v)
    tipos = sorted(por_tipo)
    if not tipos:
        return float("nan"), float("nan")
    rnd = random.Random(M.SEMENTE)
    meds = []
    for _ in range(n):
        amostra = [v for t in (rnd.choice(tipos) for _ in tipos) for v in por_tipo[t]]
        meds.append(sum(amostra) / len(amostra))
    meds.sort()
    return meds[int(0.025 * n)], meds[int(0.975 * n) - 1]


def _mcnemar(a: list[bool], b: list[bool]) -> tuple[int, int, float]:
    """(só a acerta, só b acerta, p bilateral exato)."""
    n01 = sum(x and not y for x, y in zip(a, b))
    n10 = sum(y and not x for x, y in zip(a, b))
    n = n01 + n10
    if n == 0:
        return n01, n10, 1.0
    k = min(n01, n10)
    p = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n * 2
    return n01, n10, min(1.0, p)


PORTOES = ("d9", "d5", "d2c", "d6", "d6-u", "d2c-r", "d9-2h", "d9+m")


def pares(rs: list[dict[str, Any]], inv: dict[str, Any], localizadores: list[str]) -> list[str]:
    """D: portão de um modo × ranking forçado de outro, nos mesmos instantes (60 s)."""
    idx = {(r["modo"], r["cenario"], r["periodo"], r["t"]): r for r in rs}
    chaves = sorted({k[1:] for k in idx})
    out = ["", "## D — detecção (portão) × localização (ranking forçado), mesmos instantes", "",
           "| portão \\ localizador | alarme normais | decide estáveis | " + " | ".join(localizadores) + " |",
           "|---|---|---|" + "---|" * len(localizadores)]
    for g in PORTOES:
        celulas, base = [], None
        for loc in localizadores:
            sint = []
            for k in chaves:
                rg, rl = idx.get((g, *k)), idx.get((loc, *k))
                if rg and rl:
                    sint.append({**rl, "modo": "par", "decidiu": rg["decidiu"],
                                 "ranking": rl["forcado"] if rg["decidiu"] else []})
            cs = list(por_cenario(sint, inv).values())
            celulas.append(f"{f1(cs):.3f}" if cs else "—")
            if base is None and cs:
                base = (_taxa(cs, "alarme", "n_nor"), _taxa(cs, "dec", "n_est"))
        if base:
            out.append(f"| {g} | {base[0]:.1%} | {base[1]:.0%} | " + " | ".join(celulas) + " |")
    out.append("")
    out.append("Células: F1@1 do par em todos os cenários onde os dois existem (a0 só onde há a0).")
    return out


def tabela_completa(pc: dict[tuple[str, str], dict[str, float]], inv: dict[str, Any],
                    o1: dict[str, dict[str, float]]) -> list[str]:
    """Todos os modos por F1@1 com portão; F1@2; F1@1/F1@2 sabendo que é falha (= acerto com oráculo)."""
    linhas = []
    for m in sorted({m for m, _ in pc}):
        cs = [v for (mm, _c), v in pc.items() if mm == m]
        vals = o1[m]
        lo, hi = _bootstrap_tipo(vals, inv)
        grupos = {g: [v for c, v in vals.items() if inv[c]["grupo"] == g] for g in "fhg"}
        linhas.append((m, f1(cs, 1), f1(cs, 2), _taxa(cs, "o1", "n_est"), _taxa(cs, "o2", "n_est"), lo, hi,
                       {g: (sum(v) / len(v) if v else float("nan")) for g, v in grupos.items()},
                       _taxa(cs, "alarme", "n_nor"), _taxa(cs, "dec", "n_est"), len(vals)))
    linhas.sort(key=lambda x: (-x[1], -x[3]))
    out = ["## Tabela completa — ordenada por F1@1 com portão", "",
           "| # | modo | cenários | F1@1 | F1@2 | F1@1 sabendo que é falha | F1@2 sabendo que é falha | "
           "IC 95% (top-1, por tipo) | f | h | g | alarme normais | decide estáveis |",
           "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for i, (m, a, b, c, d, lo, hi, g, al, dec, n) in enumerate(linhas, 1):
        out.append(f"| {i} | {m} | {n} | {a:.3f} | {b:.3f} | {c:.0%} | {d:.0%} | {lo:.0%}–{hi:.0%} | "
                   f"{g['f']:.0%} | {g['h']:.0%} | {g['g']:.0%} | {al:.1%} | {dec:.0%} |")
    return out + [""]


def final(unificado: bool = False) -> str:
    inv = _inv()
    rs_base = base_unificada(inv) if unificado else base_final(inv)
    if unificado:   # b3 (constante) nos mesmos instantes, para entrar na tabela com F1
        alvo = Counter(inv[c]["esperado"] for c in inv).most_common(1)[0][0]
        rs_base += [{**r, "modo": "b3", "decidiu": True, "ranking": [alvo], "forcado": [alvo]}
                    for r in rs_base if r["modo"] == "d9"]
    pc = por_cenario(rs_base, inv)
    modos = sorted({m for m, _ in pc})
    cens_todos = sorted(inv)
    esp_freq = Counter(inv[c]["esperado"] for c in cens_todos).most_common(1)[0][0]
    o1: dict[str, dict[str, float]] = defaultdict(dict)
    for (m, c), v in pc.items():
        if v.get("n_est"):
            o1[m][c] = v["o1"] / v["n_est"]
    o1["b3"] = {c: float(inv[c]["esperado"] == esp_freq) for c in cens_todos}
    linhas = []
    for m in [m for m in modos if m != "b3"] + ["b3"]:
        vals = o1[m]
        cs = [pc.get((m, c), {}) for c in vals]
        grupos = {g: [v for c, v in vals.items() if inv[c]["grupo"] == g] for g in "fhg"}
        lo, hi = _bootstrap_tipo(vals, inv)
        linhas.append((m, len(vals), sum(vals.values()) / max(1, len(vals)), lo, hi,
                       {g: (sum(v) / len(v) if v else float("nan")) for g, v in grupos.items()},
                       _taxa(cs, "o3", "n_est") if m != "b3" else float("nan"),
                       f1([pc[(m, c)] for c in vals if (m, c) in pc]) if m != "b3" else float("nan"),
                       _taxa(cs, "alarme", "n_nor") if m != "b3" else float("nan"),
                       _taxa(cs, "dec", "n_est") if m != "b3" else float("nan")))
    linhas.sort(key=lambda x: -x[2])
    out = tabela_completa({k: v for k, v in pc.items()}, inv, o1) if unificado else []
    out += ["## Tabela única — localização com oráculo (decisão forçada), 5 estáveis por cenário", "",
           f"b3 = constante `{esp_freq}` (o alvo mais frequente). Resultados com g: **exploratórios**.", "",
           "| # | modo | cenários | oráculo@1 | IC 95% (por tipo) | f | h | g | oráculo@3 | F1@1 (com portão) | "
           "alarme normais | decide estáveis |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for i, (m, n, med, lo, hi, g, o3, f, al, dec) in enumerate(linhas, 1):
        out.append(f"| {i} | {m} | {n} | {med:.0%} | {lo:.0%}–{hi:.0%} | {g['f']:.0%} | {g['h']:.0%} | "
                   f"{g['g']:.0%} | {o3:.0%} | {f:.3f} | {al:.1%} | {dec:.0%} |")
    # S: filhos contra o pai, pareado nos cenários comuns (acerto@1 majoritário com oráculo)
    out += ["", "## S — filhos contra o pai (oráculo@1 majoritário, McNemar pareado nos cenários comuns)", "",
            "| filho | pai | cenários | só o filho acerta | só o pai acerta | p | F1@1 filho × pai | "
            "alarme filho × pai | veredito |", "|---|---|---|---|---|---|---|---|---|"]
    for filho, pai in PAIS.items():
        comuns = sorted(set(o1[filho]) & set(o1[pai]))
        a = [o1[filho][c] > 0.5 for c in comuns]
        b = [o1[pai][c] > 0.5 for c in comuns]
        n01, n10, p = _mcnemar(a, b)
        cf = [pc[(filho, c)] for c in comuns if (filho, c) in pc]
        cp = [pc[(pai, c)] for c in comuns if (pai, c) in pc]
        f_f, f_p = f1(cf), f1(cp)
        al_f, al_p = _taxa(cf, "alarme", "n_nor"), _taxa(cp, "alarme", "n_nor")
        sucesso = (p < 0.05 and n01 > n10) or (f_f > f_p and al_f - al_p <= 0.05)
        out.append(f"| {filho} | {pai} | {len(comuns)} | {n01} | {n10} | {p:.3f} | {f_f:.3f} × {f_p:.3f} | "
                   f"{al_f:.1%} × {al_p:.1%} | {'sucesso' if sucesso else 'sem evidência de ganho'} |")
    # V2 e V3
    out += ["", "## V2/V3 — viés da a0", ""]
    a0 = o1.get("a0") or {}
    if a0:
        med_a0 = sum(a0.values()) / len(a0)
        for b in ("b1", "b2", "b3"):
            comuns = sorted(set(a0) & set(o1[b]))
            mb = sum(o1[b][c] for c in comuns) / max(1, len(comuns))
            ma = sum(a0[c] for c in comuns) / max(1, len(comuns))
            out.append(f"- V2 {b}: oráculo@1 {mb:.0%} × a0 {ma:.0%} nos mesmos {len(comuns)} cenários → "
                       f"{'VALE (≤ 10 p.p.)' if ma - mb <= 0.10 else 'não vale'}")
        gf = [v for c, v in a0.items() if inv[c]["grupo"] == "f"]
        gg = [v for c, v in a0.items() if inv[c]["grupo"] == "g"]
        if gf and gg:
            dif = sum(gg) / len(gg) - sum(gf) / len(gf)
            out.append(f"- V3: a0 g {sum(gg) / len(gg):.0%} × f {sum(gf) / len(gf):.0%} (Δ {dif:+.0%}) → "
                       f"{'VALE (≥ 20 p.p.)' if dif >= 0.20 else 'não vale'}")
        out.append(f"- a0 média: {med_a0:.0%} em {len(a0)} cenários")
    ordem = [m for m, *_ in linhas]
    out += pares(rs_base, inv, [m for m in ordem if m not in ("b1", "b2", "b3")][:6])
    if unificado:
        out += comparacao(inv, base_final(inv), rs_base)
    # por cenário
    out += ["", "## Oráculo@1 por cenário", "", "| cenário | gabarito | " + " | ".join(ordem) + " |",
            "|---|---|" + "---|" * len(ordem)]
    for c in cens_todos:
        out.append(f"| {c} | {inv[c]['esperado'].replace('teastore-', '')} | "
                   + " | ".join(f"{o1[m][c]:.0%}" if c in o1[m] else "—" for m in ordem) + " |")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("comando", choices=("amostragem", "vies", "e1", "final", "unificado"))
    args = ap.parse_args()
    texto = {"amostragem": amostragem, "vies": vies, "e1": e1, "final": final,
             "unificado": lambda: final(unificado=True)}[args.comando]()
    with open(os.path.join(PR.SAIDA, f"{args.comando}.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
