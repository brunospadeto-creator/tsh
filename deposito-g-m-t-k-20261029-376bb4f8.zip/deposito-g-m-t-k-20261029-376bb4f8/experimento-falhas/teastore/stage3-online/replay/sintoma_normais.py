#!/usr/bin/env python3
"""Alarme do canal de sintoma (análise adicional, fora do protocolo): conta, nos 41 cenários do TeaStore, os instantes
normais e com causa em que `d9k.servico_k8s` devolve um serviço, com o mesmo código de `metricas_rz_k8s.py --teste`.

O BARO/N-Sigma oficiais (`E2.oficiais`) são desligados, porque não entram na contagem e exigem o pacote RCAEval.
Rodar da raiz de um checkout com a telemetria bruta (`resultados/` completo), por exemplo o depósito do Zenodo.
Uso: replay/sintoma_normais.py [--jobs N]
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import metricas_rz_k8s as M  # noqa: E402

if __name__ == "__main__":
    M.E2.oficiais = lambda *a, **k: {"BARO": [], "N-Sigma": []}
    sys.argv = [sys.argv[0], "--teste", *sys.argv[1:]]
    raise SystemExit(M.main())
