#!/usr/bin/env python3
"""Emenda 2 do `bases-externas/metricas-rz/PROTOCOLO-COMPLETO.md` no TeaStore: método novo `g-m∨t∨k|mfk` (eventos K8s
de sintoma), BARO/N-Sigma oficiais, AC@k e sensibilidade do FP, na definitiva (24) e em B′ (17).

- `g-m∨t∨k|mfk`: portão `g-m` OU `d9-b+c@0.01` OU evento K8s de sintoma (`d9k.servico_k8s`, eventos limpos da Fase 0
  vistos até o instante, como na d9-k e no `baseline_dinamica.py`); ranking `m-rzf` com o serviço K8s promovido ao
  1º (`d9k._promover`). Decomposição descritiva: `g-m∨t|mfk` (só a promoção) e `g-m∨t∨k|mf` (só o portão).
- H-k1 (41 cenários, pareado com `g-m∨t|mf`): ΔF1@1 > 0 e IC 95% (bootstrap de cenário) todo acima de 0.
- H-k2 (B′): F1@1 ≥ 0,6 e F1@2 ≥ 0,7 e alarme ≤ 20%.
- Métricas recalculadas com o código congelado (`metricas_rz_teastore.serie`, `ciclo`), com a mesma calibração de
  cada conjunto; a decisão do `g-m∨t|mf` tem de reproduzir a gravada (checado).

`--teste`: só conta instantes com sintoma K8s por cenário (sem resultado). Saída:
`resultados/protocolo-metricas-rz/k8s/` e `resultado-emenda2-teastore.md`. Uso: replay/metricas_rz_k8s.py [--teste]
"""
from __future__ import annotations

import argparse
import datetime
import gzip
import json
import os
import random
import sys
import warnings
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import baseline_dinamica as BDT  # noqa: E402, N812
import confirmatorio as CF  # noqa: E402, N812
import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import hibrido_d9a as H  # noqa: E402, N812
import metricas_rz_ineditos as MI  # noqa: E402, N812
import metricas_rz_teastore as T  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

sys.path.insert(0, os.path.join(SELF_DIR, "..", "..", "..", "..", "bases-externas", "metricas-rz"))
import emenda2 as E2  # noqa: E402, N812

CI = T.CI
SAIDA = os.path.join(T.SAIDA, "k8s")
FPS_G = (0.01, 0.05, 0.10)


def conjuntos() -> dict[str, dict[str, Any]]:
    return {
        "B′": {"casos": MI.casos(), "metricas": os.path.join(MI.SAIDA, "metricas"),
               "dinamica": os.path.join(MI.SAIDA, "dinamica"), "hibrido": os.path.join(MI.SAIDA, "hibrido"),
               "solucoes": os.path.join(MI.SAIDA, "solucoes")},
        "definitiva": {"casos": DF.casos(DF.runs()), "metricas": os.path.join(T.SAIDA, "def"),
                       "dinamica": os.path.join(BDT.SAIDA, "def"), "hibrido": os.path.join(H.SAIDA, "def"),
                       "solucoes": DF.SAIDA},
    }


def _linhas(arq: str) -> list[dict[str, Any]]:
    with gzip.open(arq, "rt") as f:
        return [json.loads(x) for x in f if x.strip()]


def caso(job: tuple[str, dict[str, Any]]) -> dict[str, Any]:
    """Escores das métricas (baseline e instantes), K8s por instante, portão de traces e BARO/N-Sigma do caso."""
    from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k  # noqa: PLC0415
    from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: PLC0415
    warnings.simplefilter("ignore", RuntimeWarning)
    case_dir, cj = job
    AF = PR.AF  # noqa: N806
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    nome = f"{run_id}__{falha}.jsonl.gz"
    gate = {r["t"]: r for r in _linhas(os.path.join(cj["dinamica"], nome)) if r["modo"] == T.TRACES}
    grav = {r["t"]: r for r in _linhas(os.path.join(cj["metricas"], nome)) if r["modo"] == "g-m∨t|mf"}
    per = PR.AI.periodos(case_dir)
    ini_n, fim_n = per["normal"][0], per["normal"][1]
    k8s = PR._k8s_limpo(AF._k8s_dicts(case_dir), ini_n)
    pre_k8s = AF._visao_em(k8s, fim_n)
    cfg = d9k._cfg({"entry_services": PR.P.ENTRY_SERVICES})
    tempo, val, cols = T.serie(case_dir)
    base = {}
    t = tempo[0] + T.INICIO_BASELINE
    while t <= ini_n.timestamp():
        base[str(t)] = CI.escores(tempo, val, cols, t, (t - CI.JANELA - CI.REF, t - CI.JANELA), familia=True)
        t += 60
    inst = []
    for ts, g in sorted(gate.items()):
        tt = datetime.datetime.fromisoformat(ts)
        janela = (tt - datetime.timedelta(seconds=PR.AI.JANELA_SEG), tt)
        if g["periodo"] == "estavel":
            delta = janela[0] - fim_n
            ev = AF._iso(pre_k8s, delta) + AF._iso(AF._a_partir_de(AF._visao_em(k8s, tt), janela[0]))
            ref = (fim_n.timestamp() - CI.REF, fim_n.timestamp())
        else:
            ev = AF._iso(AF._visao_em(k8s, tt))
            ref = (tt.timestamp() - CI.JANELA - CI.REF, tt.timestamp() - CI.JANELA)
        ent = EntradaIncidente(incidente_id=f"k8s-{ts}", janela=janela, abertura_incidente=tt, traces=[],
                               traces_lookback=[], metricas={}, eventos_k8s=ev,
                               config_sistema={"entry_services": PR.P.ENTRY_SERVICES})
        inst.append({"t": ts, "periodo": g["periodo"], "gt": g["status"] == "decidiu",
                     "k8s": d9k.servico_k8s(ent, cfg),
                     "f": CI.escores(tempo, val, cols, tt.timestamp(), ref, familia=True),
                     "bj": E2.baro_janela(tempo, val, cols, tt.timestamp(), ref),
                     "grav": grav.get(ts)})
    fim_est = per["estavel"][1].timestamp()
    b = int(sum(tempo <= fim_est))
    of = E2.oficiais(tempo[:b], val[:b], cols, fim_n.timestamp(), "teastore")
    return {"cenario": f"{run_id}/{falha}", "base": base, "inst": inst, "of": of}


def _boot_delta(pa: dict[str, dict], pb: dict[str, dict], n: int = 2000) -> tuple[float, float, float]:
    cs = sorted(pa)
    fn = lambda s: A.f1([pa[c] for c in s]) - A.f1([pb[c] for c in s])  # noqa: E731
    rnd = random.Random(PR.M.SEMENTE)
    v = sorted(fn([rnd.choice(cs) for _ in cs]) for _ in range(n))
    return fn(cs), v[int(0.025 * n)], v[int(0.975 * n) - 1]


def avaliar(nome: str, cj: dict[str, Any], res: list[dict[str, Any]]) -> tuple[dict, dict, list[str]]:
    from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k  # noqa: PLC0415
    inv = CF.inventario(cj["casos"])
    pseudo = [{"periodo": "normal", "na_baseline": True, "grupo": "teastore", "caso": r["cenario"], "t": t}
              for r in res for t in r["base"]]
    es = {(r["cenario"], t): e for r in res for t, e in r["base"].items()}
    norm = CI.normalizadores(pseudo, es)["teastore"]
    taus = {fp: CI.tau_gate(pseudo, es, {"teastore": norm}, fp)["teastore"] for fp in FPS_G}
    rows, difs = [], 0
    caso_ac: dict[str, tuple[list, list]] = {m: ([], []) for m in (
        "BARO (oficial)", "N-Sigma (oficial)", "g-m∨t|mf — 1º instante", "g-m∨t∨k|mfk — 1º instante")}
    for r in res:
        esp = inv[r["cenario"]]["esperado"]
        primeiro = True
        for x in r["inst"]:
            rk = CI.ranking_rzl(x["f"], norm)
            umax = max(CI._u(x["f"], norm).values(), default=0.0)
            gm = {fp: umax >= taus[fp] for fp in FPS_G}
            svc = x["k8s"]
            rkk = d9k._promover(rk, svc, 3)
            ds = {"g-m∨t|mf": (gm[0.05] or x["gt"], rk), "g-m∨t∨k|mfk": (gm[0.05] or x["gt"] or bool(svc), rkk),
                  "g-m∨t|mfk": (gm[0.05] or x["gt"], rkk), "g-m∨t∨k|mf": (gm[0.05] or x["gt"] or bool(svc), rk),
                  "g-m∨t|BARO-janela": (gm[0.05] or x["gt"], x["bj"]),
                  "g-m∨t|mf @FP0,01": (gm[0.01] or x["gt"], rk), "g-m∨t|mf @FP0,10": (gm[0.10] or x["gt"], rk),
                  "g-m∨t∨k|mfk @FP0,01": (gm[0.01] or x["gt"] or bool(svc), rkk),
                  "g-m∨t∨k|mfk @FP0,10": (gm[0.10] or x["gt"] or bool(svc), rkk)}
            g = x["grav"]
            if g is not None and ((g["status"] == "decidiu") != ds["g-m∨t|mf"][0] or g["forcado"] != rk):
                difs += 1
            run_id, falha = r["cenario"].split("/")
            for m, (dec, lst) in ds.items():
                rows.append({"run_id": run_id, "falha": falha, "periodo": x["periodo"], "t": x["t"], "modo": m,
                             "status": "decidiu" if dec else "absteve", "ranking": lst[:3] if dec else [],
                             "forcado": lst[:3]})
            if x["periodo"] == "estavel" and primeiro:
                primeiro = False
                full = E2.ordem_completa(x["f"], norm)
                for m, lst in (("BARO (oficial)", r["of"]["BARO"]), ("N-Sigma (oficial)", r["of"]["N-Sigma"]),
                               ("g-m∨t|mf — 1º instante", full),
                               ("g-m∨t∨k|mfk — 1º instante", d9k._promover(full, svc, 99))):
                    caso_ac[m][0].append(lst)
                    caso_ac[m][1].append(esp)
    pasta = os.path.join(SAIDA, "B-ineditos" if nome == "B′" else "def")
    os.makedirs(pasta, exist_ok=True)
    por: dict[str, list] = {}
    for x in rows:
        por.setdefault(f"{x['run_id']}__{x['falha']}", []).append(json.dumps(x))
    for k, ls in por.items():
        with gzip.open(os.path.join(pasta, f"{k}.jsonl.gz"), "wt") as f:
            f.write("\n".join(ls) + "\n")
    rs = C._novos(inv, pasta, "*.jsonl.gz")
    rs += [x for x in C._novos(inv, cj["hibrido"], "*.jsonl.gz") if x["modo"] in ("d9-k", "d9-k+a", "d9", "d9+a")]
    rs += [{**x, "modo": "v-cons-b"} for x in C._novos(inv, cj["solucoes"], "*.jsonl.gz") if x["modo"] == "v-cons-b-prod"]
    comuns = {(x["cenario"], x["t"]) for x in rs if x["modo"] == "g-m∨t∨k|mfk"}
    for m in ("d9-k", "d9-k+a", "v-cons-b", "d9", "d9+a"):
        comuns &= {(x["cenario"], x["t"]) for x in rs if x["modo"] == m}
    rs = [x for x in rs if (x["cenario"], x["t"]) in comuns]
    pcs: dict[str, dict[str, Any]] = {}
    for (m, c), x in A.por_cenario(rs, inv).items():
        pcs.setdefault(m, {})[c] = x
    n_k = sum(1 for r in res for x in r["inst"] if x["k8s"])
    out = [f"## {nome} ({len(pcs['g-m∨t|mf'])} cenários, {len(comuns)} instantes comuns)", "",
           f"Checagem: decisão e ranking do `g-m∨t|mf` recalculados × gravados — {difs} diferenças. Instantes com sintoma "
           f"K8s: {n_k}. τ do g-m (FP 0,05) = {taus[0.05]:.3f}.", "",
           "| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo AC@1 | AC@3 |", "|---|---|---|---|---|---|---|"]
    for m in ("g-m∨t∨k|mfk", "g-m∨t|mfk", "g-m∨t∨k|mf", "g-m∨t|mf", "g-m∨t|BARO-janela", "g-m∨t|mf @FP0,01",
              "g-m∨t|mf @FP0,10", "g-m∨t∨k|mfk @FP0,01", "g-m∨t∨k|mfk @FP0,10", "d9-k+a", "d9-k", "v-cons-b", "d9+a", "d9"):
        if m in pcs:
            x, ic = DF.metricas(pcs[m]), DF._boot(pcs[m], A.f1)
            out.append(f"| {m} | {x['f1']:.3f} [{ic[0]:.3f}–{ic[1]:.3f}] | {x['f2']:.3f} | {x['alarme']:.1%} | "
                       f"{x['abst']:.0%} | {x['o1']:.0%} | {x['o3']:.0%} |")
    out += ["", "Por caso (AC@k, serviço; 1º instante estável para os nossos, todo o pós-injeção para BARO/N-Sigma):", "",
            *E2.tabela_caso(caso_ac), ""]
    return pcs, inv, out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--teste", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    cjs = conjuntos()
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    res = {}
    with ProcessPoolExecutor(args.jobs) as ex:
        for nome, cj in cjs.items():
            res[nome] = list(ex.map(caso, [(c, cj) for c in cj["casos"]]))
    if args.teste:
        print("| conjunto | cenário | instantes | com sintoma K8s (normais / estáveis) | BARO devolveu |")
        print("|---|---|---|---|---|")
        for nome, rr in res.items():
            for r in rr:
                kn = sum(1 for x in r["inst"] if x["k8s"] and x["periodo"] == "normal")
                ke = sum(1 for x in r["inst"] if x["k8s"] and x["periodo"] == "estavel")
                print(f"| {nome} | {r['cenario']} | {len(r['inst'])} | {kn} / {ke} | {len(r['of']['BARO'])} serviços |")
        return 0
    out = ["# Emenda 2 no TeaStore — método novo com eventos K8s, BARO/N-Sigma oficiais, AC@k e sensibilidade", "",
           "`PROTOCOLO-COMPLETO.md` emenda 2 (E2.4). H-k1 e H-k2 confirmatórios; o resto descritivo.", ""]
    pcs_all: dict[str, dict] = {}
    for nome, cj in cjs.items():
        pcs, inv, o = avaliar(nome, cj, res[nome])
        out += o
        for m, v in pcs.items():
            pcs_all.setdefault(m, {}).update(v)
        if nome == "B′":
            x = DF.metricas(pcs["g-m∨t∨k|mfk"])
            ok = x["f1"] >= 0.6 and x["f2"] >= 0.7 and x["alarme"] <= 0.20
            out += [f"**H-k2 (B′, leitura fixada):** F1@1 {x['f1']:.3f} (≥ 0,6: {'sim' if x['f1'] >= 0.6 else 'não'}), "
                    f"F1@2 {x['f2']:.3f} (≥ 0,7: {'sim' if x['f2'] >= 0.7 else 'não'}), alarme {x['alarme']:.1%} "
                    f"(≤ 20%: {'sim' if x['alarme'] <= 0.2 else 'não'}) → **{'CONFIRMA' if ok else 'NÃO CONFIRMA'}**.", ""]
    d, lo, hi = _boot_delta(pcs_all["g-m∨t∨k|mfk"], pcs_all["g-m∨t|mf"])
    ok1 = d > 0 and lo > 0
    out += ["## H-k1 — eventos K8s melhoram a descoberta (41 cenários, pareado)", "",
            f"ΔF1@1 (`g-m∨t∨k|mfk` − `g-m∨t|mf`) = {d:+.3f} [IC 95% {lo:+.3f} a {hi:+.3f}] → "
            f"**{'CONFIRMA' if ok1 else 'NÃO CONFIRMA'}**.", ""]
    for a, b in (("g-m∨t∨k|mfk", "g-m∨t|mf"), ("g-m∨t∨k|mfk", "d9-k+a"), ("g-m∨t∨k|mfk", "d9-k"),
                 ("d9-k", "d9"), ("d9-k+a", "d9+a")):
        sa, sb, p = DF.mcnemar(pcs_all[a], pcs_all[b], "tp1")
        dd, l2, h2 = _boot_delta(pcs_all[a], pcs_all[b])
        out.append(f"- {a} × {b}: ΔF1@1 {dd:+.3f} [{l2:+.3f}; {h2:+.3f}]; McNemar só {a} {sa}, só {b} {sb}, p = {p:.3f}")
    texto = "\n".join(out) + "\n"
    os.makedirs(SAIDA, exist_ok=True)
    with open(os.path.join(SAIDA, "resultado-emenda2-teastore.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
