#!/usr/bin/env python3
"""Stage 3 isolado, por instante: roda os modos d em cada instante de cada cenário.

Sem incidente. Para cada cenário de `resultados/<RUN>/<falha>/`:

- **instantes** a cada `--passo` s (padrão 3, um por pacote) em três períodos:
  `normal` (janela de referência, `referencia.json`), `transicao` (fim da referência → 1º pacote) e
  `estavel` (do início do 1º ao fim do 100º pacote de evidência);
- em cada instante `t`, o modo recebe os traces que terminam em `[t − 120 s, t]` e, como lookback (d3),
  os de `[t − 1800 s, t − 120 s]`;
- para cada valor de `fp_alvo` da grade, o `q` sai da `estatistica_por_janela` gravada na calibração
  do artefato (mesma regra de `calibracao.quantil_q`), sem recalibrar; a d3 usa um artefato por `fp_alvo`
  (`abordagens-<coleção>-d3-fp<valor>.json`), porque a grade dela é escolhida na calibração. Valores de
  `fp_alvo` que dão o mesmo `q` rodam uma vez só.

Grava uma linha JSON por (instante, modo, fp_alvo) em `<saida>/<RUN>__<falha>.jsonl` (retomável: cenário
com arquivo pronto é pulado). **Nada de gabarito entra aqui** — o serviço esperado só é usado em
`metricas_instantes.py`.

Uso (de `experimento-falhas/teastore/stage3-online/`):
    replay/avaliar_instantes.py --runs 20260926T203024Z --modos d2c --sufixo=-w120 --jobs 4
"""
from __future__ import annotations

import argparse
import copy
import datetime
import glob
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import preparar_baseline_abordagens as P  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import calibracao, processo, registro  # noqa: E402
from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: E402

JANELA_SEG = 120      # lookback_sec do Stage 3
LOOKBACK_D3_SEG = 1800
GRADE_FP = (0.025, 0.05, 0.10, 0.20)
MODOS_D = ("d1", "d2", "d3", "d4", "d1c", "d2c", "d4c")
SAIDA_PADRAO = os.path.join(R.RESULTADOS, "instantes")


def _utc(valor: str) -> datetime.datetime:
    dt = datetime.datetime.fromisoformat(valor.replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=datetime.UTC)


def periodos(case_dir: str) -> dict[str, tuple[datetime.datetime, datetime.datetime]]:
    """Os três períodos do cenário, só de horários gravados pelo harness."""
    ref = R._load(os.path.join(case_dir, "referencia.json"))
    pacotes = [R._load(p) for p in glob.glob(os.path.join(case_dir, "evidence_packages", "pkg-*.json"))]
    if not pacotes or not ref.get("window_start"):
        return {}
    ref_ini, ref_fim = _utc(ref["window_start"]), _utc(ref["window_end"])
    est_ini = min(_utc(p["window_start"]) for p in pacotes)
    est_fim = max(_utc(p["window_end"]) for p in pacotes)
    return {"normal": (ref_ini, ref_fim), "transicao": (ref_fim, est_ini), "estavel": (est_ini, est_fim)}


def eventos_do_caso(case_dir: str) -> list[Any]:
    brutos: dict[str, Any] = {}
    for nome in ("traces_full_scenario.json", "traces_stage3_window.json", "traces.json"):
        caminho = os.path.join(case_dir, nome)
        if os.path.exists(caminho):
            brutos.update(R._load(caminho).get("traces") or {})
    for parte in sorted(glob.glob(os.path.join(case_dir, "traces_salvage.parts", "*.json"))):
        dado = R._load(parte)
        brutos.update(dado.get("traces") or {} if isinstance(dado, dict) else {})
    return processo.eventos_de_traces_brutos(brutos, P.ENTRY_SERVICES)


def instantes(per: dict[str, tuple[datetime.datetime, datetime.datetime]], passo: float):
    for nome, (ini, fim) in per.items():
        t = ini + datetime.timedelta(seconds=passo)
        while t <= fim:
            yield nome, t
            t += datetime.timedelta(seconds=passo)


def artefatos_por_fp(colecao: str, modo: str, sufixo: str) -> list[tuple[list[float], float, dict[str, Any]]]:
    """[(fp_alvos, q, artefato)] — um por `q` distinto da grade."""
    if modo == "d3":
        saida = []
        for fp in GRADE_FP:
            caminho = P.caminho_artefato(colecao, modo, f"-fp{fp}")
            with open(caminho) as f:
                saida.append(([fp], float("nan"), json.load(f)))
        return saida
    with open(P.caminho_artefato(colecao, modo, sufixo)) as f:
        base = json.load(f)
    estat = [s for s in (base.get("calibracao") or {}).get("estatistica_por_janela") or [] if s is not None]
    por_q: dict[float, list[float]] = {}
    for fp in GRADE_FP:
        por_q.setdefault(calibracao.quantil_q(estat, fp), []).append(fp)
    saida = []
    for q, fps in sorted(por_q.items()):
        art = copy.deepcopy(base)
        art.setdefault("calibracao", {}).update({"q": q, "fp_alvo": min(fps)})
        saida.append((fps, q, art))
    return saida


def _sem_bolha(eventos: list[Any], janela: tuple[datetime.datetime, datetime.datetime]) -> list[Any]:
    return processo.cortar_janela(eventos, janela)


def rodar_caso(job: tuple[str, list[str], str, float, str]) -> str:
    case_dir, modos, sufixo, passo, saida = job
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência ou pacotes -- fora"
    colecao = R._load(os.path.join(os.path.dirname(case_dir), "manifest.json"))["collection_id"]
    eventos = eventos_do_caso(case_dir)
    variantes = {m: artefatos_por_fp(colecao, m, sufixo) for m in modos}
    t0 = time.monotonic()
    linhas: list[str] = []
    for periodo, t in instantes(per, passo):
        janela = (t - datetime.timedelta(seconds=JANELA_SEG), t)
        dentro = _sem_bolha(eventos, janela)
        lookback = _sem_bolha(eventos, (t - datetime.timedelta(seconds=LOOKBACK_D3_SEG), janela[0]))
        entrada = EntradaIncidente(
            incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
            traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=[],
            config_sistema={"entry_services": P.ENTRY_SERVICES},
        )
        for modo in modos:
            for fps, q, artefato in variantes[modo]:
                cfg = P.cfg_do_modo(modo, {"fp_alvo": min(fps)})
                try:
                    d = registro.executar_modo(modo, entrada, artefato, cfg)
                    linha = {"status": d.status, "motivo": d.motivo_abstencao,
                             "estatistica": calibracao.estatistica_da_decisao(d),
                             "ranking": [i.servico for i in d.ranking][:3],
                             "empate_topo": bool(d.ranking and (d.ranking[0].evidencias or {}).get(
                                 "empate_com_seguinte"))}
                except Exception as exc:  # noqa: BLE001 - um instante quebrado não derruba o cenário
                    linha = {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}", "ranking": []}
                for fp in fps:
                    linhas.append(json.dumps({
                        "run_id": run_id, "falha": falha, "colecao": colecao[:8], "periodo": periodo,
                        "t": t.isoformat(), "modo": modo, "fp_alvo": fp, "q": q,
                        "n_traces": len({e.case_id for e in dentro}), **linha}))
    os.makedirs(saida, exist_ok=True)
    with open(destino + ".tmp", "w") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", required=True, help="RUN_IDs separados por vírgula")
    ap.add_argument("--falhas", help="só estas falhas (vírgulas)")
    ap.add_argument("--modos", default=",".join(MODOS_D))
    ap.add_argument("--sufixo", default="-w120", help="sufixo do artefato (preparar_baseline_abordagens)")
    ap.add_argument("--passo", type=float, default=3.0)
    ap.add_argument("--saida", default=SAIDA_PADRAO)
    ap.add_argument("--jobs", type=int, default=1)
    args = ap.parse_args()
    modos = args.modos.split(",")
    casos = []
    for run in args.runs.split(","):
        for c in sorted(glob.glob(os.path.join(R.RESULTADOS, run, "[fhg][0-9]*"))):
            if os.path.isdir(c) and (not args.falhas or os.path.basename(c) in args.falhas.split(",")):
                casos.append(c)
    jobs = [(c, modos, args.sufixo, args.passo, args.saida) for c in casos]
    if args.jobs > 1:
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(rodar_caso, jobs):
                print(msg, flush=True)
    else:
        for j in jobs:
            print(rodar_caso(j), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
