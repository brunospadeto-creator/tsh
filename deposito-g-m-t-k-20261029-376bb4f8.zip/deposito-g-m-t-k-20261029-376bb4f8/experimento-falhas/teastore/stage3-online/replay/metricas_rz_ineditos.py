#!/usr/bin/env python3
"""Parte B′ do `bases-externas/metricas-rz/PROTOCOLO-COMPLETO.md` (emenda 1): `g-m∨t|mf` e a bateria completa nos 17
cenários gravados do TeaStore que o método nunca viu (13 do dev com pacotes de métricas + 4 da 1ª tentativa
abortada do C2 da definitiva). Tudo offline, sem coleta.

1. Executores já existentes, em modo confirmatório (D0.4 na hora), saída em
   `resultados/protocolo-metricas-rz/b-ineditos/`:
   - `paridade_solucoes.rodar_caso` → d9-k e v-cons-b;
   - `hibrido_d9a.rodar_caso` → d9-k+a e d2c-r;
   - `baseline_dinamica.rodar_caso` → d9-b+c@0.01 e d9-k-b+c@0.01 (λ e q pela baseline de cada coleção).
2. Métricas com as funções do `metricas_rz_teastore.py` (`serie`) e do `ciclo.py` congelado. Baseline das métricas
   = trecho de cada sessão antes do normal medido, juntando as 17 sessões (a regra da definitiva).
3. Leitura do §6: F1@1 ≥ 0,6 e F1@2 ≥ 0,7 e alarme ≤ 20%.

Uso: replay/metricas_rz_ineditos.py [--teste] [--jobs 24]
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
import sys
import time
import warnings
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import baseline_dinamica as BDT  # noqa: E402, N812
import confirmatorio as CF  # noqa: E402, N812
import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import hibrido_d9a as H  # noqa: E402, N812
import metricas_rz_teastore as T  # noqa: E402, N812
import paridade_solucoes as PS  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

CI = T.CI
SAIDA = os.path.join(T.SAIDA, "b-ineditos")
CENARIOS = (
    "20261013T051436Z/h3-auth-jvm-heap",
    *(f"{r}/{g}" for r in ("20261013T061915Z", "20261013T143247Z")
      for g in ("g1-auth-cpu-throttle", "g2-persistence-down", "g3-image-memory-limit", "g4-db-memory-limit",
                "g5-recommender-cpu-throttle", "g6-persistence-jvm-heap")),
    *(f"20261016T075241Z/{h}" for h in ("h1-image-cpu-throttle", "h3-auth-jvm-heap", "h4-db-cpu-throttle",
                                         "h5-image-registry-misconfig")),
)
NOVOS = ("g-m∨t|mf", "g-m|mf", "d9-b+c@0.01|mf", "m-rzf")
COMPARADORES = ("d9-k", "d9-k+a", "v-cons-b", "d2c-r", "d9", "d9-k-b+c@0.01", "d9-b+c@0.01")


def casos() -> list[str]:
    return [os.path.join(PR.R.RESULTADOS, c) for c in CENARIOS]


def _executar(job: tuple[str, str]) -> str:
    qual, c = job
    if qual == "solucoes":
        return PS.rodar_caso((c, os.path.join(SAIDA, "solucoes"), True))
    if qual == "hibrido":
        return H.rodar_caso((c, os.path.join(SAIDA, "hibrido"), True))
    return BDT.rodar_caso((c, os.path.join(SAIDA, "dinamica")))


def metricas_caso(case_dir: str) -> dict[str, Any]:
    """Como `metricas_rz_teastore.rodar_caso`, com o portão de traces lido de `b-ineditos/dinamica/`."""
    warnings.simplefilter("ignore", RuntimeWarning)
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    with gzip.open(os.path.join(SAIDA, "dinamica", f"{run_id}__{falha}.jsonl.gz"), "rt") as f:
        gate = [r for r in (json.loads(x) for x in f if x.strip()) if r["modo"] == T.TRACES]
    per = PR.AI.periodos(case_dir)
    ini_normal, fim_normal = per["normal"][0].timestamp(), per["normal"][1].timestamp()
    tempo, val, cols = T.serie(case_dir)
    base, inst = {}, {}
    t = tempo[0] + T.INICIO_BASELINE
    while t <= ini_normal:
        base[str(t)] = CI.escores(tempo, val, cols, t, (t - CI.JANELA - CI.REF, t - CI.JANELA), familia=True)
        t += 60
    for r in gate:
        t = T._ts(r["t"])
        ref = (fim_normal - CI.REF, fim_normal) if r["periodo"] == "estavel" else (t - CI.JANELA - CI.REF, t - CI.JANELA)
        inst[r["t"]] = CI.escores(tempo, val, cols, t, ref, familia=True)
    return {"run_id": run_id, "falha": falha, "base": base, "inst": inst, "gate": gate,
            "svcs": sorted({c.rsplit("_", 1)[0] for c in cols}), "n_pacotes": len(tempo)}


def gravar(res: list[dict[str, Any]]) -> dict[str, Any]:
    pseudo = [{"periodo": "normal", "na_baseline": True, "grupo": "teastore", "caso": f"{r['run_id']}/{r['falha']}",
               "t": t} for r in res for t in r["base"]]
    es = {(f"{r['run_id']}/{r['falha']}", t): e for r in res for t, e in r["base"].items()}
    norm = CI.normalizadores(pseudo, es)["teastore"]
    tau = CI.tau_gate(pseudo, es, {"teastore": norm})["teastore"]
    os.makedirs(os.path.join(SAIDA, "metricas"), exist_ok=True)
    for r in res:
        linhas = []
        for g in r["gate"]:
            e = r["inst"][g["t"]]
            rk = CI.ranking_rzl(e, norm)
            gm = max(CI._u(e, norm).values(), default=0.0) >= tau
            gt = g["status"] == "decidiu"
            base = {"run_id": r["run_id"], "falha": r["falha"], "periodo": g["periodo"], "t": g["t"], "forcado": rk}
            for modo, dec in (("g-m∨t|mf", gm or gt), ("g-m|mf", gm and bool(rk)), ("d9-b+c@0.01|mf", gt),
                              ("m-rzf", bool(rk))):
                linhas.append(json.dumps({**base, "modo": modo, "status": "decidiu" if dec else "absteve",
                                          "ranking": rk if dec else []}))
        with gzip.open(os.path.join(SAIDA, "metricas", f"{r['run_id']}__{r['falha']}.jsonl.gz"), "wt") as f:
            f.write("\n".join(linhas) + "\n")
    cal = {"n_janelas": len(pseudo), "tau": tau, "N": norm}
    with open(os.path.join(SAIDA, "calibracao-metricas.json"), "w") as f:
        json.dump(cal, f, indent=1)
    return cal


def analisar(cal: dict[str, Any]) -> str:
    cs = casos()
    inv = CF.inventario(cs)
    rs = C._novos(inv, os.path.join(SAIDA, "metricas"), "*.jsonl.gz")
    rs += [r for r in C._novos(inv, os.path.join(SAIDA, "hibrido"), "*.jsonl.gz") if r["modo"] in ("d9-k", "d9-k+a", "d2c-r", "d9")]
    rs += [{**r, "modo": "v-cons-b"} for r in C._novos(inv, os.path.join(SAIDA, "solucoes"), "*.jsonl.gz")
           if r["modo"] == "v-cons-b-prod"]
    rs += [r for r in C._novos(inv, os.path.join(SAIDA, "dinamica"), "*.jsonl.gz")
           if r["modo"] in ("d9-k-b+c@0.01", "d9-b+c@0.01")]
    modos = (*NOVOS, *COMPARADORES)
    comuns = None
    for m in modos:
        s = {(r["cenario"], r["t"]) for r in rs if r["modo"] == m}
        comuns = s if comuns is None else comuns & s
    rs = [r for r in rs if (r["cenario"], r["t"]) in comuns]
    pcs: dict[str, dict[str, Any]] = {}
    for (m, c), x in A.por_cenario(rs, inv).items():
        pcs.setdefault(m, {})[c] = x
    n_nor = sum(1 for r in rs if r["modo"] == "g-m∨t|mf" and r["periodo"] == "normal")
    out = ["# Parte B′ — TeaStore, 17 cenários gravados nunca vistos pelo `g-m∨t|mf` (confirmatório)", "",
           "`PROTOCOLO-COMPLETO.md` emenda 1; `replay/metricas_rz_ineditos.py`. 13 do dev com pacotes de métricas "
           "(baseline 547ba505) + 4 da tentativa abortada do C2 (32c273a6). Executores em modo confirmatório (D0.4 na "
           "hora); só os instantes comuns a todos os modos.", "",
           f"Instantes: {len(comuns)} ({n_nor} normais). Janelas de baseline das métricas: {cal['n_janelas']}; "
           f"τ do g-m = {cal['tau']:.3f}; famílias com N: {sum(1 for v in cal['N'].values() if v > 0)} de "
           f"{len(cal['N'])}.", "",
           "| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 |",
           "|---|---|---|---|---|---|---|"]
    for m in modos:
        if m not in pcs:
            continue
        r, ic = DF.metricas(pcs[m]), DF._boot(pcs[m], A.f1)
        out.append(f"| {m} | {r['f1']:.3f} [{ic[0]:.3f}–{ic[1]:.3f}] | {r['f2']:.3f} | {r['alarme']:.1%} | "
                   f"{r['abst']:.0%} | {r['o1']:.0%} | {r['o2']:.0%} |")
    r = DF.metricas(pcs["g-m∨t|mf"])
    ok = r["f1"] >= 0.6 and r["f2"] >= 0.7 and r["alarme"] <= 0.20
    out += ["", f"**Leitura fixada (§6):** F1@1 {r['f1']:.3f} (≥ 0,6: {'sim' if r['f1'] >= 0.6 else 'não'}), F1@2 "
            f"{r['f2']:.3f} (≥ 0,7: {'sim' if r['f2'] >= 0.7 else 'não'}), alarme {r['alarme']:.1%} (≤ 20%: "
            f"{'sim' if r['alarme'] <= 0.2 else 'não'}) → **{'CONFIRMA' if ok else 'NÃO CONFIRMA'}**.", ""]
    for b in COMPARADORES[:5]:
        sa, sb, p = DF.mcnemar(pcs["g-m∨t|mf"], pcs[b], "tp1")
        out.append(f"- McNemar g-m∨t|mf × {b} (top-1 com portão): só g-m∨t|mf {sa}, só {b} {sb}, p = {p:.3f}")
    out += ["", "## Por grupo (descritivo)", ""]
    for g in ("h", "g"):
        sub = {m: {c: x for c, x in v.items() if inv[c]["grupo"] == g} for m, v in pcs.items()}
        out += [f"### {g} ({len(sub['g-m∨t|mf'])} cenários)", "", "| modo | F1@1 | F1@2 | alarme | sabendo top-1 |",
                "|---|---|---|---|---|"]
        for m in modos:
            if sub.get(m):
                x = DF.metricas(sub[m])
                out.append(f"| {m} | {x['f1']:.3f} | {x['f2']:.3f} | {x['alarme']:.1%} | {x['o1']:.0%} |")
        out.append("")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--teste", action="store_true")
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    cs = casos()
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    if args.teste:   # rodada de teste da emenda 1: só a série de métricas, sem F1
        with ProcessPoolExecutor(args.jobs) as ex:
            series = list(ex.map(T.serie, cs))
        inv = CF.inventario(cs)
        print("| cenário | pacotes | serviços | gabarito nas colunas | fração finita | janelas antes do normal |")
        print("|---|---|---|---|---|---|")
        import numpy as np  # noqa: PLC0415
        for c, (tempo, val, cols) in zip(cs, series, strict=True):
            k = "/".join(c.split("/")[-2:])
            svcs = {x.rsplit("_", 1)[0] for x in cols}
            per = PR.AI.periodos(c)
            nb = int(max(0, (per["normal"][0].timestamp() - tempo[0] - T.INICIO_BASELINE) // 60 + 1))
            print(f"| {k} | {len(tempo)} | {len(svcs)} | {'sim' if inv[k]['esperado'] in svcs else '**NÃO**'} | "
                  f"{float(np.isfinite(val).mean()):.3f} | {nb} |")
        return 0
    t0 = time.monotonic()
    for col in sorted({PR.R._load(os.path.join(os.path.dirname(c), "manifest.json"))["collection_id"][:8] for c in cs}):
        BDT._calibracao(col)   # uma vez, antes dos processos
    print(f"calibrações da baseline: {time.monotonic() - t0:.0f}s", flush=True)
    jobs = [(q, c) for c in cs for q in ("solucoes", "hibrido", "dinamica")]
    with ProcessPoolExecutor(args.jobs) as ex:
        for msg in ex.map(_executar, jobs):
            print(msg, flush=True)
    with ProcessPoolExecutor(args.jobs) as ex:
        res = list(ex.map(metricas_caso, cs))
    texto = analisar(gravar(res))
    with open(os.path.join(SAIDA, "resultado-confirmatorio-B.md"), "w") as f:
        f.write(texto)
    print(texto)
    print(f"total: {time.monotonic() - t0:.0f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
