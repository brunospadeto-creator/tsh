#!/usr/bin/env python3
"""Replay dos modos do Stage 3 (a0, d1–d4) sobre os casos gravados, com a mesma entrada.

Para cada caso de `resultados/<RUN>/<falha>/`:

- **a0**: `replay.replay_case` (o `_run_pipeline` legado, inalterado) e o adaptador `abordagens/a0.py`;
- **d_k**: traces de `traces_full_scenario.json` + `traces_stage3_window.json` → `TraceEvent`
  (`processo.eventos_de_traces_brutos`), janela = a do incidente, lookback = antes dela; artefato da
  coleção em `resultados/insumos/abordagens-<coleção8>-<modo>.json` (preparado do backup se faltar).

O gabarito (`avaliacao.json: expected_service`) só entra **depois** da decisão, para pontuar.

**Trava de procedimento:** d1–d4 em casos de falha só no passo 9 (diagnóstico), e
exige `--diagnostico`. Sem a flag, só rodam `a0` e `d0_nula`.

Uso (de `experimento-falhas/teastore/stage3-online/`):

    python3 replay/replay_abordagens.py --runs 20261002T013953Z --modos a0 --as-recorded
    python3 replay/replay_abordagens.py --modos todos --diagnostico --jobs 6
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import avaliacao_lib as A  # noqa: E402, N812
import preparar_baseline_abordagens as P  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import a0, processo, registro  # noqa: E402
from src.application.stage3.abordagens.base import Decisao, EntradaIncidente  # noqa: E402

LIVRES_SEM_DIAGNOSTICO = {"a0", "d0_nula"}
LOOKBACK_SEG = 1800  # d3 (o resto ignora `traces_lookback`)


def _utc(valor: str) -> datetime.datetime:
    dt = datetime.datetime.fromisoformat(valor)
    return dt if dt.tzinfo else dt.replace(tzinfo=datetime.UTC)


def entrada_do_caso(case_dir: str) -> tuple[EntradaIncidente, str]:
    """`EntradaIncidente` do caso e a coleção da baseline. Nada de gabarito entra aqui."""
    run_dir = os.path.dirname(case_dir)
    colecao = R._load(os.path.join(run_dir, "manifest.json"))["collection_id"]
    inc = R._load(os.path.join(case_dir, "stage3_audit_package.json"))["incident"]
    brutos: dict[str, Any] = {}
    for nome in ("traces_full_scenario.json", "traces_stage3_window.json"):
        caminho = os.path.join(case_dir, nome)
        if os.path.exists(caminho):
            brutos.update(R._load(caminho).get("traces") or {})
    eventos = processo.eventos_de_traces_brutos(brutos, P.ENTRY_SERVICES)
    janela = (_utc(inc["window_start"]), _utc(inc["window_end"]))
    abertura = _utc(inc.get("opened_at") or inc["window_end"])
    lookback = processo.cortar_janela(
        eventos, (janela[0] - datetime.timedelta(seconds=LOOKBACK_SEG), janela[0]))
    return EntradaIncidente(
        incidente_id=inc["incident_id"], janela=janela, abertura_incidente=abertura,
        traces=processo.cortar_janela(eventos, janela), traces_lookback=lookback,
        metricas={}, eventos_k8s=[], config_sistema={"entry_services": P.ENTRY_SERVICES},
    ), colecao


def _linha(case_dir: str, modo: str, decisao: Decisao, esperado: str, extra: dict[str, Any]) -> dict[str, Any]:
    ranking = [i.servico for i in decisao.ranking]
    respondeu = decisao.status == "decidiu"
    rank = ranking.index(esperado) + 1 if respondeu and esperado in ranking else None
    return {
        "run_id": os.path.basename(os.path.dirname(case_dir)), "falha": os.path.basename(case_dir),
        "modo": modo, "versao": decisao.versao, "expected": esperado, "ranking": ranking[:5],
        "status": decisao.status, "motivo_abstencao": decisao.motivo_abstencao, "respondeu": respondeu,
        "rank": rank, "top1": rank == 1, "top2": rank is not None and rank <= 2,
        "top3": rank is not None and rank <= 3, "rr": 1.0 / rank if rank else 0.0,
        "empate_topo": A.empate_no_topo([{"escore": i.escore, "evidencias": i.evidencias} for i in decisao.ranking]),
        "p_min_ajustado": (decisao.evidencias or {}).get("p_min_ajustado"),
        "q": (decisao.parametros or {}).get("q"), "segundos": decisao.segundos, **extra,
    }


def rodar_caso(job: tuple[str, list[str], bool]) -> list[dict[str, Any]]:
    case_dir, modos, as_recorded = job
    esperado = R._load(os.path.join(case_dir, "avaliacao.json"))["expected_service"]
    linhas: list[dict[str, Any]] = []
    entrada: EntradaIncidente | None = None
    colecao = ""
    for modo in modos:
        try:
            if modo == "a0":
                r = R.replay_case(case_dir, {}, False, as_recorded)
                decisao = a0.decisao_do_legado(r["ranking"], r["abstain_reason"], respondeu=r["respondeu"],
                                               segundos=r["seconds"])
                extra = {"same_as_original": r["same_as_original"], "original_ranking": r["original_ranking"],
                         "abstain_reason_legado": r["abstain_reason"]}
            else:
                if entrada is None:
                    entrada, colecao = entrada_do_caso(case_dir)
                artefato = P.carregar_ou_preparar(colecao, modo)
                decisao = registro.executar_modo(modo, entrada, artefato, P.cfg_do_modo(modo))
                extra = {"n_traces_janela": len({e.case_id for e in entrada.traces})}
        except Exception as exc:  # noqa: BLE001 - um caso quebrado não derruba o lote
            decisao = Decisao(status="falhou", evidencias={"erro": f"{type(exc).__name__}: {exc}"})
            extra = {"erro": f"{type(exc).__name__}: {exc}"}
        linhas.append(_linha(case_dir, modo, decisao, esperado, extra))
    return linhas


def resumo_md(rows: list[dict[str, Any]], modos: list[str], cabecalho: str) -> str:
    linhas = [f"# Replay dos modos — {cabecalho}", "",
              "| modo | casos | cobertura | Top-1 | Top-1 sem empate | IC Wilson Top-1 | Top-3 | MRR | falhou |",
              "|---|---|---|---|---|---|---|---|---|"]
    for modo in modos:
        rm = [r for r in rows if r["modo"] == modo]
        m = A.metricas(rm)
        if not m.get("n"):
            continue
        n = m["n"]
        falhou = sum(1 for r in rm if r["status"] == "falhou")
        linhas.append(f"| {modo} | {n} | {m['respondidos']}/{n} | {m['ac1']}/{n} | {m['ac1_sem_empate']}/{n} | "
                      f"{m['ic_ac1'][0]:.0%}–{m['ic_ac1'][1]:.0%} | {m['ac3']}/{n} | {m['mrr']:.3f} | {falhou} |")
    linhas += ["", "## Caso × modo (posição do serviço esperado; `-` absteve, `x` fora do ranking)", "",
               "| caso | esperado | " + " | ".join(modos) + " |", "|---|---|" + "---|" * len(modos)]
    por_caso: dict[str, dict[str, dict[str, Any]]] = {}
    for r in rows:
        por_caso.setdefault(A.chave_caso(r), {})[r["modo"]] = r
    for chave in sorted(por_caso):
        celulas = []
        for modo in modos:
            r = por_caso[chave].get(modo)
            if r is None:
                celulas.append("")
            elif not r["respondeu"]:
                celulas.append("-")
            else:
                celulas.append(str(r["rank"]) if r["rank"] else "x")
        esperado = next(iter(por_caso[chave].values()))["expected"]
        linhas.append(f"| {chave} | {esperado} | " + " | ".join(celulas) + " |")
    return "\n".join(linhas) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", help="RUN_IDs separados por vírgula (padrão: todas as rodadas completas)")
    ap.add_argument("--falhas", help="falhas separadas por vírgula")
    ap.add_argument("--modos", required=True, help="a0,d0_nula,d2,... ou 'todos'")
    ap.add_argument("--diagnostico", action="store_true",
                    help="libera d1–d4 em casos de falha (passo 9 da spec 42.10: só diagnóstico)")
    ap.add_argument("--as-recorded", action="store_true", help="a0 com o θ gravado (fidelidade)")
    ap.add_argument("--jobs", type=int, default=1)
    ap.add_argument("--label", default="")
    args = ap.parse_args()

    modos = (["a0", *[m for m in registro.MODOS if m != "d0_nula"]] if args.modos == "todos"
             else args.modos.split(","))
    for modo in modos:
        if modo != "a0" and modo not in registro.MODOS:
            raise SystemExit(f"modo sem implementação: {modo}")
    bloqueados = [m for m in modos if m not in LIVRES_SEM_DIAGNOSTICO]
    if bloqueados and not args.diagnostico:
        raise SystemExit(f"{bloqueados} em casos de falha exige --diagnostico (spec 42.10, passo 9)")

    cases = R.discover_cases(args.runs.split(",") if args.runs else None)
    if args.falhas:
        cases = [c for c in cases if os.path.basename(c) in set(args.falhas.split(","))]
    stamp = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    out_dir = os.path.join(R.RESULTADOS, "replay", f"{stamp}-abordagens-{args.label or '-'.join(modos)}")
    os.makedirs(out_dir, exist_ok=True)

    jobs = [(c, modos, args.as_recorded) for c in cases]
    if args.jobs > 1:
        with ProcessPoolExecutor(max_workers=args.jobs) as pool:
            resultados = list(pool.map(rodar_caso, jobs))
    else:
        resultados = [rodar_caso(j) for j in jobs]
    rows = [linha for grupo in resultados for linha in grupo]
    for r in rows:
        marca = "T1" if r["top1"] else ("--" if r["respondeu"] else "ab")
        print(f"  {marca} {r['modo']:7s} {r['run_id'][-7:]} {r['falha']:22s} {r['ranking'][:3]} "
              f"{r.get('motivo_abstencao') or r.get('erro') or ''}", flush=True)

    cabecalho = f"runs={args.runs or 'todas'} modos={','.join(modos)} as_recorded={args.as_recorded}"
    md = resumo_md(rows, modos, cabecalho)
    with open(os.path.join(out_dir, "resumo.md"), "w") as f:
        f.write(md)
    with open(os.path.join(out_dir, "resumo.json"), "w") as f:
        json.dump({"args": vars(args), "modos": modos, "rows": rows}, f, ensure_ascii=False, indent=2, default=str)
    print("\n" + md.split("\n## Caso")[0])
    print(f"Saída: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
