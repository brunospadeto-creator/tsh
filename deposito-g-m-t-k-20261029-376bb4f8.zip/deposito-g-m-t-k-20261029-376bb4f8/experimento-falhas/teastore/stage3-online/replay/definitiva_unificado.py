#!/usr/bin/env python3
"""PROTOCOLO-COLETA-DEFINITIVA.md §7 (secundário, fora da leitura do §6): tabela única de todos os modos nos 24
cenários da coleta definitiva, ordenada por F1@1 (como a tabela única do desenvolvimento, agora sobre dado de teste).

- Modos de traces pelo avaliador unificado (`protocolo_rapido.rodar_caso_unificado`, opção A): d1, d1c, d2, d3,
  d4, d4c com os artefatos `-w120`/`-fp0.2` da baseline `32c273a6`; d2c, d6, d6-k, d6-u, d7; d2c-r, d2c-cp, d5,
  d9, d9-2h, d9+m, a0-k, a0-d, a0-b; b1, b2. K8s limpo da Fase 0 (`PR_K8S_LIMPO=1`), 60 s, janela 120 s.
- d9-k, v-cons-b e v-cons-b disparo único: os registros do produto já gravados pelo `definitiva.py` (os mesmos da
  leitura do §6); a d9-k da análise do avaliador unificado fica de fora.
- Instantes: exatamente os do `definitiva.py` (D0.4 aplicada lá); b3 = constante (alvo mais frequente).
- a0 (pipeline legado) não entra: precisa de pacotes montados, fora do avaliador unificado.

Saída: `resultados/protocolo-coleta-definitiva/unificado/` (registros) e `tabela-unica.md`.

Uso: replay/definitiva_unificado.py [--jobs 16] [--so-analise]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from typing import Any

os.environ["PR_K8S_LIMPO"] = "1"   # lido na importação do protocolo_rapido
SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

SAIDA_U = os.path.join(DF.SAIDA, "unificado")
DO_PRODUTO = {"d9-k-prod": "d9-k", "v-cons-b-prod": "v-cons-b", "v-cons-b-1": "v-cons-b-1"}
FORA_UNIF = {"d9-k"}


def base(inv: dict[str, Any]) -> list[dict[str, Any]]:
    prod = C._novos(inv, DF.SAIDA, "*.jsonl.gz")
    instantes = {(r["cenario"], r["t"]) for r in prod}
    rs = [{**r, "modo": DO_PRODUTO[r["modo"]]} for r in prod if r["modo"] in DO_PRODUTO]
    rs += [r for r in C._novos(inv, SAIDA_U, "*.jsonl.gz")
           if r["modo"] not in FORA_UNIF and (r["cenario"], r["t"]) in instantes]
    alvo = Counter(inv[c]["esperado"] for c in inv).most_common(1)[0][0]
    rs += [{**r, "modo": "b3", "decidiu": True, "ranking": [alvo], "forcado": [alvo]}
           for r in rs if r["modo"] == "d9"]
    return rs


def analisar(inv: dict[str, Any]) -> str:
    rs = base(inv)
    pcs: dict[str, dict[str, dict[str, float]]] = {}
    for (m, c), x in A.por_cenario(rs, inv).items():
        pcs.setdefault(m, {})[c] = x
    linhas = []
    for m, pc in pcs.items():
        r = DF.metricas(pc)
        por_g = {g: A.f1([x for c, x in pc.items() if inv[c]["grupo"] == g]) for g in "hg"}
        linhas.append((m, len(pc), r, DF._boot(pc, A.f1), por_g))
    linhas.sort(key=lambda x: (-x[2]["f1"], -x[2]["o1"]))
    n_inst = len({(r["cenario"], r["t"]) for r in rs if r["modo"] == "d9"})
    out = ["# Coleta definitiva — tabela única de todos os modos (§7, secundária)", "",
           f"{len(inv)} cenários ({sum(v['grupo'] == 'h' for v in inv.values())} h, "
           f"{sum(v['grupo'] == 'g' for v in inv.values())} g), {n_inst} instantes (os mesmos do `resultado.md`), "
           "baseline `32c273a6`. Fora da leitura do §6; nada ajustado. d9-k e v-cons-b = registros do produto; "
           "demais = avaliador unificado (§42.68). Sabendo = decisão forçada (oráculo).", "",
           "| # | modo | cenários | F1@1 [IC 95%] | F1@2 | F1@3 | F1@1 h | F1@1 g | alarme | abstenção | "
           "sabendo top-1 | top-2 | top-3 |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for i, (m, n, r, ic, g) in enumerate(linhas, 1):
        nome = f"**{m}**" if m in ("d9-k", "v-cons-b") else m
        out.append(f"| {i} | {nome} | {n} | {r['f1']:.3f} [{ic[0]:.3f}–{ic[1]:.3f}] | {r['f2']:.3f} | "
                   f"{r['f3']:.3f} | {g['h']:.3f} | {g['g']:.3f} | {r['alarme']:.1%} | {r['abst']:.0%} | "
                   f"{r['o1']:.0%} | {r['o2']:.0%} | {r['o3']:.0%} |")
    ordem = [m for m, *_ in linhas]
    out += ["", "## Sabendo top-1 por cenário (acertos/estáveis)", "",
            "| cenário | gabarito | " + " | ".join(ordem) + " |", "|---|---|" + "---|" * len(ordem)]
    for c in sorted(inv):
        cel = [f"{pcs[m][c]['o1']}/{pcs[m][c]['n_est']}" if c in pcs[m] and pcs[m][c].get("n_est") else "—"
               for m in ordem]
        out.append(f"| {c} | {inv[c]['esperado'].replace('teastore-', '')} | " + " | ".join(cel) + " |")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-analise", action="store_true")
    args = ap.parse_args()
    cs = DF.casos(DF.runs())
    with open(os.path.join(DF.SAIDA, "inventario.json")) as f:
        inv = json.load(f)
    if not args.so_analise:
        from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(PR.rodar_caso_unificado, [(c, 60.0, SAIDA_U, None) for c in cs]):
                print(msg, flush=True)
    texto = analisar(inv)
    with open(os.path.join(DF.SAIDA, "tabela-unica.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
