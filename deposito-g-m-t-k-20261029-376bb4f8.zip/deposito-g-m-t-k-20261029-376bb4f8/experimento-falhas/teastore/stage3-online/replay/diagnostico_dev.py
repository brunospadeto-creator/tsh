#!/usr/bin/env python3
"""Diagnóstico dos sinais candidatos dos filhos, **só em desenvolvimento** (f, h).

Estende a tabela do diagnóstico inicial a todos os cenários de dev e a todos os instantes (passo `--passo`, janela de 120 s):
para cada instante, o ranking de serviços de cada sinal candidato, sem limiar nem portão — o objetivo é saber
**qual sinal aponta o gabarito** e **quão grande ele fica nos normais**, antes de desenhar d9-2h / d6-k / d9+m.

Sinais (o banco é `teastore-db`: spans com `db.system`, como o crédito JDBC da d9):

- `efeito_max`   maior escore de efeito (razão de mediana da duração **total** ou 1+10·Δerro) por serviço — a d9;
- `proprio_delta` Δ do tempo próprio por requisição de entrada (span − união dos filhos), em ms — d6-k;
- `proprio_razao` razão do tempo próprio por requisição;
- `mediana_serv` mediana das razões das atividades do serviço (efeito pequeno e espalhado, f10) — d9-2h (i);
- `sumico_ativ`  nº de atividades com ≥ `MIN_SUMICO` na referência e 0 na janela, creditadas ao dono — d9-2h (ii);
- `k8s`          eventos K8s na janela menos a taxa da referência, por serviço — d9+m.

Escalares: `vazao` (traces na janela / na referência, por segundo), `dano` (`referencia.dano_na_entrada`).

Referência: no estável, os 150 s antes da transição (travada, como a d5 com trava); no normal, os 150 s antes da
janela (`lookback`). Também grava os rankings já calculados de d9 (parâmetro de dev) e d2c (L=1e-50) no instante.
Os g não são lidos.

Saída: `resultados/diagnostico-dev/<RUN>__<falha>.jsonl.gz` + `resumo.md` (acerto@1 por sinal no estável,
quantis do topo de cada sinal nos normais).

Uso: replay/diagnostico_dev.py [--jobs 16] [--passo 15]
"""
from __future__ import annotations

import argparse
import datetime
import glob
import gzip
import json
import os
import re
import statistics
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import avaliar_instantes as AI  # noqa: E402, N812
import metricas_instantes as M  # noqa: E402, N812
import preparar_baseline_abordagens as P  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import processo, referencia  # noqa: E402

SAIDA_PADRAO = os.path.join(R.RESULTADOS, "diagnostico-dev")
RUNS_DEV = ("20260926T203024Z", "20260927T051757Z", "20261012T072332Z", "20261012T193519Z", "20261013T051436Z")
REF_SEG = 150
MIN_EVENTOS = 5
MIN_SUMICO = 5
DB = "teastore-db"
D9_PARAM, D9_LOC = "L=1.5,E=0.1,D=off,R=150", "residuo_1"   # resumo-d8d9.md, escolhido em dev
D2C_FP, D2C_L = 0.20, 1e-50                                  # resumo-20261014.md, emenda 1
SINAIS = ("efeito_max", "proprio_delta", "proprio_razao", "mediana_serv", "sumico_ativ", "k8s")
NEUTRO = {"efeito_max": 1.0, "proprio_delta": 0.0, "proprio_razao": 1.0, "mediana_serv": 1.0, "sumico_ativ": 0.0,
          "k8s": 0.0}   # o sinal só aponta um serviço acima do neutro


def _servico(e: Any) -> str:
    return DB if e.attributes.get("db.system") else (e.service or processo.servico_da_atividade(e.activity))


def tempo_proprio(eventos: list[Any]) -> dict[int, int]:
    """id(evento) → tempo próprio em µs: duração menos a união dos intervalos dos filhos, cortada ao pai."""
    por_trace: dict[str, list[Any]] = defaultdict(list)
    for e in eventos:
        por_trace[e.case_id].append(e)
    saida: dict[int, int] = {}
    for spans in por_trace.values():
        filhos: dict[str, list[Any]] = defaultdict(list)
        for e in spans:
            pai = e.attributes.get("parent_span_id")
            if pai:
                filhos[pai].append(e)
        for e in spans:
            ini, fim = e.start_us, e.start_us + e.duration_us
            coberto, cur_i, cur_f = 0, None, None
            for f in sorted(filhos.get(e.span_id, ()), key=lambda x: x.start_us):
                a, b = max(ini, f.start_us), min(fim, f.start_us + f.duration_us)
                if b <= a:
                    continue
                if cur_f is None or a > cur_f:
                    if cur_f is not None:
                        coberto += cur_f - cur_i
                    cur_i, cur_f = a, b
                else:
                    cur_f = max(cur_f, b)
            if cur_f is not None:
                coberto += cur_f - cur_i
            saida[id(e)] = max(0, e.duration_us - coberto)
    return saida


def _k8s(case_dir: str) -> list[tuple[datetime.datetime, datetime.datetime, str, str, str]]:
    caminho = os.path.join(case_dir, "k8s_events_cluster.json")
    if not os.path.exists(caminho):
        return []
    saida = []
    for it in R._load(caminho).get("items") or []:
        nome = (it.get("involvedObject") or {}).get("name") or ""
        m = re.match(r"^(teastore-[a-z]+)", nome)
        ini = it.get("firstTimestamp") or it.get("eventTime") or (it.get("metadata") or {}).get("creationTimestamp")
        fim = it.get("lastTimestamp") or ini
        if m and ini:
            saida.append((AI._utc(ini), AI._utc(fim), m.group(1), it.get("reason") or "", it.get("type") or ""))
    return saida


def _k8s_janela(k8s, janela) -> Counter:
    c: Counter = Counter()
    for ini, fim, serv, motivo, _tipo in k8s:
        if fim >= janela[0] and ini <= janela[1]:
            c[(serv, motivo)] += 1
    return c


def _stats(ev: list[Any], proprio: dict[int, int]) -> dict[str, Any]:
    s = referencia.estatisticas(ev, servicos_raiz=P.ENTRY_SERVICES)
    for e in ev:  # o banco como serviço próprio, para todos os sinais
        if e.attributes.get("db.system") and e.activity in s["ativ"]:
            s["ativ"][e.activity]["servico"] = DB
    n_req = len(referencia.raizes_de(ev, P.ENTRY_SERVICES)) or 1
    prop_serv: dict[str, float] = defaultdict(float)
    for e in ev:
        prop_serv[_servico(e)] += proprio.get(id(e), 0)
    s["proprio_por_req_ms"] = {k: v / n_req / 1000.0 for k, v in prop_serv.items()}
    s["n_traces"] = len({e.case_id for e in ev})
    return s


def sinais(inc: dict[str, Any], ref: dict[str, Any], k_inc: Counter, k_ref: Counter, razao_t: float) -> dict[str, Any]:
    efeitos = referencia.efeitos_por_atividade(inc, ref, min_eventos=MIN_EVENTOS)
    efeito_max: dict[str, float] = {}
    por_serv: dict[str, list[float]] = defaultdict(list)
    for ef in efeitos:
        esc = referencia.escore_efeito(ef)
        efeito_max[ef["servico"]] = max(efeito_max.get(ef["servico"], 0.0), esc)
        por_serv[ef["servico"]].append(ef["ratio_mediana"])
    mediana_serv = {s: statistics.median(v) for s, v in por_serv.items() if len(v) >= 2}
    sumico: Counter = Counter()
    sumidas = []
    for a, i in ref["ativ"].items():
        if i["n"] >= MIN_SUMICO and a not in inc["ativ"]:
            sumico[i["servico"]] += 1
            sumidas.append(a)
    pi, pr = inc["proprio_por_req_ms"], ref["proprio_por_req_ms"]
    servs = set(pi) | set(pr)
    proprio_delta = {s: pi.get(s, 0.0) - pr.get(s, 0.0) for s in servs}
    proprio_razao = {s: pi.get(s, 0.0) / pr[s] for s in servs if pr.get(s, 0.0) > 0.05}
    k_serv: dict[str, float] = defaultdict(float)
    for (serv, _m), n in k_inc.items():
        k_serv[serv] += n
    for (serv, _m), n in k_ref.items():
        k_serv[serv] -= n * razao_t
    top_ef = sorted(efeitos, key=referencia.escore_efeito, reverse=True)[:5]
    return {
        "efeito_max": efeito_max, "proprio_delta": proprio_delta, "proprio_razao": proprio_razao,
        "mediana_serv": mediana_serv, "sumico_ativ": dict(sumico), "k8s": dict(k_serv),
        "_top_atividades": [(e["atividade"], round(e["ratio_mediana"], 3), round(e["delta_erro"], 3)) for e in top_ef],
        "_sumidas": sumidas[:10], "_k8s_motivos": sorted({f"{s}:{m}" for (s, m) in k_inc})[:10],
    }


def _ranking(d: dict[str, float], neutro: float) -> list[str]:
    return [s for s, v in sorted(d.items(), key=lambda kv: (-kv[1], kv[0])) if v > neutro]


def _decisoes(case_dir: str, run_id: str, falha: str) -> dict[str, dict[str, Any]]:
    """t → {'d9': ranking|None, 'd2c': ranking|None} (instantes já gravados)."""
    saida: dict[str, dict[str, Any]] = defaultdict(dict)
    d9 = os.path.join(R.RESULTADOS, "instantes-d9", f"{run_id}__{falha}__d9.jsonl.gz")
    if os.path.exists(d9):
        with gzip.open(d9, "rt") as f:
            for x in f:
                r = json.loads(x)
                if r["param"] == D9_PARAM:
                    rk = (r.get("rankings") or {}).get(D9_LOC)
                    saida[r["t"]]["d9"] = rk if r["status"] == "decidiu" and rk else None
    base = os.path.join(R.RESULTADOS, "instantes", f"{run_id}__{falha}.jsonl")
    if os.path.exists(base):
        with open(base) as f:
            for x in f:
                r = json.loads(x)
                if r["modo"] == "d2c" and r.get("fp_alvo") == D2C_FP:
                    est = r.get("estatistica")
                    ok = r["status"] == "decidiu" and est is not None and est <= D2C_L
                    saida[r["t"]]["d2c"] = r.get("ranking") if ok else None
    return saida


def rodar_caso(job: tuple[str, float, str]) -> str:
    case_dir, passo, saida = job
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência ou pacotes -- fora"
    t0 = time.monotonic()
    eventos = AI.eventos_do_caso(case_dir)
    proprio = tempo_proprio(eventos)
    k8s = _k8s(case_dir)
    decisoes = _decisoes(case_dir, run_id, falha)
    esperado = M.esperado(run_id, falha)
    cache: dict[Any, dict[str, Any]] = {}

    def st(janela):
        if janela not in cache:
            cache[janela] = _stats(AI._sem_bolha(eventos, janela), proprio)
        return cache[janela]

    ref_fixa = (per["normal"][1] - datetime.timedelta(seconds=REF_SEG), per["normal"][1])
    linhas = []
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, passo):
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        if periodo == "estavel":
            ref_j = ref_fixa
        else:
            ref_j = (janela[0] - datetime.timedelta(seconds=REF_SEG), janela[0])
            if ref_j[0] < per["normal"][0]:
                continue
        inc, ref = st(janela), st(ref_j)
        razao_t = AI.JANELA_SEG / REF_SEG
        sig = sinais(inc, ref, _k8s_janela(k8s, janela), _k8s_janela(k8s, ref_j), razao_t)
        dano = referencia.dano_na_entrada(inc, ref, {})
        dec = decisoes.get(t.isoformat(), {})
        linhas.append(json.dumps({
            "run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat(), "esperado": esperado,
            "vazao": (inc["n_traces"] / AI.JANELA_SEG) / (ref["n_traces"] / REF_SEG) if ref["n_traces"] else None,
            "dano_lat": dano["ratio_lat"], "dano_erro": dano["delta_erro"],
            "rankings": {s: _ranking(sig[s], NEUTRO[s])[:4] for s in SINAIS},
            "topo": {s: (max(sig[s].values()) if sig[s] else None) for s in SINAIS},
            "valor_esperado": {s: sig[s].get(esperado) for s in SINAIS},
            "d9": dec.get("d9"), "d2c": dec.get("d2c"),
            "top_atividades": sig["_top_atividades"], "sumidas": sig["_sumidas"], "k8s_motivos": sig["_k8s_motivos"],
        }))
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} instantes em {time.monotonic() - t0:.0f}s"


# --- resumo ---

def _q(v: list[float], p: float) -> float:
    v = sorted(x for x in v if x is not None)
    return v[min(len(v) - 1, int(p * len(v)))] if v else float("nan")


def resumo(saida: str) -> str:
    por_cen: dict[str, list[dict[str, Any]]] = {}
    for arq in sorted(glob.glob(os.path.join(saida, "*.jsonl.gz"))):
        with gzip.open(arq, "rt") as f:
            linhas = [json.loads(x) for x in f if x.strip()]
        if linhas:
            por_cen[f"{linhas[0]['run_id']}/{linhas[0]['falha']}"] = linhas
    cols = (*SINAIS, "d9", "d2c")
    out = ["# Diagnóstico dos sinais candidatos — só desenvolvimento (f, h)", "",
           f"Gerado por `replay/diagnostico_dev.py` em {datetime.datetime.now(datetime.UTC):%Y-%m-%dT%H:%MZ}. "
           "Sem portão nem limiar: acerto@1 = fração dos instantes estáveis em que o gabarito é o topo do sinal "
           "(d9/d2c: decidiu e acertou). Os g não foram lidos.", "",
           "## Acerto@1 por cenário (instantes estáveis)", "",
           "| cenário | gabarito | n | vazão (med) | " + " | ".join(cols)
           + " | topo mais comum da d9 | atividade de maior efeito (med.) | sumidas | K8s |",
           "|---|---|---|---|" + "---|" * len(cols) + "---|---|---|---|"]
    tot: dict[str, list[float]] = defaultdict(list)
    for cen, linhas in por_cen.items():
        est = [r for r in linhas if r["periodo"] == "estavel"]
        if not est:
            continue
        esp = est[0]["esperado"]
        cel = []
        for c in cols:
            if c in SINAIS:
                v = sum(bool(r["rankings"][c]) and r["rankings"][c][0] == esp for r in est) / len(est)
            else:
                v = sum(bool(r[c]) and r[c][0] == esp for r in est) / len(est)
            tot[c].append(v)
            cel.append(f"{v:.0%}")
        meio = est[len(est) // 2]
        top_d9 = Counter((r["d9"] or ["(absteve)"])[0] for r in est).most_common(1)[0][0]
        ativ = "; ".join(f"{a} ×{x:g}" for a, x, _ in meio["top_atividades"][:2])
        out.append(f"| {cen} | {esp.replace('teastore-', '')} | {len(est)} | "
                   f"{statistics.median([r['vazao'] for r in est if r['vazao'] is not None] or [float('nan')]):.2f} | "
                   + " | ".join(cel) + f" | {top_d9.replace('teastore-', '')} | {ativ} | "
                   f"{len(meio['sumidas'])} | {', '.join(meio['k8s_motivos'][:3])} |")
    out.append("| **média por cenário** | | | | " + " | ".join(f"**{statistics.mean(tot[c]):.0%}**" for c in cols)
               + " | | | | |")
    out += ["", "## Tamanho do topo de cada sinal: normais vs estáveis (quantis)", "",
            "Para escolher limiar só em dev: quanto o maior valor de cada sinal chega nos instantes normais.", "",
            "| sinal | normal p50 | normal p95 | normal p99 | estável p50 | estável, valor do gabarito p50 |",
            "|---|---|---|---|---|---|"]
    todas = [r for linhas in por_cen.values() for r in linhas]
    for s in SINAIS:
        nor = [r["topo"][s] for r in todas if r["periodo"] == "normal"]
        est = [r["topo"][s] for r in todas if r["periodo"] == "estavel"]
        gab = [r["valor_esperado"][s] for r in todas if r["periodo"] == "estavel"]
        out.append(f"| {s} | {_q(nor, .5):.3g} | {_q(nor, .95):.3g} | {_q(nor, .99):.3g} | {_q(est, .5):.3g} | "
                   f"{_q(gab, .5):.3g} |")
    nor_v = [r["vazao"] for r in todas if r["periodo"] == "normal"]
    est_v = [r["vazao"] for r in todas if r["periodo"] == "estavel"]
    out += ["", f"Vazão (janela/referência): normal p1 {_q(nor_v, .01):.2f}, p5 {_q(nor_v, .05):.2f}; "
            f"estável p5 {_q(est_v, .05):.2f}, p50 {_q(est_v, .5):.2f}."]
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--passo", type=float, default=15.0)
    ap.add_argument("--saida", default=SAIDA_PADRAO)
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-resumo", action="store_true")
    args = ap.parse_args()
    if not args.so_resumo:
        casos = [c for run in RUNS_DEV for c in sorted(glob.glob(os.path.join(R.RESULTADOS, run, "[fh][0-9]*")))
                 if os.path.isdir(c)]
        jobs = [(c, args.passo, args.saida) for c in casos]
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(rodar_caso, jobs):
                print(msg, flush=True)
    texto = resumo(args.saida)
    with open(os.path.join(args.saida, "resumo.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
