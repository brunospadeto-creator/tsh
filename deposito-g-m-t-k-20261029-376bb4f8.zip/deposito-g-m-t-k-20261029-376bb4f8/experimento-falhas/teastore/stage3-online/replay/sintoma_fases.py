#!/usr/bin/env python3
"""Eventos de sintoma do Kubernetes fora da falha (análise adicional, pedida pelos revisores simulados; fora do protocolo).

Nos 41 cenários do TeaStore usados no artigo (os mesmos de `resultado-sintoma-normais.md`), conta os eventos do
cluster cujo motivo está em `d9k.K8S_SINTOMA` em três fases da linha do tempo de cada cenário:
- **antes**: até o fim da janela normal de referência (`referencia.json`): implantação inicial e operação normal;
- **falha**: do fim da referência ao fim da janela da injeção (`incident.json`): aplicação da falha e período estável;
- **depois**: depois da janela da injeção: reversão da falha (uma atualização de rotina) e recuperação.
Os eventos de sintoma em "antes" e em "depois" são os que operações de rotina emitem sem a causa estar ativa.
Uso: replay/sintoma_fases.py [--raiz DIR] → `resultados/protocolo-metricas-rz/k8s/resultado-sintoma-fases.md`.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import sys
from collections import Counter, defaultdict

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ_REPO = os.path.abspath(os.path.join(AQUI, "..", "..", "..", ".."))
sys.path.insert(0, RAIZ_REPO)
from src.application.stage3.abordagens.d9k_portao_grafo_k8s import K8S_SINTOMA  # noqa: E402

LISTA = os.path.join(AQUI, "..", "resultados", "protocolo-metricas-rz", "k8s", "resultado-sintoma-normais.md")


def _ts(s: str) -> float:
    s = s.rstrip("Z")
    return dt.datetime.fromisoformat(s).replace(tzinfo=dt.timezone.utc).timestamp()


def cenarios(lista: str) -> list[tuple[str, str]]:
    return re.findall(r"^\| (B′|definitiva) \| ([0-9TZ]+/[^ |]+) \|", open(lista).read(), re.M)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raiz", default=os.path.join(AQUI, "..", "resultados"))
    ap.add_argument("--lista", default=LISTA)
    a = ap.parse_args()
    sint = set(K8S_SINTOMA)
    linhas, tot = [], defaultdict(Counter)
    por_motivo = defaultdict(Counter)
    for conj, cen in cenarios(a.lista):
        d = os.path.join(a.raiz, cen)
        ref_fim = _ts(json.load(open(os.path.join(d, "referencia.json")))["window_end"])
        inc_fim = _ts(json.load(open(os.path.join(d, "incident.json")))["window_end"])
        ev = json.load(open(os.path.join(d, "k8s_events_cluster.json")))
        ev = ev["items"] if isinstance(ev, dict) else ev
        c = Counter()
        for e in ev:
            t1 = e.get("firstTimestamp") or e.get("eventTime") or e.get("lastTimestamp")
            t2 = e.get("lastTimestamp") or t1
            if not t1:
                continue
            a1, a2 = _ts(t1), _ts(t2)
            # um evento agregado (`count` > 1) vale do primeiro ao último registro: conta em cada fase que atravessa
            fases = [f for f, (i, j) in (("antes", (-1e18, ref_fim)), ("falha", (ref_fim, inc_fim)),
                                          ("depois", (inc_fim, 1e18))) if a1 <= j and a2 > i]
            for fase in fases:
                c[f"{fase}_todos"] += 1
                if e.get("reason") in sint:
                    c[f"{fase}_sint"] += 1
                    por_motivo[fase][e["reason"]] += 1
        for k, v in c.items():
            tot[conj][k] += v
        linhas.append(f"| {conj} | {cen} | {c['antes_sint']} / {c['antes_todos']} | {c['falha_sint']} / "
                      f"{c['falha_todos']} | {c['depois_sint']} / {c['depois_todos']} |")
    sem_antes = sum(1 for l in linhas if l.split("|")[3].strip().startswith("0 /"))
    sem_depois = sum(1 for l in linhas if l.split("|")[5].strip().startswith("0 /"))
    out = ["# Eventos de sintoma do Kubernetes fora da falha no TeaStore (análise adicional)", "",
           "`replay/sintoma_fases.py`. Eventos do cluster com motivo em `K8S_SINTOMA` "
           f"({', '.join(K8S_SINTOMA)}) por fase da linha do tempo de cada cenário. Célula: eventos de sintoma / todos "
           "os eventos; um evento agregado conta em cada fase que o intervalo do primeiro ao último registro atravessa.", "",
           f"Cenários: {len(linhas)}. Sem nenhum evento de sintoma antes do fim da referência: {sem_antes}; sem nenhum "
           f"depois da janela da injeção (reversão): {sem_depois}.", "",
           "| conjunto | total antes (sintoma / todos) | falha | depois |", "|---|---|---|---|"]
    for conj, c in tot.items():
        out.append(f"| {conj} | {c['antes_sint']} / {c['antes_todos']} | {c['falha_sint']} / {c['falha_todos']} | "
                   f"{c['depois_sint']} / {c['depois_todos']} |")
    out += ["", "Motivos dos eventos de sintoma por fase: " + "; ".join(
        f"{f}: {dict(por_motivo[f])}" for f in ("antes", "falha", "depois")), "",
        "| conjunto | cenário | antes | falha | depois |", "|---|---|---|---|---|", *linhas]
    dest = os.path.join(AQUI, "..", "resultados", "protocolo-metricas-rz", "k8s", "resultado-sintoma-fases.md")
    texto = "\n".join(out) + "\n"
    open(dest, "w").write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
