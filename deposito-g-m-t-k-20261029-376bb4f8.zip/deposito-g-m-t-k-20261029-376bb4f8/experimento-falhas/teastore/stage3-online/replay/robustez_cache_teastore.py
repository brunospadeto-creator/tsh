#!/usr/bin/env python3
"""Cache por instante do TeaStore (41 cenários: B′ 17 + definitiva 24) para a emenda 3 (robustez) do
`bases-externas/metricas-rz/PROTOCOLO-COMPLETO.md`.

Por cenário: janelas de baseline das métricas, e por instante os escores `m-rzf` (`f`), o serviço K8s de sintoma, o
portão de traces gravado, os efeitos da d5 e o p_min da d2c-r (q = 1), para recalibrar λ e q a cada sorteio (mesmas
linhas do `baseline_dinamica.rodar_caso`). Também guarda o BARO/N-Sigma oficiais, as decisões gravadas de d9-k, d9-k+a,
d9, d9+a e v-cons-b, e as janelas da baseline de traces de cada coleção.

Opções:
- `--grade J R`: refaz só os escores das métricas com janela J s e referência R s (R5);
- `--saida`: o pickle.

Uso: replay/robustez_cache_teastore.py [--grade 120 600] [--saida X.pkl]
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import pickle
import sys
import warnings
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import baseline_dinamica as BDT  # noqa: E402, N812
import confirmatorio as CF  # noqa: E402, N812
import consenso as C  # noqa: E402, N812
import metricas_rz_k8s as K  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812

CI = K.CI


def efeitos_caso(case_dir: str, instantes: list[tuple[str, str]]) -> dict[str, dict[str, Any]]:
    """Efeitos da d5 (todas as atividades) e p_min da d2c-r em cada instante (as linhas do `baseline_dinamica`)."""
    import a0b_insumos as A0BI  # noqa: N812, PLC0415
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    from src.application.stage3.abordagens import d5_portao as d5  # noqa: PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    from src.application.stage3.abordagens import referencia  # noqa: PLC0415
    from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: PLC0415
    AI, AF = PR.AI, PR.AF  # noqa: N806
    per = AI.periodos(case_dir)
    eventos = A0BI.eventos_do_caso(case_dir)
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), fim_normal))
    sis = {"entry_services": PR.P.ENTRY_SERVICES}
    cfg9 = d9._cfg({**sis, **PR.PORTAO_D9})
    out = {}
    for periodo, ts in instantes:
        t = datetime.datetime.fromisoformat(ts)
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if periodo == "estavel":
            lookback = AF._deslocar_traces(pre_falha, int((janela[0] - fim_normal).total_seconds() * 1e6))
        else:
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), janela[0]))
        ent = EntradaIncidente(incidente_id=f"r-{ts}", janela=janela, abertura_incidente=t, traces=dentro,
                               traces_lookback=lookback, metricas={}, eventos_k8s=[], config_sistema=sis)
        raiz = d5._entradas(ent, cfg9)
        ref = referencia.estatisticas(d5._eventos_ref(ent, cfg9), servicos_raiz=raiz)
        efeitos = d5.medir(referencia.estatisticas(ent.traces, servicos_raiz=raiz), ref, cfg9)["efeitos"]
        try:
            dp = d2cr.decidir(ent, {}, {**sis, "q": 1.0})
            pm = (dp.evidencias or {}).get("p_min_ajustado")
            pm, rk = (float(pm) if pm is not None else 1.0), bool(dp.ranking)
        except Exception:  # noqa: BLE001
            pm, rk = 1.0, False
        out[ts] = {"efeitos": efeitos, "p_min": pm, "rk2": rk}
    return out


def job(arg: tuple[str, dict[str, Any], bool]) -> dict[str, Any]:
    case_dir, cj, com_traces = arg
    r = K.caso((case_dir, cj))
    if com_traces:
        ef = efeitos_caso(case_dir, [(x["periodo"], x["t"]) for x in r["inst"]])
        for x in r["inst"]:
            x.update(ef[x["t"]])
    return r


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--grade", nargs=2, type=int, default=None)
    ap.add_argument("--saida", default=os.path.join(K.T.SAIDA, "robustez", "cache-teastore.pkl"))
    ap.add_argument("--jobs", type=int, default=24)
    args = ap.parse_args()
    warnings.simplefilter("ignore", RuntimeWarning)
    if args.grade:
        CI.JANELA, CI.REF = args.grade
    cjs = K.conjuntos()
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    out: dict[str, Any] = {"conjuntos": {}}
    with ProcessPoolExecutor(args.jobs) as ex:
        for nome, cj in cjs.items():
            inv = CF.inventario(cj["casos"])
            res = list(ex.map(job, [(c, cj, args.grade is None) for c in cj["casos"]]))
            comp = {}
            if args.grade is None:
                rs = [x for x in C._novos(inv, cj["hibrido"], "*.jsonl.gz") if x["modo"] in ("d9-k", "d9-k+a", "d9", "d9+a")]
                rs += [{**x, "modo": "v-cons-b"} for x in C._novos(inv, cj["solucoes"], "*.jsonl.gz")
                       if x["modo"] == "v-cons-b-prod"]
                for x in rs:
                    comp[(x["modo"], x["cenario"], x["t"])] = (x["decidiu"], x["ranking"], x["forcado"])
            out["conjuntos"][nome] = {"inv": inv, "res": res, "comp": comp}
    if args.grade is None:
        out["baseline_traces"] = {}
        for col in ("547ba505", "32c273a6"):
            with open(os.path.join(BDT.SAIDA, f"baseline-{col}.json")) as f:
                out["baseline_traces"][col] = json.load(f)
    os.makedirs(os.path.dirname(args.saida), exist_ok=True)
    with open(args.saida + ".tmp", "wb") as f:
        pickle.dump(out, f)
    os.replace(args.saida + ".tmp", args.saida)
    print(f"cache: {args.saida}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
