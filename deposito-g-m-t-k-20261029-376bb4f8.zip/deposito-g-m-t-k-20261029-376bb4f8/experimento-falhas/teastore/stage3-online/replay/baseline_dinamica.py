#!/usr/bin/env python3
"""Pré-teste d9-b / d2c-b / d9-b+c e d9-k-b / d9-k-b+c na definitiva do TeaStore
(`bases-externas/baseline-dinamica/PROTOCOLO.md`). Limiares calculados pela baseline da coleção (90 min), sem
valor fixo de portão nem de q; única constante de política: `FP_ALVO`.

Mesma entrada, instantes e D0.4 do `hibrido_d9a.py` (definitiva). Modos novos com nomes novos; `d9`, `d9-k` refeitos
como referência e `d9+a`/`d9-k+a`/`v-cons-b` lidos dos registros já gravados. Nada de `src/` muda.
Saída: `resultados/protocolo-baseline-dinamica/def/` e `resultado.md`.
Uso: replay/baseline_dinamica.py [--jobs 16] [--so-analise]
"""
from __future__ import annotations

import argparse
import datetime
import gzip
import json
import os
import sys
import time
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)
sys.path.insert(0, os.path.join(SELF_DIR, "..", "..", "..", "..", "bases-externas", "baseline-dinamica"))

import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import hibrido_d9a as H  # noqa: E402, N812
import paridade_solucoes as PS  # noqa: E402, N812
import preparar_baseline_abordagens as P  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

import calib  # noqa: E402  (bases-externas/baseline-dinamica; depois dos módulos do replay, que põem a raiz no path)

from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: E402

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-baseline-dinamica")
FPS = (calib.FP_ALVO, 0.01)


def _calibracao(colecao: str) -> dict[str, Any]:
    """Medidas das janelas da baseline da coleção (cache em disco) → calibração para cada FP."""
    destino = os.path.join(SAIDA, f"baseline-{colecao}.json")
    if not os.path.exists(destino):
        import a0b_insumos as A0BI  # noqa: N812, PLC0415
        from src.application.stage3.abordagens import processo  # noqa: PLC0415
        with gzip.open(P.backup_de(colecao)) as f:
            brutos = json.load(f).get("traces") or {}
        eventos = A0BI.enriquecer(processo.eventos_de_traces_brutos(brutos, P.ENTRY_SERVICES), brutos)
        sis = {"entry_services": PR.P.ENTRY_SERVICES}
        janelas = [calib.medir(ent, sis, PR.PORTAO_D9) for ent in calib.janelas_normais(eventos, sis["entry_services"])]
        os.makedirs(SAIDA, exist_ok=True)
        with open(destino + ".tmp", "w") as f:
            json.dump(janelas, f, default=str)
        os.replace(destino + ".tmp", destino)
    with open(destino) as f:
        janelas = json.load(f)
    return {str(fp): calib.calibrar(janelas, fp) for fp in FPS}


def _nomes(d: Any) -> list[str]:
    return [i.servico for i in d.ranking][:3]


def rodar_caso(job: tuple[str, str]) -> str:
    import a0b_insumos as A0BI  # noqa: N812, PLC0415
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    from src.application.stage3.abordagens import d5_portao as d5  # noqa: PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k  # noqa: PLC0415
    from src.application.stage3.abordagens import referencia  # noqa: PLC0415
    case_dir, saida = job
    AI, AF = PR.AI, PR.AF  # noqa: N806
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência -- fora"
    t0 = time.monotonic()
    colecao = PR.R._load(os.path.join(os.path.dirname(case_dir), "manifest.json"))["collection_id"][:8]
    cals = _calibracao(colecao)
    eventos = A0BI.eventos_do_caso(case_dir)
    k8s = PR._k8s_limpo(AF._k8s_dicts(case_dir), per["normal"][0])
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), fim_normal))
    pre_k8s = AF._visao_em(k8s, fim_normal)
    sis = {"entry_services": PR.P.ENTRY_SERVICES}
    cfg9 = d9._cfg({**sis, **PR.PORTAO_D9})
    linhas = []
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, PS.PASSO):
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if len({e.case_id for e in dentro}) < PS.MIN_TRACES:
            continue
        if periodo == "estavel":
            delta = janela[0] - fim_normal
            lookback = AF._deslocar_traces(pre_falha, int(delta.total_seconds() * 1e6))
            k8s_todos = AF._iso(pre_k8s, delta) + AF._iso(AF._a_partir_de(AF._visao_em(k8s, t), janela[0]))
        else:
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), janela[0]))
            k8s_todos = AF._iso(AF._visao_em(k8s, t))
        ent = EntradaIncidente(incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
                               traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=k8s_todos,
                               config_sistema=sis)
        base = {"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat()}
        res: dict[str, dict[str, Any]] = {}
        # referências refeitas: d9 e d9-k (como no hibrido_d9a)
        g9 = PR._decidir(d9, ent, {}, cfg9)
        f9 = g9["ranking"] if g9["status"] == "decidiu" and g9["ranking"] else \
            PR._decidir(d9, ent, {}, {**cfg9, **PR.PERMISSIVO_D5})["ranking"]
        res["d9"] = {"status": g9["status"], "ranking": g9["ranking"] if g9["status"] == "decidiu" else [], "forcado": f9}
        dk = d9k.decidir(ent, {}, sis)
        fk = list(dk.evidencias.get("ranking_forcado") or [])[:3]
        res["d9-k"] = {"status": dk.status, "ranking": _nomes(dk) if dk.status == "decidiu" else [], "forcado": fk}
        servico_k8s = d9k.servico_k8s(ent, d9k._cfg(sis))
        # medidas para a d9-b: efeitos (todas as atividades) e grafo da janela
        raiz = d5._entradas(ent, cfg9)
        ev_ref = d5._eventos_ref(ent, cfg9)
        ref = referencia.estatisticas(ev_ref, servicos_raiz=raiz)
        efeitos = d5.medir(referencia.estatisticas(ent.traces, servicos_raiz=raiz), ref, cfg9)["efeitos"]
        ctx = d9.contexto(list(ent.traces), ev_ref, ref, cfg9)
        try:
            dp = d2cr.decidir(ent, {}, {**sis, "q": 1.0})
            pm = (dp.evidencias or {}).get("p_min_ajustado")
            pm = float(pm) if pm is not None else 1.0
            f2 = _nomes(dp) if dp.status == "decidiu" else []
        except Exception:  # noqa: BLE001
            pm, f2 = 1.0, []
        for fp in FPS:
            cal, suf = cals[str(fp)], "" if fp == calib.FP_ALVO else f"@{fp}"
            passou = calib.passou_d9b(efeitos, cal)
            rb = [lin["servico"] for lin in d9.ranquear(passou, ctx, "residuo_1")][:3] if passou else []
            res["d9-b" + suf] = {"status": "decidiu" if rb else "absteve", "ranking": rb, "forcado": f9}
            # d9-k-b: portão d9-b OU K8s; ranking = o `ranking_base` da d9-k sobre o que passou na d9-b (residuo_1 →
            # efeito da d5 → profundo); só K8s abriu → o forçado da d9-k; serviço K8s no 1º
            base_b: list[str] = []
            if passou:
                for lst in (rb, [lin["servico"] for lin in referencia.ranking_por_efeito(passou)],
                            [lin["servico"] for lin in d9.ranquear(passou, ctx, "profundo")]):
                    base_b += [s for s in lst if s not in base_b]
            rk = d9k._promover(base_b[:3] or fk, servico_k8s, 3) if (rb or servico_k8s) else []
            res["d9-k-b" + suf] = {"status": "decidiu" if rk else "absteve", "ranking": rk, "forcado": fk}
            q = cal["q_d2cb"]
            rc = _nomes(d2cr.decidir(ent, {}, {**sis, "q": q})) if pm <= q else []
            res["d2c-b" + suf] = {"status": "decidiu" if rc else "absteve", "ranking": rc, "forcado": f2, "q": q,
                                  "p_min": pm}
            for hib, prim in (("d9-b+c", "d9-b"), ("d9-k-b+c", "d9-k-b")):
                p = res[prim + suf]
                usa = p if p["status"] == "decidiu" else res["d2c-b" + suf]
                res[hib + suf] = {"status": usa["status"], "ranking": usa["ranking"], "forcado": p["forcado"],
                                  "origem": prim if usa is p else "d2c-b"}
        linhas += [json.dumps({**base, "modo": m, **v}) for m, v in res.items()]
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def analisar() -> str:
    cs = DF.casos(DF.runs())
    inv = H._inv("def", cs)
    rs = C._novos(inv, os.path.join(SAIDA, "def"), "*.jsonl.gz")
    rs += [r for r in C._novos(inv, os.path.join(H.SAIDA, "def"), "*.jsonl.gz") if r["modo"] in ("d9+a", "d9-k+a")]
    rs += [{**r, "modo": "v-cons-b"} for r in C._novos(inv, DF.SAIDA, "*.jsonl.gz") if r["modo"] == "v-cons-b-prod"]
    instantes = {(r["cenario"], r["t"]) for r in rs if r["modo"] == "d9-b"}
    rs = [r for r in rs if (r["cenario"], r["t"]) in instantes]
    pcs: dict[str, dict[str, Any]] = {}
    for (m, c), x in A.por_cenario(rs, inv).items():
        pcs.setdefault(m, {})[c] = x
    cal = _calibracao(PR.R._load(os.path.join(os.path.dirname(cs[0]), "manifest.json"))["collection_id"][:8])
    out = ["# Pré-teste d9-b / d2c-b / d9-b+c no TeaStore (definitiva) — limiares pela baseline da coleção", "",
           "`bases-externas/baseline-dinamica/PROTOCOLO.md`. Descritivo (a definitiva já foi vista). Mesma entrada e "
           "instantes do `hibrido_d9a.py`; `d9+a`, `d9-k+a` e `v-cons-b` lidos dos registros gravados.", "",
           "| FP_ALVO | janelas da baseline | λ | q d2c-b |", "|---|---|---|---|"]
    out += [f"| {fp} | {c['n_janelas']} | {c['lambda']:.3f} | {c['q_d2cb']:.2e} |" for fp, c in cal.items()]
    out += ["", f"## Definitiva ({len(pcs.get('d9-b', {}))} cenários, {len(instantes)} instantes)", "",
            "| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 | top-3 |",
            "|---|---|---|---|---|---|---|---|"]
    ordem = ("d9-k", "v-cons-b", "d9-k+a", "d9-k-b", "d9-k-b+c", "d9", "d9+a", "d9-b", "d9-b+c", "d2c-b",
             "d9-k-b@0.01", "d9-k-b+c@0.01", "d9-b@0.01", "d9-b+c@0.01", "d2c-b@0.01")
    for m in ordem:
        if m not in pcs:
            continue
        r, ic = DF.metricas(pcs[m]), DF._boot(pcs[m], A.f1)
        out.append(f"| {m} | {r['f1']:.3f} [{ic[0]:.3f}–{ic[1]:.3f}] | {r['f2']:.3f} | {r['alarme']:.1%} | "
                   f"{r['abst']:.0%} | {r['o1']:.0%} | {r['o2']:.0%} | {r['o3']:.0%} |")
    out.append("")
    for a, b in (("d9-b", "d9"), ("d9-k-b", "d9-k"), ("d9-b+c", "d9+a"), ("d9-k-b+c", "d9-k+a"),
                 ("d9-k-b+c", "d9-k")):
        if a in pcs and b in pcs:
            sa, sb, p = DF.mcnemar(pcs[a], pcs[b], "tp1")
            out.append(f"- McNemar {a} × {b} (top-1 com portão): só {a} {sa}, só {b} {sb}, p = {p:.3f}")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-analise", action="store_true")
    args = ap.parse_args()
    if not args.so_analise:
        cs = DF.casos(DF.runs())
        colecao = PR.R._load(os.path.join(os.path.dirname(cs[0]), "manifest.json"))["collection_id"][:8]
        t0 = time.monotonic()
        cal = _calibracao(colecao)   # uma vez, antes dos processos
        print(f"baseline {colecao}: {time.monotonic() - t0:.0f}s; "
              + "; ".join(f"fp {fp}: n={c['n_janelas']} λ={c['lambda']:.3f} q={c['q_d2cb']:.2e}"
                          for fp, c in cal.items()), flush=True)
        from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(rodar_caso, [(c, os.path.join(SAIDA, "def")) for c in cs]):
                print(msg, flush=True)
    texto = analisar()
    with open(os.path.join(SAIDA, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
