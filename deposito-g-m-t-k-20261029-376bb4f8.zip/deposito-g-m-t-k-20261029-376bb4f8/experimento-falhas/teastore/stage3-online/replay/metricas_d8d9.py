#!/usr/bin/env python3
"""F1 por instante de d8 e d9: parâmetro escolhido em desenvolvimento (f, h), teste nos g.

**d8** é calculada aqui, combinando por instante as saídas já gravadas (nenhum modo recalculado): portão =
`__d5.jsonl` (os 72 portões, com o estado sequencial da d5), localizador = d2c (`<caso>.jsonl`) ou d6
(`__d6d7.jsonl`, α = 1,0 e 0,5) em cada `fp_alvo`, sem o limiar da emenda 1. A regra é `d8_fusao.combinar`.
À parte e exploratório: portão + a0 (`__a0.jsonl`, só onde a a0 tem instantes).

**d9** vem de `avaliar_instantes_d9.py` (`instantes-d9/*.jsonl.gz`, ranking das 3 localizações por portão).

Mesmas contagens de `metricas_instantes.contar` (estável: TP se o esperado está no Top-k; decidiu sem ele = FP e
FN; absteve = FN; normal: decidiu = FP), acumuladas por cenário e parâmetro para não carregar as linhas.

Uso: replay/metricas_d8d9.py [--jobs 12] [--saida resultados/instantes-d9/resumo-d8d9.md]
"""
from __future__ import annotations

import argparse
import glob
import gzip
import json
import os
import random
import sys
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import metricas_instantes as M  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import d8_fusao  # noqa: E402
from src.application.stage3.abordagens.base import Decisao, ItemRanking  # noqa: E402

INSTANTES = os.path.join(R.RESULTADOS, "instantes")
INSTANTES_D9 = os.path.join(R.RESULTADOS, "instantes-d9")
CAMPOS = ("n_nor", "alarme_nor", "n_est", "decide_est", "tp1", "tp2", "tp3")
FAMILIAS = ("d8", "d8-a0", "d9")


def _decisao(linha: dict[str, Any]) -> Decisao:
    return Decisao(status=linha["status"], motivo_abstencao=linha.get("motivo"),
                   ranking=[ItemRanking(s, float(i)) for i, s in enumerate(linha.get("ranking") or [])])


def _ler(caminho: str) -> list[dict[str, Any]]:
    abrir = gzip.open if caminho.endswith(".gz") else open
    with abrir(caminho, "rt") as f:
        return [json.loads(x) for x in f if x.strip()]


def _somar(cont: dict[str, int], periodo: str, decidiu: bool, ranking: list[str], esperado: str) -> None:
    if periodo == "normal":
        cont["n_nor"] += 1
        cont["alarme_nor"] += decidiu
    elif periodo == "estavel":
        cont["n_est"] += 1
        cont["decide_est"] += decidiu
        for k in M.KS:
            cont[f"tp{k}"] += decidiu and esperado in ranking[:k]


def contar_cenario(base: str) -> tuple[str, str, dict[str, dict[str, dict[str, int]]]]:
    """`base` = `<instantes>/<RUN>__<falha>`. Devolve contagens `{familia: {param: contagem}}`."""
    run_id, falha = os.path.basename(base).split("__", 1)
    esperado = M.esperado(run_id, falha)
    novo = lambda: dict.fromkeys(CAMPOS, 0)  # noqa: E731
    saida: dict[str, dict[str, dict[str, int]]] = {f: defaultdict(novo) for f in FAMILIAS}

    portoes: dict[str, list[tuple[str, str, dict[str, Any]]]] = defaultdict(list)   # t -> [(param, periodo, linha)]
    for r in _ler(base + "__d5.jsonl"):
        portoes[r["t"]].append((r["param"], r["periodo"], r))
    locais: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)                 # t -> {loc: linha}
    for r in _ler(base + ".jsonl"):
        if r["modo"] == "d2c":
            locais[r["t"]][f"d2c|fp={r['fp_alvo']:g}"] = r
    for r in _ler(base + "__d6d7.jsonl"):
        if r["modo"] == "d6":
            locais[r["t"]][f"d6{r['variante']}|fp={r['fp_alvo']:g}"] = r
    a0: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    if os.path.exists(base + "__a0.jsonl"):
        for r in _ler(base + "__a0.jsonl"):
            a0[r["t"]][f"a0|{r['param']}"] = r

    for t, lista in portoes.items():
        for familia, cands in (("d8", locais.get(t, {})), ("d8-a0", a0.get(t, {}))):
            if not cands:
                continue
            # o resultado só depende de o portão abrir: combina uma vez por localizador
            aberto = {loc: d8_fusao.combinar(Decisao(status="decidiu"), _decisao(r)) for loc, r in cands.items()}
            for param_portao, periodo, linha in lista:
                abriu = linha["status"] == "decidiu"
                for loc, d in aberto.items():
                    decidiu = abriu and d.status == "decidiu"
                    _somar(saida[familia][f"{param_portao}|{loc}"], periodo, decidiu,
                           [i.servico for i in d.ranking] if decidiu else [], esperado)
    d9 = os.path.join(INSTANTES_D9, os.path.basename(base) + "__d9.jsonl.gz")
    if os.path.exists(d9):
        for r in _ler(d9):
            for loc in ("residuo_1", "residuo_05", "profundo"):
                ranking = (r.get("rankings") or {}).get(loc)
                _somar(saida["d9"][f"{r['param']}|{loc}"], r["periodo"], r["status"] == "decidiu" and bool(ranking),
                       ranking or [], esperado)
    return run_id, falha, {f: dict(v) for f, v in saida.items()}


# --- métricas sobre contagens ---

def para_contar(c: dict[str, int], k: int) -> dict[str, int]:
    """As contagens de `metricas_instantes.contar` a partir dos campos acumulados."""
    tp = c[f"tp{k}"]
    return {"tp": tp, "fp": c["alarme_nor"] + c["decide_est"] - tp, "fn": c["n_est"] - tp,
            "tn": c["n_nor"] - c["alarme_nor"]}


def somar_campos(cs: list[dict[str, int]]) -> dict[str, int]:
    return {k: sum(c[k] for c in cs) for k in CAMPOS}


def escolher(por_cen: dict[str, dict[str, dict[str, int]]], cenarios: list[str]) -> str:
    """Maior F1@1 somando `cenarios`; empate → menos FP, depois o rótulo (como `metricas_instantes.escolher`)."""
    params = sorted({p for cen in cenarios for p in por_cen.get(cen, {})})

    def chave(p: str) -> tuple[float, int, str]:
        c = para_contar(somar_campos([por_cen[cen][p] for cen in cenarios if p in por_cen.get(cen, {})]), 1)
        return (M.f1(c), -c["fp"], p)
    return max(params, key=chave)


def tipo_cen(cen: str) -> str:
    return M.tipo_de(cen.split("/", 1)[1])


def avaliar_familia(por_cen: dict[str, dict[str, dict[str, int]]]) -> dict[str, Any] | None:
    dev = sorted(c for c in por_cen if not tipo_cen(c).startswith("g") and por_cen[c])
    teste = sorted(c for c in por_cen if tipo_cen(c).startswith("g") and por_cen[c])
    if not dev or not teste:
        return None
    escolhido = escolher(por_cen, dev)
    # validação cruzada em desenvolvimento, deixando um tipo de fora
    fora = []
    for tipo in sorted({tipo_cen(c) for c in dev}):
        outros = [c for c in dev if tipo_cen(c) != tipo]
        if not outros:  # um tipo só em desenvolvimento (d8-a0: só o ensaio h3): sem validação cruzada
            continue
        p = escolher(por_cen, outros)
        fora += [por_cen[c][p] for c in dev if tipo_cen(c) == tipo and p in por_cen[c]]
    sel = {c: por_cen[c][escolhido] for c in teste if escolhido in por_cen[c]}
    tot = somar_campos(list(sel.values()))
    rng = random.Random(M.SEMENTE)
    chaves = sorted(sel)
    boots = sorted(M.f1(para_contar(somar_campos([sel[rng.choice(chaves)] for _ in chaves]), 1))
                   for _ in range(M.N_BOOT))
    return {"param": escolhido, "f1_dev_cv": M.f1(para_contar(somar_campos(fora), 1)) if fora else float("nan"),
            "f1_g": {k: M.f1(para_contar(tot, k)) for k in M.KS},
            "ic_g": (boots[int(0.025 * M.N_BOOT)], boots[int(0.975 * M.N_BOOT) - 1]),
            "alarme_g": tot["alarme_nor"] / tot["n_nor"] if tot["n_nor"] else float("nan"),
            "decide_g": tot["decide_est"] / tot["n_est"] if tot["n_est"] else float("nan"),
            "acerto_g": tot["tp1"] / tot["n_est"] if tot["n_est"] else float("nan"),
            "n_dev": len(dev), "n_g": len(sel),
            "acertos_por_cenario": {c: v["tp1"] for c, v in sel.items()}}


def relatorio(contagens: dict[str, dict[str, dict[str, dict[str, int]]]]) -> str:
    out = ["# d8 e d9 — F1 por instante (PREREG-D8-D9.md)", "",
           "Parâmetro escolhido só em desenvolvimento (tipos f, h; critério F1@1, empate → menos alarme); teste nos "
           "18 g. **Exploratório nos g**: o desenho foi motivado pelo resultado g de 14/10. Referência: d2c F1@1 g "
           "0,738, d5 0,000 (`resumo-20261014.md`).", "",
           "| modo | parâmetro (dev) | cenários dev/g | F1@1 dev (CV) | F1@1 g | IC g | F1@2 g | F1@3 g | "
           "alarme normais g | decide estáveis g | acerto@1 g |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    res = {}
    for familia in FAMILIAS:
        por_cen = {cen: v.get(familia, {}) for cen, v in contagens.items()}
        r = res[familia] = avaliar_familia(por_cen)
        if not r:
            out.append(f"| {familia} | — | sem dados | | | | | | | | |")
            continue
        out.append(f"| {familia}{' (exploratório)' if familia == 'd8-a0' else ''} | {r['param']} | "
                   f"{r['n_dev']}/{r['n_g']} | {r['f1_dev_cv']:.3f} | {r['f1_g'][1]:.3f} | "
                   f"{r['ic_g'][0]:.3f}–{r['ic_g'][1]:.3f} | {r['f1_g'][2]:.3f} | {r['f1_g'][3]:.3f} | "
                   f"{r['alarme_g']:.1%} | {r['decide_g']:.0%} | {r['acerto_g']:.0%} |")
    out += ["", "Hipóteses (PREREG-D8-D9.md §4, exploratórias):", ""]
    if res.get("d8"):
        r = res["d8"]
        ok = r["f1_g"][1] >= 0.738 and r["alarme_g"] <= 0.05
        out.append(f"- **H7 (d8)**: F1@1 g {r['f1_g'][1]:.3f} vs d2c 0.738, alarme {r['alarme_g']:.1%} → "
                   f"{'confirmada' if ok else 'não confirmada'}")
    if res.get("d9"):
        r = res["d9"]
        ok = r["f1_g"][1] > 0.0 and r["acerto_g"] >= 0.5
        out.append(f"- **H8 (d9)**: F1@1 g {r['f1_g'][1]:.3f} vs d5 0.000, acerto@1 {r['acerto_g']:.0%} → "
                   f"{'confirmada' if ok else 'não confirmada'}")
    out += ["", "## Acertos@1 por cenário g (parâmetro escolhido)", "",
            "| cenário | " + " | ".join(f for f in FAMILIAS if res.get(f)) + " |",
            "|---|" + "---|" * sum(1 for f in FAMILIAS if res.get(f))]
    cens = sorted({c for f in FAMILIAS if res.get(f) for c in res[f]["acertos_por_cenario"]})
    for c in cens:
        out.append(f"| {c} | " + " | ".join(str(res[f]["acertos_por_cenario"].get(c, "—"))
                                            for f in FAMILIAS if res.get(f)) + " |")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("--saida", default=os.path.join(INSTANTES_D9, "resumo-d8d9.md"))
    args = ap.parse_args()
    bases = sorted(p[:-len("__d5.jsonl")] for p in glob.glob(os.path.join(INSTANTES, "*__d5.jsonl")))
    contagens: dict[str, Any] = {}
    with ProcessPoolExecutor(args.jobs) as ex:
        for run_id, falha, cont in ex.map(contar_cenario, bases):
            contagens[f"{run_id}/{falha}"] = cont
    os.makedirs(os.path.dirname(args.saida), exist_ok=True)
    with open(os.path.join(os.path.dirname(args.saida), "contagens-d8d9.json"), "w") as f:
        json.dump(contagens, f)
    texto = relatorio(contagens)
    with open(args.saida, "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
