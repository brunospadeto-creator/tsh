#!/usr/bin/env python3
"""PROTOCOLO-CONSENSO.md §2–§5: a0-p, d9-k e v-cons sobre a base unificada limpa (Fase 0).

Base: `protocolo-rapido/unificado` (60 s) com os modos que usam eventos K8s trocados pela versão filtrada
(`protocolo-consenso/limpo`: a0-k, a0-d, b1, b2, d9-k) e a a0 com eventos de sintoma (`protocolo-consenso/a0`).
Instantes com < 30 traces (D0.4) saem para todos. Persistência, K8s-abre-portão e o voto são calculados aqui,
sobre os registros (só instantes passados do mesmo período).

Escolha só em dev (f, h); g lido uma vez com o escolhido. Saída: `protocolo-consenso/resultado.md`.

Uso: replay/consenso.py
"""
from __future__ import annotations

import glob
import json
import math
import os
import sys
from collections import Counter, defaultdict
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-consenso")
NS = (1, 3, 5)
LIMPOS = {"a0-k", "a0-d", "b1", "b2", "d9-k"}
PAIS_COMPARA = ("d9", "a0", "d6", "d2c", "d6-u", "d1c")


def _novos(inv: dict[str, Any], pasta: str, padrao: str) -> list[dict[str, Any]]:
    out = []
    for arq in sorted(glob.glob(os.path.join(pasta, padrao))):
        for r in A._linhas(arq):
            if r["periodo"] not in ("normal", "estavel") or r.get("param") not in (None, "k=3"):
                continue
            cen = f"{r['run_id']}/{r['falha']}"
            dec = r["status"] == "decidiu"
            out.append({"cenario": cen, "modo": r["modo"], "periodo": r["periodo"], "t": r["t"],
                        "seg": A._seg(inv, cen, r["periodo"], r["t"]), "decidiu": dec,
                        "ranking": r["ranking"] if dec else [],
                        "forcado": r["forcado"] if "forcado" in r else (r["ranking"] if dec else []),
                        "k8s": r.get("k8s_sintoma")})
    return out


def base(inv: dict[str, Any]) -> tuple[list[dict[str, Any]], set[tuple[str, str]]]:
    with open(os.path.join(SAIDA, "higiene.json")) as f:
        hig = json.load(f)
    fora = {(c, t) for c, t in hig["poucos_traces"]}
    rs = [r for r in A.novos(inv, "unificado") if r["modo"] not in LIMPOS and r["modo"] != "a0"]
    rs += _novos(inv, os.path.join(SAIDA, "limpo"), "*.jsonl.gz")
    rs += _novos(inv, os.path.join(SAIDA, "a0"), "*__a0.jsonl")
    return [r for r in rs if (r["cenario"], r["t"]) not in fora], fora


def _series(rs: list[dict[str, Any]]) -> dict[tuple[str, str, str], list[dict[str, Any]]]:
    s: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for r in rs:
        s[(r["modo"], r["cenario"], r["periodo"])].append(r)
    for v in s.values():
        v.sort(key=lambda r: r["t"])
    return s


def _persistir(lst: list[dict[str, Any]], i: int, n: int, campo: str) -> str | None:
    jan = [x[campo][0] for x in lst[max(0, i - n + 1):i + 1] if x[campo]]
    if not jan:
        return None
    cont = Counter(jan)
    mx = max(cont.values())
    return next(x for x in reversed(jan) if cont[x] == mx)   # empate: o mais recente


def variante_persistente(serie: dict, modo: str, n: int, novo: str, abre_k8s: bool = False) -> list[dict[str, Any]]:
    out = []
    for (m, _c, _p), lst in serie.items():
        if m != modo:
            continue
        for i, r in enumerate(lst):
            pf = _persistir(lst, i, n, "forcado")
            forc = ([pf] + [x for x in r["forcado"] if x != pf])[:3] if pf else r["forcado"]
            dec = r["decidiu"] or (abre_k8s and bool(r.get("k8s")))
            if dec:
                pr = _persistir([x if x["decidiu"] else {**x, "ranking": []} for x in lst], i, n, "ranking")
                base_rk = r["ranking"] or forc
                rk = ([pr] + [x for x in base_rk if x != pr])[:3] if pr else base_rk
            else:
                rk = []
            out.append({**r, "modo": novo, "decidiu": dec, "ranking": rk, "forcado": forc})
    return out


def _metr(rs: list[dict[str, Any]], inv: dict[str, Any], grupos: str = "fh") -> dict[str, float]:
    pc = A.por_cenario([r for r in rs if inv[r["cenario"]]["grupo"] in grupos], inv)
    cs = list(pc.values())
    o = [v["o1"] / v["n_est"] for v in cs if v.get("n_est")]
    return {"o1": sum(o) / len(o) if o else float("nan"), "f1": A.f1(cs), "f1_2": A.f1(cs, 2),
            "o2": A._taxa(cs, "o2", "n_est"), "alarme": A._taxa(cs, "alarme", "n_nor"),
            "dec": A._taxa(cs, "dec", "n_est"), "n": len(o)}


def _por_grupo(rs: list[dict[str, Any]], inv: dict[str, Any]) -> dict[str, float]:
    return {g: _metr(rs, inv, g)["o1"] for g in ("fhg", "f", "h", "g", "fh")}


def votar(serie: dict, inv: dict[str, Any], votantes: list[str], n: int, pesos: dict[str, float],
          portao: list[dict[str, Any]], nome: str = "v-cons") -> list[dict[str, Any]]:
    """Borda no top-3 (3, 2, 1) com o 1º persistido; desempate K8s → persistência → nº de votantes → d9-k."""
    idx = {(r["cenario"], r["periodo"], r["t"]): r for r in portao}
    pos: dict[tuple[str, str, str], dict[str, tuple[list[str], int]]] = defaultdict(dict)
    for (m, c, p), lst in serie.items():
        if m not in votantes:
            continue
        for i, r in enumerate(lst):
            pf = _persistir(lst, i, n, "forcado")
            rk = ([pf] + [x for x in r["forcado"] if x != pf])[:3] if pf else r["forcado"][:3]
            jan = [x["forcado"][0] for x in lst[max(0, i - n + 1):i + 1] if x["forcado"]]
            pos[(c, p, r["t"])][m] = (rk, jan)
    out = []
    for chave, por_v in pos.items():
        g = idx.get(chave)
        if g is None or any(v not in por_v for v in votantes):
            continue
        escore: Counter = Counter()
        persist: Counter = Counter()
        n_vot: Counter = Counter()
        for v, (rk, jan) in por_v.items():
            for i, s in enumerate(rk):
                escore[s] += (3 - i) * pesos.get(v, 1.0)
                n_vot[s] += 1
            for s in jan:
                persist[s] += 1
        if not escore:
            continue
        k8s = g.get("k8s")
        d9k = (por_v.get("d9-k") or ([], []))[0]

        def chave_ord(s: str) -> tuple:
            return (escore[s], s == k8s, persist[s], n_vot[s], -(d9k.index(s) if s in d9k else 9))
        ordem = sorted(escore, key=chave_ord, reverse=True)
        tot = sum(escore.values())
        margem = (escore[ordem[0]] - (escore[ordem[1]] if len(ordem) > 1 else 0)) / tot if tot else 0.0
        c, p, t = chave
        out.append({"cenario": c, "modo": nome, "periodo": p, "t": t, "seg": g["seg"], "decidiu": g["decidiu"],
                    "ranking": ordem[:3] if g["decidiu"] else [], "forcado": ordem[:3], "margem": margem})
    return out


def _pesos_conf(serie_rs: dict[str, list[dict[str, Any]]], inv: dict[str, Any], votantes: list[str],
                tipos_treino: set[str]) -> dict[str, float]:
    w = {}
    for v in votantes:
        rs = [r for r in serie_rs[v] if inv[r["cenario"]]["tipo"] in tipos_treino]
        acc = _metr(rs, inv, "fhg")["o1"]
        acc = min(0.95, max(0.05, acc if acc == acc else 0.5))
        w[v] = max(0.1, math.log(acc / (1 - acc)) + 1.0)
    return w


def main() -> int:
    inv = A._inv()
    rs, fora = base(inv)
    serie = _series(rs)
    out = ["# Protocolo do consenso — resultados (PROTOCOLO-CONSENSO.md)", "",
           f"Base unificada limpa: eventos K8s só de sintoma a partir do normal; {len(fora)} instantes com < 30 traces "
           "excluídos para todos (D0.4: estáveis de f5 e f12 sem nenhum trace; normais de h2 e h4). "
           "Escolha em dev (f+h); g lido uma vez. 'sabendo' = top-1 com oráculo, média por cenário.", ""]

    # pais na base limpa
    por_modo: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in rs:
        por_modo[r["modo"]].append(r)
    out += ["## Pais e baselines na base limpa", "",
            "| modo | F1@1 dev | F1@1 todos | alarme | sabendo todos | f | h | g | dev |",
            "|---|---|---|---|---|---|---|---|---|"]
    for m in (*PAIS_COMPARA, "d9-k", "a0-k", "b2", "b1"):
        if m not in por_modo:
            continue
        d, t = _metr(por_modo[m], inv, "fh"), _metr(por_modo[m], inv, "fhg")
        g = _por_grupo(por_modo[m], inv)
        out.append(f"| {m} | {d['f1']:.3f} | {t['f1']:.3f} | {t['alarme']:.1%} | {g['fhg']:.0%} | {g['f']:.0%} | "
                   f"{g['h']:.0%} | {g['g']:.0%} | {g['fh']:.0%} |")

    # a0-p
    out += ["", "## a0-p — escolha de n em dev (sabendo que é falha)", "",
            "| n | dev | f | h | g | todos |", "|---|---|---|---|---|---|"]
    a0p = {n: variante_persistente(serie, "a0", n, "a0-p") for n in NS}
    for n in NS:
        g = _por_grupo(a0p[n], inv)
        out.append(f"| {n} | {g['fh']:.0%} | {g['f']:.0%} | {g['h']:.0%} | {g['g']:.0%} | {g['fhg']:.0%} |")
    n_a0p = max(NS, key=lambda n: (round(_por_grupo(a0p[n], inv)["fh"], 6), -n))
    ga0, gp = _por_grupo(por_modo["a0"], inv), _por_grupo(a0p[n_a0p], inv)
    ok_a0p = gp["fh"] >= ga0["fh"] + 0.05 and all(gp[x] >= ga0[x] - 0.05 for x in "fhg")
    out.append(f"\nEscolhido n = {n_a0p}. Sucesso (dev ≥ a0 + 5 p.p., nenhum grupo −5 p.p.): "
               f"{'SIM' if ok_a0p else 'NÃO'} (a0 dev {ga0['fh']:.0%} → {gp['fh']:.0%}).")

    # d9-k
    out += ["", "## d9-k — escolha em dev (F1@1 com portão)", "",
            "| n | K8s abre portão | F1@1 dev | alarme dev | sabendo dev | F1@1 todos | sabendo todos | g |",
            "|---|---|---|---|---|---|---|---|"]
    d9k = {}
    for n in NS:
        for abre in (False, True):
            v = variante_persistente(serie, "d9-k", n, "d9-k*", abre)
            d9k[(n, abre)] = v
            d, t = _metr(v, inv, "fh"), _metr(v, inv, "fhg")
            out.append(f"| {n} | {'sim' if abre else 'não'} | {d['f1']:.3f} | {d['alarme']:.1%} | {d['o1']:.0%} | "
                       f"{t['f1']:.3f} | {t['o1']:.0%} | {_metr(v, inv, 'g')['o1']:.0%} |")
    esc_d9k = max(d9k, key=lambda k: (round(_metr(d9k[k], inv, "fh")["f1"], 6),
                                      -_metr(d9k[k], inv, "fh")["alarme"], -k[0]))
    md, m9 = _metr(d9k[esc_d9k], inv, "fh"), _metr(por_modo["d9"], inv, "fh")
    ok_d9k = md["f1"] >= m9["f1"] and md["alarme"] - m9["alarme"] <= 0.01
    out.append(f"\nEscolhido n = {esc_d9k[0]}, K8s abre portão = {'sim' if esc_d9k[1] else 'não'}. Sucesso "
               f"(F1@1 dev ≥ d9 {m9['f1']:.3f}, alarme ≤ +1 p.p.): {'SIM' if ok_d9k else 'NÃO'} ({md['f1']:.3f}).")

    # v-cons
    portao = d9k[esc_d9k]
    serie_v = dict(serie)
    serie_v.update(_series([{**r, "modo": "a0-p"} for r in a0p[n_a0p]]))
    serie_v.update(_series([{**r, "modo": "d9-k"} for r in d9k[esc_d9k]]))
    serie_rs = {m: [r for (mm, _c, _p), lst in serie_v.items() if mm == m for r in lst]
                for m in ("d9-k", "a0-p", "d6", "d1c", "d6-u")}
    tipos_dev = sorted({inv[c]["tipo"] for c in inv if inv[c]["grupo"] != "g"})
    grade = [(vs, n, p) for vs in (["d9-k", "a0-p", "d6"], ["d9-k", "a0-p", "d6", "d1c"],
                                   ["d9-k", "a0-p", "d6", "d6-u"]) for n in NS for p in ("iguais", "confiabilidade")]

    def rodar(vs: list[str], n: int, p: str, tipos_treino: set[str]) -> list[dict[str, Any]]:
        pesos = _pesos_conf(serie_rs, inv, vs, tipos_treino) if p == "confiabilidade" else {}
        return votar(serie_v, inv, vs, n, pesos, portao)

    out += ["", "## v-cons — grade em dev (sabendo que é falha)", "",
            "| votantes | n | pesos | dev | F1@1 dev | todos | g |", "|---|---|---|---|---|---|---|"]
    res = {}
    for vs, n, p in grade:
        v = rodar(vs, n, p, set(tipos_dev))
        res[(tuple(vs), n, p)] = v
        md_ = _metr(v, inv, "fh")
        out.append(f"| {'+'.join(vs)} | {n} | {p} | {md_['o1']:.0%} | {md_['f1']:.3f} | "
                   f"{_metr(v, inv, 'fhg')['o1']:.0%} | {_metr(v, inv, 'g')['o1']:.0%} |")
    # validação cruzada deixando o tipo de fora (estimativa honesta da escolha)
    acertos_cv: list[float] = []
    for tipo in tipos_dev:
        treino = set(tipos_dev) - {tipo}
        melhor = max(grade, key=lambda k: _metr([r for r in res[(tuple(k[0]), k[1], k[2])]
                                                 if inv[r["cenario"]]["tipo"] in treino], inv, "fh")["o1"])
        v = rodar(melhor[0], melhor[1], melhor[2], treino)
        acertos_cv += [x for x in [_metr([r for r in v if inv[r["cenario"]]["tipo"] == tipo], inv, "fh")["o1"]]
                       if x == x]
    esc = max(grade, key=lambda k: (round(_metr(res[(tuple(k[0]), k[1], k[2])], inv, "fh")["o1"], 6),
                                    -len(k[0]), -k[1], k[2] == "iguais"))
    vc = res[(tuple(esc[0]), esc[1], esc[2])]
    mv, m9t = _metr(vc, inv, "fh"), _metr(por_modo["d9"], inv, "fh")
    ok_v = mv["o1"] >= m9t["o1"] + 0.10 and mv["f1"] >= m9t["f1"]
    out.append(f"\nEscolhido: {'+'.join(esc[0])}, n = {esc[1]}, pesos {esc[2]}. Estimativa por validação cruzada "
               f"(tipo fora, dev): {sum(acertos_cv) / len(acertos_cv):.0%}. Sucesso (dev ≥ d9 + 10 p.p. sabendo e "
               f"F1@1 dev ≥ d9): {'SIM' if ok_v else 'NÃO'} ({mv['o1']:.0%} × {m9t['o1']:.0%}; "
               f"F1 {mv['f1']:.3f} × {m9t['f1']:.3f}).")

    # confiança calibrada (tercis da margem em dev)
    dev_est = sorted(r["margem"] for r in vc if r["periodo"] == "estavel" and inv[r["cenario"]]["grupo"] != "g")
    cortes = (dev_est[len(dev_est) // 3], dev_est[2 * len(dev_est) // 3]) if dev_est else (0, 0)
    out += ["", "## Confiança do v-cons (margem da Borda, tercis de dev)", "",
            "| faixa | dev: acerto | g: acerto |", "|---|---|---|"]
    for nome, lo, hi in (("baixa", -1, cortes[0]), ("média", cortes[0], cortes[1]), ("alta", cortes[1], 2)):
        cel = []
        for grupos in ("fh", "g"):
            x = [r["forcado"][:1] == [inv[r["cenario"]]["esperado"]] for r in vc
                 if r["periodo"] == "estavel" and inv[r["cenario"]]["grupo"] in grupos and lo < r["margem"] <= hi]
            cel.append(f"{sum(x) / len(x):.0%} (n={len(x)})" if x else "—")
        out.append(f"| {nome} | " + " | ".join(cel) + " |")

    # tabela final e testes
    finais = {"v-cons": vc, "d9-k": d9k[esc_d9k], "a0-p": a0p[n_a0p], **{m: por_modo[m] for m in PAIS_COMPARA}}
    out += ["", "## Tabela final (g = leitura única, exploratória)", "",
            "| modo | F1@1 dev | F1@1 g | F1@1 todos | F1@2 todos | alarme | sabendo dev | sabendo g | sabendo todos | "
            "sabendo@2 todos | f | h |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    linhas = []
    for m, v in finais.items():
        d, gg, t, gr = _metr(v, inv, "fh"), _metr(v, inv, "g"), _metr(v, inv, "fhg"), _por_grupo(v, inv)
        linhas.append((t["f1"], f"| {m} | {d['f1']:.3f} | {gg['f1']:.3f} | {t['f1']:.3f} | {t['f1_2']:.3f} | "
                                f"{t['alarme']:.1%} | {d['o1']:.0%} | {gg['o1']:.0%} | {t['o1']:.0%} | {t['o2']:.0%} | "
                                f"{gr['f']:.0%} | {gr['h']:.0%} |"))
    out += [lin for _f, lin in sorted(linhas, key=lambda x: -x[0])]

    def maj(v: list[dict[str, Any]]) -> dict[str, bool]:
        pc = A.por_cenario(v, inv)
        return {c: x["o1"] / x["n_est"] > 0.5 for (_m, c), x in pc.items() if x.get("n_est")}
    out += ["", "## McNemar pareado (acerto majoritário sabendo que é falha)", "",
            "| comparação | grupo | cenários | só o 1º acerta | só o 2º acerta | p |", "|---|---|---|---|---|---|"]
    for a_, b_ in (("v-cons", "d9"), ("v-cons", "a0"), ("d9-k", "d9"), ("a0-p", "a0")):
        ma, mb = maj(finais[a_]), maj(finais[b_])
        for grupos, rot in (("fh", "dev"), ("g", "g"), ("fhg", "todos")):
            cs = sorted(c for c in set(ma) & set(mb) if inv[c]["grupo"] in grupos)
            n01, n10, p = A._mcnemar([ma[c] for c in cs], [mb[c] for c in cs])
            out.append(f"| {a_} × {b_} | {rot} | {len(cs)} | {n01} | {n10} | {p:.3f} |")
    texto = "\n".join(out) + "\n"
    with open(os.path.join(SAIDA, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
