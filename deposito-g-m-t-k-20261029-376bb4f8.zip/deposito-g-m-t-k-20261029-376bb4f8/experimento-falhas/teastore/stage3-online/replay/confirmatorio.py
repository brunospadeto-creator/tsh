#!/usr/bin/env python3
"""PROTOCOLO-CONFIRMATORIO.md: d9-k, v-cons-b e d9 nos 21 cenários das coletas não usadas.

Executa `paridade_solucoes.rodar_caso` em modo confirmatório (D0.4 aplicada na hora, d9 gravada junto) e lê com as
métricas do protocolo rápido. Saída: `resultados/protocolo-confirmatorio/` (registros, `inventario.json`,
`resultado.md`).

Uso: replay/confirmatorio.py [--jobs 16]
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import random
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import consenso as C  # noqa: E402, N812
import paridade_solucoes as PS  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-confirmatorio")
RUNS = ("20261002T013953Z", "20260926T190446Z", "20260926T134559Z", "20260926T135052Z", "20260926T135501Z",
        "20261001T231714Z", "20261004T061011Z", "20261004T074140Z", "20261012T023725Z", "20261011T220351Z")
MODOS = ("d9-k-prod", "v-cons-b-prod", "v-cons-b-1", "d9")


def casos() -> list[str]:
    """Só os cenários com referência, pacotes e traces (§1 do protocolo)."""
    out = []
    for run in RUNS:
        for c in sorted(glob.glob(os.path.join(PR.R.RESULTADOS, run, "[fgh][0-9]*"))):
            if os.path.isdir(c) and os.path.exists(os.path.join(c, "traces_full_scenario.json")) and PR.AI.periodos(c):
                out.append(c)
    return out


def inventario(cs: list[str]) -> dict[str, Any]:
    saida = {}
    for c in cs:
        run_id, falha = os.path.basename(os.path.dirname(c)), os.path.basename(c)
        per = PR.AI.periodos(c)
        colecao = PR.R._load(os.path.join(os.path.dirname(c), "manifest.json"))["collection_id"][:8]
        saida[f"{run_id}/{falha}"] = {
            "tipo": PR.M.tipo_de(falha), "grupo": PR.M.tipo_de(falha)[0], "esperado": PR.M.esperado(run_id, falha),
            "colecao": colecao, "periodos_seg": {k: (v[1] - v[0]).total_seconds() for k, v in per.items()},
            "inicio_estavel": per["estavel"][0].isoformat(), "fim_normal": per["normal"][1].isoformat()}
    return saida


def _boot(valores: list[float], n: int = 2000) -> tuple[float, float]:
    rnd = random.Random(PR.M.SEMENTE)
    meds = sorted(sum(rnd.choice(valores) for _ in valores) / len(valores) for _ in range(n))
    return meds[int(0.025 * n)], meds[int(0.975 * n) - 1]


def analisar(inv: dict[str, Any]) -> str:
    rs = [r for r in C._novos(inv, SAIDA, "*.jsonl.gz") if r["modo"] in MODOS]
    rot = {"d9-k-prod": "d9-k", "v-cons-b-prod": "v-cons-b (n = 5, avaliado)",
           "v-cons-b-1": "v-cons-b disparo único (produto)", "d9": "d9 (pai)"}
    out = ["# Protocolo confirmatório — resultado (PROTOCOLO-CONFIRMATORIO.md)", "",
           f"{len(inv)} cenários ({sum(v['grupo'] == 'f' for v in inv.values())} f, "
           f"{sum(v['grupo'] == 'h' for v in inv.values())} h), {len({(r['cenario'], r['t']) for r in rs})} "
           "instantes (60 s; < 30 traces fora). Código congelado em `d7318c35`; nada ajustado.", "",
           "| modo | F1@1 | F1@2 | F1@3 | alarme | sabendo top-1 [IC 95%] | top-2 | top-3 [IC 95%] | f | h |",
           "|---|---|---|---|---|---|---|---|---|---|"]
    res: dict[str, dict[str, float]] = {}
    for m in MODOS:
        v = [r for r in rs if r["modo"] == m]
        pc = A.por_cenario(v, inv)
        cs = list(pc.values())
        est = {c: x for (_m, c), x in pc.items() if x.get("n_est")}
        o = {k: [x[f"o{k}"] / x["n_est"] for x in est.values()] for k in (1, 2, 3)}
        med = {k: sum(o[k]) / len(o[k]) for k in o}
        grupo = {g: [x["o1"] / x["n_est"] for c, x in est.items() if inv[c]["grupo"] == g] for g in "fh"}
        i1, i3 = _boot(o[1]), _boot(o[3])
        res[m] = {"f1": A.f1(cs), "alarme": A._taxa(cs, "alarme", "n_nor"), "o1": med[1], "o3": med[3]}
        out.append(f"| {rot[m]} | {A.f1(cs):.3f} | {A.f1(cs, 2):.3f} | {A.f1(cs, 3):.3f} | "
                   f"{res[m]['alarme']:.1%} | {med[1]:.0%} [{i1[0]:.0%}–{i1[1]:.0%}] | {med[2]:.0%} | "
                   f"{med[3]:.0%} [{i3[0]:.0%}–{i3[1]:.0%}] | "
                   + " | ".join(f"{sum(g) / len(g):.0%} (n={len(g)})" if g else "—" for g in grupo.values()) + " |")
    out += ["", "## Por cenário (top-1 sabendo que é falha; F1 com portão)", "",
            "| cenário | coleção | esperado | d9-k | v-cons-b | v-cons-b top-3 | d9 |", "|---|---|---|---|---|---|---|"]
    pcs = {m: A.por_cenario([r for r in rs if r["modo"] == m], inv) for m in MODOS}
    for c in sorted(inv):
        cel = []
        for m, k in (("d9-k-prod", 1), ("v-cons-b-prod", 1), ("v-cons-b-prod", 3), ("d9", 1)):
            x = pcs[m].get((m, c))
            cel.append(f"{x[f'o{k}']}/{x['n_est']}" if x and x.get("n_est") else "—")
        out.append(f"| {c} | {inv[c]['colecao']} | {inv[c]['esperado']} | " + " | ".join(cel) + " |")
    k, v9, vc = res["d9-k-prod"], res["d9"], res["v-cons-b-prod"]
    ok_k = k["f1"] >= v9["f1"] and k["alarme"] <= 0.02
    ok_v = vc["o3"] >= 0.80 and vc["o1"] >= v9["o1"]
    out += ["", "## Leitura (§3, fixada antes)", "",
            f"- d9-k: F1@1 {k['f1']:.3f} × d9 {v9['f1']:.3f}; alarme {k['alarme']:.1%} → "
            + ("**confirma**" if ok_k else "**não confirma**") + ".",
            f"- v-cons-b: top-3 sabendo {vc['o3']:.0%} (critério ≥ 80%); top-1 {vc['o1']:.0%} × d9 {v9['o1']:.0%} → "
            + ("**confirma**" if ok_v else "**não confirma**") + "."]
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-analise", action="store_true")
    args = ap.parse_args()
    cs = casos()
    inv = inventario(cs)
    os.makedirs(SAIDA, exist_ok=True)
    with open(os.path.join(SAIDA, "inventario.json"), "w") as f:
        json.dump(inv, f, indent=1)
    if not args.so_analise:
        from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(PS.rodar_caso, [(c, SAIDA, True) for c in cs]):
                print(msg, flush=True)
    texto = analisar(inv)
    with open(os.path.join(SAIDA, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
