#!/usr/bin/env python3
"""PROTOCOLO-COLETA-DEFINITIVA.md §5–§6: d9-k, v-cons-b e d9 nos cenários da coleta definitiva.

Escrito ANTES da coleta. Mesma medida do confirmatório (`confirmatorio.py`, `paridade_solucoes.rodar_caso`
com D0.4 na hora), com os runs lidos de `resultados/definitiva/C*.run` (gravados pelo
`run-definitiva-lotes.sh`), grupos h e g, IC 95% por bootstrap de cenário e McNemar exato pareado.
Saída: `resultados/protocolo-coleta-definitiva/` (registros, `inventario.json`, `resultado.md`).

Uso: replay/definitiva.py [--jobs 16] [--so-analise]
"""
from __future__ import annotations

import argparse
import glob
import json
import math
import os
import random
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import confirmatorio as CF  # noqa: E402, N812
import consenso as C  # noqa: E402, N812
import paridade_solucoes as PS  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-coleta-definitiva")
DRIVER = os.path.join(PR.R.RESULTADOS, "definitiva")
LOTES = ("C1", "C2", "C3", "C4")
MODOS = ("d9-k-prod", "v-cons-b-prod", "v-cons-b-1", "d9")
ROT = {"d9-k-prod": "d9-k", "v-cons-b-prod": "v-cons-b (n = 5, avaliado)",
       "v-cons-b-1": "v-cons-b disparo único (produto)", "d9": "d9 (referência)"}


def runs() -> dict[str, str]:
    """lote -> run_id; lote sem `.done` fica de fora e é declarado como ausente."""
    out = {}
    for lote in LOTES:
        if os.path.exists(os.path.join(DRIVER, f"{lote}.done")):
            with open(os.path.join(DRIVER, f"{lote}.run")) as f:
                out[lote] = f.read().strip()
    return out


def casos(rs: dict[str, str]) -> list[str]:
    out = []
    for run in rs.values():
        for c in sorted(glob.glob(os.path.join(PR.R.RESULTADOS, run, "[gh][0-9]*"))):
            if os.path.isdir(c) and os.path.exists(os.path.join(c, "traces_full_scenario.json")) and PR.AI.periodos(c):
                out.append(c)
    return out


def _boot(pc: dict[str, dict[str, float]], fn: Any, n: int = 2000) -> tuple[float, float]:
    """IC 95% por bootstrap de cenário de uma estatística sobre a lista de contagens por cenário."""
    rnd = random.Random(PR.M.SEMENTE)
    cs = list(pc.values())
    meds = sorted(fn([rnd.choice(cs) for _ in cs]) for _ in range(n))
    return meds[int(0.025 * n)], meds[int(0.975 * n) - 1]


def _media(chave: str) -> Any:
    def fn(cs: list[dict[str, float]]) -> float:
        v = [x[chave] / x["n_est"] for x in cs if x.get("n_est")]
        return sum(v) / len(v) if v else float("nan")
    return fn


def mcnemar(a: dict[str, dict[str, float]], b: dict[str, dict[str, float]], chave: str) -> tuple[int, int, float]:
    """Acerto majoritário por cenário (`chave`/n_est > 0,5): (só a, só b, p exato bilateral)."""
    so_a = sum(A._maj(a[c], chave) and not A._maj(b[c], chave) for c in a if c in b)
    so_b = sum(A._maj(b[c], chave) and not A._maj(a[c], chave) for c in a if c in b)
    n = so_a + so_b
    p = min(1.0, 2 * sum(math.comb(n, i) for i in range(min(so_a, so_b) + 1)) / 2 ** n) if n else 1.0
    return so_a, so_b, p


def metricas(pc: dict[str, dict[str, float]]) -> dict[str, float]:
    cs = list(pc.values())
    o = {k: _media(f"o{k}")(cs) for k in (1, 2, 3)}
    return {"f1": A.f1(cs), "f2": A.f1(cs, 2), "f3": A.f1(cs, 3), "alarme": A._taxa(cs, "alarme", "n_nor"),
            "abst": 1 - A._taxa(cs, "dec", "n_est"), "o1": o[1], "o2": o[2], "o3": o[3]}


def analisar(inv: dict[str, Any], rs_lotes: dict[str, str]) -> str:
    rs = [r for r in C._novos(inv, SAIDA, "*.jsonl.gz") if r["modo"] in MODOS]
    pcs = {m: {c: x for (_m, c), x in A.por_cenario([r for r in rs if r["modo"] == m], inv).items()} for m in MODOS}
    ausentes = [lt for lt in LOTES if lt not in rs_lotes]
    out = ["# Coleta definitiva — resultado (PROTOCOLO-COLETA-DEFINITIVA.md)", "",
           f"{len(inv)} cenários ({sum(v['grupo'] == 'h' for v in inv.values())} h, "
           f"{sum(v['grupo'] == 'g' for v in inv.values())} g), "
           f"lotes {', '.join(f'{k}={v}' for k, v in rs_lotes.items())}"
           + (f"; **ausentes: {', '.join(ausentes)}**" if ausentes else "") + ". Nada ajustado.", ""]
    res: dict[str, dict[str, float]] = {}
    for rot_g, filtro in (("todos", lambda g: True), ("h", lambda g: g == "h"), ("g", lambda g: g == "g")):
        out += [f"## Grupo: {rot_g}", "",
                "| modo | F1@1 [IC 95%] | F1@2 | F1@3 | alarme | abstenção | sabendo top-1 [IC 95%] | top-2 | "
                "top-3 [IC 95%] |", "|---|---|---|---|---|---|---|---|---|"]
        for m in MODOS:
            pc = {c: x for c, x in pcs[m].items() if filtro(inv[c]["grupo"])}
            if not pc:
                continue
            r = metricas(pc)
            if rot_g == "todos":
                res[m] = r
            f, i1, i3 = _boot(pc, A.f1), _boot(pc, _media("o1")), _boot(pc, _media("o3"))
            out.append(f"| {ROT[m]} | {r['f1']:.3f} [{f[0]:.3f}–{f[1]:.3f}] | {r['f2']:.3f} | {r['f3']:.3f} | "
                       f"{r['alarme']:.1%} | {r['abst']:.0%} | {r['o1']:.0%} [{i1[0]:.0%}–{i1[1]:.0%}] | "
                       f"{r['o2']:.0%} | {r['o3']:.0%} [{i3[0]:.0%}–{i3[1]:.0%}] |")
        out.append("")
    out += ["## McNemar exato pareado (acerto majoritário por cenário)", ""]
    for a, b, chave, txt in (("d9-k-prod", "d9", "tp1", "d9-k × d9, top-1 com portão"),
                             ("v-cons-b-prod", "d9-k-prod", "o3", "v-cons-b × d9-k, top-3 sabendo")):
        sa, sb, p = mcnemar(pcs[a], pcs[b], chave)
        out.append(f"- {txt}: só {ROT[a]} {sa}, só {ROT[b]} {sb}, p = {p:.3f}")
    out += ["", "## Por cenário (top-1 com portão / top-1 e top-3 sabendo)", "",
            "| cenário | esperado | d9-k tp1 | d9 tp1 | v-cons-b o1 | v-cons-b o3 | d9-k o3 |",
            "|---|---|---|---|---|---|---|"]
    for c in sorted(inv):
        cel = []
        for m, k in (("d9-k-prod", "tp1"), ("d9", "tp1"), ("v-cons-b-prod", "o1"), ("v-cons-b-prod", "o3"),
                     ("d9-k-prod", "o3")):
            x = pcs[m].get(c)
            cel.append(f"{x[k]}/{x['n_est']}" if x and x.get("n_est") else "—")
        out.append(f"| {c} | {inv[c]['esperado']} | " + " | ".join(cel) + " |")
    k, v9, vc = res["d9-k-prod"], res["d9"], res["v-cons-b-prod"]
    ok_k = k["f1"] >= v9["f1"] and k["alarme"] <= 0.02
    ok_v = vc["o3"] >= 0.80 and vc["o1"] >= v9["o1"]
    out += ["", "## Leitura (§6, fixada antes)", "",
            f"- d9-k: F1@1 {k['f1']:.3f} × d9 {v9['f1']:.3f}; alarme {k['alarme']:.1%} → "
            + ("**confirma**" if ok_k else "**não confirma**") + ".",
            f"- v-cons-b: top-3 sabendo {vc['o3']:.0%} (≥ 80%); top-1 sabendo {vc['o1']:.0%} × d9 {v9['o1']:.0%} → "
            + ("**confirma**" if ok_v else "**não confirma**") + f". (Secundário: top-3 × d9-k {k['o3']:.0%}.)"]
    if ausentes:
        out.append(f"- Lotes ausentes ({', '.join(ausentes)}): resultado **parcial**, não vale como confirmação (§3).")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-analise", action="store_true")
    args = ap.parse_args()
    rs_lotes = runs()
    if not rs_lotes:
        raise SystemExit(f"nenhum lote concluído em {DRIVER}")
    cs = casos(rs_lotes)
    inv = CF.inventario(cs)
    os.makedirs(SAIDA, exist_ok=True)
    with open(os.path.join(SAIDA, "inventario.json"), "w") as f:
        json.dump(inv, f, indent=1)
    if not args.so_analise:
        from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(PS.rodar_caso, [(c, SAIDA, True) for c in cs]):
                print(msg, flush=True)
    texto = analisar(inv, rs_lotes)
    with open(os.path.join(SAIDA, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
