#!/usr/bin/env python3
"""Híbrido d9+a / d9-k+a nos três conjuntos do TeaStore (`bases-externas/d9a/PROTOCOLO.md`).

Mesma entrada, mesmos instantes e mesma higiene dos modelos anteriores (`paridade_solucoes.rodar_caso`):
desenvolvimento = `PR.casos()` com a higiene do `higiene.json`; confirmatório = `confirmatorio.casos()` e
definitiva = `definitiva.casos()`, ambos com a D0.4 na hora. Modos gravados por instante:

- `d9` (portão da d9; forçado permissivo) e `d9-k` (`d9k.decidir`, com os eventos K8s limpos) — referência e
  paridade com os registros oficiais;
- `d2c-r` (q = 1e-50) e `d2c-a` (q = 1e-3 × min p_min de H; H = até 3 instantes normais anteriores do caso;
  nos instantes estáveis, os 3 últimos normais = o passado da sessão antes da falha; |H| < 2 → abstém);
- `d9+a` = d9, ou d2c-a quando a d9 abstém (forçado = d9); `d9-k+a` = d9-k, ou d2c-a (forçado = d9-k).

Todos os instantes contam (como nos modelos anteriores); sem histórico a d2c-a abstém. Nada de `src/` muda.
Saída: `resultados/protocolo-hibrido-d9a/<conjunto>/` e `resultado.md`.
Uso: replay/hibrido_d9a.py [--conjuntos dev,conf,def] [--jobs 16] [--so-analise]
"""
from __future__ import annotations

import argparse
import datetime
import gzip
import json
import os
import sys
import time
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import confirmatorio as CF  # noqa: E402, N812
import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import paridade_solucoes as PS  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: E402

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-hibrido-d9a")
MARGEM, K_MIN, K_MAX = 1e-3, 2, 3
MODOS = ("d9-k", "d9-k+a", "d9", "d9+a", "d2c-r", "d2c-a")
OFICIAL = {"def": (DF.SAIDA, "v-cons-b-prod"), "conf": (CF.SAIDA, "v-cons-b-prod"), "dev": (PS.SAIDA, "v-cons-b-prod")}


def _casos(conj: str) -> list[str]:
    if conj == "dev":
        return [c for c in PR.casos() if PR.AI.periodos(c)]
    if conj == "conf":
        return CF.casos()
    return DF.casos(DF.runs())


def _nomes(d: Any) -> list[str]:
    return [i.servico for i in d.ranking][:3]


def rodar_caso(job: tuple[str, str, bool]) -> str:
    import a0b_insumos as A0BI  # noqa: N812, PLC0415
    from src.application.stage3.abordagens import d2cr_nulo_rolante as d2cr  # noqa: PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    from src.application.stage3.abordagens import d9k_portao_grafo_k8s as d9k  # noqa: PLC0415
    case_dir, saida, confirmatorio = job
    AI, AF = PR.AI, PR.AF  # noqa: N806
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência -- fora"
    t0 = time.monotonic()
    fora = set() if confirmatorio else PS._fora()
    eventos = A0BI.eventos_do_caso(case_dir)
    k8s = PR._k8s_limpo(AF._k8s_dicts(case_dir), per["normal"][0])
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), fim_normal))
    pre_k8s = AF._visao_em(k8s, fim_normal)
    sis = {"entry_services": PR.P.ENTRY_SERVICES}
    cfg9 = {**sis, **PR.PORTAO_D9}
    hist: list[float] = []
    linhas = []
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, PS.PASSO):
        if (f"{run_id}/{falha}", t.isoformat()) in fora:
            continue
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if confirmatorio and len({e.case_id for e in dentro}) < PS.MIN_TRACES:
            continue
        if periodo == "estavel":
            delta = janela[0] - fim_normal
            lookback = AF._deslocar_traces(pre_falha, int(delta.total_seconds() * 1e6))
            k8s_todos = AF._iso(pre_k8s, delta) + AF._iso(AF._a_partir_de(AF._visao_em(k8s, t), janela[0]))
        else:
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), janela[0]))
            k8s_todos = AF._iso(AF._visao_em(k8s, t))
        ent = EntradaIncidente(incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
                               traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=k8s_todos,
                               config_sistema=sis)
        base = {"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat()}
        res: dict[str, dict[str, Any]] = {}
        # d9 (como no paridade_solucoes)
        g9 = PR._decidir(d9, ent, {}, cfg9)
        f9 = g9["ranking"] if g9["status"] == "decidiu" and g9["ranking"] else \
            PR._decidir(d9, ent, {}, {**cfg9, **PR.PERMISSIVO_D5})["ranking"]
        res["d9"] = {"status": g9["status"], "ranking": g9["ranking"] if g9["status"] == "decidiu" else [], "forcado": f9}
        # d9-k (módulo do produto)
        dk = d9k.decidir(ent, {}, sis)
        res["d9-k"] = {"status": dk.status, "ranking": _nomes(dk) if dk.status == "decidiu" else [],
                       "forcado": list(dk.evidencias.get("ranking_forcado") or [])[:3]}
        # d2c-r e d2c-a: um d2c-r permissivo dá o p_min; os outros só são chamados se puderem decidir
        try:
            dp = d2cr.decidir(ent, {}, {**sis, "q": 1.0})
            pm = (dp.evidencias or {}).get("p_min_ajustado")
            pm = float(pm) if pm is not None else 1.0
            f2 = _nomes(dp) if dp.status == "decidiu" else []
        except Exception:  # noqa: BLE001
            pm, f2 = 1.0, []
        r2 = _nomes(d2cr.decidir(ent, {}, {**sis, "q": 1e-50})) if pm <= 1e-50 else []
        res["d2c-r"] = {"status": "decidiu" if r2 else "absteve", "ranking": r2, "forcado": f2, "p_min": pm}
        h = hist[-K_MAX:]
        q = MARGEM * min(h) if len(h) >= K_MIN else None
        ra = _nomes(d2cr.decidir(ent, {}, {**sis, "q": q})) if q is not None and pm <= q else []
        res["d2c-a"] = {"status": "decidiu" if ra else "absteve", "ranking": ra, "forcado": f2, "q": q, "n_hist": len(h)}
        if periodo == "normal":
            hist.append(pm)
        for hib, prim in (("d9+a", "d9"), ("d9-k+a", "d9-k")):
            p = res[prim]
            usa = p if p["status"] == "decidiu" and p["ranking"] else res["d2c-a"]
            res[hib] = {"status": usa["status"], "ranking": usa["ranking"], "forcado": p["forcado"],
                        "origem": prim if usa is p else "d2c-a"}
        linhas += [json.dumps({**base, "modo": m, **v}) for m, v in res.items()]
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def _inv(conj: str, cs: list[str]) -> dict[str, Any]:
    inv = PR.inventario() if conj == "dev" else CF.inventario(cs)
    return {k: v for k, v in inv.items() if any(c.endswith(k) for c in cs)}


def analisar(conjuntos: list[str]) -> str:
    rot = {"dev": "Desenvolvimento", "conf": "Confirmatório", "def": "Definitiva"}
    out = ["# Híbrido d9+a / d9-k+a no TeaStore — mesma bateria dos modelos anteriores", "",
           "Mesma entrada, instantes e higiene do `paridade_solucoes.rodar_caso`. `d9-k`/`d9` refeitos aqui (paridade "
           "com os registros oficiais abaixo); `v-cons-b` = registros oficiais. Descritivo: estes conjuntos já foram "
           "vistos.", ""]
    for conj in conjuntos:
        cs = _casos(conj)
        inv = _inv(conj, cs)
        rs = C._novos(inv, os.path.join(SAIDA, conj), "*.jsonl.gz")
        pasta, modo_vc = OFICIAL[conj]
        rs += [{**r, "modo": "v-cons-b"} for r in C._novos(inv, pasta, "*.jsonl.gz") if r["modo"] == modo_vc]
        instantes = {(r["cenario"], r["t"]) for r in rs if r["modo"] == "d9"}
        rs = [r for r in rs if r["modo"] != "v-cons-b" or (r["cenario"], r["t"]) in instantes]
        pcs = {}
        for (m, c), x in A.por_cenario(rs, inv).items():
            pcs.setdefault(m, {})[c] = x
        out += [f"## {rot[conj]} ({len(pcs.get('d9', {}))} cenários, {len(instantes)} instantes)", "",
                "| modo | F1@1 [IC 95%] | F1@2 | alarme | abstenção | sabendo top-1 | top-2 | top-3 |",
                "|---|---|---|---|---|---|---|---|"]
        for m in ("d9-k", "v-cons-b", "d2c-r", "d9-k+a", "d9+a", "d2c-a", "d9"):
            if m not in pcs:
                continue
            r, ic = DF.metricas(pcs[m]), DF._boot(pcs[m], A.f1)
            out.append(f"| {m} | {r['f1']:.3f} [{ic[0]:.3f}–{ic[1]:.3f}] | {r['f2']:.3f} | {r['alarme']:.1%} | "
                       f"{r['abst']:.0%} | {r['o1']:.0%} | {r['o2']:.0%} | {r['o3']:.0%} |")
        out.append("")
        for a, b in (("d9-k+a", "d9-k"), ("d9+a", "d9"), ("d2c-a", "d2c-r")):
            if a in pcs and b in pcs:
                sa, sb, p = DF.mcnemar(pcs[a], pcs[b], "tp1")
                out.append(f"- McNemar {a} × {b} (top-1 com portão): só {a} {sa}, só {b} {sb}, p = {p:.3f}")
        out.append("")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--conjuntos", default="dev,conf,def")
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-analise", action="store_true")
    args = ap.parse_args()
    conjuntos = args.conjuntos.split(",")
    if not args.so_analise:
        from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
        jobs = [(c, os.path.join(SAIDA, conj), conj != "dev") for conj in conjuntos for c in _casos(conj)]
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(rodar_caso, jobs):
                print(msg, flush=True)
    texto = analisar(conjuntos)
    os.makedirs(SAIDA, exist_ok=True)
    with open(os.path.join(SAIDA, "resultado.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
