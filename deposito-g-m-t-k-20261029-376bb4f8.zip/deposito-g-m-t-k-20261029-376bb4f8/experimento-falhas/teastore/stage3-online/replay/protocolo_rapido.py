#!/usr/bin/env python3
"""Protocolo rápido (`experimento-falhas/teastore/PROTOCOLO-RAPIDO.md`): avaliação comum nos 54 cenários.

Subcomandos:

- `inventario`: períodos, gabarito e insumos de cada cenário (`inventario.json`).
- `rodar`: os modos de referência da própria sessão (d2c, d6, d5, d9 e os 8 filhos) e os baselines ingênuos
  (b1 = serviço com mais spans de erro na janela; b2 = primeiro serviço com evento K8s na janela) nos instantes
  normais e estáveis, um a cada `--passo` s. Cada modo grava a decisão com o parâmetro final (`status`,
  `ranking`) **e** a decisão forçada (`forcado`: o ranking do parâmetro final se decidiu, senão o da versão
  permissiva do mesmo modo — §3 do protocolo). Mesma entrada do `avaliar_instantes_filhos` (referência travada
  no pré-falha, deslocada, nos estáveis). d1–d4 e d7 não rodam aqui: o registro gravado com `q` do fp 0,20
  já decide sempre (subamostrado na análise).

Saída: `resultados/protocolo-rapido/` (`inventario.json`, `modos/<RUN>__<falha>.jsonl.gz`).

- `unificado` (opção A): **todos** os modos de traces no mesmo laço — d1, d1c, d2, d3, d4, d4c pelo
  registro do `q` do fp 0,20 com o portão da emenda 1 (estatística ≤ L); d2c, d6 (a=1), d6-k, d6-u, d7 a partir de
  uma decisão da d2c por instante (portão L; d7 com similaridade ≥ 0,5); os modos de referência da sessão como no
  `rodar`. Lookback de 1800 s (o da d3), pré-falha deslocado nos estáveis para todos.

Uso: replay/protocolo_rapido.py inventario | rodar | unificado [--passo 60] [--jobs 16] [--falhas f1-latency,...]
     [--modos d9+m --subdir modos15]   (E2 falhou para o modo: volta a 20 instantes, §4 do protocolo)
"""
from __future__ import annotations

import argparse
import copy
import datetime
import glob
import gzip
import json
import os
import sys
import time
from collections import Counter
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import avaliar_instantes as AI  # noqa: E402, N812
import avaliar_instantes_filhos as AF  # noqa: E402, N812
import diagnostico_dev as DD  # noqa: E402, N812
import metricas_instantes as M  # noqa: E402, N812
import preparar_baseline_abordagens as P  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import (  # noqa: E402
    a0b_baseline,
    a0d_regua,
    a0k_k8s,
    calibracao,
    d2c_diferencial,
    d2ccp_ponto_mudanca,
    d2cr_nulo_rolante,
    d5_portao,
    d6_residuo,
    d6k_aresta,
    d6u_uniao,
    d7_assinatura,
    d9_2h_grafo,
    d9_portao_grafo,
    d9m_grafo,
    registro,
)
from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: E402

SAIDA = os.path.join(R.RESULTADOS, "protocolo-rapido")
RUNS_G = ("20261012T213402Z", "20261013T061915Z", "20261013T143247Z")
RUNS = DD.RUNS_DEV + RUNS_G
PORTAO_D5 = {"limiar": 1.5, "limiar_erro": 0.05, "limiar_dano_lat": None, "ref_seg": 150}
PORTAO_D9 = AF.PORTAO_D9
PERMISSIVO_D5 = {"limiar": 1.0, "limiar_erro": 0.0, "limiar_dano_lat": None, "min_traces": 0}
Q_FINAL, Q_PERMISSIVO = AF.Q_D2C, 1.0
# nome -> (módulo, cfg final, cfg permissiva, artefato d2c: None | "q")
MODOS: dict[str, tuple[Any, dict[str, Any], dict[str, Any], bool]] = {
    "d2c": (d2c_diferencial, {}, {}, True),
    "d6": (d6_residuo, {}, {}, True),
    "d6-k": (d6k_aresta, {}, {}, True),
    "d6-u": (d6u_uniao, {}, {}, True),
    "d2c-r": (d2cr_nulo_rolante, {"q": Q_FINAL}, {"q": Q_PERMISSIVO}, False),
    "d2c-cp": (d2ccp_ponto_mudanca, {}, {"limiar_efeito": 1.0, "min_eventos": 1}, False),
    "d5": (d5_portao, PORTAO_D5, {**PORTAO_D5, **PERMISSIVO_D5}, False),
    "d9": (d9_portao_grafo, PORTAO_D9, {**PORTAO_D9, **PERMISSIVO_D5}, False),
    "d9-2h": (d9_2h_grafo, PORTAO_D9, {**PORTAO_D9, **PERMISSIVO_D5}, False),
    "d9+m": (d9m_grafo, PORTAO_D9, {**PORTAO_D9, **PERMISSIVO_D5}, False),
    "a0-k": (a0k_k8s, {}, {"alpha": 1.0}, False),
    "a0-d": (a0d_regua, {}, {"alpha": 1.0}, False),
}


# Fase 0 do PROTOCOLO-CONSENSO.md: motivos K8s de sintoma (os de operação são do próprio harness: rollout do patch).
K8S_SINTOMA = {"OOMKilled", "OOMKilling", "BackOff", "Unhealthy", "Evicted", "Failed", "FailedScheduling",
               "ProbeWarning"}
K8S_LIMPO = os.environ.get("PR_K8S_LIMPO") == "1"


def _k8s_limpo(k8s: list[dict[str, Any]], inicio_normal: datetime.datetime) -> list[dict[str, Any]]:
    """Só sintoma, e só a parte de cada evento a partir do início do normal (`count` proporcional)."""
    return AF._a_partir_de([e for e in k8s if e["reason"] in K8S_SINTOMA], inicio_normal)


def _d9k_base(entrada: EntradaIncidente, cfg: dict[str, Any]) -> list[str]:
    """Ranking da d9-k antes do canal K8s: `residuo_1` completado pelo efeito (d5) e pelo `profundo`, top-3."""
    saida: list[str] = []
    for mod, extra in ((d9_portao_grafo, {"localizacao": "residuo_1"}), (d5_portao, {}),
                       (d9_portao_grafo, {"localizacao": "profundo"})):
        try:
            d = mod.decidir(entrada, {}, {**AF.SISTEMA, **cfg, **extra})
        except Exception:  # noqa: BLE001
            continue
        saida += [i.servico for i in d.ranking if i.servico not in saida]
        if len(saida) >= 3:
            break
    return saida[:3]


def _k8s_top(k8s: list[dict[str, Any]], janela: tuple[datetime.datetime, datetime.datetime]) -> str | None:
    cont: Counter = Counter()
    for e in AF._a_partir_de(AF._visao_em(k8s, janela[1]), janela[0]):
        cont[e["res"]] += int(e["count"])
    return max(cont, key=lambda s: (cont[s], s)) if cont else None


# Avaliador unificado (opção A): os modos de artefato no mesmo laço, com o portão da emenda 1
# (registro do `q` do fp 0,20 + estatística ≤ L) e a mesma entrada dos modos de referência da sessão.
FP_UNIF = 0.20
LOOKBACK_UNIF = 1800          # o da d3 (`lookback_seg`); os demais cortam o seu `ref_seg` dentro dele
L_EMENDA1 = {"d1": 1e-10, "d1c": 1e-200, "d2": 1e-20, "d2c": 1e-50, "d4": 1e-05, "d4c": 1e-05, "d6": 1e-50,
             "d6-k": 1e-50, "d6-u": 1e-50, "d7": 1e-20}
SIM_D7 = 0.5
MODOS_ARTEFATO = ("d1", "d1c", "d2", "d3", "d4", "d4c")
MODOS_SESSAO = ("d2c-r", "d2c-cp", "d5", "d9", "d9-2h", "d9+m", "a0-k", "a0-d")


def _artefato_fp(colecao: str, modo: str) -> dict[str, Any]:
    """O artefato do modo com o `q` do fp 0,20 (mesma regra do `avaliar_instantes.artefatos_por_fp`)."""
    if modo == "d3":
        with open(P.caminho_artefato(colecao, "d3", f"-fp{FP_UNIF}")) as f:
            return json.load(f)
    return next(art for fps, _q, art in AI.artefatos_por_fp(colecao, modo, "-w120") if FP_UNIF in fps)


def _linha_artefato(d: Any, modo: str, extra_ok: bool = True) -> dict[str, Any]:
    est = calibracao.estatistica_da_decisao(d)
    rk = [i.servico for i in d.ranking][:3]
    decidiu_fp = d.status == "decidiu"
    if modo == "d3":
        ok = decidiu_fp
    else:
        ok = decidiu_fp and est is not None and est <= L_EMENDA1[modo] and extra_ok
    return {"status": "decidiu" if ok else "absteve", "motivo": d.motivo_abstencao if not decidiu_fp else
            (None if ok else "acima_do_L"), "estatistica": est, "ranking": rk if ok else [],
            "forcado": rk if decidiu_fp else [], "origem": "fp0.2"}


def rodar_caso_unificado(job: tuple[str, float, str, list[str] | None]) -> str:
    case_dir, passo, saida, so_modos = job
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência ou pacotes -- fora"

    def quer(m: str) -> bool:
        return not so_modos or m in so_modos

    t0 = time.monotonic()
    colecao = R._load(os.path.join(os.path.dirname(case_dir), "manifest.json"))["collection_id"]
    if quer("a0-b"):   # a0-b: mesmos eventos, com `url.path`
        import a0b_insumos as A0BI  # noqa: N812, PLC0415
        eventos = A0BI.eventos_do_caso(case_dir)
        art_a0b = A0BI.artefato(colecao[:8])
    else:
        eventos = AI.eventos_do_caso(case_dir)
    k8s = AF._k8s_dicts(case_dir)
    if K8S_LIMPO:
        k8s = _k8s_limpo(k8s, per["normal"][0])
    arts = {m: _artefato_fp(colecao, m) for m in (*MODOS_ARTEFATO, "d2c") if quer(m) or m == "d2c"}
    art_perm = copy.deepcopy(arts["d2c"])
    art_perm["calibracao"]["q"] = Q_PERMISSIVO
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=LOOKBACK_UNIF), fim_normal))
    pre_k8s = AF._visao_em(k8s, fim_normal)
    linhas = []
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, passo):
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if periodo == "estavel":
            delta = janela[0] - fim_normal
            lookback = AF._deslocar_traces(pre_falha, int(delta.total_seconds() * 1e6))
            k8s_todos = AF._iso(pre_k8s, delta) + AF._iso(AF._a_partir_de(AF._visao_em(k8s, t), janela[0]))
        else:
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=LOOKBACK_UNIF), janela[0]))
            k8s_todos = AF._iso(AF._visao_em(k8s, t))
        entrada = EntradaIncidente(
            incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
            traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=k8s_todos,
            config_sistema={"entry_services": P.ENTRY_SERVICES})
        base = {"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat(),
                "seg_desde_estavel": (t - per["estavel"][0]).total_seconds(),
                "n_traces": len({e.case_id for e in dentro})}

        def gravar(modo: str, linha: dict[str, Any], base: dict[str, Any] = base) -> None:
            linhas.append(json.dumps({**base, "modo": modo, **linha}))

        for modo in MODOS_ARTEFATO:
            if not quer(modo):
                continue
            try:
                d = registro.executar_modo(modo, entrada, arts[modo], P.cfg_do_modo(modo, {"fp_alvo": FP_UNIF}))
                gravar(modo, _linha_artefato(d, modo))
            except Exception as exc:  # noqa: BLE001
                gravar(modo, {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}"[:200], "ranking": [],
                              "forcado": [], "origem": "fp0.2"})
        familia = [m for m in ("d2c", "d6", "d6-k", "d6-u", "d7") if quer(m)]
        if familia:
            cfg = {**AF.SISTEMA, **P.cfg_do_modo("d6", {"fp_alvo": FP_UNIF})}
            try:
                b = d2c_diferencial.decidir(entrada, arts["d2c"], cfg)
                b_perm = None
                derivados = {
                    "d2c": lambda b: b,
                    "d6": lambda b: d6_residuo.decidir_de_base(b, entrada, arts["d2c"], {**cfg, "atenuacao": 1.0}),
                    "d6-k": lambda b: d6k_aresta.decidir_de_base(b, entrada, arts["d2c"], cfg),
                    "d6-u": lambda b: d6u_uniao.decidir_de_base(b, entrada, arts["d2c"], cfg),
                    "d7": lambda b: d7_assinatura.decidir_de_base(b, entrada, arts["d2c"],
                                                                  {**cfg, "limiar_similaridade": 0.0}),
                }
                for modo in familia:
                    d = derivados[modo](b)
                    sim_ok = True
                    if modo == "d7":
                        sim = d.ranking[0].evidencias.get("similaridade") if d.ranking else None
                        sim_ok = sim is not None and sim >= SIM_D7
                    linha = _linha_artefato(d, modo, sim_ok)
                    linha["estatistica"] = calibracao.estatistica_da_decisao(b)
                    ok_l = (b.status == "decidiu" and linha["estatistica"] is not None
                            and linha["estatistica"] <= L_EMENDA1[modo] and sim_ok and d.status == "decidiu")
                    linha.update({"status": "decidiu" if ok_l else "absteve",
                                  "ranking": [i.servico for i in d.ranking][:3] if ok_l else []})
                    if not linha["forcado"] and modo != "d7":   # protocolo §3: família d2c → q = 1
                        if b_perm is None:
                            b_perm = d2c_diferencial.decidir(entrada, art_perm, cfg)
                        dp = (derivados[modo](b_perm) if modo != "d2c" else b_perm)
                        linha.update({"forcado": [i.servico for i in dp.ranking][:3], "origem": "permissivo"})
                    gravar(modo, linha)
            except Exception as exc:  # noqa: BLE001
                for modo in familia:
                    gravar(modo, {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}"[:200],
                                  "ranking": [], "forcado": [], "origem": "fp0.2"})
        for nome in MODOS_SESSAO:
            if not quer(nome):
                continue
            mod, cfg_m, cfg_perm, _usa = MODOS[nome]
            linha = _decidir(mod, entrada, {}, cfg_m)
            if linha["status"] == "decidiu" and linha["ranking"]:
                forcado, origem = linha["ranking"], "final"
            else:
                forcado, origem = _decidir(mod, entrada, {}, {**cfg_m, **cfg_perm})["ranking"], "permissivo"
            gravar(nome, {**linha, "forcado": forcado, "origem": origem})
        if quer("a0-b"):
            linha = _decidir(a0b_baseline, entrada, art_a0b, {})
            if linha["status"] == "decidiu" and linha["ranking"]:
                forcado, origem = linha["ranking"], "final"
            else:
                forcado, origem = _decidir(a0b_baseline, entrada, art_a0b, {"alpha": 1.0})["ranking"], "permissivo"
            gravar("a0-b", {**linha, "forcado": forcado, "origem": origem})
        if quer("d9-k"):   # PROTOCOLO-CONSENSO §3: a base; persistência e K8s abre-portão na análise
            gate = _decidir(d9_portao_grafo, entrada, {}, PORTAO_D9)
            aberto = gate["status"] == "decidiu" and bool(gate["ranking"])
            final = _d9k_base(entrada, PORTAO_D9) if aberto else []
            forcado = final or _d9k_base(entrada, {**PORTAO_D9, **PERMISSIVO_D5})
            topk = _k8s_top(k8s, janela)
            if topk:
                final = ([topk] + [x for x in final if x != topk])[:3] if aberto else []
                forcado = ([topk] + [x for x in forcado if x != topk])[:3]
            gravar("d9-k", {"status": "decidiu" if aberto else "absteve", "motivo": gate["motivo"],
                            "ranking": final, "forcado": forcado, "origem": "final" if aberto else "permissivo",
                            "k8s_sintoma": topk})
        for nome, rk in (("b1", _b1(dentro)), ("b2", _b2(k8s, janela))):
            if quer(nome):
                gravar(nome, {"status": "decidiu" if rk else "absteve", "motivo": None, "ranking": rk,
                              "forcado": rk, "origem": "final"})
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def casos() -> list[str]:
    return [c for run in RUNS for c in sorted(glob.glob(os.path.join(R.RESULTADOS, run, "[fgh][0-9]*")))
            if os.path.isdir(c)]


def inventario() -> dict[str, Any]:
    saida = {}
    for c in casos():
        run_id, falha = os.path.basename(os.path.dirname(c)), os.path.basename(c)
        per = AI.periodos(c)
        saida[f"{run_id}/{falha}"] = {
            "tipo": M.tipo_de(falha), "grupo": M.tipo_de(falha)[0], "esperado": M.esperado(run_id, falha),
            "periodos_seg": {k: (v[1] - v[0]).total_seconds() for k, v in per.items()},
            "inicio_estavel": per["estavel"][0].isoformat() if per else None,
            "fim_normal": per["normal"][1].isoformat() if per else None,
            "pacotes_continuos": os.path.isdir(os.path.join(c, "evidence_packages_continuos")),
            "k8s": os.path.exists(os.path.join(c, "k8s_events_cluster.json")),
            "traces": [n for n in ("traces_full_scenario.json", "traces_stage3_window.json", "traces.json")
                       if os.path.exists(os.path.join(c, n))],
        }
    return saida


def _artefatos(case_dir: str) -> tuple[dict[str, Any], dict[str, Any]]:
    final = AF._artefato_d2c(case_dir)
    permissivo = copy.deepcopy(final)
    permissivo["calibracao"]["q"] = Q_PERMISSIVO
    return final, permissivo


def _b1(dentro: list[Any]) -> list[str]:
    erros = Counter(str(e.service) for e in dentro if getattr(e, "is_error", False) and e.service)
    return [s for s, _ in erros.most_common(3)]


def _b2(k8s: list[dict[str, Any]], janela: tuple[datetime.datetime, datetime.datetime]) -> list[str]:
    """Serviços com evento K8s na janela, pelo primeiro instante dentro dela (desempate: mais ocorrências)."""
    melhor: dict[str, tuple[datetime.datetime, int]] = {}
    for e in AF._a_partir_de(AF._visao_em(k8s, janela[1]), janela[0]):
        chave = (max(e["first_ts"], janela[0]), -int(e["count"]))
        if e["res"] not in melhor or chave < melhor[e["res"]]:
            melhor[e["res"]] = chave
    return sorted(melhor, key=lambda s: (melhor[s], s))[:3]


def _decidir(mod: Any, entrada: EntradaIncidente, art: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    try:
        d = mod.decidir(entrada, art, {**AF.SISTEMA, **cfg})
        return {"status": d.status, "motivo": d.motivo_abstencao, "ranking": [i.servico for i in d.ranking][:3]}
    except Exception as exc:  # noqa: BLE001 - um instante quebrado não derruba o cenário
        return {"status": "falhou", "motivo": f"{type(exc).__name__}: {exc}"[:200], "ranking": []}


def rodar_caso(job: tuple[str, float, str, list[str] | None]) -> str:
    case_dir, passo, saida, so_modos = job
    modos = {k: v for k, v in MODOS.items() if not so_modos or k in so_modos}
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência ou pacotes -- fora"
    t0 = time.monotonic()
    eventos = AI.eventos_do_caso(case_dir)
    k8s = AF._k8s_dicts(case_dir)
    art_final, art_perm = _artefatos(case_dir)
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=AF.LOOKBACK_SEG), fim_normal))
    pre_k8s = AF._visao_em(k8s, fim_normal)
    linhas = []
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, passo):
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if periodo == "estavel":
            delta = janela[0] - fim_normal
            lookback = AF._deslocar_traces(pre_falha, int(delta.total_seconds() * 1e6))
            k8s_todos = AF._iso(pre_k8s, delta) + AF._iso(AF._a_partir_de(AF._visao_em(k8s, t), janela[0]))
        else:
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=AF.LOOKBACK_SEG), janela[0]))
            k8s_todos = AF._iso(AF._visao_em(k8s, t))
        entrada = EntradaIncidente(
            incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
            traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=k8s_todos,
            config_sistema={"entry_services": P.ENTRY_SERVICES})
        base = {"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat(),
                "seg_desde_estavel": (t - per["estavel"][0]).total_seconds(),
                "n_traces": len({e.case_id for e in dentro})}
        for nome, (mod, cfg, cfg_perm, usa_art) in modos.items():
            linha = _decidir(mod, entrada, art_final if usa_art else {}, cfg)
            if linha["status"] == "decidiu" and linha["ranking"]:
                forcado, origem = linha["ranking"], "final"
            else:
                perm = _decidir(mod, entrada, art_perm if usa_art else {}, {**cfg, **cfg_perm})
                forcado, origem = perm["ranking"], "permissivo"
            linhas.append(json.dumps({**base, "modo": nome, **linha, "forcado": forcado, "origem": origem}))
        for nome, rk in ((("b1", _b1(dentro)), ("b2", _b2(k8s, janela))) if not so_modos else ()):
            linhas.append(json.dumps({**base, "modo": nome, "status": "decidiu" if rk else "absteve",
                                      "motivo": None, "ranking": rk, "forcado": rk, "origem": "final"}))
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("comando", choices=("inventario", "rodar", "unificado"))
    ap.add_argument("--passo", type=float, default=60.0)
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--falhas")
    ap.add_argument("--modos", help="só estes modos (sem os baselines), separados por vírgula")
    ap.add_argument("--subdir", default="modos")
    ap.add_argument("--saida", default=SAIDA)
    args = ap.parse_args()
    os.makedirs(args.saida, exist_ok=True)
    if args.comando == "inventario":
        inv = inventario()
        with open(os.path.join(args.saida, "inventario.json"), "w") as f:
            json.dump(inv, f, indent=1, sort_keys=True)
        grupos = Counter(v["grupo"] for v in inv.values())
        print(f"{len(inv)} cenários {dict(grupos)}; pacotes contínuos: "
              f"{sum(v['pacotes_continuos'] for v in inv.values())}; sem períodos: "
              f"{[k for k, v in inv.items() if not v['periodos_seg']]}")
        print("períodos (s):", Counter(tuple(round(x) for x in v["periodos_seg"].values()) for v in inv.values()))
        return 0
    from concurrent.futures import ProcessPoolExecutor
    alvo = [c for c in casos() if not args.falhas or os.path.basename(c) in args.falhas.split(",")]
    with ProcessPoolExecutor(args.jobs) as ex:
        so = args.modos.split(",") if args.modos else None
        func = rodar_caso_unificado if args.comando == "unificado" else rodar_caso
        for msg in ex.map(func, [(c, args.passo, os.path.join(args.saida, args.subdir), so) for c in alvo]):
            print(msg, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
