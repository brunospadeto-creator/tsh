#!/usr/bin/env python3
"""Insumos da a0-b: eventos com `url.path` e o artefato da baseline normal por coleção.

O `TraceEvent` do produto não guarda `url.path` (e `traces.py` está no fecho congelado), então o avaliador
acrescenta o atributo a partir dos traces brutos, pelo `span_id` — o mesmo dado que o coletor já recebe.

Uso: replay/a0b_insumos.py [coleção ...]   (padrão d7cd3536 547ba505; gera `resultados/insumos/abordagens-<coleção>-a0-b.json`)
"""
from __future__ import annotations

import glob
import gzip
import json
import os
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import preparar_baseline_abordagens as P  # noqa: E402, N812
import replay as R  # noqa: E402, N812

from src.application.stage3.abordagens import a0b_baseline, processo  # noqa: E402

CFG = {**P.CFG_SISTEMA_MODOS_C, "entry_services": P.ENTRY_SERVICES}


def _caminhos(brutos: dict[str, Any]) -> dict[str, str]:
    saida = {}
    for t in brutos.values():
        for s in t.get("spans") or []:
            tags = {x.get("key"): x.get("value") for x in s.get("tags") or []}
            caminho = tags.get("url.path") or tags.get("http.target") or tags.get("http.url")
            if caminho:
                saida[str(s.get("spanID"))] = str(caminho)
    return saida


def enriquecer(eventos: list[Any], brutos: dict[str, Any]) -> list[Any]:
    caminhos = _caminhos(brutos)
    for e in eventos:
        if e.span_id in caminhos:
            e.attributes["url.path"] = caminhos[e.span_id]
    return eventos


def eventos_do_caso(case_dir: str) -> list[Any]:
    """`avaliar_instantes.eventos_do_caso` + `url.path`."""
    brutos: dict[str, Any] = {}
    for nome in ("traces_full_scenario.json", "traces_stage3_window.json", "traces.json"):
        caminho = os.path.join(case_dir, nome)
        if os.path.exists(caminho):
            brutos.update(R._load(caminho).get("traces") or {})
    for parte in sorted(glob.glob(os.path.join(case_dir, "traces_salvage.parts", "*.json"))):
        dado = R._load(parte)
        brutos.update(dado.get("traces") or {} if isinstance(dado, dict) else {})
    return enriquecer(processo.eventos_de_traces_brutos(brutos, P.ENTRY_SERVICES), brutos)


def caminho(colecao: str) -> str:
    return P.caminho_artefato(colecao, "a0-b")


def artefato(colecao: str) -> dict[str, Any]:
    with open(caminho(colecao)) as f:
        return json.load(f)


def main() -> int:
    for colecao in sys.argv[1:] or ("d7cd3536", "547ba505"):
        with gzip.open(P.backup_de(colecao)) as f:
            brutos = json.load(f).get("traces") or {}
        eventos = enriquecer(processo.eventos_de_traces_brutos(brutos, P.ENTRY_SERVICES), brutos)
        art = a0b_baseline.preparar_baseline(eventos, [], CFG)
        art["_preparo"] = {"colecao": colecao, "n_eventos": len(eventos)}
        with open(caminho(colecao), "w") as f:
            json.dump(art, f)
        print(colecao, art["janelas"], "janelas;", len(art.get("servicos") or []), "serviços")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
