"""Arcabouço de avaliação da localização.

- `metricas(rows)`: AC@1, AC@2, AC@3, Avg@5 (métricas do RCAEval) e MRR, com IC 95% de Wilson; abstenção
  conta como erro, e o recorte "só respondidos" vem ao lado;
- `rodar(casos, overrides)`: replay de uma configuração sobre os casos (processos em paralelo), sem gravar;
- configurações de referência e grades de ajuste por modo, usadas por `sensibilidade.py` e `lofo.py`.
"""

from __future__ import annotations

import math
import os
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import ProcessPoolExecutor
from typing import Any

import replay as R  # noqa: N812

REF_V5: dict[str, Any] = {"localization_mode": "votos"}
REF_V6: dict[str, Any] = {"localization_mode": "anomalias"}

# Parâmetros ajustáveis de cada modo (o resto é configuração de sistema). v5: os pesos e limiares variados na
# grade; v6: os três números da localização por anomalias.
GRADE_V5: dict[str, list[Any]] = {
    "vote_weights.erro_http": [1.0, 2.0],
    "http_error_min_share": [0.05, 0.1],
    "vote_weights.chamada_ausente": [1.0, 1.5, 2.0],
    "vote_weights.descoberta": [2.0, 2.5],
}
GRADE_V6: dict[str, list[Any]] = {
    "anomaly_k": [2.0, 2.5, 3.0, 4.0, 5.0],
    "piso_relativo": [0.02, 0.05, 0.1],
}
PESOS_V5 = ("estrutural", "descoberta", "inanicao", "fronteira", "taxa_erro", "chamada_ausente", "k8s", "erro_http")


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    den = 1 + z * z / n
    centro = (p + z * z / (2 * n)) / den
    meia = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centro - meia), min(1.0, centro + meia))


def empate_no_topo(ranking: Sequence[Mapping[str, Any]]) -> bool:
    """O 1º colocado empata com o 2º? (a d2 "acertava" perdendo empate no piso de 1e-300
    pelo nome.) Versões `c` marcam `evidencias.empate_com_seguinte`; nas v1, empate = mesmo `escore`."""
    if len(ranking) < 2:
        return False
    ev = ranking[0].get("evidencias") or {}
    if "empate_com_seguinte" in ev:
        return bool(ev["empate_com_seguinte"])
    return ranking[0].get("escore") is not None and ranking[0].get("escore") == ranking[1].get("escore")


def _rank(row: Mapping[str, Any]) -> int | None:
    return row.get("rank") if row.get("respondeu", True) else None


def metricas(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    n = len(rows)
    if not n:
        return {"n": 0}
    ranks = [_rank(r) for r in rows]
    ac = {j: sum(1 for r in ranks if r is not None and r <= j) for j in range(1, 6)}
    respondidos = [r for r in rows if r.get("respondeu", True)]
    out: dict[str, Any] = {
        "n": n, "ac1": ac[1], "ac2": ac[2], "ac3": ac[3],
        "avg5": round(sum(ac[j] / n for j in range(1, 6)) / 5, 4),
        "mrr": round(sum(1.0 / r for r in ranks if r) / n, 4),
        "ic_ac1": [round(x, 3) for x in wilson(ac[1], n)], "ic_ac3": [round(x, 3) for x in wilson(ac[3], n)],
        "abstencoes": n - len(respondidos), "respondidos": len(respondidos),
        # acerto que dependeu de desempate (nome, ordem de inserção) não conta
        "ac1_sem_empate": sum(1 for r, row in zip(ranks, rows) if r == 1 and not row.get("empate_topo")),
    }
    return out


def linha(m: Mapping[str, Any]) -> str:
    n = m.get("n") or 0
    if not n:
        return "sem casos"
    return (f"AC@1 {m['ac1']}/{n} ({m['ac1'] / n:.0%}, IC {m['ic_ac1'][0]:.0%}–{m['ic_ac1'][1]:.0%}) · "
            f"AC@3 {m['ac3']}/{n} ({m['ac3'] / n:.0%}) · Avg@5 {m['avg5']:.3f} · MRR {m['mrr']:.3f} · "
            f"abstenções {m['abstencoes']}")


def casos(runs: Iterable[str] | None = None) -> list[str]:
    return R.discover_cases(list(runs) if runs else None)


def rodar(cases: Sequence[str], overrides: Mapping[str, Any], jobs: int = 7) -> list[dict[str, Any]]:
    """Replay de uma configuração (overrides no formato de `--set`, chaves com ponto)."""
    cfg: dict[str, Any] = {}
    for chave, valor in overrides.items():
        R._set_path(cfg, chave, str(valor) if not isinstance(valor, str) else valor)  # noqa: SLF001
    trabalhos = [(c, cfg, False, False) for c in cases]
    if jobs > 1:
        with ProcessPoolExecutor(max_workers=jobs) as pool:
            return list(pool.map(R._safe_replay, trabalhos))  # noqa: SLF001
    return [R._safe_replay(t) for t in trabalhos]  # noqa: SLF001


def usar_baseline(caminho: str | None) -> None:
    if caminho:
        os.environ["REPLAY_BASELINE"] = os.path.abspath(caminho)


def chave_caso(row: Mapping[str, Any]) -> str:
    return f"{row['run_id']}__{row['falha']}"
