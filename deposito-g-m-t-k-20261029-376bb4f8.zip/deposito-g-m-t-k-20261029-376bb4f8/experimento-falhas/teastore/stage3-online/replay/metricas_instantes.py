#!/usr/bin/env python3
"""F1 por instante e validação cruzada por tipo de falha.

Lê os `.jsonl` de `avaliar_instantes.py` e só aqui junta o gabarito (`avaliacao.json: expected_service`,
corrigido pela causa nas falhas feitas dentro do MariaDB). Por instante e `k ∈ {1, 2, 3}`:

- `estavel`: decidiu com o esperado no Top-k → TP; decidiu sem ele → FP e FN; absteve/falhou → FN;
- `normal`: decidiu → FP; senão TN;
- `transicao`: fora do F1 (relatório à parte).

Validação cruzada deixando um **tipo de falha** de fora (o prefixo `f1`, `h3`, `g4`…): em cada dobra o
`fp_alvo` com maior F1@1 nos outros tipos (empate → menor `fp_alvo`) é aplicado ao tipo de fora; as
contagens das dobras somam. IC 95% por bootstrap **por cenário** (2000 reamostragens, percentil).

Uso:
    replay/metricas_instantes.py [--entrada resultados/instantes] [--saida resumo.md]
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import random
import re
import sys
from collections import defaultdict
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import replay as R  # noqa: E402, N812

KS = (1, 2, 3)
# causa aplicada dentro do MariaDB -> o banco é o culpado.
GABARITO_PELA_CAUSA = {"f3": "teastore-db", "f7": "teastore-db", "f8": "teastore-db"}
# Alvo da injeção quando o cenário não tem `avaliacao.json` (ensaio h1: h2–h6 sem a etapa de incidente).
# Cópia de `lib.sh:_falha_to_service` (HOLDOUT.md / HOLDOUT-2.md, registrados antes da coleta).
ALVO_DO_HARNESS = {"h1": "image", "h5": "image", "h2": "recommender", "h6": "recommender", "h3": "auth",
                   "h4": "db", "g1": "auth", "g2": "persistence", "g3": "image", "g4": "db",
                   "g5": "recommender", "g6": "persistence"}
# Emenda 1 (a): limiar sobre a estatística de decisão, para os modos d com `q` calibrado (não d3, não a0).
LIMIARES = (1e-3, 1e-5, 1e-10, 1e-20, 1e-50, 1e-100, 1e-200)
COM_LIMIAR = {"d1", "d2", "d4", "d1c", "d2c", "d4c", "d6", "d7"}
# Modos novos: parâmetros escolhidos só em desenvolvimento (f, h), teste único nos g.
MODOS_NOVOS = ("d5", "d6", "d7")
LIMIARES_SIMILARIDADE = (0.5, 0.7, 0.9)  # d7
FP_FROUXO = 0.20
N_BOOT = 2000
SEMENTE = 20261013


def tipo_de(falha: str) -> str:
    m = re.match(r"^([fhg]\d+)", falha)
    return m.group(1) if m else falha


def esperado(run_id: str, falha: str) -> str:
    tipo = tipo_de(falha)
    if tipo in GABARITO_PELA_CAUSA:
        return GABARITO_PELA_CAUSA[tipo]
    caminho = os.path.join(R.RESULTADOS, run_id, falha, "avaliacao.json")
    if not os.path.exists(caminho) and tipo in ALVO_DO_HARNESS:
        return f"teastore-{ALVO_DO_HARNESS[tipo]}"
    return R._load(caminho)["expected_service"]


def carregar(entrada: str) -> list[dict[str, Any]]:
    linhas = []
    for arq in sorted(glob.glob(os.path.join(entrada, "*.jsonl"))):
        with open(arq) as f:
            linhas.extend(json.loads(x) for x in f if x.strip())
    cache: dict[tuple[str, str], str] = {}
    for r in linhas:
        chave = (r["run_id"], r["falha"])
        if chave not in cache:
            cache[chave] = esperado(*chave)
        r["esperado"], r["tipo"], r["cenario"] = cache[chave], tipo_de(r["falha"]), f"{r['run_id']}/{r['falha']}"
        sufixo = f"|{r['variante']}" if r.get("variante") else ""
        r["param"] = (f"fp={r['fp_alvo']}" if "fp_alvo" in r else r.get("param", "-")) + sufixo
    linhas = linhas + candidatos_limiar(linhas)
    return [r for r in linhas if r["modo"] != "d7"] + candidatos_similaridade([r for r in linhas if r["modo"] == "d7"])


def candidatos_similaridade(linhas: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """d7: decide se a decisão de base decidiu **e** a similaridade do topo ≥ limiar."""
    saida = []
    for r in linhas:
        sim = r.get("similaridade_topo")
        for lim in LIMIARES_SIMILARIDADE:
            decide = r["status"] == "decidiu" and sim is not None and sim >= lim
            saida.append({**r, "param": f"{r['param']}|s={lim:g}", "status": "decidiu" if decide else "absteve"})
    return saida


def candidatos_limiar(linhas: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Emenda 1 (a): decide se decidiu com o `q` mais frouxo **e** a estatística ≤ limiar; ranking dessa execução."""
    extras = []
    for r in linhas:
        if r["modo"] not in COM_LIMIAR or r.get("fp_alvo") != FP_FROUXO:
            continue
        est = r.get("estatistica")
        for lim in LIMIARES:
            decide = r["status"] == "decidiu" and est is not None and est <= lim
            sufixo = f"|{r['variante']}" if r.get("variante") else ""
            extras.append({**r, "param": f"L={lim:g}{sufixo}", "status": "decidiu" if decide else "absteve"})
    return extras


def contar(linhas: list[dict[str, Any]], k: int) -> dict[str, int]:
    c = {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
    for r in linhas:
        decidiu = r["status"] == "decidiu"
        if r["periodo"] == "estavel":
            if decidiu and r["esperado"] in r["ranking"][:k]:
                c["tp"] += 1
            elif decidiu:
                c["fp"] += 1
                c["fn"] += 1
            else:
                c["fn"] += 1
        elif r["periodo"] == "normal":
            c["fp" if decidiu else "tn"] += 1
    return c


def f1(c: dict[str, int]) -> float:
    den = 2 * c["tp"] + c["fp"] + c["fn"]
    return 2 * c["tp"] / den if den else 0.0


def somar(cs: list[dict[str, int]]) -> dict[str, int]:
    return {k: sum(c[k] for c in cs) for k in ("tp", "fp", "fn", "tn")}


def bootstrap(por_cenario: dict[str, dict[str, int]]) -> tuple[float, float]:
    chaves = sorted(por_cenario)
    if not chaves:
        return (0.0, 0.0)
    rng = random.Random(SEMENTE)
    valores = sorted(f1(somar([por_cenario[rng.choice(chaves)] for _ in chaves])) for _ in range(N_BOOT))
    return valores[int(0.025 * N_BOOT)], valores[int(0.975 * N_BOOT) - 1]


def escolher(cont1: dict[tuple[str, str], dict[str, int]], tipos: list[str], params: list[str]) -> str:
    """Maior F1@1 somando `tipos`; empate → o que alarma menos (menos FP), depois o rótulo."""
    def chave(par: str) -> tuple[float, int, str]:
        c = somar([cont1[(t, par)] for t in tipos if (t, par) in cont1])
        return (f1(c), -c["fp"], par)
    return max(params, key=chave)


def validacao_cruzada(linhas: list[dict[str, Any]]) -> dict[str, Any]:
    """Uma dobra por tipo. Devolve contagens de fora por cenário (para o IC) e o parâmetro de cada dobra."""
    por_tipo_par: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for r in linhas:
        por_tipo_par[(r["tipo"], r["param"])].append(r)
    tipos = sorted({t for t, _ in por_tipo_par})
    params = sorted({p for _, p in por_tipo_par})
    cont1 = {chave: contar(rs, 1) for chave, rs in por_tipo_par.items()}
    escolhas: dict[str, str] = {}
    fora: dict[int, dict[str, dict[str, int]]] = {k: {} for k in KS}
    for tipo in tipos:
        melhor = escolher(cont1, [t for t in tipos if t != tipo], params)
        escolhas[tipo] = melhor
        de_fora = por_tipo_par.get((tipo, melhor), [])
        cenarios = sorted({r["cenario"] for r in de_fora})
        for k in KS:
            for cen in cenarios:
                fora[k][cen] = contar([r for r in de_fora if r["cenario"] == cen], k)
    return {"escolhas": escolhas, "fora": fora}


def _taxas(rs: list[dict[str, Any]]) -> tuple[float, float, float]:
    nor = [r for r in rs if r["periodo"] == "normal"]
    est = [r for r in rs if r["periodo"] == "estavel"]
    alarme = sum(r["status"] == "decidiu" for r in nor) / len(nor) if nor else float("nan")
    decide = sum(r["status"] == "decidiu" for r in est) / len(est) if est else float("nan")
    acertos = sum(r["status"] == "decidiu" and r["ranking"][:1] == [r["esperado"]] for r in est)
    acerto = acertos / len(est) if est else float("nan")
    return alarme, decide, acerto


def dev_e_teste(rm: list[dict[str, Any]]) -> dict[str, Any]:
    """Parâmetro escolhido no desenvolvimento (tipos f, h); medido uma vez nos g."""
    dev = [r for r in rm if not r["tipo"].startswith("g")]
    teste = [r for r in rm if r["tipo"].startswith("g")]
    por_par: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for r in dev:
        por_par[(r["tipo"], r["param"])].append(r)
    if not por_par:
        return {}
    escolhido = escolher({k: contar(v, 1) for k, v in por_par.items()}, sorted({r["tipo"] for r in dev}),
                         sorted({r["param"] for r in dev}))
    cv_dev = validacao_cruzada(dev)
    sel = [r for r in teste if r["param"] == escolhido]
    por_cen: dict[int, dict[str, dict[str, int]]] = {k: {} for k in KS}
    for cen in sorted({r["cenario"] for r in sel}):
        for k in KS:
            por_cen[k][cen] = contar([r for r in sel if r["cenario"] == cen], k)
    return {"param": escolhido, "f1_dev_cv": f1(somar(list(cv_dev["fora"][1].values()))),
            "f1_teste": {k: f1(somar(list(por_cen[k].values()))) for k in KS},
            "ic_teste": bootstrap(por_cen[1]), "taxas_teste": _taxas(sel), "n_cenarios_teste": len(por_cen[1]),
            "acerto_por_cenario": {cen: c["tp"] for cen, c in por_cen[1].items()}}


def relatorio_novos(linhas: list[dict[str, Any]]) -> list[str]:
    out = ["", "## Modos novos (PREREG-D5-D7.md): parâmetro do desenvolvimento, teste único nos g", "",
           "| modo | parâmetro (escolhido em f+h) | F1@1 dev (CV) | F1@1 g | IC | F1@2 g | F1@3 g | alarme normais g "
           "| decide estáveis g | acerto@1 g |",
           "|---|---|---|---|---|---|---|---|---|---|"]
    res = {}
    for modo in (*MODOS_NOVOS, "d2c"):
        rm = [r for r in linhas if r["modo"] == modo]
        if not rm:
            continue
        r = res[modo] = dev_e_teste(rm)
        if not r:
            continue
        a, d, c = r["taxas_teste"]
        out.append(f"| {modo}{' (referência)' if modo == 'd2c' else ''} | {r['param']} | {r['f1_dev_cv']:.3f} | "
                   f"{r['f1_teste'][1]:.3f} | {r['ic_teste'][0]:.3f}–{r['ic_teste'][1]:.3f} | {r['f1_teste'][2]:.3f} | "
                   f"{r['f1_teste'][3]:.3f} | {a:.0%} | {d:.0%} | {c:.0%} |")
    out += ["", "Hipóteses (PREREG-D5-D7.md §4):", ""]
    if res.get("d5"):
        a, d, _ = res["d5"]["taxas_teste"]
        out.append(f"- **H4 (d5)**: alarme nos normais g = {a:.1%} (≤ 5%?) e decide em {d:.1%} dos estáveis g "
                   f"(≥ 50%?) → {'confirmada' if a <= 0.05 and d >= 0.5 else 'não confirmada'}")
    for h, modo in (("H5", "d6"), ("H6", "d7")):
        if res.get(modo) and res.get("d2c"):
            x, y = res[modo]["f1_teste"][1], res["d2c"]["f1_teste"][1]
            ganha = sum(1 for cen, tp in res[modo]["acerto_por_cenario"].items()
                        if tp > res["d2c"]["acerto_por_cenario"].get(cen, 0))
            perde = sum(1 for cen, tp in res[modo]["acerto_por_cenario"].items()
                        if tp < res["d2c"]["acerto_por_cenario"].get(cen, 0))
            out.append(f"- **{h} ({modo})**: F1@1 g {x:.3f} vs d2c {y:.3f} → "
                       f"{'confirmada' if x >= y else 'não confirmada'}; cenários com mais acertos: {modo} {ganha}, "
                       f"d2c {perde}")
        elif modo in MODOS_NOVOS:
            out.append(f"- **{h} ({modo})**: sem dados — não testada")
    return out


def relatorio(linhas: list[dict[str, Any]]) -> str:
    novos = [r for r in linhas if r["modo"] in MODOS_NOVOS]
    linhas = [r for r in linhas if r["modo"] not in MODOS_NOVOS]
    modos = sorted({r["modo"] for r in linhas})
    cenarios = sorted({r["cenario"] for r in linhas})
    tipos = sorted({r["tipo"] for r in linhas})
    out = ["# Stage 3 isolado — F1 por instante", "",
           f"{len(cenarios)} cenários, {len(tipos)} tipos de falha. Validação cruzada deixando um tipo de fora; "
           "IC 95% bootstrap por cenário.", "",
           "| modo | F1@1 (CV) | IC | F1@2 (CV) | F1@3 (CV) | alarme nos normais | acerto@1 sob falha "
           "| parâmetro final |",
           "|---|---|---|---|---|---|---|---|"]
    detalhes = []
    for modo in modos:
        rm = [r for r in linhas if r["modo"] == modo]
        cv = validacao_cruzada(rm)
        f1s = {k: f1(somar(list(cv["fora"][k].values()))) for k in KS}
        ic = bootstrap(cv["fora"][1])
        # taxas lidas das linhas com o fp escolhido em cada dobra
        sel = [r for r in rm if r["param"] == cv["escolhas"][r["tipo"]]]
        n_nor = [r for r in sel if r["periodo"] == "normal"]
        n_est = [r for r in sel if r["periodo"] == "estavel"]
        alarme = sum(r["status"] == "decidiu" for r in n_nor) / len(n_nor) if n_nor else float("nan")
        acerto = (sum(r["status"] == "decidiu" and r["ranking"][:1] == [r["esperado"]] for r in n_est) / len(n_est)
                  if n_est else float("nan"))
        por_par: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        for r in rm:
            por_par[(r["tipo"], r["param"])].append(r)
        final = escolher({k: contar(v, 1) for k, v in por_par.items()}, sorted({r["tipo"] for r in rm}),
                         sorted({r["param"] for r in rm}))
        out.append(f"| {modo} | {f1s[1]:.3f} | {ic[0]:.3f}–{ic[1]:.3f} | {f1s[2]:.3f} | {f1s[3]:.3f} | "
                   f"{alarme:.0%} | {acerto:.0%} | {final} |")
        dobras = ", ".join(f"{t}={fp}" for t, fp in sorted(cv["escolhas"].items()))
        detalhes.append(f"- {modo}: parâmetro por dobra {dobras}")
    return "\n".join(out + ["", "## Escolhas por dobra", "", *detalhes]
                     + relatorio_novos(novos + [r for r in linhas if r["modo"] == "d2c"])) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--entrada", default=os.path.join(R.RESULTADOS, "instantes"))
    ap.add_argument("--saida", help="grava o resumo em Markdown aqui (padrão: só stdout)")
    args = ap.parse_args()
    texto = relatorio(carregar(args.entrada))
    print(texto)
    if args.saida:
        with open(args.saida, "w") as f:
            f.write(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
