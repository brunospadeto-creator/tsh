#!/usr/bin/env python3
"""Paridade das soluções definitivas: d9-k e v-cons-b do produto × a avaliação offline.

Roda `vconsb_consenso.ConsensoVConsB` (que chama a `d9k_portao_grafo_k8s`, a a0-b e a d6) instante a instante,
com a mesma entrada do avaliador unificado (60 s, referência pré-falha deslocada nos estáveis, eventos K8s
limpos da Fase 0, `url.path` para a a0-b) e os mesmos instantes da base limpa (D0.4 fora). Um objeto por
período, como a persistência da análise. Grava `protocolo-consenso/solucoes/<run>__<falha>.jsonl.gz` com os
modos `d9-k-prod` e `v-cons-b-prod`; `--comparar` lê os registros e compara com `consenso.py`/`a0b_analise.py`.

Uso: replay/paridade_solucoes.py [--jobs 8] [--comparar]
"""
from __future__ import annotations

import argparse
import datetime
import gzip
import json
import os
import sys
import time

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import protocolo_rapido as PR  # noqa: E402, N812

from src.application.stage3.abordagens import vconsb_consenso as vc  # noqa: E402
from src.application.stage3.abordagens.base import EntradaIncidente  # noqa: E402

SAIDA = os.path.join(PR.R.RESULTADOS, "protocolo-consenso", "solucoes")
PASSO = 60
MIN_TRACES = 30   # D0.4


def _fora() -> set[tuple[str, str]]:
    with open(os.path.join(PR.R.RESULTADOS, "protocolo-consenso", "higiene.json")) as f:
        return {(c, t) for c, t in json.load(f)["poucos_traces"]}


def rodar_caso(job: str | tuple[str, str, bool]) -> str:
    """`job` = caso, ou `(caso, pasta de saída, confirmatório)`. No confirmatório a D0.4 é aplicada aqui (< 30
    traces na janela) em vez de vir do `higiene.json`, e a d9 (pai) é gravada junto como referência."""
    import a0b_insumos as A0BI  # noqa: N812, PLC0415
    from src.application.stage3.abordagens import d9_portao_grafo as d9  # noqa: PLC0415
    case_dir, saida, confirmatorio = (job, SAIDA, False) if isinstance(job, str) else job
    AI, AF = PR.AI, PR.AF  # noqa: N806
    run_id, falha = os.path.basename(os.path.dirname(case_dir)), os.path.basename(case_dir)
    destino = os.path.join(saida, f"{run_id}__{falha}.jsonl.gz")
    if os.path.exists(destino):
        return f"{run_id}/{falha}: já feito"
    per = AI.periodos(case_dir)
    if not per:
        return f"{run_id}/{falha}: sem referência ou pacotes -- fora"
    t0 = time.monotonic()
    fora = set() if confirmatorio else _fora()
    colecao = PR.R._load(os.path.join(os.path.dirname(case_dir), "manifest.json"))["collection_id"]
    artefato = {"a0-b": A0BI.artefato(colecao[:8]), "d6": PR._artefato_fp(colecao, "d2c")}
    eventos = A0BI.eventos_do_caso(case_dir)
    k8s = PR._k8s_limpo(AF._k8s_dicts(case_dir), per["normal"][0])
    fim_normal = per["normal"][1]
    pre_falha = AI._sem_bolha(eventos, (fim_normal - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), fim_normal))
    pre_k8s = AF._visao_em(k8s, fim_normal)
    cfg = {"entry_services": PR.P.ENTRY_SERVICES}
    linhas, consenso, periodo_atual = [], None, None
    for periodo, t in AI.instantes({k: v for k, v in per.items() if k != "transicao"}, PASSO):
        if periodo != periodo_atual:
            consenso, periodo_atual = vc.ConsensoVConsB(artefato, cfg), periodo
        if (f"{run_id}/{falha}", t.isoformat()) in fora:
            continue
        janela = (t - datetime.timedelta(seconds=AI.JANELA_SEG), t)
        dentro = AI._sem_bolha(eventos, janela)
        if confirmatorio and len({e.case_id for e in dentro}) < MIN_TRACES:
            continue
        if periodo == "estavel":
            delta = janela[0] - fim_normal
            lookback = AF._deslocar_traces(pre_falha, int(delta.total_seconds() * 1e6))
            k8s_todos = AF._iso(pre_k8s, delta) + AF._iso(AF._a_partir_de(AF._visao_em(k8s, t), janela[0]))
        else:
            lookback = AI._sem_bolha(eventos, (janela[0] - datetime.timedelta(seconds=PR.LOOKBACK_UNIF), janela[0]))
            k8s_todos = AF._iso(AF._visao_em(k8s, t))
        entrada = EntradaIncidente(
            incidente_id=f"instante-{t.isoformat()}", janela=janela, abertura_incidente=t,
            traces=dentro, traces_lookback=lookback, metricas={}, eventos_k8s=k8s_todos,
            config_sistema={"entry_services": PR.P.ENTRY_SERVICES})
        d = consenso.decidir(entrada)
        if confirmatorio:
            cfg_d9 = {**cfg, **PR.PORTAO_D9}
            g9 = PR._decidir(d9, entrada, {}, cfg_d9)
            f9 = g9["ranking"] if g9["status"] == "decidiu" and g9["ranking"] else \
                PR._decidir(d9, entrada, {}, {**cfg_d9, **PR.PERMISSIVO_D5})["ranking"]
            linhas.append(json.dumps({"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat(),
                                      "modo": "d9", "status": g9["status"], "ranking": g9["ranking"],
                                      "forcado": f9}))
        ev = d.evidencias
        base = {"run_id": run_id, "falha": falha, "periodo": periodo, "t": t.isoformat()}
        aberto = bool(ev.get("portao_d9k"))
        linhas.append(json.dumps({**base, "modo": "d9-k-prod", "status": "decidiu" if aberto else "absteve",
                                  "ranking": (ev.get("votos") or {}).get("d9-k", []) if aberto else [],
                                  "forcado": (ev.get("votos") or {}).get("d9-k", []),
                                  "k8s_sintoma": ev.get("k8s_sintoma")}))
        linhas.append(json.dumps({**base, "modo": "v-cons-b-prod", "status": d.status,
                                  "ranking": [i.servico for i in d.ranking], "forcado": ev.get("ranking_forcado", []),
                                  "margem": ev.get("margem"), "confianca": ev.get("confianca"),
                                  "votos": ev.get("votos"), "falhas": ev.get("falhas")}))
        if confirmatorio:   # disparo único (produto: um job por incidente, sem histórico) = n 1 nos dois níveis
            brutos = {**(ev.get("votos") or {}), "a0-b": ev.get("a0b_bruto") or []}
            v1 = vc.votar(brutos, None, ev.get("k8s_sintoma"), {**vc._cfg({}), "n_persistencia": 1})
            linhas.append(json.dumps({**base, "modo": "v-cons-b-1", "status": d.status,
                                      "ranking": v1["ordem"] if aberto else [], "forcado": v1["ordem"]}))
    os.makedirs(saida, exist_ok=True)
    with gzip.open(destino + ".tmp", "wt") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(destino + ".tmp", destino)
    return f"{run_id}/{falha}: {len(linhas)} linhas em {time.monotonic() - t0:.0f}s"


def comparar() -> int:
    import a0b_analise as AB  # noqa: N812, PLC0415
    import consenso as C  # noqa: N812, PLC0415
    import protocolo_rapido_analise as A  # noqa: N812, PLC0415
    inv = A._inv()
    rs, fora = C.base(inv)
    rs += [r for r in C._novos(inv, os.path.join(C.SAIDA, "limpo-a0b"), "*.jsonl.gz")
           if (r["cenario"], r["t"]) not in fora]
    serie = C._series(rs)
    d9k = C.variante_persistente(serie, "d9-k", 1, "d9-k", True)
    a0bp = C.variante_persistente(serie, "a0-b", 5, "a0-b-p")
    s2 = dict(serie)
    s2.update(C._series(d9k))
    s2.update(C._series(a0bp))
    dev = {inv[c]["tipo"] for c in inv if inv[c]["grupo"] != "g"}
    vs = ["d9-k", "a0-b-p", "d6"]
    sr = {m: [r for (mm, _c, _p), lst in s2.items() if mm == m for r in lst] for m in vs}
    vcb = C.votar(s2, inv, vs, 5, C._pesos_conf(sr, inv, vs, dev), d9k, "v-cons-b")
    prod = [r for r in C._novos(inv, SAIDA, "*.jsonl.gz") if (r["cenario"], r["t"]) not in fora]
    por = {m: {(r["cenario"], r["periodo"], r["t"]): r for r in v}
           for m, v in (("d9-k", d9k), ("v-cons-b", vcb),
                        ("d9-k-prod", [r for r in prod if r["modo"] == "d9-k-prod"]),
                        ("v-cons-b-prod", [r for r in prod if r["modo"] == "v-cons-b-prod"]))}
    out = ["# Paridade das soluções definitivas (produto × avaliação offline)", "",
           "| modo | instantes | mesmo portão | mesmo 1º forçado | mesmo top-3 forçado |", "|---|---|---|---|---|"]
    divergentes = []
    for m in ("d9-k", "v-cons-b"):
        a, b = por[m], por[m + "-prod"]
        ch = sorted(set(a) & set(b))
        g = sum(a[k]["decidiu"] == b[k]["decidiu"] for k in ch)
        p1 = sum(a[k]["forcado"][:1] == b[k]["forcado"][:1] for k in ch)
        p3 = sum(a[k]["forcado"][:3] == b[k]["forcado"][:3] for k in ch)
        divergentes += [(m, k, a[k]["forcado"], b[k]["forcado"]) for k in ch
                        if a[k]["forcado"][:1] != b[k]["forcado"][:1]]
        out.append(f"| {m} | {len(ch)} (offline {len(a)}, produto {len(b)}) | {g / len(ch):.1%} | {p1 / len(ch):.1%} | "
                   f"{p3 / len(ch):.1%} |")
    out += ["", "## Métricas recalculadas com os registros do produto", "",
            "| modo | F1@1 | F1@2 | F1@3 | sabendo top-1 | top-2 | top-3 | alarme | F1@1 dev | sabendo dev | "
            "F1@1 g | sabendo g | f | h |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    out += [AB._linha(m, list(por[m].values()), inv) for m in ("d9-k", "d9-k-prod", "v-cons-b", "v-cons-b-prod")]
    out += ["", f"Instantes com 1º forçado divergente: {len(divergentes)}", ""]
    out += [f"- {m} {k[0]} {k[1]} {k[2]}: offline {x} × produto {y}" for m, k, x, y in divergentes[:40]]
    texto = "\n".join(out) + "\n"
    with open(os.path.join(C.SAIDA, "paridade-solucoes.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("--falhas", default="")
    ap.add_argument("--comparar", action="store_true")
    args = ap.parse_args()
    if args.comparar:
        return comparar()
    from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
    alvo = [c for c in PR.casos() if not args.falhas or os.path.basename(c) in args.falhas.split(",")]
    with ProcessPoolExecutor(args.jobs) as ex:
        for msg in ex.map(rodar_caso, alvo):
            print(msg, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
