#!/usr/bin/env python3
"""Replay offline do Stage 3 sobre rodadas salvas do lote F1-F14.

Roda o `_run_pipeline` REAL do Stage 3 (mesmo código do job-runner) contra os insumos gravados em
`resultados/<RUN_ID>/<falha>/`, sem cluster, sem stresser e sem reinjetar falha:

- traces: `traces_full_scenario.json` (+ `traces_stage3_window.json`, quando existe) servidos por um
  Jaeger falso que responde `services()`/`traces(service, start, end, limit)` como o de verdade;
- baseline: `resultados/insumos/baseline-<coleção>.json` (exportado por `export_insumos.py`) ou o
  `baseline.json` da própria rodada;
- métricas por pod: `monitoring_logs.json` da rodada (exportado) ou, nas rodadas antigas,
  reconstruídas dos `evidence_packages/pkg-*.json`;
- eventos K8s: `k8s_events_cluster.json` (dump bruto do namespace, filtrado pela janela de eventos
  do Stage 3 com a mesma regra de sobreposição do `K8sClient`) ou os gravados no pacote de
  auditoria (rodadas antigas não têm; `--as-recorded` sempre usa os do pacote);
- incidente e θ: `stage3_audit_package.json` / `incident.json`.

Uso (do diretório `experimento-falhas/teastore/stage3-online/`, com pm4py instalado):

    python3 replay/replay.py                         # todas as rodadas completas, config atual
    python3 replay/replay.py --runs 20260923T010018Z --set vote_weights.metrica=0
    python3 replay/replay.py --legacy                # sem votos
    python3 replay/replay.py --as-recorded           # θ gravado no pacote: confere fidelidade com o ao vivo
    python3 replay/replay.py --config minha-regra.json --label teste-x

Saída em `resultados/replay/<timestamp>-<label>/`: `resumo.json`, `resumo.md` e um JSON por caso.
"""

import argparse
import datetime
import glob
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from types import SimpleNamespace
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(SELF_DIR)
REPO_ROOT = os.path.abspath(os.path.join(BASE_DIR, "../../.."))
RESULTADOS = os.path.join(BASE_DIR, "resultados")
sys.path.insert(0, REPO_ROOT)

from src.application.stage3.config import DEFAULT_VOTE_WEIGHTS, resolve_config  # noqa: E402
from src.application.stage3.tasks import _Run, _run_pipeline, _stage3_section  # noqa: E402
from src.application.stage3.votes import health_events_window  # noqa: E402
from src.monitor.tasks import metrics_by_entity_json  # noqa: E402


def _dt(value: str | None) -> datetime.datetime | None:
    if not value:
        return None
    parsed = datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return parsed.astimezone(datetime.UTC).replace(tzinfo=None) if parsed.tzinfo else parsed


def _load(path: str) -> Any:
    with open(path) as f:
        return json.load(f)


# ── fakes ────────────────────────────────────────────────────────────


class DumpJaeger:
    """Jaeger falso sobre os traces brutos gravados (mesmo formato de `/api/traces`)."""

    def __init__(self, traces: dict[str, dict[str, Any]], services: list[str]):
        self._traces = traces
        self._services = services
        self._by_service: dict[str, list[tuple[int, str]]] = {}
        for tid, trace in traces.items():
            procs = trace.get("processes") or {}
            first: dict[str, int] = {}
            for span in trace.get("spans") or []:
                svc = str((procs.get(span.get("processID")) or {}).get("serviceName") or "")
                start = int(span.get("startTime") or 0)
                first[svc] = min(first.get(svc, start), start)
            for svc, start in first.items():
                self._by_service.setdefault(svc, []).append((start, tid))

    def services(self) -> list[str]:
        return list(self._services)

    def traces(self, service: str, start_us: int, end_us: int, limit: int) -> list[dict[str, Any]]:
        hits = sorted(((s, t) for s, t in self._by_service.get(service, []) if start_us <= s <= end_us), reverse=True)
        return [self._traces[t] for _, t in hits[:limit]]


class ReplayRepo:
    """Só o que `_run_pipeline` consulta: baseline, logs anteriores e config de LLM (mock)."""

    def __init__(self, baseline: dict[str, Any], previous_logs: list[Any],
                 referencia: dict[str, Any] | None = None):
        self._baseline = self._ns(baseline)
        # Janela de referência do cenário (Etapa F do plano-traces): servida quando o Stage 3 pede a coleção
        # dela (`incident.referencia_collection_id`); sem isto o replay do modo "anomalias" ignorava a referência.
        self._ref_id = (referencia or {}).get("referencia_collection_id")
        self._referencia = self._ns({"baseline_id": self._ref_id, **(referencia or {})}) if referencia else None
        self._previous = previous_logs

    @staticmethod
    def _ns(baseline: dict[str, Any]) -> SimpleNamespace:
        return SimpleNamespace(
            baseline_id=baseline.get("baseline_id"), status="completed", n_samples=baseline.get("n_samples"),
            computed_at=_dt(baseline.get("computed_at")), metric_stats=baseline.get("metric_stats") or {},
            process_models=baseline.get("process_models") or {}, span_stats=baseline.get("span_stats") or {},
            service_graph=baseline.get("service_graph") or {}, service_stats=baseline.get("service_stats") or {},
        )

    def get_collection_baseline(self, collection_id: str) -> Any:
        if self._referencia is not None and collection_id == self._ref_id:
            return self._referencia
        return self._baseline

    def list_monitoring_logs_before(self, *args: Any, **kwargs: Any) -> list[Any]:
        return list(self._previous)

    def get_llm_config(self) -> dict[str, Any]:
        return {}


def _log_ns(row: dict[str, Any]) -> SimpleNamespace:
    return SimpleNamespace(**{**row, "window_start": _dt(row.get("window_start")),
                              "collected_at": _dt(row.get("collected_at"))})


def _logs_from_packages(case_dir: str) -> list[SimpleNamespace]:
    logs = []
    for path in sorted(glob.glob(os.path.join(case_dir, "evidence_packages", "pkg-*.json"))):
        pkg = _load(path)
        logs.append(SimpleNamespace(
            log_id=os.path.basename(path), run_id="replay", collection_id=None,
            window_start=_dt(pkg.get("window_start")), collected_at=_dt(pkg.get("window_end")),
            metrics_by_entity_json=metrics_by_entity_json(pkg.get("metrics_by_entity") or {}),
        ))
    return logs


def _events_from_cluster_dump(path: str, window: tuple[datetime.datetime, datetime.datetime]) -> list[dict[str, Any]]:
    """`kubectl get events -o json` -> formato do coletor, com sobreposição [first, last] x janela."""
    out = []
    for item in _load(path).get("items") or []:
        last = _dt(item.get("lastTimestamp") or item.get("eventTime") or item["metadata"].get("creationTimestamp"))
        first = _dt(item.get("firstTimestamp")) or last
        if last is None or last < window[0] or first > window[1]:
            continue
        obj = item.get("involvedObject") or {}
        out.append({
            "ts": item.get("lastTimestamp") or "", "kind": "Pod", "reason": str(item.get("reason") or "Unknown"),
            "res": str(obj.get("name") or "") if obj.get("kind") == "Pod" else "",
            "msg": str(item.get("message") or ""), "count": int(item.get("count") or 1),
        })
    return out


# ── casos ────────────────────────────────────────────────────────────


# Critérios criados depois de um lote: o θ gravado não os tem, e sem isto o default atual os ligaria
# no `--as-recorded`. Valor = comportamento de antes de existirem.
# Abstenções da síntese: a localização já foi publicada, então o ranking vale como resposta.
LLM_ABSTAIN_REASONS = {"invalid_llm_output", "llm_abstained"}

_ABSENT_WHEN_RECORDED: dict[str, Any] = {"discovery_min_bucket_share": 0.0, "missing_min_trace_share": 0.0}


def _baseline_for(run_dir: str, collection_id: str) -> dict[str, Any] | None:
    # --baseline (via env, para chegar aos processos do --jobs): diagnostica contra outra baseline
    forced = os.environ.get("REPLAY_BASELINE")
    for path in ((forced,) if forced else (
            os.path.join(run_dir, "baseline.json"),
            os.path.join(RESULTADOS, "insumos", f"baseline-{collection_id[:8]}.json"))):
        if os.path.exists(path):
            return _load(path)
    return None


def _set_path(cfg: dict[str, Any], dotted: str, raw: str) -> None:
    try:
        value: Any = json.loads(raw)
    except json.JSONDecodeError:
        value = raw
    keys = dotted.split(".")
    node = cfg
    for key in keys[:-1]:
        node = node.setdefault(key, {})
    node[keys[-1]] = value


def replay_case(
    case_dir: str, overrides: dict[str, Any], legacy: bool, as_recorded: bool = False
) -> dict[str, Any]:
    run_dir = os.path.dirname(case_dir)
    manifest = _load(os.path.join(run_dir, "manifest.json"))
    audit = _load(os.path.join(case_dir, "stage3_audit_package.json"))
    evaluation = _load(os.path.join(case_dir, "avaliacao.json"))
    s3 = audit["stage3"]
    baseline = _baseline_for(run_dir, manifest["collection_id"])
    if baseline is None:
        raise SystemExit(f"sem baseline exportada para {manifest['collection_id']} (rode export_insumos.py)")

    # Padrão: config do sistema + defaults do código ATUAL (é o que se quer avaliar). O θ gravado no
    # pacote congela todos os valores da época -- inclusive pesos de voto --, então só vale para
    # conferir fidelidade com a execução ao vivo (`--as-recorded`).
    params = {**_ABSENT_WHEN_RECORDED, **(s3.get("parameters") or {})} if as_recorded else {}
    if as_recorded and "vote_weights" in params:  # voto criado depois do lote: peso 0, não o default atual
        params["vote_weights"] = {**{k: 0.0 for k in DEFAULT_VOTE_WEIGHTS}, **params["vote_weights"]}
    system_cfg = dict((baseline.get("system") or {}).get("stage3_config") or {})
    cfg_raw = {**system_cfg, **params, **overrides}
    if legacy:
        cfg_raw["localization_votes"] = False
    cfg = resolve_config(cfg_raw)

    traces: dict[str, Any] = {}
    for name in ("traces_full_scenario.json", "traces_stage3_window.json"):
        path = os.path.join(case_dir, name)
        if os.path.exists(path):
            traces.update(_load(path).get("traces") or {})
    services = sorted({
        str(p.get("serviceName")) for t in traces.values() for p in (t.get("processes") or {}).values()
    } | set(((s3.get("traces") or {}).get("query") or {}).get("services") or []) | set(cfg.excluded_services))

    inc = audit["incident"]
    referencia = _load(os.path.join(case_dir, "referencia", "referencia.json")) \
        if os.path.exists(os.path.join(case_dir, "referencia", "referencia.json")) else None
    incident = SimpleNamespace(
        incident_id=inc["incident_id"], system_id=inc["system_id"], hypothesis="incidente",
        window_start=_dt(inc["window_start"]), window_end=_dt(inc["window_end"]),
        created_at=_dt(inc.get("opened_at")), profile_id=None,
        referencia_collection_id=(referencia or {}).get("referencia_collection_id"),
    )
    exported = os.path.join(case_dir, "monitoring_logs.json")
    if os.path.exists(exported):
        data = _load(exported)
        logs = [_log_ns(r) for r in data.get("logs") or []]
        previous = [_log_ns(r) for r in data.get("previous_logs") or []]
    else:
        logs, previous = _logs_from_packages(case_dir), []
    cluster_dump = os.path.join(case_dir, "k8s_events_cluster.json")
    if os.path.exists(cluster_dump) and not as_recorded:
        events = _events_from_cluster_dump(cluster_dump, health_events_window(
            incident.window_start, incident.window_end, cfg.k8s_event_lookback_sec, cfg.trace_settle_seconds,
        ))
    else:  # os que o Stage 3 buscou na execução original (gravados no pacote de auditoria)
        events = (s3.get("localization") or {}).get("k8s_events") or []

    system = SimpleNamespace(name=(baseline.get("system") or {}).get("name", "teastore"),
                             stage3_config=cfg_raw, system_id=inc["system_id"])
    run = _Run(incident=incident, system=system, cfg=cfg, logs=logs,
               collection_id=manifest["collection_id"], started_at=datetime.datetime.now())
    t0 = time.monotonic()
    abstain = _run_pipeline(run, ReplayRepo(baseline, previous, referencia), DumpJaeger(traces, services), None,
                            lambda system, start, end: list(events))
    elapsed = time.monotonic() - t0
    section = _stage3_section(run, "abstained" if abstain else "completed", abstain)

    expected = evaluation["expected_service"]
    ranking = [c.pod_name for c in run.candidates]
    # Abstenção antes da síntese = o Stage 3 não publicou suspeito. O ranking fica gravado para
    # inspeção, mas não pontua: F4/F14 contavam como Top-2 com o sistema tendo dito "não sei".
    respondeu = not abstain or abstain in LLM_ABSTAIN_REASONS
    rank = ranking.index(expected) + 1 if respondeu and expected in ranking else None
    original = [s.get("service") for s in (s3.get("localization") or {}).get("suspects") or []]
    return {
        "run_id": os.path.basename(run_dir), "falha": os.path.basename(case_dir), "expected": expected,
        "ranking": ranking, "respondeu": respondeu,
        "rank": rank, "top1": rank == 1, "top2": rank is not None and rank <= 2,
        "top3": rank is not None and rank <= 3, "rr": 1.0 / rank if rank else 0.0,
        "status": section["status"], "abstain_reason": abstain,
        "localizacao_abstain_reason": run.localizacao_abstain_reason,
        "votes": section["localization"].get("votes"), "original_ranking": original,
        "same_as_original": ranking == original, "seconds": round(elapsed, 2),
        "trace_signals": section["localization"].get("trace_signals"),
    }


def _safe_replay(job: tuple[str, dict[str, Any], bool, bool]) -> dict[str, Any]:
    case = job[0]
    try:
        return replay_case(*job)
    except Exception as exc:  # um caso quebrado não derruba o replay inteiro
        return {"run_id": os.path.basename(os.path.dirname(case)), "falha": os.path.basename(case),
                "expected": "?", "ranking": [], "respondeu": False, "rank": None,
                "top1": False, "top2": False, "top3": False, "rr": 0.0, "status": "erro",
                "abstain_reason": f"{type(exc).__name__}: {exc}", "votes": []}


def discover_cases(runs: list[str] | None) -> list[str]:
    cases = []
    for run_dir in sorted(glob.glob(os.path.join(RESULTADOS, "2*"))):
        if runs and os.path.basename(run_dir) not in runs:
            continue
        if not os.path.exists(os.path.join(run_dir, "manifest.json")):
            continue
        for case in sorted(glob.glob(os.path.join(run_dir, "[fhg][0-9]*"))):
            needed = ("stage3_audit_package.json", "avaliacao.json", "traces_full_scenario.json")
            if all(os.path.exists(os.path.join(case, n)) for n in needed):
                cases.append(case)
    return cases


def calibration_runs() -> set[str]:
    """Rodadas de calibração (`particao.json`); as demais são de teste."""
    path = os.path.join(SELF_DIR, "particao.json")
    return set(_load(path).get("calibracao") or []) if os.path.exists(path) else set()


def _metrics_line(rows: list[dict[str, Any]]) -> str:
    n = len(rows)
    if not n:
        return "sem casos"
    t1, t2, t3 = (sum(r[k] for r in rows) for k in ("top1", "top2", "top3"))
    mrr = sum(r["rr"] for r in rows) / n
    answered = [r for r in rows if r.get("respondeu", True)]
    na = len(answered)
    line = (f"Top-1 {t1}/{n} ({t1 / n:.0%}) · Top-2 {t2}/{n} ({t2 / n:.0%}) · Top-3 {t3}/{n} ({t3 / n:.0%}) · "
            f"MRR {mrr:.3f} · abstenções {n - na}/{n} ({(n - na) / n:.0%})")
    if na < n:
        a1, a2, a3 = (sum(r[k] for r in answered) for k in ("top1", "top2", "top3"))
        line += (f" · só respondidos: Top-1 {a1}/{na} ({a1 / na:.0%}), Top-2 {a2}/{na} ({a2 / na:.0%}), "
                 f"Top-3 {a3}/{na} ({a3 / na:.0%})" if na else " · nenhum respondido")
    return line


def _summary_md(label: str, rows: list[dict[str, Any]], cfg_overrides: dict[str, Any], legacy: bool) -> str:
    n = len(rows)
    calib = calibration_runs()
    test_rows = [r for r in rows if r["run_id"] not in calib]
    lines = [
        f"# Replay Stage 3 — {label}", "",
        f"- Casos: {n} | legado (sem votos): {legacy} | overrides: `{json.dumps(cfg_overrides, ensure_ascii=False)}`",
        f"- **Todos: {_metrics_line(rows)}**",
        f"- Calibração ({len(rows) - len(test_rows)}): {_metrics_line([r for r in rows if r['run_id'] in calib])}",
        f"- **Teste ({len(test_rows)}): {_metrics_line(test_rows)}** — só este vale como avaliação "
        "(`replay/particao.json`)", "",
        "| falha | rodada | esperado | posição | ranking | votos do esperado | status |",
        "|---|---|---|---|---|---|---|",
    ]
    for r in sorted(rows, key=lambda r: (int(r["falha"].split("-")[0][1:]), r["run_id"])):
        votes = next((v for v in r["votes"] or [] if v["entity"] == r["expected"]), None)
        vnames = "+".join(x["name"] for x in votes["votes"]) if votes else "—"
        rank = r["rank"] or ("absteve" if not r.get("respondeu", True) else "—")
        short = [s.replace("teastore-", "") for s in r["ranking"]]
        status = r["status"] + (f" ({r['abstain_reason']})" if r["abstain_reason"] else "")
        lines.append(f"| {r['falha']} | {r['run_id'][-7:]} | {r['expected'].replace('teastore-', '')} | {rank} | "
                     f"{', '.join(short)} | {vnames} | {status} |")
    by_fault: dict[str, list[dict[str, Any]]] = {}
    for r in rows:
        by_fault.setdefault(r["falha"], []).append(r)
    lines += ["", "## Por falha (todos os casos; abstenção conta como erro)", "",
              "| falha | Top-1 | Top-2 | Top-3 | abstenções |", "|---|---|---|---|---|"]
    for falha in sorted(by_fault, key=lambda f: int(f.split("-")[0][1:])):
        rs = by_fault[falha]
        n = len(rs)
        lines.append(f"| {falha} | {sum(r['top1'] for r in rs)}/{n} | {sum(r['top2'] for r in rs)}/{n} | "
                     f"{sum(r['top3'] for r in rs)}/{n} | {sum(not r.get('respondeu', True) for r in rs)}/{n} |")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--runs", help="RUN_IDs separados por vírgula (padrão: todas as rodadas com manifest)")
    parser.add_argument("--falhas", help="falhas separadas por vírgula (ex.: f7-pool-contention)")
    parser.add_argument("--config", help="JSON com overrides do stage3_config")
    parser.add_argument("--set", action="append", default=[], help="override pontual chave=valor (aceita a.b=v)")
    parser.add_argument("--legacy", action="store_true", help="desliga os votos (comportamento anterior)")
    parser.add_argument("--as-recorded", action="store_true",
                        help="usa o θ gravado no pacote de auditoria (fidelidade com a execução ao vivo)")
    parser.add_argument("--jobs", type=int, default=1, help="casos em paralelo (processos)")
    parser.add_argument("--label", default="")
    parser.add_argument("--out", default=os.path.join(RESULTADOS, "replay"))
    parser.add_argument("--baseline", help="baseline exportada (export_insumos.py) no lugar da gravada na rodada")
    args = parser.parse_args()
    if args.baseline:
        os.environ["REPLAY_BASELINE"] = os.path.abspath(args.baseline)

    overrides: dict[str, Any] = _load(args.config) if args.config else {}
    for item in args.set:
        key, _, value = item.partition("=")
        _set_path(overrides, key, value)
    cases = discover_cases(args.runs.split(",") if args.runs else None)
    if args.falhas:
        wanted = set(args.falhas.split(","))
        cases = [c for c in cases if os.path.basename(c) in wanted]
    label = args.label or ("legado" if args.legacy else "votos")
    stamp = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    out_dir = os.path.join(args.out, f"{stamp}-{label}")
    os.makedirs(out_dir, exist_ok=True)

    rows = []
    jobs = [(case, overrides, args.legacy, args.as_recorded) for case in cases]
    if args.jobs > 1:
        with ProcessPoolExecutor(max_workers=args.jobs) as pool:
            results = list(pool.map(_safe_replay, jobs))
    else:
        results = map(_safe_replay, jobs)
    for row in results:
        rows.append(row)
        with open(os.path.join(out_dir, f"{row['run_id']}__{row['falha']}.json"), "w") as f:
            json.dump(row, f, ensure_ascii=False, indent=2, default=str)
        mark = "T1" if row["top1"] else "T2" if row["top2"] else "--"
        print(f"  {mark} {row['run_id'][-7:]} {row['falha']:22s} esperado={row['expected']:22s} "
              f"ranking={row['ranking']} {row.get('abstain_reason') or ''}", flush=True)

    md = _summary_md(label, rows, overrides, args.legacy)
    with open(os.path.join(out_dir, "resumo.md"), "w") as f:
        f.write(md)
    with open(os.path.join(out_dir, "resumo.json"), "w") as f:
        json.dump({"label": label, "legacy": args.legacy, "overrides": overrides, "rows": rows}, f,
                  ensure_ascii=False, indent=2, default=str)
    print("\n" + md.split("\n| falha")[0])
    print(f"Saída: {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
