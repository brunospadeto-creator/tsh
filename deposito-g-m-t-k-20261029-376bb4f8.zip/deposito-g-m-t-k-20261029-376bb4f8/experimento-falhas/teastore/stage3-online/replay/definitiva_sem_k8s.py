#!/usr/bin/env python3
"""Ablação do canal K8s na coleta definitiva (secundário, fora da leitura do §6).

Mesma medida do `definitiva.py` (`paridade_solucoes.rodar_caso` no modo confirmatório, D0.4 na hora, mesmos
instantes), com uma única troca: `protocolo_rapido._k8s_limpo` devolve lista vazia, então **nenhum** evento K8s
chega à `EntradaIncidente`. Mede a d9-k e o v-cons-b sem K8s e confere, instante a instante, se a d9-k sem K8s é
idêntica à d9 (status, ranking e ranking forçado). Nada de `src/` nem dos scripts existentes muda (troca só neste
processo).

Saída: `resultados/protocolo-coleta-definitiva/sem-k8s/` (registros) e `resultado-sem-k8s.md`.

Uso: replay/definitiva_sem_k8s.py [--jobs 16] [--so-analise]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SELF_DIR)

import consenso as C  # noqa: E402, N812
import definitiva as DF  # noqa: E402, N812
import paridade_solucoes as PS  # noqa: E402, N812
import protocolo_rapido as PR  # noqa: E402, N812
import protocolo_rapido_analise as A  # noqa: E402, N812

SAIDA_SK = os.path.join(DF.SAIDA, "sem-k8s")
PR._k8s_limpo = lambda k8s, inicio: []   # noqa: E731 — a ablação: nenhum evento K8s


def _pcs(rs: list[dict[str, Any]], inv: dict[str, Any]) -> dict[str, dict[str, dict[str, float]]]:
    return {m: {c: x for (_m, c), x in A.por_cenario([r for r in rs if r["modo"] == m], inv).items()}
            for m in DF.MODOS}


def _linha(rot: str, pc: dict[str, dict[str, float]]) -> str:
    r = DF.metricas(pc)
    f, i1 = DF._boot(pc, A.f1), DF._boot(pc, DF._media("o1"))
    g = {k: A.f1([x for c, x in pc.items() if c.split("/")[-1][0] == k]) for k in "hg"}
    return (f"| {rot} | {r['f1']:.3f} [{f[0]:.3f}–{f[1]:.3f}] | {r['f2']:.3f} | {r['f3']:.3f} | {g['h']:.3f} | "
            f"{g['g']:.3f} | {r['alarme']:.1%} | {r['abst']:.0%} | {r['o1']:.0%} [{i1[0]:.0%}–{i1[1]:.0%}] | "
            f"{r['o2']:.0%} | {r['o3']:.0%} |")


def analisar(inv: dict[str, Any]) -> str:
    com = [r for r in C._novos(inv, DF.SAIDA, "*.jsonl.gz") if r["modo"] in DF.MODOS]
    sem = [r for r in C._novos(inv, SAIDA_SK, "*.jsonl.gz") if r["modo"] in DF.MODOS]
    pc_com, pc_sem = _pcs(com, inv), _pcs(sem, inv)

    # identidade d9-k sem K8s × d9, instante a instante
    chave = lambda r: (r["cenario"], r["t"])  # noqa: E731
    d9 = {chave(r): r for r in sem if r["modo"] == "d9"}
    dk = {chave(r): r for r in sem if r["modo"] == "d9-k-prod"}
    dec = lambda r: r["decidiu"] and bool(r["ranking"])  # noqa: E731
    dif_dec = sum(dec(dk[k]) != dec(d9[k]) for k in dk if k in d9)
    dif_top1 = sum(dec(dk[k]) and dec(d9[k]) and dk[k]["ranking"][:1] != d9[k]["ranking"][:1] for k in dk if k in d9)
    dif_f1 = sum((dk[k]["forcado"] or [])[:1] != (d9[k]["forcado"] or [])[:1] for k in dk if k in d9)
    dif_f3 = sum((dk[k]["forcado"] or [])[:3] != (d9[k]["forcado"] or [])[:3] for k in dk if k in d9)
    d9_com = {chave(r): r for r in com if r["modo"] == "d9"}
    d9_igual = sum(d9_com.get(k, {}).get("ranking") == r["ranking"] and d9_com.get(k, {}).get("forcado") == r["forcado"]
                   for k, r in d9.items())

    cab = ["| modo | F1@1 [IC 95%] | F1@2 | F1@3 | F1@1 h | F1@1 g | alarme | abstenção | sabendo top-1 [IC 95%] | "
           "top-2 | top-3 |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    out = ["# Coleta definitiva — ablação do canal K8s (§42.87, secundário)", "",
           f"{len(inv)} cenários, mesmos instantes e medida do `definitiva.py`; única troca: nenhum evento K8s na "
           "entrada (`_k8s_limpo` → []). Nada ajustado.", "", *cab]
    for m, rot in (("d9-k-prod", "d9-k com K8s"), ("d9-k-prod", "**d9-k sem K8s**"), ("v-cons-b-prod", "v-cons-b com K8s"),
                   ("v-cons-b-prod", "**v-cons-b sem K8s**"), ("v-cons-b-1", "v-cons-b-1 com K8s"),
                   ("v-cons-b-1", "**v-cons-b-1 sem K8s**"), ("d9", "d9 (não usa K8s)")):
        out.append(_linha(rot, (pc_sem if "sem" in rot else pc_com)[m]))
    out += ["", "## d9-k sem K8s × d9, instante a instante", "",
            f"- instantes comparados: {len([k for k in dk if k in d9])}",
            f"- decisão (decidiu × absteve) diferente: {dif_dec}",
            f"- 1º serviço diferente quando os dois decidem: {dif_top1}",
            f"- ranking forçado diferente: top-1 {dif_f1}, top-3 {dif_f3}",
            f"- d9 desta rodada = d9 da rodada com K8s (ranking e forçado): {d9_igual}/{len(d9)}", "",
            "## McNemar exato pareado (acerto majoritário por cenário)", ""]
    for a, pa, b, pb, k, txt in (
            ("d9-k-prod", pc_com, "d9-k-prod", pc_sem, "tp1", "d9-k com × sem K8s (top-1 com portão)"),
            ("d9-k-prod", pc_sem, "d9", pc_sem, "tp1", "d9-k sem K8s × d9 (top-1 com portão)"),
            ("v-cons-b-prod", pc_com, "v-cons-b-prod", pc_sem, "o3", "v-cons-b com × sem K8s (top-3 sabendo)"),
            ("v-cons-b-prod", pc_sem, "d9-k-prod", pc_sem, "o3", "v-cons-b × d9-k, ambos sem K8s (top-3 sabendo)")):
        sa, sb, p = DF.mcnemar(pa[a], pb[b], k)
        out.append(f"- {txt}: só o 1º {sa}, só o 2º {sb}, p = {p:.3f}")
    out += ["", "## Por cenário (top-1 com portão; top-3 sabendo do v-cons-b)", "",
            "| cenário | esperado | d9-k com | d9-k sem | d9 | v-cons-b o3 com | v-cons-b o3 sem |",
            "|---|---|---|---|---|---|---|"]
    for c in sorted(inv):
        cel = []
        for pc, m, k in ((pc_com, "d9-k-prod", "tp1"), (pc_sem, "d9-k-prod", "tp1"), (pc_sem, "d9", "tp1"),
                         (pc_com, "v-cons-b-prod", "o3"), (pc_sem, "v-cons-b-prod", "o3")):
            x = pc[m].get(c)
            cel.append(f"{x[k]}/{x['n_est']}" if x and x.get("n_est") else "—")
        out.append(f"| {c} | {inv[c]['esperado'].replace('teastore-', '')} | " + " | ".join(cel) + " |")
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--so-analise", action="store_true")
    args = ap.parse_args()
    cs = DF.casos(DF.runs())
    with open(os.path.join(DF.SAIDA, "inventario.json")) as f:
        inv = json.load(f)
    if not args.so_analise:
        from concurrent.futures import ProcessPoolExecutor  # noqa: PLC0415
        with ProcessPoolExecutor(args.jobs) as ex:
            for msg in ex.map(PS.rodar_caso, [(c, SAIDA_SK, True) for c in cs]):
                print(msg, flush=True)
    texto = analisar(inv)
    with open(os.path.join(DF.SAIDA, "resultado-sem-k8s.md"), "w") as f:
        f.write(texto)
    print(texto)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
