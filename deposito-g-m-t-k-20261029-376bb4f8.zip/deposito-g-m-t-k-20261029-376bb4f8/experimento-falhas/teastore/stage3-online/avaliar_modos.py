#!/usr/bin/env python3
"""Avaliação por modo de um lote ao vivo: a0 + cada d_k escolhido, **separados**.

    python3 avaliar_modos.py caso <dir_do_cenario> <servico_esperado>   # grava avaliacao_modos.json
    python3 avaliar_modos.py lote <dir_do_lote> [<dir_do_lote> ...]     # grava resumo_modos.md

O gabarito entra só aqui, depois das decisões. a0 vem do `avaliacao.json` (avaliação legada); cada d_k
vem do `decisao` do pacote de auditoria do modo (`stage3_modos_audit/<modo>.json`), que tem o ranking
completo. Mesmo formato de linha do `replay/replay_abordagens.py`, para comparar ao vivo × replay.
"""
from __future__ import annotations

import glob
import json
import os
import sys
from typing import Any

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SELF_DIR, "replay"))


def _linha(case_dir: str, modo: str, status: str, ranking: list[str], esperado: str,
           extra: dict[str, Any]) -> dict[str, Any]:
    respondeu = status == "decidiu"
    rank = ranking.index(esperado) + 1 if respondeu and esperado in ranking else None
    return {
        "run_id": os.path.basename(os.path.dirname(os.path.abspath(case_dir))),
        "falha": os.path.basename(os.path.abspath(case_dir)), "modo": modo, "expected": esperado,
        "ranking": ranking[:5], "status": status, "respondeu": respondeu, "rank": rank,
        "top1": rank == 1, "top2": rank is not None and rank <= 2, "top3": rank is not None and rank <= 3,
        "rr": 1.0 / rank if rank else 0.0, **extra,
    }


def avaliar_caso(case_dir: str, esperado: str) -> list[dict[str, Any]]:
    linhas: list[dict[str, Any]] = []
    legado = os.path.join(case_dir, "avaliacao.json")
    if os.path.exists(legado):
        a = json.load(open(legado))
        respondeu = bool(a.get("respondeu", True))
        ranking = [str(c.get("service") if isinstance(c, dict) else c) for c in a.get("ranking") or []]
        linhas.append(_linha(case_dir, "a0", "decidiu" if respondeu else "absteve", ranking, esperado,
                             {"versao": "a0-v1"}))
    for caminho in sorted(glob.glob(os.path.join(case_dir, "stage3_modos_audit", "*.json"))):
        modo = os.path.splitext(os.path.basename(caminho))[0]
        try:
            pacote = json.load(open(caminho))
        except json.JSONDecodeError:
            linhas.append(_linha(case_dir, modo, "falhou", [], esperado, {"erro": "pacote ilegivel"}))
            continue
        decisao = pacote.get("decisao") or {}
        ranking = [str(i.get("servico")) for i in decisao.get("ranking") or []]
        from avaliacao_lib import empate_no_topo

        linhas.append(_linha(case_dir, modo, str(decisao.get("status") or "falhou"), ranking, esperado, {
            "versao": decisao.get("versao"), "motivo_abstencao": decisao.get("motivo_abstencao"),
            "audit_sha256": pacote.get("sha256"), "empate_topo": empate_no_topo(decisao.get("ranking") or []),
        }))
    with open(os.path.join(case_dir, "avaliacao_modos.json"), "w") as fh:
        json.dump(linhas, fh, ensure_ascii=False, indent=2)
    return linhas


def avaliar_lote(dirs: list[str]) -> str:
    from replay_abordagens import resumo_md

    linhas: list[dict[str, Any]] = []
    for lote in dirs:
        # f* = calibração, h*/g* = hold-outs (HOLDOUT.md, HOLDOUT-2.md)
        for caminho in sorted(glob.glob(os.path.join(lote, "[fhg][0-9]*", "avaliacao_modos.json"))):
            linhas.extend(json.load(open(caminho)))
    modos = ["a0"] + sorted({r["modo"] for r in linhas} - {"a0"})
    md = resumo_md(linhas, modos, "ao vivo: " + ", ".join(os.path.basename(d.rstrip("/")) for d in dirs))
    with open(os.path.join(dirs[0], "resumo_modos.md"), "w") as fh:
        fh.write(md)
    with open(os.path.join(dirs[0], "avaliacao_modos_lote.json"), "w") as fh:
        json.dump(linhas, fh, ensure_ascii=False, indent=2)
    return md


def main() -> int:
    if len(sys.argv) >= 4 and sys.argv[1] == "caso":
        linhas = avaliar_caso(sys.argv[2], sys.argv[3])
        for r in linhas:
            print(f"    {r['modo']:5s} {r['status']:8s} rank={r['rank']} {r['ranking'][:3]}")
        return 0
    if len(sys.argv) >= 3 and sys.argv[1] == "lote":
        print(avaliar_lote(sys.argv[2:]).split("\n## Caso")[0])
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
