#!/usr/bin/env python3
"""Avaliação de um cenário do lote: suspeito apontado x serviço onde a falha foi injetada.

Mantém os campos antigos de `avaliacao.json` (`matched` = acerto no Top-1) e acrescenta o ranking
completo, a posição do serviço esperado, Top-2/Top-3, reciprocal rank, os votos que o esperado
recebeu e se o caso começou com o TeaStore não saudável (`health_pre.json`).
Também registra a síntese do LLM: provedor (`mock` deixa
explícito que não houve LLM real), abstenção, confiança, coerência com a localização (P4) e se a
hipótese cita o serviço esperado.

Acrescenta a checagem de manifestação da M2 (`manifestacao.py`): separa os casos que produziram sinal
dos que não produziram, para o lote não contar falha silenciosa como erro de diagnóstico.

Uso: avaliar_caso.py <dir_do_cenario> <falha> <servico_esperado> [baseline.json]
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from manifestacao import classificar_manifestacao


def _load(path: str) -> dict:
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


_LEVELS = {"baixa": 0, "média": 1, "alta": 2}


def _coherent(llm_conf: str | None, loc_conf: str | None) -> bool | None:
    """False quando a síntese é mais confiante que a localização (P4); None sem os dois níveis."""
    if llm_conf not in _LEVELS or loc_conf not in _LEVELS:
        return None
    return _LEVELS[llm_conf] <= _LEVELS[loc_conf]


LLM_ABSTAIN_REASONS = {"invalid_llm_output", "llm_abstained"}


def main() -> int:
    case_dir, falha, expected = sys.argv[1:4]
    baseline_path = sys.argv[4] if len(sys.argv) > 4 else ""
    diag = _load(os.path.join(case_dir, "stage3_diagnosis.json")).get("diagnosis", {}) or {}
    audit = _load(os.path.join(case_dir, "stage3_audit_package.json"))
    s3 = audit.get("stage3") or {}
    loc = s3.get("localization") or {}
    suspects = loc.get("suspects") or diag.get("entity_candidates") or []
    ranking = [str(s.get("pod_name") or s.get("service") or "") for s in suspects]
    # Abstenção antes da síntese = nenhum suspeito publicado: o ranking fica para inspeção, sem pontuar
    # (mesma regra do replay). Abstenção do LLM não conta: a localização já tinha saído.
    respondeu = not (s3.get("status") == "abstained" and s3.get("abstain_reason") not in LLM_ABSTAIN_REASONS)
    rank = ranking.index(expected) + 1 if respondeu and expected in ranking else None
    top_service = diag.get("top_candidate_service") or ""
    top_pod = diag.get("top_candidate_pod") or ""
    health = _load(os.path.join(case_dir, "health_pre.json"))
    expected_votes = next((v for v in loc.get("votes") or [] if v.get("entity") == expected), None)
    out = {
        "falha": falha, "expected_service": expected,
        "top_candidate_service": top_service, "top_candidate_pod": top_pod,
        "top_candidate_confidence": diag.get("top_candidate_confidence"),
        "matched": respondeu and bool(top_service == expected or top_pod.startswith(expected + "-")
                                      or top_pod == expected),
        "ranking": ranking, "respondeu": respondeu, "rank": rank,
        "top2": rank is not None and rank <= 2, "top3": rank is not None and rank <= 3,
        "rr": round(1.0 / rank, 4) if rank else 0.0,
        "expected_votes": [x.get("name") for x in (expected_votes or {}).get("votes", [])],
        "status": s3.get("status"), "abstain_reason": s3.get("abstain_reason"),
        "localizacao_abstain_reason": s3.get("localizacao_abstain_reason"),
        "selection_rule": loc.get("selection_rule"),
        "health_pre_ok": health.get("ok") if health else None,
        "health_pre_problems": health.get("problems", []) if health else None,
        "llm_provider": diag.get("llm_provider"), "llm_abstain": diag.get("llm_abstain"),
        "llm_confidence": diag.get("llm_confidence"),
        "confidence_coherent": _coherent(diag.get("llm_confidence"), diag.get("top_candidate_confidence")),
        "llm_hypothesis_cites_expected": (
            expected.removeprefix("teastore-") in str(diag.get("llm_hypothesis") or "")
            if diag.get("llm_hypothesis") else None
        ),
    }
    # M2 do plano -- a falha se manifestou? Sem isso, um caso que não produziu sinal nenhum ainda
    # ocupa o denominador principal e derruba a taxa de acerto (F4/F8/F10/F14 no lote `081432Z`).
    manifestacao = None
    if baseline_path:
        baseline = _load(baseline_path)
        if baseline:
            manifestacao = classificar_manifestacao(case_dir, expected, baseline)
            manifestacao["falha"] = falha
    else:
        manifestacao = {"falha": falha, "servico_esperado": expected, "classificacao": "indeterminado",
                        "motivo": "baseline não informada", "sinais": [], "n_sinais_positivos": 0}
    out["manifestacao"] = manifestacao
    out["manifestou"] = manifestacao["classificacao"] == "manifesta"
    with open(os.path.join(case_dir, "avaliacao.json"), "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"    avaliacao: esperado={expected} | ranking={ranking} | posição={rank or '-'}"
          f" | saudável antes={out['health_pre_ok']} | manifestação={manifestacao['classificacao']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
