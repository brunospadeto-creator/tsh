#!/usr/bin/env bash
# Orquestra cenários de falha no TeaStore e monta, pra cada um, um pacote
# IGUAL a um incidente real detectado pelo monitoramento (plano de melhoria,
# 21/09/2026): aplica a falha, liga o stresser (sempre 10-20 usuários, já
# configurado no deployment do stresser), coleta 3 pacotes de evidência reais
# da aplicação TeaStore ao vivo (Loki/Prometheus/K8s), simula a detecção
# (força stage1_result=anomalous nos 3 -- não há motor Stage1/2 treinado hoje)
# e então usa as funções REAIS de abertura de incidente e execução do Stage 3
# (mesmo código de produção, mesmas tabelas: `incidents`, `stage3_diagnoses`,
# pacote de auditoria congelado). Ao final salva no sistema de arquivos o
# incidente, o diagnóstico, o pacote de auditoria, os 3 pacotes de evidência e
# os traces brutos do Jaeger da janela do incidente.
#
# Reaproveita a infraestrutura já existente em ../lib.sh (aplicar/reverter
# falha, stresser) -- não reimplementa nada disso. A parte de "simular a
# detecção" (forçar os 3 monitoring_logs + abrir o incidente) está em
# simular_incidente.py, porque precisa chamar funções internas
# (`maybe_open_incident_for_recent_anomalias`, `collect_evidence`) que não têm
# endpoint HTTP -- por isso o script abre seu próprio port-forward pro
# Postgres.
#
# Também salva `traces_full_scenario.json` (traces do cenário inteiro, do
# stresser ligado ao desligado -- não só a janela estreita que o Stage 3
# analisou) e `avaliacao.json` (bate o suspeito apontado contra o serviço onde
# a falha foi injetada de verdade, plano de melhoria P7).
#
# Objetivo: só coletar material bruto para uma segunda rodada de análise
# profunda visando melhorar o Stage 3 -- este script não analisa nada.
#
# Insumos para replay offline: cada rodada também grava
# `baseline.json` (baseline completa da coleção + stage3_config), e cada
# cenário grava `monitoring_logs.json` (logs do incidente + anteriores),
# `traces_stage3_window.json` (traces exatamente na janela de busca do
# Stage 3), `k8s_events_cluster.json` e `health_pre.json` (checagem de saúde
# antes de aplicar a falha -- health_gate.py). Com isso
# `replay/replay.py` reexecuta o Stage 3 sem cluster.
#
# Uso:
#   ./run-stage3-online.sh -c COLLECTION_ID [opções]
#
# Opções:
#   -c, --collection-id ID  OBRIGATÓRIO. Coleção com baseline já completa
#                           (métricas + traces) -- calcule antes na tela de
#                           Coleções ("Calcular Baseline" + "Coletar Traces de
#                           Baseline"). O script recusa rodar se não estiver
#                           completa. A janela de cada pacote de evidência é
#                           sempre herdada de collection.package_window_seconds
#                           (nunca um valor fixo à parte).
#   -n, --num N             Quantidade de cenários a aplicar, em ordem
#                           (f1..f14). Padrão: 3. Ignorado se -f for usado.
#   -f, --falhas LISTA      Lista explícita de cenários, separados por vírgula
#                           (ex.: f1-latency,f3-sql-degradation,f14-log-bomb).
#                           Tem prioridade sobre -n.
#   --warmup SEG            PISO do warmup MEDIDO depois de implantar a falha:
#                           só coleta quando a latência do webui estabiliza sob
#                           a falha (aguardar_regime_webui, mesma régua da
#                           baseline). A implantação recria o pod do serviço-alvo
#                           e o cold start da JVM entrava na janela -- foi o que
#                           contaminou o lote 081432Z. Tem de
#                           ser > lookback_sec do Stage 3. Padrão: 300.
#   --warmup-max SEG        Teto desse warmup (falhas como a f11 nunca
#                           estabilizam; o teto fica registrado). Padrão: 1200.
#   --ref-warmup SEG        Piso do warmup MEDIDO antes da janela de referência
#                           (o rollback do cenário anterior também recria um pod).
#                           Padrão: 300. O teto é o mesmo de --warmup-max.
#   --verify-timeout SEG    Prazo para verificar_falha.py confirmar que a falha
#                           está aplicada, só ela, e o webui no ar. Se não
#                           confirmar, o cenário NÃO é coletado (marker
#                           FALHA_NAO_VERIFICADA) e a rodada segue. Padrão: 300.
#   --sem-warmup-medido     Troca os warmups medidos por sleep fixo do piso
#                           (diagnóstico; a janela pode sair contaminada).
#   --ref-window SEG        Janela de REFERÊNCIA do cenário, coletada com o app
#                           saudável sob a mesma carga, logo antes de injetar a
#                           falha (Etapa F). A localização compara a janela da
#                           falha com essa base e com a baseline global, para
#                           não chamar de sintoma a deriva que o próprio
#                           experimento provoca entre cenários. Padrão: 300.
#   --stage3-timeout SEG    Quanto esperar o job do Stage 3 concluir antes de
#                           desistir de salvar o diagnóstico. Padrão: 600.
#   --coleta SEG            Coleta pacotes continuamente por SEG segundos (em
#                           vez de 3 pacotes) e abre o incidente com todos: a
#                           janela do incidente cobre a coleta inteira. Padrão:
#                           0 (3 pacotes, threshold real de produção).
#   --shuffle [SEMENTE]     Embaralha a ordem dos cenários (evita que um cenário
#                           venha sempre depois do mesmo vizinho). Sem semente,
#                           usa uma aleatória; a semente e a ordem final vão
#                           para o manifest.json (reprodutível).
#   -h, --help
#
# Variáveis de ambiente:
#   VERITAS_SYSTEM_ID  Padrão: f530cda3-e337-4c63-a7dc-d57c8722afef (TeaStore)
set -euo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SELF_DIR/../../.." && pwd)"
source "$SELF_DIR/../lib.sh"

VERITAS_SYSTEM_ID="${VERITAS_SYSTEM_ID:-f530cda3-e337-4c63-a7dc-d57c8722afef}"
RESULTADOS_DIR="$SELF_DIR/resultados"
N_PACOTES=3  # tem que bater com o threshold real de maybe_open_incident_for_recent_anomalias

# Ordem canônica f1..f14 (nomes usados por _falha_to_service/_is_infra_fault em ../lib.sh).
CANONICAL_FALHAS=(
    f1-latency f2-jvm-memory f3-sql-degradation f4-invalid-path f5-jvm-heap
    f6-db-connectivity f7-pool-contention f8-missing-table f9-incompat-version
    f10-cpu-contention f11-memory-limit f12-cpu-throttle f13-bad-probe f14-log-bomb
)

COLLECTION_ID=""
NUM=3
FALHAS_LIST=""
WARMUP=300
WARMUP_MAX=1200
REF_WARMUP=300
WARMUP_TOL="${WARMUP_TOL:-5}"
VERIFY_TIMEOUT=300
SEM_WARMUP_MEDIDO=0
REF_WINDOW=300
STAGE3_TIMEOUT=600
SHUFFLE_SEED=""
COLETA=0
ORIGINAL_MONITORING_ACTIVE=""
ACTIVE_PROFILE_ID=""

_validate_positive_int() {
    local name="$1" value="$2"
    if ! [[ "$value" =~ ^[0-9]+$ ]] || [ "$value" -le 0 ]; then
        echo "ERRO: $name deve ser um inteiro positivo (recebido: '$value')" >&2
        exit 1
    fi
}

while [ $# -gt 0 ]; do
    case "$1" in
        -c|--collection-id) COLLECTION_ID="$2"; shift 2 ;;
        -n|--num) NUM="$2"; shift 2 ;;
        -f|--falhas) FALHAS_LIST="$2"; shift 2 ;;
        --warmup) WARMUP="$2"; shift 2 ;;
        --warmup-max) WARMUP_MAX="$2"; shift 2 ;;
        --ref-warmup) REF_WARMUP="$2"; shift 2 ;;
        --verify-timeout) VERIFY_TIMEOUT="$2"; shift 2 ;;
        --sem-warmup-medido) SEM_WARMUP_MEDIDO=1; shift ;;
        --ref-window) REF_WINDOW="$2"; shift 2 ;;
        --stage3-timeout) STAGE3_TIMEOUT="$2"; shift 2 ;;
        --coleta) COLETA="$2"; shift 2 ;;
        --shuffle)
            if [ $# -ge 2 ] && [[ "$2" =~ ^[0-9]+$ ]]; then SHUFFLE_SEED="$2"; shift 2
            else SHUFFLE_SEED="$(( (RANDOM << 15) | RANDOM ))"; shift; fi ;;
        -h|--help) sed -n '2,/^set -euo/p' "$0" | sed '$d'; exit 0 ;;
        *) echo "Opção desconhecida: $1 (use -h para ajuda)" >&2; exit 1 ;;
    esac
done

if [ -z "$COLLECTION_ID" ]; then
    echo "ERRO: -c/--collection-id é obrigatório (coleção com baseline completa -- métricas + traces)." >&2
    exit 1
fi
_validate_positive_int "quantidade de cenários (-n)" "$NUM"
_validate_positive_int "warmup (--warmup)" "$WARMUP"
_validate_positive_int "teto do warmup (--warmup-max)" "$WARMUP_MAX"
_validate_positive_int "warmup da referência (--ref-warmup)" "$REF_WARMUP"
_validate_positive_int "prazo da verificação (--verify-timeout)" "$VERIFY_TIMEOUT"
_validate_positive_int "ref-window (--ref-window)" "$REF_WINDOW"
_validate_positive_int "timeout do Stage 3 (--stage3-timeout)" "$STAGE3_TIMEOUT"

if [ -n "$FALHAS_LIST" ]; then
    IFS=',' read -ra FALHAS <<< "$FALHAS_LIST"
else
    if [ "$NUM" -gt "${#CANONICAL_FALHAS[@]}" ]; then
        echo "ERRO: -n ${NUM} maior que o total de cenários conhecidos (${#CANONICAL_FALHAS[@]})." >&2
        exit 1
    fi
    FALHAS=("${CANONICAL_FALHAS[@]:0:$NUM}")
fi

if [ -n "$SHUFFLE_SEED" ]; then
    mapfile -t FALHAS < <(python3 -c "
import random, sys
falhas = sys.argv[2:]
random.Random(int(sys.argv[1])).shuffle(falhas)
print('\n'.join(falhas))
" "$SHUFFLE_SEED" "${FALHAS[@]}")
    echo ">>> Ordem embaralhada (semente ${SHUFFLE_SEED}): ${FALHAS[*]}"
fi

for falha in "${FALHAS[@]}"; do
    if [ "$(_falha_to_service "$falha")" = "unknown" ]; then
        echo "ERRO: cenário desconhecido: '$falha'" >&2
        exit 1
    fi
done

# ── Cleanup ──────────────────────────────────────────────────────────

cleanup() {
    local exit_code=$?
    echo ""
    echo ">>> Limpando recursos..."
    _pacotes_continuos_fim 2>/dev/null || true
    stresser_off 2>/dev/null || true
    if [ "$ORIGINAL_MONITORING_ACTIVE" = "true" ] && [ -n "$ACTIVE_PROFILE_ID" ]; then
        echo "    Religando o monitoramento real (estava ativo antes da rodada, perfil ${ACTIVE_PROFILE_ID})..."
        _veritas_api "POST" "/systems/${VERITAS_SYSTEM_ID}/monitor/start" "{\"profile_id\": \"${ACTIVE_PROFILE_ID}\"}" > /dev/null 2>&1 || true
    fi
    kill_port_forwards 2>/dev/null || true
    echo ">>> Cleanup concluído (exit_code=$exit_code)."
}
trap cleanup EXIT

# ── Port-forward do web (API do Veritas, usada por _veritas_api em todo o resto) ──
#
# Ao contrário do resto de ../lib.sh (que assume um port-forward externo já
# aberto em localhost:8000), este script abre o seu próprio -- não depende de
# nada ter sido deixado rodando de fora.

echo ">>> Port-forward do web (8000)..."
fuser -k 8000/tcp 2>/dev/null || true
sleep 1
pf_svc "web" 8000 8000 "monitor"
sleep 2

# ── Baseline: confere que a coleção escolhida está pronta ──────────────

echo ">>> Validando coleção ${COLLECTION_ID}..."
collection_resp=$(_veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}/collections/${COLLECTION_ID}" "")
PACKAGE_WINDOW=$(echo "$collection_resp" | python3 -c "import json,sys; print(json.load(sys.stdin)['collection']['package_window_seconds'])" 2>/dev/null || echo "")
if [ -z "$PACKAGE_WINDOW" ]; then
    echo "ERRO: coleção ${COLLECTION_ID} não encontrada no sistema ${VERITAS_SYSTEM_ID}." >&2
    exit 1
fi

baseline_resp=$(_veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}/collections/${COLLECTION_ID}/baseline/status" "")
baseline_status=$(echo "$baseline_resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('status',''))" 2>/dev/null || echo "")
trace_status=$(echo "$baseline_resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('trace_status',''))" 2>/dev/null || echo "")
if [ "$baseline_status" != "completed" ] || [ "$trace_status" != "completed" ]; then
    echo "ERRO: coleção ${COLLECTION_ID} não tem baseline completa (status=${baseline_status:-?}, trace_status=${trace_status:-?})." >&2
    echo "      Calcule em: Coleções > ${COLLECTION_ID} > \"Calcular Baseline\" + \"Coletar Traces de Baseline\"." >&2
    exit 1
fi
echo "    OK: baseline completa (janela herdada: ${PACKAGE_WINDOW}s)."

# ── Pausa o monitoramento real durante a rodada ─────────────────────
#
# Se monitoring_active=true, o ciclo real (execute_monitoring) roda sozinho
# a cada polling_interval_sec e grava monitoring_logs de verdade -- que vão
# se intercalar com os 3 que simular_incidente.py força como anomalous.
# maybe_open_incident_for_recent_anomalias olha os ÚLTIMOS 3 logs do sistema
# sem filtrar por origem, então um ciclo real caindo no meio quebra a
# simulação. Pausa uma vez pra rodada inteira (religa no cleanup).

system_resp=$(_veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}" "")
ORIGINAL_MONITORING_ACTIVE=$(echo "$system_resp" | python3 -c "import json,sys; d=json.load(sys.stdin); print(str((d.get('system') or d).get('monitoring_active')).lower())" 2>/dev/null || echo "false")
if [ "$ORIGINAL_MONITORING_ACTIVE" = "true" ]; then
    profiles_resp=$(_veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}/profiles" "")
    ACTIVE_PROFILE_ID=$(echo "$profiles_resp" | python3 -c "
import json, sys
profiles = json.load(sys.stdin)
active = next((p for p in profiles if p.get('active')), None)
print(active['profile_id'] if active else '')
" 2>/dev/null || true)
    echo ">>> Pausando o monitoramento real (estava ativo, perfil ${ACTIVE_PROFILE_ID:-desconhecido}) até o fim da rodada..."
    _veritas_api "POST" "/systems/${VERITAS_SYSTEM_ID}/monitor/stop" "" > /dev/null
else
    echo ">>> Monitoramento real já estava desligado -- nada a pausar."
fi

# ── Port-forwards: Jaeger (dump de traces), Postgres (simular_incidente.py) e
# Loki/Prometheus (_collect_signals, mesma coleta real de execute_monitoring) ──

echo ">>> Port-forward do Jaeger (16686), Postgres (5432), Loki (3100) e Prometheus (9090)..."
fuser -k 16686/tcp 2>/dev/null || true
fuser -k 5432/tcp 2>/dev/null || true
fuser -k 3100/tcp 2>/dev/null || true
fuser -k 9090/tcp 2>/dev/null || true
sleep 1
pf_svc "jaeger" 16686 16686 "observability"
pf_svc "postgres" 5432 5432 "monitor"
pf_svc "loki" 3100 3100 "observability"
pf_svc "prometheus" 9090 9090 "observability"
sleep 2
JAEGER_ENDPOINT="http://localhost:16686"
export VERITAS_DB_URL="postgresql://veritas:password@localhost:5432/veritas"
export VERITAS_LOKI_URL="http://localhost:3100"
export VERITAS_PROMETHEUS_URL="http://localhost:9090"

# ── Setup da rodada ──────────────────────────────────────────────────

RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_DIR="$RESULTADOS_DIR/$RUN_ID"
mkdir -p "$RUN_DIR"
CODE_VERSION="$(git -C "$REPO_ROOT" rev-parse --short HEAD 2>/dev/null || echo unknown)"
if [ -n "$(git -C "$REPO_ROOT" status --porcelain -- src 2>/dev/null)" ]; then
    CODE_VERSION="${CODE_VERSION}+dirty"
fi

echo ">>> Exportando a baseline completa da coleção (insumo do replay offline)..."
PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/export_insumos.py" baseline "$COLLECTION_ID" "$RUN_DIR/baseline.json" \
    --system-id "$VERITAS_SYSTEM_ID" || echo "    AVISO: export da baseline falhou -- replay offline desta rodada vai precisar de resultados/insumos/."

falhas_json=$(printf '"%s",' "${FALHAS[@]}")
falhas_json="[${falhas_json%,}]"
cat > "$RUN_DIR/manifest.json" <<EOF
{
  "run_id": "${RUN_ID}", "system_id": "${VERITAS_SYSTEM_ID}", "collection_id": "${COLLECTION_ID}",
  "package_window_seconds": ${PACKAGE_WINDOW}, "n_pacotes": ${N_PACOTES}, "falhas": ${falhas_json},
  "warmup_seconds": ${WARMUP}, "ref_window_seconds": ${REF_WINDOW},
  "warmup_medido": $([ "$SEM_WARMUP_MEDIDO" = 1 ] && echo false || echo true),
  "warmup_max_seconds": ${WARMUP_MAX}, "ref_warmup_seconds": ${REF_WARMUP}, "warmup_tol_pct": ${WARMUP_TOL},
  "verify_timeout_seconds": ${VERIFY_TIMEOUT}, "exp_base": "${EXP_BASE}",
  "stage3_timeout_seconds": ${STAGE3_TIMEOUT},
  "code_version": "${CODE_VERSION}", "shuffle_seed": ${SHUFFLE_SEED:-null},
  "coleta_seconds": ${COLETA}
}
EOF
echo ">>> Rodada ${RUN_ID}: ${#FALHAS[@]} cenário(s) — ${FALHAS[*]}"
echo "    Resultados em: ${RUN_DIR}"

# ── Aguarda o job do Stage 3 concluir (mesma rota de polling da UI real) ─────

aguardar_stage3_job() {
    local incident_id="$1" timeout="$2"
    local elapsed=0 status="pending"
    while [ "$status" = "pending" ] || [ "$status" = "running" ]; do
        sleep 3
        status=$(_veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}/stage3/summary" "" \
            | python3 -c "import json,sys; print(json.load(sys.stdin).get('status','error'))" 2>/dev/null || echo "error")
        elapsed=$((elapsed + 3))
        if [ "$elapsed" -ge "$timeout" ]; then
            echo "    AVISO: Stage 3 do incidente ${incident_id} não concluiu em ${timeout}s (status=${status})."
            return 1
        fi
    done
    echo "    Stage 3 concluído: status=${status}"
    return 0
}

# Modos d1–d4: espera os jobs `stage3_abordagem` do incidente ficarem terminais. Sem modo
# d_k escolhido, o painel não tem d_k e a espera termina na hora.
aguardar_modos() {
    local incident_id="$1" timeout="$2" elapsed=0 pendentes="?"
    while [ "$elapsed" -lt "$timeout" ]; do
        pendentes=$(_veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}/stage3/modos" "" \
            | python3 -c "
import json,sys
v=json.load(sys.stdin)
print(' '.join(p['modo'] for p in v.get('modos',[]) if p['modo']!='a0' and not p.get('terminal')))" 2>/dev/null || echo "?")
        [ -z "$pendentes" ] && { echo "    Modos concluídos."; return 0; }
        sleep 5; elapsed=$((elapsed + 5))
    done
    echo "    AVISO: modos sem concluir em ${timeout}s: ${pendentes}"
    return 1
}

# ── Warmup medido e verificação da falha ─────────────────────────────

# Warmup com o stresser já ligado: mede o regime (lib.sh) e grava o resultado no cenário. Com
# --sem-warmup-medido, dorme o piso e registra que o regime não foi medido.
_aquecer() {  # piso arquivo
    if [ "$SEM_WARMUP_MEDIDO" = "1" ]; then
        echo "    --sem-warmup-medido: sleep fixo de ${1}s (regime NÃO medido)."
        aguardar "$1"
        echo "{\"status\": \"nao_medido\", \"segundos\": $1}" > "$2"
        return 0
    fi
    aguardar_regime_webui "$1" "$WARMUP_MAX" "$WARMUP_TOL" "$2"
    if [ "$REGIME_STATUS" != "estavel" ]; then
        echo "    AVISO: warmup terminou como '${REGIME_STATUS}' -- registrado em $(basename "$2")."
    fi
}

_verificar_falha() {  # falha fase [timeout]
    python3 "$SELF_DIR/verificar_falha.py" --falha "$1" --exp-base "$EXP_BASE" --namespace "$NAMESPACE" \
        --fase "$2" --timeout "${3:-$VERIFY_TIMEOUT}" --out "$FALHA_DIR/verificacao_${2}.json"
}

# Cenário que não passou na verificação: não coleta (o Stage 3 seria avaliado contra uma falha que não
# está lá, ou com a aplicação fora do ar), desfaz a falha e deixa o marker para o resumo final.
_descartar_cenario() {  # falha motivo
    _pacotes_continuos_fim
    echo "    !!! ${1}: ${2} -- cenário DESCARTADO (não coletado). Ver $(basename "$FALHA_DIR")/verificacao_*.json"
    echo "$2" > "$FALHA_DIR/FALHA_NAO_VERIFICADA"
    stresser_off || true
    rollback_falha_build "$1" || echo "    AVISO: rollback de ${1} falhou."
}

# Pacotes de evidência contínuos da referência e da transição: o
# simulador só grava os do período estável. Coletor em segundo plano, do stresser ligado até logo antes do
# simulador; não grava monitoring_logs nem abre incidente.
PC_PID=""
_pacotes_continuos_inicio() {  # dir
    PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/coletar_pacotes_continuos.py" --system-id "$VERITAS_SYSTEM_ID" \
        --collection-id "$COLLECTION_ID" --package-window "$PACKAGE_WINDOW" --out-dir "$1" \
        > "$1.json" 2> "$1.err" &
    PC_PID=$!
}
_pacotes_continuos_fim() {
    [ -n "$PC_PID" ] || return 0
    kill -TERM "$PC_PID" 2>/dev/null || true
    wait "$PC_PID" 2>/dev/null || true
    PC_PID=""
}

# ── Loop dos cenários ────────────────────────────────────────────────
#
# Retry curto pra chamadas de API depois do stage3: uma falha transitória (port-forward, web
# reiniciando) não pode derrubar o lote inteiro nem deixar a falha injetada aplicada -- achado
# real ao rodar o lote completo (o script morreu no meio do f4-invalid-path e a
# falha ficou aplicada até ser revertida manualmente).
_veritas_api_retry() {
    local method="$1" path="$2" data="$3" attempt
    for attempt in 1 2 3; do
        if _veritas_api "$method" "$path" "$data"; then
            return 0
        fi
        echo "    AVISO: tentativa ${attempt}/3 falhou (method=$method path=$path), nova tentativa em 5s..." >&2
        sleep 5
    done
    return 1
}

CENARIO_IDX=0
for falha in "${FALHAS[@]}"; do
    CENARIO_IDX=$((CENARIO_IDX + 1))
    FALHA_DIR="$RUN_DIR/$falha"
    mkdir -p "$FALHA_DIR/evidence_packages"

    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "  Cenário: ${falha} (início $(date -u +%H:%M:%S))"
    echo "═══════════════════════════════════════════════════════════"

    # Checagem de saúde ANTES de aplicar a falha: o rollback do cenário anterior tem que ter
    # terminado e o registry tem que listar os pods certos (-- contaminação
    # F13->F14). Não bloqueia o lote: o resultado vai para health_pre.json/avaliacao.json.
    python3 "$SELF_DIR/health_gate.py" --out "$FALHA_DIR/health_pre.json" --timeout "${HEALTH_TIMEOUT:-300}" --jaeger "$JAEGER_ENDPOINT" \
        || echo "    AVISO: TeaStore não ficou saudável antes de ${falha} -- caso marcado como contaminado."

    echo "    Ligando stresser (10-20 usuários)..."
    scenario_start=$(date -u +%Y-%m-%dT%H:%M:%S)
    stresser_on
    _pacotes_continuos_inicio "$FALHA_DIR/evidence_packages_continuos"
    # Warmup MEDIDO antes da referência: o rollback do cenário anterior recriou o pod do serviço dele, e
    # a referência tem de descrever o app em regime, não o cold start do vizinho.
    echo "    Warmup pré-referência (app saudável sob carga)..."
    _aquecer "$REF_WARMUP" "$FALHA_DIR/warmup_pre_referencia.json"
    # A referência cobre REF_WINDOW segundos SOB CARGA ESTÁVEL, depois do aquecimento -- o mesmo protocolo da
    # baseline (aquecimento fora da janela). Com a janela ancorada em `agora - REF_WINDOW` logo após ligar o
    # stresser, ela pegava o ocioso anterior (poucas traces); ancorada no instante em que o stresser subiu,
    # ela virava o próprio aquecimento (rampa de carga). O início vai explícito para o coletor.
    carga_inicio=$(date -u +%Y-%m-%dT%H:%M:%S)
    echo "    Janela de referência: ${REF_WINDOW}s sob carga, antes da injeção..."
    aguardar "$REF_WINDOW"

    # Janela de REFERÊNCIA (Etapa F do plano de rastros): app saudável, MESMA carga, coleta logo antes da
    # injeção. O experimento suja o ambiente entre um cenário e outro (F5 deixa -Xmx64m, F11 derruba pods,
    # F14 enche o disco de log) e a baseline global continua descrevendo o ambiente anterior -- então a
    # janela da falha herda a deriva e a localização acusa sintoma onde só mudou o cenário. A referência é
    # a segunda base da localização, junto da global. Falhar aqui não aborta o cenário: segue sem
    # referência e o resultado fica marcado como mais fraco.
    ref_id="ref-${falha}-${RUN_ID}"
    echo "    Coletando a referência (${carga_inicio}Z + ${REF_WINDOW}s, app saudável)..."
    if PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/coletar_referencia.py" \
        --system-id "$VERITAS_SYSTEM_ID" --referencia-id "$ref_id" \
        --janela-inicio "$carga_inicio" --janela-seg "$REF_WINDOW" --jaeger "$JAEGER_ENDPOINT" \
        --out-dir "$FALHA_DIR/referencia" > "$FALHA_DIR/referencia.json" 2>"$FALHA_DIR/referencia.err"; then
        ref_n=$(python3 -c "import json;print(json.load(open('$FALHA_DIR/referencia.json')).get('n_traces',0))" 2>/dev/null || echo 0)
        echo "    Referência ok: ${ref_n} traces em ${ref_id}"
    else
        ref_id=""
        echo "    AVISO: referência de ${falha} não coletou -- cenário segue sem ela (ver ${FALHA_DIR}/referencia.err)."
        cat "$FALHA_DIR/referencia.err" | sed 's/^/      /' | head -5
    fi

    echo "    Aplicando a falha ${falha}..."
    aplicar_falha_build "$falha" || echo "    AVISO: aplicar_falha_build retornou erro -- a verificação decide."
    wait_for_teastore_ready "$falha" || true

    # Teste 1: a falha está no pod que roda, só ela, e o webui responde. Sem isso o cenário não vale.
    if ! _verificar_falha "$falha" pos-implantacao; then
        _descartar_cenario "$falha" "verificação pós-implantação reprovada"
        continue
    fi

    # Warmup MEDIDO sob a falha: a implantação recriou o pod-alvo; a janela só abre com a latência do
    # webui estável no regime da falha (ou no teto, que fica registrado).
    echo "    Warmup pós-implantação (regime sob a falha)..."
    _aquecer "$WARMUP" "$FALHA_DIR/warmup_pos_falha.json"

    # Teste 2: depois do warmup a falha continua lá e a aplicação continua no ar (um rollout tardio, um
    # restart do pod ou um webui que caiu durante o warmup invalidariam a janela).
    if ! _verificar_falha "$falha" pre-coleta 60; then
        _descartar_cenario "$falha" "verificação pré-coleta reprovada"
        continue
    fi

    _pacotes_continuos_fim
    echo "    Pacotes contínuos (referência + transição): $(ls "$FALHA_DIR/evidence_packages_continuos" 2>/dev/null | grep -c '^pkg-' || true)"
    echo "    Coletando ${N_PACOTES} pacotes de evidência reais (janela ${PACKAGE_WINDOW}s cada) e simulando o incidente..."
    sim_extra=()
    [ -n "$ref_id" ] && sim_extra=(--referencia-collection-id "$ref_id")
    sim_resp=$(PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/simular_incidente.py" \
        --system-id "$VERITAS_SYSTEM_ID" --collection-id "$COLLECTION_ID" --falha "$falha" \
        --package-window "$PACKAGE_WINDOW" --n-pacotes "$N_PACOTES" --coleta-seg "$COLETA" \
        --out-dir "$FALHA_DIR/evidence_packages" \
        "${sim_extra[@]}" \
        --run-tag "${RUN_ID}__c${CENARIO_IDX}")
    # Tag por cenario: com uma so por lote o 1o incidente fica ATIVO e o repositorio recusa a duplicata,
    # e os demais cenarios nao abrem (hold-out de 11-12/10). O indice e da ordem embaralhada,
    # entao nao revela a falha (bb4adfa4 tirou o nome da falha da hipotese).
    echo "$sim_resp" > "$FALHA_DIR/simulacao.json"
    scenario_end=$(date -u +%Y-%m-%dT%H:%M:%S)
    stresser_off

    incident_id=$(echo "$sim_resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('incident_id') or '')" 2>/dev/null || true)
    if [ -z "$incident_id" ]; then
        echo "    AVISO: incidente não abriu pra '${falha}' -- ver ${FALHA_DIR}/simulacao.json"
        rollback_falha_build "$falha"
        continue
    fi
    echo "    incident_id=${incident_id}"

    aguardar_stage3_job "$incident_id" "$STAGE3_TIMEOUT" || true
    aguardar_modos "$incident_id" "${MODOS_TIMEOUT:-1800}" || true

    # Subshell: qualquer falha aqui dentro (API, dump de traces, avaliação) não pode matar o
    # script (set -euo pipefail do pai) nem pular o rollback logo abaixo -- só essa etapa de
    # coleta de resultados é perdida pra este cenário, o experimento continua.
    (
        _veritas_api_retry "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}" "" \
            > "$FALHA_DIR/incident.json"
        _veritas_api_retry "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}/stage3" "" \
            > "$FALHA_DIR/stage3_diagnosis.json"
        _veritas_api_retry "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}/stage3/audit" "" \
            > "$FALHA_DIR/stage3_audit_package.json"
        # Modos escolhidos: painel + pacote de auditoria de cada d_k (o ranking completo está no pacote)
        _veritas_api_retry "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}/stage3/modos" "" \
            > "$FALHA_DIR/stage3_modos.json" || true
        for modo in $(python3 -c "import json; print(' '.join(p['modo'] for p in json.load(open('$FALHA_DIR/stage3_modos.json')).get('modos',[]) if p['modo']!='a0'))" 2>/dev/null); do
            mkdir -p "$FALHA_DIR/stage3_modos_audit"
            _veritas_api "GET" "/systems/${VERITAS_SYSTEM_ID}/incidents/${incident_id}/stage3/modos/${modo}/audit" "" \
                > "$FALHA_DIR/stage3_modos_audit/${modo}.json" || true
        done

        # Insumos do replay offline: logs de monitoramento do incidente (+ anteriores), traces na
        # janela EXATA de busca do Stage 3 e os eventos do namespace.
        PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/export_insumos.py" incidente "$incident_id" \
            "$FALHA_DIR/monitoring_logs.json" --system-id "$VERITAS_SYSTEM_ID" \
            || echo "    AVISO: export dos monitoring_logs falhou pra ${falha}."
        q_start=$(python3 -c "import json; q=json.load(open('$FALHA_DIR/stage3_audit_package.json'))['stage3']['traces']['query'] or {}; print(q.get('window_start',''))" 2>/dev/null || true)
        q_end=$(python3 -c "import json; q=json.load(open('$FALHA_DIR/stage3_audit_package.json'))['stage3']['traces']['query'] or {}; print(q.get('window_end',''))" 2>/dev/null || true)
        if [ -n "$q_start" ] && [ -n "$q_end" ]; then
            PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/dump_traces.py" \
                "$JAEGER_ENDPOINT" "$q_start" "$q_end" "$FALHA_DIR/traces_stage3_window.json" \
                || echo "    AVISO: dump da janela do Stage 3 falhou pra ${falha}."
        fi
        kubectl get events -n "$NAMESPACE" -o json > "$FALHA_DIR/k8s_events_cluster.json" 2>/dev/null \
            || echo "    AVISO: dump dos eventos K8s falhou pra ${falha}."

        window_start=$(python3 -c "import json; d=json.load(open('$FALHA_DIR/incident.json')); print((d.get('incident') or d).get('window_start') or '')" 2>/dev/null || true)
        window_end=$(python3 -c "import json; d=json.load(open('$FALHA_DIR/incident.json')); print((d.get('incident') or d).get('window_end') or '')" 2>/dev/null || true)
        if [ -n "$window_start" ] && [ -n "$window_end" ]; then
            PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/dump_traces.py" \
                "$JAEGER_ENDPOINT" "$window_start" "$window_end" "$FALHA_DIR/traces.json" \
                || echo "    AVISO: dump de traces falhou pra ${falha}."
        else
            echo "    AVISO: sem window_start/window_end no incidente -- traces não coletados."
        fi
        # Traces do cenário inteiro (stresser ligado até desligado, não só a janela estreita que o
        # Stage 3 usou) -- material bruto extra pra segunda rodada de análise (ex.: testar se um
        # lookback_sec diferente teria achado algo que o efetivo não achou).
        PYTHONPATH="$REPO_ROOT" python3 "$SELF_DIR/dump_traces.py" \
            "$JAEGER_ENDPOINT" "$scenario_start" "$scenario_end" "$FALHA_DIR/traces_full_scenario.json" \
            || echo "    AVISO: dump de traces do cenário inteiro falhou pra ${falha}."

# O `|| AVISO` acima so pega falha do processo. O dump_traces.py tambem "succede"
# gravando 0 traces (stresser desligado, janela errada, OTLP sem spans), e ai o
# cenario terminaria sem material de replay sem ninguem notar. Com BADGER_SPAN_STORE_TTL=6h
# a perda e definitiva: marca o caso e o resumo final cobra.
python3 - "$FALHA_DIR" <<'PYTRACE' || echo "    AVISO: conferencia de traces falhou para ${falha}."
import json, os, sys
d = sys.argv[1]
faltando = []
for nome in ("traces_stage3_window.json", "traces.json", "traces_full_scenario.json"):
    p = os.path.join(d, nome)
    if not os.path.exists(p):
        faltando.append(nome + "=ausente")
        continue
    try:
        n = json.load(open(p)).get("n_traces")
    except Exception as exc:
        faltando.append(nome + "=ilegivel(" + str(exc) + ")")
        continue
    if not n:
        faltando.append(nome + "=0")
if faltando:
    with open(os.path.join(d, "TRACES_AUSENTES"), "w") as fh:
        fh.write(" ".join(faltando) + "\n")
    print("    TRACES AUSENTES:", " ".join(faltando))
PYTRACE

        # Avaliação automática: bate o suspeito apontado contra o serviço onde a falha foi injetada de
        # verdade (mapeamento real de _falha_to_service, não uma suposição) -- plano de melhoria P7
        # (métrica de acurácia), usando o ground truth que este próprio script já conhece.
        expected_service="teastore-$(_falha_to_service "$falha")"
        python3 "$SELF_DIR/avaliar_caso.py" "$FALHA_DIR" "$falha" "$expected_service" "$RUN_DIR/baseline.json" \
            || echo "    AVISO: avaliação automática falhou pra ${falha}."
        python3 "$SELF_DIR/avaliar_modos.py" caso "$FALHA_DIR" "$expected_service" \
            || echo "    AVISO: avaliação dos modos falhou pra ${falha}."
    ) || echo "    AVISO: coleta/avaliação do incidente ${incident_id} (${falha}) teve erro -- revertendo a falha mesmo assim."

    rollback_falha_build "$falha"
    echo "  ${falha} concluído: $(date -u +%H:%M:%S)"
done

echo ""
python3 "$SELF_DIR/health_gate.py" --out "$RUN_DIR/health_final.json" --timeout "${HEALTH_TIMEOUT:-300}" --jaeger "$JAEGER_ENDPOINT" \
    || echo "    AVISO: TeaStore não ficou saudável depois do último cenário."
python3 "$SELF_DIR/avaliar_lote.py" "$RUN_DIR" || echo "    AVISO: resumo do lote falhou."
# a cobertura de janelas é conferida por caso (tempo sem evidência e maior lacuna). A coleta
# ancorava cada janela em "agora", depois de esperar o trabalho anterior, e perdia ~32% da linha do
# tempo — ausência de sinal que o relatório lia como "a falha não se manifestou". simular_incidente.py
# agora ancora as janelas numa grade de relógio, então são contíguas por construção; o piso do
# checker subiu para 0,95 (aceite da Etapa F do plano de rastros).
python3 "$SELF_DIR/checar_pacotes.py" "$RUN_DIR" || echo "    AVISO: cobertura de coleta abaixo do mínimo (§6)."

# Resumo de traces: TTL de 6h no Badger nao da segunda chance a um cenario sem dump.
sem_traces=$(find "$RUN_DIR" -mindepth 2 -maxdepth 2 -name TRACES_AUSENTES 2>/dev/null | sort)
if [ -n "$sem_traces" ]; then
    echo ""
    echo "  !!! $(echo "$sem_traces" | wc -l) cenario(s) SEM material de trace (marker TRACES_AUSENTES):"
    while read -r m; do
        echo "      $(basename "$(dirname "$m")"): $(tr "\n" " " < "$m")"
    done <<< "$sem_traces"
    echo "      O replay offline e o ranking nao sao reproduziveis para esses casos."
else
    echo "  Todos os cenarios tem material de trace para o replay."
fi

# Resumo da verificação e dos warmups: cenário descartado não entra no denominador; warmup que não
# estabilizou entra, mas a janela dele pode ter rampa e isso tem de estar escrito.
python3 - "$RUN_DIR" "${FALHAS[@]}" <<'PYRES' | tee "$RUN_DIR/resumo_verificacao.txt" || echo "    AVISO: resumo da verificação falhou."
import json, os, sys
run_dir, falhas = sys.argv[1], sys.argv[2:]
def ler(caminho):
    try:
        return json.load(open(caminho))
    except (OSError, json.JSONDecodeError):
        return {}
print("")
print("  Cenário               | verificação | warmup pré-ref        | warmup pós-falha")
print("  ----------------------+-------------+-----------------------+----------------------")
descartados, instaveis = [], []
for f in falhas:
    d = os.path.join(run_dir, f)
    if os.path.exists(os.path.join(d, "FALHA_NAO_VERIFICADA")):
        verif = "DESCARTADO"
        descartados.append(f)
    elif ler(os.path.join(d, "verificacao_pre-coleta.json")).get("ok"):
        verif = "ok"
    else:
        verif = "?"
    cols = []
    for nome in ("warmup_pre_referencia.json", "warmup_pos_falha.json"):
        w = ler(os.path.join(d, nome))
        if not w:
            cols.append("-")
            continue
        cols.append(f"{w.get('status')} {w.get('segundos')}s {w.get('mediana_ms') or '-'}ms")
        if w.get("status") != "estavel":
            instaveis.append(f"{f}/{nome}={w.get('status')}")
    print(f"  {f:21s} | {verif:11s} | {cols[0]:21s} | {cols[1]}")
print("")
if descartados:
    print(f"  !!! {len(descartados)} cenário(s) DESCARTADO(S) (falha não verificada): {', '.join(descartados)}")
if instaveis:
    print(f"  !!! warmup sem regime estável (janela pode ter rampa): {', '.join(instaveis)}")
if not descartados and not instaveis:
    print("  Todos os cenários verificados e com warmup estável.")
PYRES
echo ">>> Rodada ${RUN_ID} concluída. Resultados em: ${RUN_DIR}"
