# Protocolo rápido — avaliação comum do Stage 3 numa base única

Registrado em 2026-10-14 (ARQ), **antes** de rodar qualquer etapa. Opção A da §42.65+ do `session.md`: os 54 cenários,
resultados que usam os g marcados como **exploratórios** (os g já foram abertos para os pais; para os filhos e para a
pergunta de localização com oráculo, esta é a primeira leitura).

## 1. Objetivos

1. **Validar os protocolos já criados numa base única**: os mesmos 54 cenários, a mesma pergunta e o mesmo critério para
   a0, d1–d9 e os 8 filhos; conferir que a amostragem reduzida reproduz os números já publicados.
2. **Validar se os filhos tiveram sucesso** contra o seu pai.
3. **Validar o viés da a0**: o acerto vem da falha ou do rastro da injeção (reinício do pod alvo, eventos K8s)?
4. Separar **detecção** (portão) de **localização** (ranking), e medir o melhor par portão + localizador.

## 2. Base

- **Cenários**: 54 = 36 de dev (f, h; runs `20260926T203024Z`, `20260927T051757Z`, `20261012T072332Z`,
  `20261012T193519Z`, `20261013T051436Z`) + 18 g (`20261012T213402Z`, `20261013T061915Z`, `20261013T143247Z`).
  Nenhum cenário é cortado.
- **Gabarito**: `metricas_instantes.esperado` (pela causa: f3/f7/f8 → `teastore-db`).
- **Instantes (formato rápido)**: 5 normais + 5 estáveis por cenário, um a cada 60 s (os de 15 s já gravados são
  subamostrados de 4 em 4; o que for recalculado usa `--passo 60`). Janela de 120 s, referência travada no pré-falha
  nos estáveis (como §42.63).
- **Parâmetros**: só o final de cada modo, sem grade — a0 `k=3`; d1 `L=1e-10`; d1c `L=1e-200`; d2 `L=1e-20`;
  d2c `L=1e-50`; d3 `fp=0.2`; d4/d4c `L=1e-05`; d5 `L=1.5,E=0.05,D=off,R=150`; d6 `L=1e-50|a=1`; d7 `L=1e-20|s=0.5`;
  d8 `L=1.2,E=0.1,D=1.2,R=150|d6a=1`; d9 `L=1.5,E=0.1,D=off,R=150|residuo_1`; filhos com os de partida (§42.63 (d)).
- **a0 nos 54**: sem métricas de recurso (a ablação §42.62 mostrou que não mudam o acerto), com pacotes montados no
  replay a cada 3 s quando o cenário não tem `evidence_packages_continuos`. Antes, a montagem é validada contra os
  pacotes reais nos 13 cenários que os têm (critério E1).

## 3. Perguntas e métricas

- **L — Localização com oráculo** ("sabemos que há anomalia"): portão desligado; em cada instante estável o modo
  devolve o ranking. Métricas: acerto@1 e acerto@3 por cenário (média dos 5 instantes), resumidas por f, h, g e total.
  **Decisão forçada** (como se desliga o portão, fixado antes de rodar): o modo roda com o parâmetro final; se
  decidir, vale o seu ranking; se abstiver, roda de novo com a versão mais permissiva do **mesmo** modo e vale esse
  ranking. Permissivo: d1–d7 → o registro com `q` do fp 0,20 (já gravado, sempre decide); d2c, d6, d6-k, d6-u,
  d2c-r → `q = 1`; d5, d9, d9-2h, d9+m → `limiar = 1`, `limiar_erro = 0`, dano off, `min_traces = 0`;
  d2c-cp → `limiar_efeito = 1`, `min_eventos = 1`; a0-k, a0-d → `alpha = 1`; a0 → já decide sempre.
  Ranking vazio mesmo assim = erro (o modo não tem evidência). d8 sob oráculo = d6 (mesmo localizador) e d8-a0 = a0;
  não são medidos à parte.
- **D — Detecção**: com o portão de cada modo, alarme nos normais e fração dos estáveis com decisão; atraso até a
  primeira decisão após a transição.
- **F1@1 por instante** (métrica atual) recalculada na mesma base, para continuidade.
- **Estatística**: IC 95% por bootstrap **por tipo de falha** (26 tipos; repetições do mesmo tipo não são
  independentes). Comparação de dois modos pareada por cenário: McNemar no acerto@1 majoritário do cenário e
  Wilcoxon no acerto@1 contínuo. Diferenças < ~20 p.p. não são detectáveis com 54 cenários — não serão afirmadas.

## 4. Critérios fixados antes

- **E1 (montagem dos pacotes da a0)**: nos 13 cenários com pacotes reais, a a0 sem métricas com pacotes montados
  difere da a0 sem métricas com pacotes reais em ≤ 1 cenário no acerto@1 majoritário. Se falhar, a a0 fica só nos 13.
- **E2 (amostragem reduzida)**: em todos os modos já gravados, F1@1 e acerto@1 com 5 instantes ficam a ≤ 0,03 / ≤ 5 p.p.
  dos de 20 instantes, e ≤ 1 cenário muda o acerto@1 majoritário. Se falhar, volta para 20 instantes.
- **E3 (reprodução)**: os números de dev já publicados (d9 0,594; d2c 0,316; filhos §42.63 (d)) se reproduzem com 20
  instantes; a divergência d2c 0,256 (CV) × 0,316 (L fixo) é explicada.
- **S (sucesso de um filho)**: acerto@1 com oráculo **maior que o do pai** nos 54 (McNemar p < 0,05) **ou** F1@1 maior
  que o do pai sem piorar o alarme nos normais em mais de 5 p.p. Pais: a0-k/a0-d → a0; d2c-r/d2c-cp → d2c;
  d6-k/d6-u → d6; d9-2h/d9+m → d9. Com p ≥ 0,05: "sem evidência de ganho", não "fracasso".
- **V (viés da a0)** — a a0 é considerada dependente do rastro da injeção se **qualquer** um valer:
  - V1: acerto@1 nos primeiros 120 s após a injeção (início da transição) supera o do período estável em ≥ 30 p.p.
    (dados de 15 s já gravados, 12 g). *Ajuste antes de ver dado*: o inventário mostrou que o estável começa
    341–1596 s após a injeção (a transição vem antes), então "primeiros 60 s do estável" não mede o rastro do
    reinício; a comparação passa a ser transição inicial × estável. Complemento: a curva acerto@1 × tempo;
  - V2: um baseline ingênuo com a mesma entrada fica a ≤ 10 p.p. da a0 no acerto@1 com oráculo — (b1) serviço com
    mais spans de erro na janela; (b2) primeiro serviço com evento K8s na janela; (b3) alvo mais frequente do
    conjunto (constante);
  - V3: nos f (falhas de aplicação, sem reinício do alvo), o acerto@1 da a0 fica ≥ 20 p.p. abaixo do dos g.
  V3 sozinho indica dependência do tipo de falha, não necessariamente rastro; o relatório separa os dois.

## 5. Ordem de execução (minutos estimados)

| # | etapa | código | máquina | depende de |
|---|---|---|---|---|
| 0 | Registrar este protocolo (commit antes de rodar) | 15 | — | — |
| 1 | Inventário dos 54: períodos, gabarito, quais têm pacotes contínuos, traces e eventos K8s | 10 | 2 | 0 |
| 2 | E2 e E3 sobre o que já está gravado (subamostrar 15 s → 60 s; reproduzir dev) | 15 | 3 | 1 |
| 3 | V1 (acerto por tempo desde a injeção, a0 nos 12 g, dados gravados) | 10 | 1 | 1 |
| 4 | Pacotes montados para a a0 + E1 nos 13 cenários com pacotes reais | 30 | 10 | 1 |
| 5 | a0 sem métricas, k=3, nos 54 (`--passo 60`) — em segundo plano | 5 | 20 | 4 (E1 ok) |
| 6 | Oráculo: portão desligado em d1–d9 e filhos; rodar nos 54 com `--passo 60` — em paralelo à 5 | 40 | 30 | 2 |
| 7 | Baselines ingênuos b1–b3 (V2) nos mesmos instantes | 20 | 5 | 1 |
| 8 | Detecção (D) e pares portão + localizador, a partir de 5 e 6 | 20 | 2 | 5, 6 |
| 9 | Tabela única, testes pareados, IC por tipo, veredictos S e V | 30 | 2 | 5–8 |
| 10 | Registro no `session.md` e commit/push | 15 | — | 9 |

Total ≈ 3 h 30 de relógio (≈ 3 h 30 de código/análise; ≈ 75 min de máquina, a maior parte em paralelo).
As etapas 2, 3 e 7 usam só dados gravados e respondem cedo às perguntas E2/E3 e V1.

## 6. Saída

`experimento-falhas/teastore/stage3-online/resultados/protocolo-rapido/` (`inventario.json`, `*.jsonl.gz`,
`resumo.md`). Resultados com g sempre rotulados "exploratório".
