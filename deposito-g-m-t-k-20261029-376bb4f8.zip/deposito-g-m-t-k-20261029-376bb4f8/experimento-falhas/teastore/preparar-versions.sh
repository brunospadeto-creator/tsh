#!/usr/bin/env bash
# preparar-versions.sh — Estrutura de releases (CI/CD realista) no fork TeaStore do Gitea.
#
# Transforma cada falha em um release real do repositório:
#   - master            → baseline limpo (código sem falha)
#   - release/fN        → branch por falha com 1 commit contendo o bug no código
#   - exp-v1.0.0        → tag do baseline
#   - exp-v1.0.0-fN     → tag de cada release de falha
#
# Idempotente: commits usam data fixa (baseline) → mesmo SHA em re-execuções.
# Uso: ./preparar-versions.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GITEA_USER="${GITEA_USER:-veritas}"
GITEA_TOKEN="${TEASTORE_GITEA_TOKEN:?defina TEASTORE_GITEA_TOKEN (token do Gitea; nao versionar)}"
APP_REPO_URL="${TEASTORE_APP_REPO:-http://localhost:3000/descartesresearch/TeaStore.git}"
PUSH_URL="http://${GITEA_USER}:${GITEA_TOKEN}@localhost:3000/descartesresearch/TeaStore.git"
WORK_DIR="${TEATRE_STORE_WORK_DIR:-/tmp/teastore-versions}"
PATCHES_DIR="${TEATRE_STORE_PATCHES_DIR:-/tmp/teastore-config/patches}"
BASELINE_COMMIT="${TEASTORE_COMMIT:-$(cat "$SCRIPT_DIR/../TEASTORE_COMMIT" 2>/dev/null || echo master)}"

# falha -> (patch canônico, mensagem de release)
declare -A CANONIC_OF=(
  [f1]="f1-latency" [f2]="f2-jvm-memory" [f3]="f3-sql-degradation"
  [f4]="f4-invalid-path" [f5]="f5-jvm-heap" [f6]="f6-db-connectivity"
  [f7]="f7-pool-contention" [f8]="f8-missing-table"
  [f9]="f9-incompat-version" [f10]="f10-cpu-contention"
)
declare -A MSG_OF=(
  [f1]="release(f1): latency — CategoryServlet loop O(n^2)"
  [f2]="release(f2): memory — ProductServlet ConcurrentHashMap leak"
  [f3]="release(f3): sql — ProductRepository getAllEntities sleep 5s"
  [f4]="release(f4): path — Dockerfile catalog path inválido"
  [f5]="release(f5): heap — Dockerfile _JAVA_OPTIONS Xms16m Xmx64m"
  [f6]="release(f6): db — persistence.xml JDBC host inexistente"
  [f7]="release(f7): pool — ProductRepository sleep 3s contention"
  [f8]="release(f8): table — PersistenceProduct tabela _F8"
  [f9]="release(f9): version — RegistryREST resposta v2"
  [f10]="release(f10): cpu — ProductRepository ThreadPoolExecutor 100/200"
)

# ── preparar clone de trabalho (self-healing após reboot) ────────────
echo "=== [preparar-versions] clone em $WORK_DIR ==="
if [[ -d "$WORK_DIR/.git" ]]; then
    cd "$WORK_DIR"
    git remote set-url origin "$APP_REPO_URL" 2>/dev/null || true
    git remote set-url --push origin "$PUSH_URL" 2>/dev/null || true
    git fetch origin --tags --prune 2>&1 | tail -1 || true
else
    rm -rf "$WORK_DIR"
    git clone "$APP_REPO_URL" "$WORK_DIR"
    cd "$WORK_DIR"
    git remote set-url --push origin "$PUSH_URL" 2>/dev/null || true
fi
git config user.name  >/dev/null 2>&1 || git config user.name  "veritas"
git config user.email >/dev/null 2>&1 || git config user.email "veritas@localhost"

[[ -d "$PATCHES_DIR" ]] || { echo "ERRO: patches nao encontrados em $PATCHES_DIR"; exit 1; }

# ── baseline ─────────────────────────────────────────────────────────
BASELINE_SHA="$(git rev-parse --verify "${BASELINE_COMMIT}^{commit}" 2>/dev/null || git rev-parse origin/master)"
echo "Baseline commit: $BASELINE_SHA"
BASE_DATE="$(git log -1 --format=%cI "$BASELINE_SHA")"
echo "Baseline date (usada p/ commits determinísticos): $BASE_DATE"

echo ""
echo "=== tag exp-v1.0.0 → $BASELINE_SHA ==="
git tag exp-v1.0.0 "$BASELINE_SHA" 2>/dev/null && git push origin exp-v1.0.0 2>&1 | tail -1 || \
    echo "(tag exp-v1.0.0 já existe)"

# ── uma branch + commit + tag por falha ──────────────────────────────
for F in f1 f2 f3 f4 f5 f6 f7 f8 f9 f10; do
    CANONIC="${CANONIC_OF[$F]}"
    PATCH="$PATCHES_DIR/${CANONIC}.patch"
    BRANCH="release/${F}"
    TAG="exp-v1.0.0-${F}"
    MSG="${MSG_OF[$F]}"

    [[ -f "$PATCH" ]] || { echo "AVISO: patch nao encontrado ($PATCH), pulando $F"; continue; }

    echo ""
    echo "=== $F: branch $BRANCH + tag $TAG (patch=$CANONIC) ==="

    # branch a partir do baseline (sempre limpa)
    git checkout -q -B "$BRANCH" "$BASELINE_SHA"
    git reset -q --hard "$BASELINE_SHA"
    git clean -fdq

    # aplica o bug
    if ! git apply "$PATCH" 2>/dev/null; then
        echo "    ERRO: git apply falhou para $PATCH"
        exit 1
    fi

    git add -A
    if git diff --cached --quiet; then
        echo "    (sem diff nesse baseline para $F — nada a commitar)"
        continue
    fi

    # commit com data fixa → determinístico
    GIT_AUTHOR_DATE="$BASE_DATE" GIT_COMMITTER_DATE="$BASE_DATE" \
        git commit -q -m "$MSG"

    NEW_SHA="$(git rev-parse HEAD)"
    echo "    commit=$(git rev-parse --short HEAD) ($MSG)"

    if git rev-parse -q --verify "refs/tags/$TAG" >/dev/null && \
       [[ "$(git rev-parse "refs/tags/$TAG")" == "$NEW_SHA" ]]; then
        echo "    (tag $TAG já existe apontando para o mesmo commit)"
    else
        git tag "$TAG" HEAD
        git push origin "$TAG" 2>&1 | tail -1 || true
    fi
    git push origin "$BRANCH" 2>&1 | tail -1 || true
done

git checkout -q master 2>/dev/null || git checkout -q main 2>/dev/null || true

echo ""
echo "=== [preparar-versions] concluído ==="
git ls-remote origin 2>/dev/null | grep -E "refs/tags/exp-|refs/heads/release/" || true